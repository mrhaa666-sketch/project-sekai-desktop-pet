// 唱歌窗口：只暴露这个窗口需要的接口（密钥不会传到页面）
const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('singAPI', {
  config: () => ipcRenderer.invoke('sing-config'),
  prepare: (p) => ipcRenderer.invoke('sing-prepare', p),
  voice: (p) => ipcRenderer.invoke('sing-voice', p),
  listen: (p) => ipcRenderer.invoke('sing-listen', p),
  cancel: (id) => ipcRenderer.send('sing-cancel', id),
  onProgress: (cb) => ipcRenderer.on('sing-progress', (_e, v) => cb(v)),
  onPrefill: (cb) => ipcRenderer.on('sing-prefill', (_e, v) => cb(v)),
  save: (v) => ipcRenderer.invoke('sing-save', v),
  exportSong: (v) => ipcRenderer.invoke('sing-export', v),
  toPet: (v) => ipcRenderer.invoke('sing-to-pet', v),
  stopPet: () => ipcRenderer.send('sing-stop-pet'),
  done: (v) => ipcRenderer.send('sing-done', v),
  openSettings: () => ipcRenderer.send('sing-open-settings'),
});
