'use strict';
/* 未来唱歌用的声音处理（纯计算，不联网；浏览器的后台线程和 Node 测试里都能用）
 *
 * 做法（类似 UTAU 的“逐音拼接”）：
 *  1. 用你在 MiniMax 复刻的音色，把一行歌词按“一个音一个音、中间停顿”念出来（停顿用官方的 <#秒数#> 标记）；
 *  2. segment()   按静音把这一行切成每个音；
 *  3. estimateF0() 估计每个音原本的音高；
 *  4. psola()     用 TD-PSOLA 把每个音变到旋律要求的音高和长度（辅音不拉长，只拉长元音），加颤音和滑音；
 *  5. renderSong() 按节拍排好；有导入的曲子时对齐到曲子的小节上，和曲子混在一起（不合成任何乐器）。
 * 唱出来的是“你复刻的音色”，听感接近 VOCALOID / UTAU，不会像真人演唱那样自然。
 */
(function (root) {
  const clamp = (x, a, b) => Math.max(a, Math.min(b, x));
  const midiHz = (m) => 440 * Math.pow(2, (m - 69) / 12);
  const hzMidi = (f) => 69 + 12 * Math.log2(f / 440);

  /* ---------- 歌词切成一个个音 ---------- */
  const SMALL = 'ぁぃぅぇぉゃゅょゎァィゥェォャュョヮ';
  const isKana = (c) => /[぀-ヿ]/.test(c);
  const isHan = (c) => /[㐀-鿿豈-﫿]/.test(c);
  // 日语按“拍”（小写假名并到前一个音；っ、ー 也算一拍），中文一个字一个音；英文单词一个音
  function syllabify(line) {
    // 手动分音：歌词里用 / 隔开时，按 / 和空格切（比如“だ/れ/も”“夜/空”）
    if (/\//.test(String(line || ''))) return String(line).split(/[\/\s　]+/).map((x) => x.replace(/[、。，,.!！?？「」『』（）()…]/g, '')).filter(Boolean);
    const out = [];
    const s = String(line || '').replace(/[\s　、。，,.!！?？「」『』（）()…・~～\-—]+/g, ' ').trim();
    let word = '';
    const flush = () => { if (word) { out.push(word); word = ''; } };
    for (const c of s) {
      if (c === ' ') { flush(); continue; }
      if (/[A-Za-z']/.test(c)) { word += c; continue; }
      flush();
      if (SMALL.includes(c) && out.length && isKana(out[out.length - 1].slice(-1))) { out[out.length - 1] += c; continue; }
      if (isKana(c) || isHan(c) || /[0-9]/.test(c)) out.push(c);
    }
    flush();
    return out;
  }
  const hasKanjiWithKana = (line) => /[぀-ヿ]/.test(line) && /[㐀-鿿]/.test(line);

  /* ---------- 简谱：旋律的文字接口 ----------
   * 一行歌词对应一行简谱，音之间用空格隔开：
   *   1–7 唱名（1 = 主音，按大调音阶），0 = 休止（不占歌词）
   *   前面加 # / b：升半音 / 降半音；后面加 ' 或 ·：高八度（可叠加）；加 , ：低八度（可叠加）
   *   时值：默认 1 拍；每个 _ 减半；每个 - 加 1 拍；. 变成 1.5 倍
   *   例：1 2 3_ 5_ 6- 0 5'.
   */
  const DEG = [0, 2, 4, 5, 7, 9, 11];
  function parseJianpu(text) {
    const notes = [], errors = [];
    for (const tok of String(text || '').trim().split(/\s+/).filter(Boolean)) {
      const m = /^([#b]?)([0-7])(['·’,，]*)([_\-.]*)$/.exec(tok);
      if (!m) { errors.push(`看不懂“${tok}”`); continue; }
      let beats = 1;
      for (const c of m[4]) { if (c === '_') beats /= 2; else if (c === '-') beats += 1; }
      if (m[4].includes('.')) beats *= 1.5;
      if (m[2] === '0') { notes.push([null, beats]); continue; }
      let semi = DEG[+m[2] - 1] + (m[1] === '#' ? 1 : m[1] === 'b' ? -1 : 0);
      for (const c of m[3]) semi += c === ',' || c === '，' ? -12 : 12;
      notes.push([semi, beats]);
    }
    return { notes, errors };
  }
  function toJianpu(notes) {
    return notes.map(([semi, beats]) => {
      let s;
      if (semi == null) s = '0';
      else {
        const o = Math.floor(semi / 12), pc = ((semi % 12) + 12) % 12;
        // 黑键按常见写法：b3、b6、b7（小调常用），#1、#4
        const name = { 1: '#1', 3: 'b3', 6: '#4', 8: 'b6', 10: 'b7' }[pc] || String(DEG.indexOf(pc) + 1);
        s = name + (o > 0 ? "'".repeat(o) : ','.repeat(-o));
      }
      if (beats === 1.5) return s + '.';
      if (beats >= 1) return s + '-'.repeat(Math.round(beats) - 1) + (beats % 1 === 0.5 ? '_' : '');
      let b = beats, u = '';
      while (b < 1 - 1e-6 && u.length < 4) { b *= 2; u += '_'; }
      return s + u;
    }).join(' ');
  }
  const sungCount = (notes) => notes.filter((n) => n[0] != null).length;

  /* ---------- 没有聊天模型时的本地旋律 ---------- */
  function rng(seed) { let s = (seed >>> 0) || 1; return () => { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; }; }
  const MAJOR = [0, 2, 4, 5, 7, 9, 11], MINOR = [0, 2, 3, 5, 7, 8, 10];
  // counts：每行有几个音。返回每行的 [半音偏移, 拍数] 列表；相同长度的行重复同一个旋律型，听起来像一首歌
  function localMelody(counts, { seed = 7, minor = false } = {}) {
    const R = rng(seed), scale = minor ? MINOR : MAJOR;
    const deg = (d) => { const o = Math.floor(d / 7); return scale[((d % 7) + 7) % 7] + 12 * o; };
    const memo = new Map();
    return counts.map((n, li) => {
      const key = n + ':' + (li % 4 === 3 ? 'end' : 'mid');
      if (memo.has(key) && R() < 0.7) return memo.get(key).map((x) => x.slice());
      const notes = [];
      let d = li % 2 ? 4 : 2;            // 从 3 度或 5 度附近开始
      const peak = Math.floor(n * (0.4 + R() * 0.3));
      for (let i = 0; i < n; i++) {
        const last = i === n - 1;
        if (last) d = li % 4 === 3 ? 0 : (R() < 0.5 ? 4 : 2);     // 段落最后一行回到主音
        else if (i < peak) d += R() < 0.7 ? 1 : (R() < 0.5 ? 0 : 2);
        else d -= R() < 0.7 ? 1 : (R() < 0.5 ? 0 : -1);
        d = clamp(d, -2, 9);
        const beats = last ? 2 : (R() < 0.75 ? 0.5 : 1);
        notes.push([deg(d), beats]);
      }
      memo.set(key, notes);
      return notes;
    });
  }

  /* ---------- 切分：按静音把一行念白切成 n 个音 ---------- */
  function segment(x, sr, n) {
    const hop = Math.round(sr * 0.01), frames = Math.floor(x.length / hop);
    const rms = new Float32Array(frames);
    for (let f = 0; f < frames; f++) { let s = 0; for (let i = f * hop; i < (f + 1) * hop; i++) s += x[i] * x[i]; rms[f] = Math.sqrt(s / hop); }
    const peak = Math.max(1e-6, ...rms);
    const thr = Math.max(peak * 0.04, 1e-4);
    let regs = [];
    let start = -1;
    for (let f = 0; f <= frames; f++) {
      const on = f < frames && rms[f] > thr;
      if (on && start < 0) start = f;
      if (!on && start >= 0) { regs.push([start, f]); start = -1; }
    }
    // 很短的间隙（<60ms，多半是辅音前的闭塞）并回去；很短的碎片（<30ms）丢掉
    regs = regs.reduce((a, r) => { if (a.length && r[0] - a[a.length - 1][1] < 6) a[a.length - 1][1] = r[1]; else a.push(r); return a; }, []).filter((r) => r[1] - r[0] >= 3);
    if (!regs.length) return [];
    // 多了：合并间隙最小的两段；少了：把最长的一段在能量最低处切开
    while (regs.length > n && regs.length > 1) {
      let k = 0, g = Infinity;
      for (let i = 0; i < regs.length - 1; i++) { const gap = regs[i + 1][0] - regs[i][1]; if (gap < g) { g = gap; k = i; } }
      regs.splice(k, 2, [regs[k][0], regs[k + 1][1]]);
    }
    while (regs.length < n) {
      let k = 0;
      for (let i = 1; i < regs.length; i++) if (regs[i][1] - regs[i][0] > regs[k][1] - regs[k][0]) k = i;
      const [a, b] = regs[k];
      if (b - a < 8) break;
      let m = a + Math.floor((b - a) / 2), mv = Infinity;
      for (let f = a + 3; f < b - 3; f++) if (rms[f] < mv) { mv = rms[f]; m = f; }
      regs.splice(k, 1, [a, m], [m, b]);
    }
    return regs.map(([a, b]) => ({ s: Math.max(0, a * hop - Math.round(sr * 0.005)), e: Math.min(x.length, b * hop + Math.round(sr * 0.01)) }));
  }

  /* ---------- 音高估计（归一化自相关），返回每 10ms 一个值，0 = 无声/清音 ---------- */
  function f0Track(x, sr, s = 0, e = x.length) {
    const hop = Math.round(sr * 0.01), win = Math.round(sr * 0.03);
    const minL = Math.floor(sr / 700), maxL = Math.ceil(sr / 70);
    const out = [];
    for (let p = s; p + win + maxL < e; p += hop) {
      let e0 = 0; for (let i = 0; i < win; i++) e0 += x[p + i] * x[p + i];
      if (e0 / win < 1e-6) { out.push(0); continue; }
      const rs = new Float32Array(maxL + 1);
      let best = 0;
      for (let L = minL; L <= maxL; L++) {
        let c = 0, e1 = 0;
        for (let i = 0; i < win; i++) { c += x[p + i] * x[p + i + L]; e1 += x[p + i + L] * x[p + i + L]; }
        rs[L] = c / Math.sqrt(e0 * e1 + 1e-12);
        if (rs[L] > best) best = rs[L];
      }
      // 周期的整数倍处相关也很高：取第一个接近最大值的局部峰（避免把音高估低一个或几个八度）
      let bl = 0;
      for (let L = minL + 1; L < maxL; L++) if (rs[L] >= best * 0.92 && rs[L] >= rs[L - 1] && rs[L] >= rs[L + 1]) { bl = L; break; }
      if (bl) { const a = rs[bl - 1], b = rs[bl], c2 = rs[bl + 1], den = a - 2 * b + c2; if (den < 0) bl += 0.5 * (a - c2) / den; }
      out.push(best > 0.6 && bl ? sr / bl : 0);
    }
    return out;
  }
  function estimateF0(x, sr, s = 0, e = x.length) {
    const t = f0Track(x, sr, s, e).filter((v) => v > 0).sort((a, b) => a - b);
    return t.length >= 2 ? t[Math.floor(t.length / 2)] : 0;
  }

  /* ---------- TD-PSOLA：把一个音变到目标音高和长度 ---------- */
  // seg：这个音的采样；f0：原本的音高（Hz，0 时按 200Hz 处理）；target(t)：第 t 秒的目标音高（Hz）；dur：目标长度（秒）
  function psola(seg, sr, f0, target, dur) {
    const L = seg.length, D = Math.max(1, Math.round(dur * sr));
    const P0 = Math.round(sr / (f0 > 0 ? f0 : 200));
    // 分析标记：从能量最大的位置附近开始，按原周期往两边排
    // 分析标记对准每个周期的峰（声门脉冲附近），这样每个片段里只有一个脉冲，降调时才不会留下原来的音高
    const marks = [];
    const peakNear = (c, r) => { let b = c, v = -1; for (let i = Math.max(0, c - r); i <= Math.min(L - 1, c + r); i++) if (Math.abs(seg[i]) > v) { v = Math.abs(seg[i]); b = i; } return b; };
    let m = peakNear(Math.floor(P0 / 2), Math.floor(P0 / 2));
    while (m < L - 1) { marks.push(m); const nx = peakNear(m + P0, Math.floor(P0 / 4)); m = nx > m + P0 / 2 ? nx : m + P0; }
    if (!marks.length) marks.push(Math.floor(L / 2));
    // 时间对应：辅音（开头到稳定发声）不拉长，中段拉长，结尾原速
    const tr = f0Track(seg, sr);
    let firstVoiced = tr.findIndex((v) => v > 0);
    const c = clamp((firstVoiced < 0 ? 0 : firstVoiced) * 0.01 * sr + 0.02 * sr, 0, L * 0.4);
    const tail = Math.min(L * 0.15, 0.06 * sr);
    const warp = (to) => {
      if (D <= L) return to * L / D;                       // 比原来短：整体压缩
      if (to < c) return to;
      if (to > D - tail) return L - tail + (to - (D - tail));
      return c + (to - c) * (L - tail - c) / Math.max(1, D - tail - c);
    };
    const out = new Float32Array(D + 2 * P0), wsum = new Float32Array(D + 2 * P0);
    const W = 2 * P0, han = new Float32Array(W);
    for (let i = 0; i < W; i++) han[i] = 0.5 - 0.5 * Math.cos(2 * Math.PI * (i + 0.5) / W);
    let to = 0;
    while (to < D) {
      const ti = warp(to);
      // 最近的分析标记
      let k = Math.round((ti - marks[0]) / P0); k = clamp(k, 0, marks.length - 1);
      while (k > 0 && marks[k] > ti + P0 / 2) k--;
      while (k < marks.length - 1 && marks[k] < ti - P0 / 2) k++;
      const am = marks[k];
      for (let i = 0; i < W; i++) {
        const src = am - P0 + i, dst = Math.round(to) - P0 + i + P0;
        if (src < 0 || src >= L || dst < 0 || dst >= out.length) continue;
        out[dst] += seg[src] * han[i]; wsum[dst] += han[i];
      }
      const ft = target(to / sr);
      to += Math.max(sr / 1500, sr / (ft > 0 ? ft : f0 || 200));
    }
    const res = new Float32Array(D);
    for (let i = 0; i < D; i++) { const w = wsum[i + P0]; res[i] = w > 0.15 ? out[i + P0] / w : out[i + P0] / 0.15; }
    return res;
  }

  // 简单的 Schroeder 混响
  function reverb(x, sr, mix = 0.18) {
    const combs = [1557, 1617, 1491, 1422].map((d) => ({ d: Math.round(d * sr / 44100), buf: null, i: 0 }));
    const aps = [225, 556].map((d) => ({ d: Math.round(d * sr / 44100), buf: null, i: 0 }));
    for (const c of combs) c.buf = new Float32Array(c.d);
    for (const a of aps) a.buf = new Float32Array(a.d);
    const y = new Float32Array(x.length);
    for (let n = 0; n < x.length; n++) {
      let s = 0;
      for (const c of combs) { const o = c.buf[c.i]; c.buf[c.i] = x[n] + o * 0.8; c.i = (c.i + 1) % c.d; s += o; }
      s *= 0.25;
      for (const a of aps) { const o = a.buf[a.i]; const v = s + o * 0.5; a.buf[a.i] = v; a.i = (a.i + 1) % a.d; s = o - v * 0.5; }
      y[n] = x[n] * (1 - mix) + s * mix;
    }
    return y;
  }

  /* ---------- 整首 ----------
   * song：{ bpm, tonic(MIDI), lines:[{ start?(秒), notes:[[半音|null, 拍]], units:[{ x, sr, f0 }] }] }
   * opts.backing：导入的曲子（单声道 Float32Array，采样率和输出相同）。有曲子时人声按每行的 start 对齐到曲子上；
   * 没有曲子时是清唱，各行依次排开。这里不合成任何乐器。
   * 返回 { vocal, mix, sr, lines:[{ t0, t1 }], env:[每 20ms 的人声响度 0–1], duration }
   */
  function renderSong(song, { sr = 44100, backing = null, backingGain = 0.8, onProgress = () => {} } = {}) {
    const bpm = clamp(song.bpm || 90, 40, 220), spb = 60 / bpm;
    let cursor = 1.0;                                     // 清唱：从 1 秒开始，行与行之间空 2 拍
    const plan = song.lines.map((ln) => {
      const total = ln.notes.reduce((s, n) => s + n[1], 0) * spb;
      const start = Number.isFinite(ln.start) ? ln.start : cursor;
      cursor = Math.max(cursor, start + total + 2 * spb);
      return { start, total };
    });
    const vocalEnd = Math.max(0, ...plan.map((p) => p.start + p.total));
    const N = Math.max(backing ? backing.length : 0, Math.ceil((vocalEnd + 1.5) * sr));
    const vocal = new Float32Array(N);
    const lines = [];
    let prevMidi = null;
    song.lines.forEach((ln, li) => {
      let t = plan[li].start;
      lines.push({ t0: t, t1: t + plan[li].total });
      let ui = 0;
      ln.notes.forEach(([semi, beats], i) => {
        const len = beats * spb;
        if (semi == null) { t += len; return; }            // 休止
        const u = ln.units[ui++];
        if (!u || !u.x || !u.x.length) { t += len; return; }
        const nextRest = i + 1 < ln.notes.length && ln.notes[i + 1][0] == null;
        const midi = song.tonic + semi, dur = len * (i === ln.notes.length - 1 || nextRest ? 0.95 : 1.0);
        const from = prevMidi == null ? midi : prevMidi;
        const target = (tt) => {
          const glide = Math.min(1, tt / 0.05);                       // 50ms 滑音
          const vib = dur > 0.4 && tt > 0.25 ? 0.25 * Math.min(1, (tt - 0.25) / 0.3) * Math.sin(2 * Math.PI * 5.5 * tt) : 0;
          return midiHz(from + (midi - from) * glide + vib);
        };
        let y = psola(u.x, u.sr, u.f0, target, dur);
        if (u.sr !== sr) {
          const r = u.sr / sr, z = new Float32Array(Math.floor(y.length / r));
          for (let k = 0; k < z.length; k++) { const p = k * r, i0 = Math.floor(p), fr = p - i0; z[k] = (y[i0] || 0) * (1 - fr) + (y[i0 + 1] || 0) * fr; }
          y = z;
        }
        const s0 = Math.round(t * sr), fadeIn = Math.round(0.008 * sr), fadeOut = Math.round(0.03 * sr);
        let peak = 1e-6; for (let k = 0; k < y.length; k++) peak = Math.max(peak, Math.abs(y[k]));
        const g = 0.6 / peak;
        for (let k = 0; k < y.length && s0 + k < N; k++) {
          if (s0 + k < 0) continue;
          const env = Math.min(1, k / fadeIn, (y.length - k) / fadeOut);
          vocal[s0 + k] += y[k] * g * env;
        }
        prevMidi = midi; t += len;
      });
      onProgress((li + 1) / song.lines.length * 0.8);
    });
    const v2 = reverb(vocal, sr, 0.16);
    // 人声和导入的曲子分别归一，再按比例混合，最后整体到约 -1 dBFS
    let vp = 1e-6; for (let i = 0; i < N; i++) vp = Math.max(vp, Math.abs(v2[i]));
    let bp = 1e-6; if (backing) for (let i = 0; i < backing.length; i++) bp = Math.max(bp, Math.abs(backing[i]));
    const mix = new Float32Array(N);
    let pk = 1e-6;
    for (let i = 0; i < N; i++) { mix[i] = v2[i] / vp + (backing && i < backing.length ? backing[i] / bp * backingGain : 0); pk = Math.max(pk, Math.abs(mix[i])); }
    const g = 0.89 / pk;
    for (let i = 0; i < N; i++) mix[i] *= g;
    const hop = Math.round(sr * 0.02), env = [];
    let vk = 1e-6; for (let i = 0; i < N; i++) vk = Math.max(vk, Math.abs(vocal[i]));
    for (let i = 0; i < N; i += hop) { let s2 = 0; for (let k = i; k < Math.min(N, i + hop); k++) s2 += vocal[k] * vocal[k]; env.push(Math.round(clamp(Math.sqrt(s2 / hop) / vk * 2.2, 0, 1) * 100) / 100); }
    onProgress(1);
    return { vocal: v2, mix, sr, lines, env, envRate: 50, duration: N / sr };
  }

  function wav(x, sr) {
    const b = new ArrayBuffer(44 + x.length * 2), v = new DataView(b);
    const w = (o, s) => { for (let i = 0; i < s.length; i++) v.setUint8(o + i, s.charCodeAt(i)); };
    w(0, 'RIFF'); v.setUint32(4, 36 + x.length * 2, true); w(8, 'WAVE'); w(12, 'fmt '); v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, 1, true);
    v.setUint32(24, sr, true); v.setUint32(28, sr * 2, true); v.setUint16(32, 2, true); v.setUint16(34, 16, true); w(36, 'data'); v.setUint32(40, x.length * 2, true);
    for (let i = 0; i < x.length; i++) v.setInt16(44 + i * 2, clamp(x[i], -1, 1) * 32767, true);
    return new Uint8Array(b);
  }

  // 按曲子的调：主音的音级固定（pc，0=C），只选八度，让旋律中间的音靠近复刻音色本来的音高
  function pickTonicForKey(pc, voiceF0, lines) {
    const all = lines.flatMap((l) => l.notes.map((n) => n[0]).filter((x) => x != null));
    const mid = all.length ? (Math.min(...all) + Math.max(...all)) / 2 : 6;
    const want = (voiceF0 > 0 ? hzMidi(voiceF0) : 62) + 2 - mid;
    let best = 60 + pc, bd = Infinity;
    for (let m = 36 + pc; m <= 84; m += 12) if (Math.abs(m - want) < bd) { bd = Math.abs(m - want); best = m; }
    return best;
  }
  // 清唱：按复刻音色的平均音高选调：让旋律中间的音靠近原声，变调少、更自然
  function pickTonic(voiceF0, lines) {
    const all = lines.flatMap((l) => l.notes.map((n) => n[0]).filter((x) => x != null));
    if (!all.length || !(voiceF0 > 0)) return 64;
    const mid = (Math.min(...all) + Math.max(...all)) / 2;
    return Math.round(clamp(hzMidi(voiceF0) + 2 - mid, 50, 72));
  }

  root.SingDSP = { parseJianpu, toJianpu, sungCount, syllabify, hasKanjiWithKana, localMelody, segment, f0Track, estimateF0, psola, renderSong, wav, pickTonic, pickTonicForKey, midiHz, hzMidi };
  if (typeof module !== 'undefined' && module.exports) module.exports = root.SingDSP;
})(typeof self !== 'undefined' ? self : typeof globalThis !== 'undefined' ? globalThis : this);
