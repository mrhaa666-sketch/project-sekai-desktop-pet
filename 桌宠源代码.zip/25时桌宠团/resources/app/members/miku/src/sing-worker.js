'use strict';
// 唱歌窗口的后台线程：分析导入的曲子；切分、变调、对齐到曲子上、混音。都在这里做，不卡界面
importScripts('sing-dsp.js', 'music-analysis.js');
const PC = { C: 0, 'C#': 1, D: 2, Eb: 3, E: 4, F: 5, 'F#': 6, G: 7, Ab: 8, A: 9, Bb: 10, B: 11 };
self.onmessage = (e) => {
  const m = e.data || {}, id = m.id;
  const prog = (p, stage) => self.postMessage({ id, progress: p, stage });
  try {
    if (m.type === 'analyze') {
      const r = self.MusicAnalysis.analyzeAudio(m.samples, m.sampleRate, prog);
      r.brief = self.MusicAnalysis.singBrief(r);
      r.tonicPc = PC[r.key.tonic] ?? 0;
      self.postMessage({ id, result: r });
      return;
    }
    // 渲染：lines:[{ samples, sr, notes, start? }], bpm, keyPc（有曲子时）, keyShift（清唱时升降调 / 有曲子时只能是 ±12）
    const D = self.SingDSP;
    const song = { bpm: m.bpm, lines: [] };
    const f0s = [], warn = [];
    m.lines.forEach((l, i) => {
      const n = D.sungCount(l.notes);          // 休止不占音
      const segs = D.segment(l.samples, l.sr, n);
      if (segs.length !== n) warn.push(`第 ${i + 1} 行切出 ${segs.length} 个音，应该是 ${n} 个，少的音会空着（可以在设置 → 唱歌 里把停顿调长）`);
      const units = segs.map((s) => { const x = l.samples.slice(s.s, s.e); const f0 = D.estimateF0(x, l.sr); if (f0 > 0) f0s.push(f0); return { x, sr: l.sr, f0 }; });
      song.lines.push({ notes: l.notes, units, start: l.start });
      prog(0.05 + 0.15 * (i + 1) / m.lines.length, '切分和测音高');
    });
    f0s.sort((a, b) => a - b);
    const voiceF0 = f0s.length ? f0s[Math.floor(f0s.length / 2)] : 0;
    song.tonic = (m.keyPc != null ? D.pickTonicForKey(m.keyPc, voiceF0, song.lines) : D.pickTonic(voiceF0, song.lines)) + (m.keyShift || 0);
    const r = D.renderSong(song, { sr: 44100, backing: m.backing || null, onProgress: (p) => prog(0.2 + p * 0.75, p < 0.8 ? '变调和拼接' : '和曲子混在一起') });
    const wav = D.wav(r.mix, r.sr);
    self.postMessage({ id, result: { wav, lines: r.lines, env: r.env, envRate: r.envRate, duration: r.duration, tonic: song.tonic, voiceF0: Math.round(voiceF0), warn } }, [wav.buffer]);
  } catch (err) {
    self.postMessage({ id, error: String((err && err.message) || err) });
  }
};
