'use strict';
/* 未来的歌：歌词 + 简谱（自己写，或让她编）→ 用复刻音色逐行合成 → 本机调音高、和导入的曲子混在一起（不合成乐器）→ 试听、保存、让桌宠唱
 * 歌词和旋律都以文字为准：编调子只是把结果填进这两个框，之后怎么改都行。 */
const api = window.singAPI;
const D = window.SingDSP;
const $ = (id) => document.getElementById(id);
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const mmss = (s) => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`;
const setMsg = (id, t, cls = '') => { const e = $(id); e.textContent = t; e.className = 'msg' + (cls ? ' ' + cls : ''); };
const MOOD_NAME = { calm: '平静', soft: '柔和', warm: '温暖', happy: '开心', moved: '感动', sad: '低落', hurt: '难过', serious: '认真', singing: '唱歌' };

let cfg = null, job = null, worker = null, result = null, blobUrl = null, raf = 0;
let music = null;               // 导入的曲子：{ name, analysis, backing(44.1kHz 单声道), decoded }
let anaWorker = null, anaJob = 0;
let helper = null;              // 她整理出的读音、心情、标题：{ title, bpm, minor, byText: Map(歌词行 → { units, mood }) }
const voiceCache = new Map();   // 已合成的一行：units → 采样（改调、改旋律时不再请求）

// 清唱：整首升降 -12 到 12 个半音；有曲子时人声要和曲子同调，只能换八度
function keyOptions() {
  const cur = +$('keyShift').value || 0;
  $('keyShift').innerHTML = '';
  const list = music ? [-12, 0, 12] : Array.from({ length: 25 }, (_, i) => i - 12);
  for (const k of list) { const o = document.createElement('option'); o.value = k; o.textContent = k === 0 ? (music ? '跟着曲子的调' : '按音色自动') : music ? (k > 0 ? '高八度' : '低八度') : (k > 0 ? '高 ' : '低 ') + Math.abs(k); $('keyShift').appendChild(o); }
  $('keyShift').value = list.includes(cur) ? String(cur) : '0';
}
keyOptions();

async function loadConfig() {
  cfg = await api.config();
  const pill = $('cfgPill');
  pill.textContent = cfg.voiceReady ? `复刻音色：${cfg.voiceId}` : '复刻音色未设置';
  pill.className = 'pill ' + (cfg.voiceReady ? 'ok' : 'bad');
  $('listenHint').textContent = cfg.listenModel ? `听曲模型：${cfg.listenModel}（用“看图”设置里的平台和密钥）` : '设置 → 唱歌 里还没有填听曲模型；不勾选也能编，只用本机分析的结果。';
  pill.title = cfg.voiceReady ? `语音模型 ${cfg.ttsModel}；编调子：${cfg.chatReady ? cfg.chatModel : '本地规则'}` : '右键桌宠 → 设置 → 语音：填 MiniMax 密钥和复刻音色 ID';
  if (cfg.prefill) applySong(cfg.prefill);
  refresh();
}
// 外部给的歌（插件、聊天、导入的文件）
function applySong(p) {
  if (!p) return;
  if (p.lyrics != null && p.lyrics !== '') $('lyrics').value = p.lyrics;
  if (p.melody != null) $('melody').value = p.melody;
  if (p.theme) $('theme').value = p.theme;
  if (p.bpm) $('bpm').value = p.bpm;
  if (p.mode) $('mode').value = p.mode;
  if (p.key != null) $('keyShift').value = String(Math.max(-12, Math.min(12, +p.key || 0)));
  if (p.title) helper = { ...(helper || { byText: new Map() }), title: p.title };
  preview();
}
api.onPrefill(applySong);
$('openSettings').onclick = () => api.openSettings();
window.addEventListener('focus', () => { if (!job) loadConfig(); });

function refresh() {
  const busy = !!job;
  $('prepare').disabled = busy; $('write').disabled = busy;
  $('sing').disabled = busy || !current().ok;
  $('cancel').disabled = !busy;
  for (const id of ['lyrics', 'melody', 'theme', 'keyShift', 'importSong', 'pickSong', 'dropSong', 'listen']) $(id).disabled = busy;
  for (const id of ['bpm', 'mode']) $(id).disabled = busy || !!music;   // 有曲子时速度、调式跟着曲子
  $('hint').textContent = busy || !cfg ? '' : !cfg.voiceReady ? '唱之前先在设置 → 语音 里填好复刻音色' : '';
}

/* ---------- 由文字得到要唱的歌 ---------- */
const lyricLines = () => $('lyrics').value.replace(/\r/g, '').split('\n').map((l) => l.trim()).filter((l) => l && !/^\[[^\]]*\]$/.test(l));
const melodyLines = () => $('melody').value.replace(/\r/g, '').split('\n').map((l) => l.trim()).filter(Boolean);
// 返回 { ok, plan, problems:[每行的问题] }
function current() {
  const ls = lyricLines(), ms = melodyLines();
  const problems = [];
  if (!ls.length) return { ok: false, problems: ['还没有歌词'] };
  if (!ms.length) return { ok: false, problems: ['还没有旋律：自己写简谱，或者点“编调子”'] };
  if (ms.length !== ls.length) problems.push(`歌词 ${ls.length} 行，简谱 ${ms.length} 行，要一样多`);
  const lines = ls.map((text, i) => {
    const h = helper && helper.byText.get(text);
    const units = h ? h.units : D.syllabify(text);
    const at = /^@(\d+)(?:\.(\d+(?:\.5)?))?\s+/.exec(ms[i] || '');
    const pj = D.parseJianpu((ms[i] || '').replace(/^@\S+\s+/, ''));
    const p = [];
    if (!h && D.hasKanjiWithKana(text) && !/\//.test(text)) p.push('有汉字，读音不确定：点“编调子”让她转成假名，或者把这行写成假名、用 / 分音');
    if (pj.errors.length) p.push('简谱' + pj.errors.join('，'));
    if (ms[i] && D.sungCount(pj.notes) !== units.length) p.push(`歌词 ${units.length} 个音，简谱 ${D.sungCount(pj.notes)} 个音（0 不算）`);
    let start;
    if (music) {
      const bars = music.analysis.bars, bar = at ? +at[1] : null;
      if (bar == null) p.push('有曲子时，行首要写从第几小节开始（比如 @8 ），或者点“编调子”');
      else if (bar >= bars.length) p.push(`第 ${bar} 小节超出了曲子（共 ${bars.length} 小节）`);
      else start = bars[bar].t + (at[2] ? +at[2] : 0) * 60 / music.analysis.tempo.bpm;
    }
    if (p.length) problems.push(`第 ${i + 1} 行：${p.join('；')}`);
    return { text, units, notes: pj.notes, mood: h ? h.mood : 'singing', start };
  });
  const bpm = music ? music.analysis.tempo.bpm : +$('bpm').value || (helper && helper.bpm) || 90;
  const minor = music ? music.analysis.key.mode === '小调' : $('mode').value ? $('mode').value === 'minor' : !!(helper && helper.minor);
  return { ok: !problems.length && bpm >= 50 && bpm <= 160, problems: bpm >= 50 && bpm <= 160 ? problems : [...problems, '速度要在 50–160 之间'], plan: { title: (helper && helper.title) || '未命名', bpm, minor, lines } };
}
function preview() {
  const c = current();
  if (!c.plan) { $('plan').hidden = true; $('planEmpty').hidden = false; $('planMeta').textContent = ''; refresh(); return; }
  const p = c.plan;
  $('planEmpty').hidden = true; $('plan').hidden = false;
  $('planMeta').textContent = `《${p.title}》 · ${p.bpm} BPM · ${music ? music.analysis.key.text + '（跟着曲子）' : p.minor ? '小调' : '大调'} · ${p.lines.length} 行`;
  $('plan').innerHTML = p.lines.map((l, i) => {
    let ui = 0;
    const cells = l.notes.map(([semi, beats]) => semi == null ? `<span class="u" style="opacity:.55">·<small>0${beats !== 1 ? ' ×' + beats : ''}</small></span>`
      : `<span class="u">${esc(l.units[ui++] || '？')}<small>${esc(D.toJianpu([[semi, 1]]))}${beats !== 1 ? ' ×' + beats : ''}</small></span>`).join('');
    const rest = l.units.slice(ui).map((u) => `<span class="u" style="color:#a8394f">${esc(u)}<small>缺音</small></span>`).join('');
    const where = l.start != null ? ` · ${mmss(l.start)} 起` : '';
    return `<div class="line" data-i="${i}"><span class="m">${MOOD_NAME[l.mood] || l.mood}${where}</span><div class="t">${esc(l.text)}</div><div class="units">${cells}${rest}</div></div>`;
  }).join('') + (c.problems.length ? `<div class="msg err">${esc(c.problems.join('\n'))}</div>` : '');
  refresh();
}
for (const id of ['lyrics', 'melody', 'bpm', 'mode']) $(id).addEventListener('input', preview);

/* ---------- 阶段 ---------- */
let stageKeys = [];
function initStages(list) {
  stageKeys = list.map((s) => s[0]);
  $('stages').innerHTML = list.map(([k, t]) => `<li data-k="${k}">${esc(t)}<span class="d"></span></li>`).join('');
  $('stages').hidden = false; $('barWrap').hidden = false; $('bar').style.width = '2%';
}
function stage(k, detail = '', frac) {
  const i = stageKeys.indexOf(k);
  [...$('stages').children].forEach((li, j) => { li.className = j < i ? 'done' : j === i ? 'on' : ''; if (j === i) li.querySelector('.d').textContent = detail; });
  if (frac != null) $('bar').style.width = Math.round(frac * 100) + '%';
}
function stagesEnd(ok) {
  const lis = [...$('stages').children];
  if (ok) { lis.forEach((li) => { li.className = 'done'; }); $('bar').style.width = '100%'; }
  else { const on = lis.find((li) => li.className === 'on'); if (on) on.className = 'fail'; }
}
api.onProgress((p) => { if (job && p.id === job.id && p.stage === 'compose') stage('compose', p.chars ? `${p.chars} 字` : ''); });

/* ---------- 编调子（让她整理读音、编调子，结果填进两个框） ---------- */
async function prepare(write) {
  if (job) return;
  const id = 'p' + Date.now();
  job = { id }; refresh(); setMsg('msg', '');
  const listenOn = !!music && $('listen').checked;
  initStages([...(listenOn ? [['listen', '她在听曲子']] : []), ['compose', music ? (write ? '她在写歌词、按曲子编调子' : '整理读音、按曲子编调子') : (write ? '她在写歌词、编调子' : '整理读音、编调子')]]);
  try {
    let listen = '';
    if (listenOn) {
      stage('listen', '', 0.1);
      const c = await clipB64();
      const lr = await api.listen({ id, clip: c.b64 });
      if (!job || job.id !== id) return;
      if (lr.error) { stagesEnd(false); setMsg('msg', lr.canceled ? '已取消。' : lr.error, lr.canceled ? 'warn' : 'err'); return; }
      listen = lr.text;
    }
    stage('compose', '', 0.4);
    const a = music && music.analysis;
    const r = await api.prepare({ id, lyrics: write ? '' : $('lyrics').value, theme: write ? $('theme').value : '', bpm: $('bpm').value, mode: $('mode').value, listen,
      music: a ? { brief: a.brief, bpm: a.tempo.bpm, minor: a.key.mode === '小调', bars: a.bars.length, beatsPerBar: a.meter.beatsPerBar } : null });
    if (r.error) { stagesEnd(false); setMsg('msg', r.canceled ? '已取消。' : r.error, r.canceled ? 'warn' : 'err'); return; }
    stagesEnd(true);
    const p = r.plan;
    helper = { title: p.title, bpm: p.bpm, minor: p.minor, listen, byText: new Map(p.lines.map((l) => [l.text, { units: l.units, mood: l.mood }])) };
    $('lyrics').value = p.lines.map((l) => l.text).join('\n');
    $('melody').value = p.lines.map((l) => (l.bar != null && music ? `@${l.bar}${l.beat ? '.' + l.beat : ''} ` : '') + D.toJianpu(l.notes)).join('\n');
    if (!$('bpm').value) $('bpm').placeholder = `自动（${p.bpm}）`;
    preview();
    setMsg('msg', `旋律编好了（${r.by === 'local' ? '本地规则' : r.by}）。可以直接改简谱，然后点“唱！”。` + (r.fixes && r.fixes.length ? '\n已自动修正：' + r.fixes.join('；') : ''), 'ok');
  } finally { job = null; refresh(); }
}
$('prepare').onclick = () => prepare(false);
$('write').onclick = () => { if (!$('theme').value.trim()) { setMsg('msg', '先写一个主题。', 'warn'); return; } prepare(true); };

/* ---------- 唱 ---------- */
async function decode(b64) {
  const bin = atob(b64), u = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
  const buf = await new OfflineAudioContext(1, 1, 32000).decodeAudioData(u.buffer);
  return buf.getChannelData(0).slice();
}
async function sing() {
  const c = current();
  if (job || !c.ok) { if (!c.ok) setMsg('msg', c.problems.join('\n'), 'err'); return; }
  const plan = c.plan;
  const id = 's' + Date.now();
  job = { id }; refresh(); setMsg('msg', ''); setMsg('saveMsg', '');
  const need = plan.lines.filter((l) => !voiceCache.has(l.units.join('|'))).length;
  initStages([['voice', need ? `用复刻音色逐行合成（${need} 行要合成，其余用已有的）` : '用已经合成过的声音（不再请求）'], ['dsp', '切分、调音高、拼接'], ['mix', music ? '和曲子混在一起' : '整理成清唱']]);
  try {
    const lines = [];
    let n = 0;
    for (let i = 0; i < plan.lines.length; i++) {
      const key = plan.lines[i].units.join('|');
      if (!voiceCache.has(key)) {
        document.querySelectorAll('.line').forEach((el) => el.classList.toggle('on', +el.dataset.i === i));
        stage('voice', `${++n} / ${need}`, 0.05 + 0.5 * n / Math.max(1, need));
        const r = await api.voice({ id, units: plan.lines[i].units });
        if (!job || job.id !== id) return;
        if (r.error) throw Object.assign(new Error(r.canceled ? '已取消。' : r.error), { canceled: r.canceled });
        voiceCache.set(key, await decode(r.b64));
      }
      lines.push({ samples: voiceCache.get(key).slice(), sr: 32000, notes: plan.lines[i].notes, start: plan.lines[i].start });   // 复制一份交给后台线程，缓存留着
    }
    document.querySelectorAll('.line').forEach((el) => el.classList.remove('on'));
    stage('dsp', '', 0.6);
    worker = new Worker('sing-worker.js');
    const res = await new Promise((resolve, reject) => {
      worker.onmessage = (e) => {
        const d = e.data;
        if (d.progress != null) stage(d.progress < 0.9 ? 'dsp' : 'mix', d.stage || '', 0.6 + d.progress * 0.4);
        if (d.result) resolve(d.result);
        if (d.error) reject(new Error('处理声音时出错：' + d.error));
      };
      worker.onerror = (e) => reject(new Error('后台线程出错：' + (e.message || '未知错误')));
      const backing = music ? music.backing.slice() : null;
      worker.postMessage({ id, lines, bpm: plan.bpm, keyPc: music ? music.analysis.tonicPc : null, keyShift: +$('keyShift').value, backing }, [...lines.map((l) => l.samples.buffer), ...(backing ? [backing.buffer] : [])]);
    });
    if (!job || job.id !== id) return;
    stagesEnd(true);
    showResult(res, plan);
    setMsg('msg', res.warn.length ? '唱好了，但有提醒：' + res.warn.join('；') : '唱好了。', res.warn.length ? 'warn' : 'ok');
    api.done({ title: plan.title });
  } catch (e) {
    stagesEnd(false);
    setMsg('msg', e.message, e.canceled ? 'warn' : 'err');
  } finally {
    if (worker) { worker.terminate(); worker = null; }
    if (job && job.id === id) job = null;
    refresh();
  }
}
$('sing').onclick = sing;
$('cancel').onclick = () => {
  if (!job) return;
  api.cancel(job.id);
  if (worker) { worker.terminate(); worker = null; }
  job = null; stagesEnd(false); setMsg('msg', '已取消。', 'warn'); refresh();
};

/* ---------- 导入曲子：本机分析（速度、调性、段落、每小节和弦），曲子本身作为伴奏 ---------- */
$('pickSong').onclick = () => $('songFileAudio').click();
$('songFileAudio').onchange = (e) => { const f = e.target.files[0]; e.target.value = ''; if (f) importSong(f); };
$('dropSong').onclick = () => { music = null; $('songName').textContent = '还没有导入（不导入就是清唱）'; $('songChips').innerHTML = ''; $('songWave').hidden = true; $('dropSong').hidden = true; keyOptions(); preview(); };
$('anaCancel').onclick = () => { if (anaWorker) { anaWorker.terminate(); anaWorker = null; } anaJob++; $('anaCancel').hidden = true; $('anaHint').textContent = '已停止分析。'; refresh(); };
async function importSong(file) {
  const my = ++anaJob;
  const hint = (t) => { if (my === anaJob) $('anaHint').textContent = t; };
  $('anaCancel').hidden = false; music = null; keyOptions();
  $('songName').textContent = file.name; $('songChips').innerHTML = ''; $('songWave').hidden = true;
  try {
    hint('解码…');
    let decoded;
    try { decoded = await new OfflineAudioContext(1, 1, 44100).decodeAudioData(await file.arrayBuffer()); }
    catch (err) { throw new Error('解码失败：文件可能已损坏，或者格式不受支持。'); }
    if (decoded.duration < 10) throw new Error('曲子太短（至少 10 秒）。');
    if (decoded.duration > 600) throw new Error('曲子太长（最多 10 分钟）。');
    const mono = async (sr) => { const oc = new OfflineAudioContext(1, Math.ceil(decoded.duration * sr), sr); const src = oc.createBufferSource(); src.buffer = decoded; src.connect(oc.destination); src.start(); return (await oc.startRendering()).getChannelData(0).slice(); };
    const backing = await mono(44100), a22 = await mono(22050);
    if (my !== anaJob) return;
    anaWorker = new Worker('sing-worker.js');
    const analysis = await new Promise((resolve, reject) => {
      anaWorker.onmessage = (ev) => { const d = ev.data; if (d.progress != null) hint(`本机分析 ${Math.round(d.progress * 100)}% · ${d.stage || ''}`); if (d.result) resolve(d.result); if (d.error) reject(new Error(d.error)); };
      anaWorker.onerror = (ev) => reject(new Error('分析线程出错：' + (ev.message || '未知错误')));
      anaWorker.postMessage({ id: my, type: 'analyze', samples: a22, sampleRate: 22050 }, [a22.buffer]);
    });
    if (my !== anaJob) return;
    music = { name: file.name.replace(/\.[^.]+$/, ''), analysis, backing, decoded };
    showSong();
    hint(analysis.gridReliable ? '分析完成（在本机完成，没有上传）。' : '分析完成，但节拍不够清楚：歌词可能对不准小节。');
  } catch (err) {
    if (my === anaJob) { hint(err.message); music = null; }
  } finally {
    if (my === anaJob) { if (anaWorker) { anaWorker.terminate(); anaWorker = null; } $('anaCancel').hidden = true; keyOptions(); preview(); }
  }
}
function showSong() {
  const a = music.analysis;
  $('dropSong').hidden = false;
  $('songChips').innerHTML = [['时长', mmss(a.duration)], ['速度', a.tempo.reliable ? a.tempo.bpm + ' BPM' : '不明显'], ['拍号', a.meter.text], ['调性', a.key.text], ['段落', a.sections.length + ' 段'], ['小节', a.bars.length]]
    .map(([k, v]) => `<span class="chip">${k} <b>${esc(v)}</b></span>`).join('');
  const cv = $('songWave'), g = cv.getContext('2d'); cv.hidden = false;
  g.clearRect(0, 0, cv.width, cv.height);
  const c = a.curve || [], mx = Math.max(1e-6, ...c);
  g.fillStyle = '#8fb7bc';
  for (let i = 0; i < c.length; i++) { const h = Math.max(2, c[i] / mx * (cv.height - 24)); g.fillRect(i / c.length * cv.width, (cv.height - h) / 2 + 8, Math.max(1, cv.width / c.length - 0.5), h); }
  g.fillStyle = '#2d636a'; g.font = '18px sans-serif';
  for (const s of a.sections) { const x = s.start / a.duration * cv.width; g.fillRect(x, 0, 2, cv.height); g.fillText(`${s.label} @${s.fromBar}`, x + 4, 18); }
}
// 截取最响段落附近约 30 秒，16kHz 单声道 WAV（只有勾选“让她听一段”才会用）
async function clipB64() {
  const a = music.analysis, d = music.decoded;
  const peak = a.sections.reduce((m, s) => (s.energy > m.energy ? s : m), a.sections[0]);
  const len = Math.min(30, d.duration), start = Math.max(0, Math.min(d.duration - len, (peak.start + peak.end) / 2 - len / 2));
  const sr = 16000, oc = new OfflineAudioContext(1, Math.ceil(len * sr), sr);
  const src = oc.createBufferSource(); src.buffer = d; src.connect(oc.destination); src.start(0, start, len);
  const x = (await oc.startRendering()).getChannelData(0);
  const w = D.wav(x, sr);
  let bin = ''; for (let i = 0; i < w.length; i += 0x8000) bin += String.fromCharCode.apply(null, w.subarray(i, i + 0x8000));
  return { b64: btoa(bin), start, len };
}

/* ---------- 导入、导出歌曲文件 ---------- */
function songNow() {
  return { title: (helper && helper.title) || '', lyrics: $('lyrics').value, melody: $('melody').value, bpm: +$('bpm').value || (helper && helper.bpm) || '', mode: $('mode').value, key: +$('keyShift').value };
}
$('exportSong').onclick = async () => { const r = await api.exportSong(songNow()); if (r.ok) setMsg('msg', '已导出到 ' + r.path, 'ok'); else if (r.error) setMsg('msg', r.error, 'err'); };
$('importSong').onclick = () => $('songFile').click();
$('songFile').onchange = async (e) => {
  const f = e.target.files[0]; e.target.value = '';
  if (!f) return;
  try {
    const j = JSON.parse(await f.text());
    if (!j || typeof j !== 'object') throw new Error();
    const lines = Array.isArray(j.lines) ? j.lines : null;
    helper = null;
    applySong({ ...j, lyrics: lines ? lines.map((l) => l.lyrics || '').join('\n') : j.lyrics || '', melody: lines ? lines.map((l) => l.melody || '').join('\n') : j.melody || '' });
    setMsg('msg', `已导入《${j.title || f.name}》。`, 'ok');
  } catch (err) { setMsg('msg', '这个文件不是歌曲文件（需要 JSON：lyrics、melody 等）。', 'err'); }
};

/* ---------- 结果 ---------- */
function showResult(r, plan) {
  result = { ...r, title: plan.title, lineText: plan.lines.map((l) => l.text), moods: plan.lines.map((l) => l.mood) };
  $('resultCard').hidden = false;
  const k = +$('keyShift').value;
  $('resultMeta').textContent = `《${plan.title}》 · ${mmss(r.duration)} · ${music ? '配着《' + music.name + '》' : '清唱'} · 你的音色约 ${r.voiceF0 || '?'} Hz${k ? ` · ${k > 0 ? '升' : '降'} ${Math.abs(k)} 个半音` : ''}`;
  if (blobUrl) URL.revokeObjectURL(blobUrl);
  blobUrl = URL.createObjectURL(new Blob([r.wav], { type: 'audio/wav' }));
  $('audio').src = blobUrl;
  drawWave(r);
  tick();
}
function drawWave(r) {
  const cv = $('wave'), g = cv.getContext('2d'), W = cv.width, H = cv.height;
  g.clearRect(0, 0, W, H);
  g.fillStyle = '#d9e7e9';
  for (const l of r.lines) g.fillRect(l.t0 / r.duration * W, 0, (l.t1 - l.t0) / r.duration * W, H);
  g.fillStyle = '#3a7a82';
  const e = r.env, n = e.length;
  for (let i = 0; i < n; i++) { const h = Math.max(1, e[i] * (H - 20)); g.fillRect(i / n * W, (H - h) / 2, Math.max(1, W / n), h); }
}
function tick() {
  const a = $('audio');
  $('time').textContent = `${mmss(a.currentTime || 0)} / ${mmss(result ? result.duration : 0)}`;
  if (result) { const i = result.lines.findIndex((l) => a.currentTime >= l.t0 && a.currentTime <= l.t1 + 0.3); document.querySelectorAll('.line').forEach((el) => el.classList.toggle('on', +el.dataset.i === i && !a.paused)); }
  if (!a.paused) raf = requestAnimationFrame(tick);
}
$('play').onclick = () => { const a = $('audio'); if (!a.src) return; a.play(); cancelAnimationFrame(raf); raf = requestAnimationFrame(tick); };
$('stop').onclick = () => { const a = $('audio'); a.pause(); a.currentTime = 0; tick(); api.stopPet(); };
$('audio').onended = () => tick();
$('save').onclick = async () => {
  if (!result) return;
  const r = await api.save({ name: result.title, bytes: result.wav });
  if (r.ok) setMsg('saveMsg', '已保存到 ' + r.path, 'ok'); else if (r.error) setMsg('saveMsg', r.error, 'err');
};
$('toPet').onclick = async () => {
  if (!result) return;
  $('audio').pause();
  const r = await api.toPet({ bytes: result.wav, env: result.env, envRate: result.envRate, title: result.title, lines: result.lines.map((l, i) => ({ ...l, text: result.lineText[i], mood: result.moods[i] })) });
  setMsg('saveMsg', r.ok ? '她在唱了。' : (r.error || '没能交给桌宠'), r.ok ? 'ok' : 'err');
};

window.__sing = { get music() { return music; }, importSong, current, get result() { return result; }, prepare, sing, applySong, voiceCache };
loadConfig();
