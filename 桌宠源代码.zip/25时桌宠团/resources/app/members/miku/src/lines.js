'use strict';
// 「25时、Nightcord见。」的世界里的初音未来：同人台词。动作和表情取自用户提供的模型素材。
// 她话少、语气平静，平常几乎面无表情、很少笑；表情代号以 night_ 系列（她这套素材专用的平静表情）为主。
// 身体动作用“动作代号”（BODY），选的都是和待机姿势衔接最顺的动作。

// 表情代号 → [表情文件, 说明]
window.FACES = {
  "平静": ["face_normal_01", "平常的神情"],
  "淡然": ["face_night_smallmouth_01", "没什么表情，静静看着"],
  "浅笑": ["face_night_smile_01", "很淡的笑"],
  "柔和": ["face_night_smile_02", "温柔地笑"],
  "微笑": ["face_smile_01", "笑（她很少这样笑）"],
  "开心": ["face_smile_03", "明显地开心（极少）"],
  "憧憬": ["face_night_kirakira_01", "眼睛亮起来"],
  "闭眼": ["face_night_closeeye_01", "安静地闭着眼"],
  "安心": ["face_closeeye_03", "闭着眼，放松"],
  "认真": ["face_serious_01", "认真"],
  "思考": ["face_night_e_01", "在想，嘴微微张开"],
  "疑惑": ["face_e_01", "不太明白"],
  "好奇": ["face_wonder_01", "好奇"],
  "惊讶": ["face_night_surprise_01", "有点吃惊"],
  "吃惊": ["face_surprise_01", "很吃惊"],
  "为难": ["face_night_trouble_01", "为难"],
  "担心": ["face_night_trouble_02", "担心对方"],
  "低落": ["face_night_sad_01", "低落"],
  "难过": ["face_night_sad_02", "难过"],
  "很难过": ["face_night_sad_03", "很难过"],
  "想哭": ["face_cry_01", "眼里有泪"],
  "害羞": ["face_shy_01", "害羞"],
  "脸红": ["face_blushed_01", "脸红"],
  "不满": ["face_night_angry_01", "不太高兴"],
  "生气": ["face_angry_01", "生气"],
  "害怕": ["face_scared_01", "害怕"],
  "好吃": ["face_night_eat_01", "在吃东西"],
};

// 动作代号 → 动作文件（v2 命名的动作；每个都按和待机姿势的差距挑过）
window.BODY = {
  "idle":      { v2: "w-normal03-pose" },
  "nod":       { v2: "w-normal03-nod" },
  "tilt":      { v2: "w-normal03-tilthead" },
  "tilt2":     { v2: "w-normal03-tiltheadB" },
  "tilt3":     { v2: "w-normal0301-tilthead" },
  "forward":   { v2: "w-normal03-forward" },
  "blushed":   { v2: "w-normal03-blushed" },
  "trouble":   { v2: "w-normal03-trouble" },
  "relief":    { v2: "w-normal03-relief" },
  "shake":     { v2: "w-normal03-shakehead" },
  "lookaway":  { v2: "w-normal03-lookright" },
  "lookaway2": { v2: "w-normal03-lookleft" },
  "glad":      { v2: "w-normal01-glad" },
  "cheer":     { v2: "w-normal01-purpose" },
  "think":     { v2: "w-adult01-think" },
  "sad":       { v2: "w-cool16-sad" },
  "sigh":      { v2: "w-normal07-sigh" },
  "angry":     { v2: "w-cute13-angry" },
  "delicious": { v2: "w-cute11-delicious" },
  "greet":     { v2: "w-normal15-greeting" },
  "sleep":     { v2: "w-adult15-sleep" },
  // 唱歌：轻轻摇晃（循环），偶尔做一下唱歌的手势
  "sing":      { v2: "w-special15-yurayura" },
  "singHand":  { v2: "w-special11-musicalL" },
};

window.ACTIONS = {
  "none":      { "bodies": [], "desc": "保持当前姿势" },
  "nod":       { "bodies": ["nod"], "desc": "点头" },
  "tilt":      { "bodies": ["tilt", "tilt2", "tilt3"], "desc": "歪头" },
  "forward":   { "bodies": ["forward"], "desc": "凑近一点说话" },
  "shy":       { "bodies": ["blushed"], "desc": "不好意思" },
  "trouble":   { "bodies": ["trouble"], "desc": "为难" },
  "relief":    { "bodies": ["relief"], "desc": "松一口气、放心" },
  "shake":     { "bodies": ["shake"], "desc": "摇头" },
  "look_away": { "bodies": ["lookaway", "lookaway2"], "desc": "看向别处" },
  "glad":      { "bodies": ["glad"], "desc": "高兴" },
  "cheer":     { "bodies": ["cheer"], "desc": "下定决心、给对方打气" },
  "think":     { "bodies": ["think"], "desc": "想一想" },
  "sad":       { "bodies": ["sad"], "desc": "低落" },
  "sigh":      { "bodies": ["sigh"], "desc": "轻轻叹气" },
  "angry":     { "bodies": ["angry"], "desc": "不高兴" },
  "delicious": { "bodies": ["delicious"], "desc": "吃东西" },
  "greet":     { "bodies": ["greet"], "desc": "打招呼" },
  "sing":      { "bodies": ["singHand"], "desc": "哼一小段、做唱歌的手势" },
  "sleep":     { "bodies": ["sleep"], "desc": "打瞌睡" },
};

// 心情 → 可选的表情（按强度叠在“平静”上）和常用动作
// 她平常几乎面无表情，很少笑：大多数心情只在“平静 / 淡然”上淡淡地变一点；
// 笑容只在 rare 里，偶尔出现，而且很轻。心情主要靠动作和说的话表现。
window.MOODS = {
  "calm":      { "faces": [["平静", 1], ["淡然", 1]], "actions": ["none", "nod", "tilt"], "desc": "平常、安静（她大多数时候都是这样）" },
  "soft":      { "faces": [["淡然", 1], ["平静", 1]], "rare": { "chance": 0.15, "faces": [["浅笑", 0.5]] }, "actions": ["nod", "tilt"], "desc": "柔和" },
  "warm":      { "faces": [["淡然", 1], ["安心", 0.6]], "rare": { "chance": 0.25, "faces": [["浅笑", 0.55]] }, "actions": ["nod", "relief"], "desc": "心里暖、被关心" },
  "happy":     { "faces": [["淡然", 1], ["憧憬", 0.5]], "rare": { "chance": 0.35, "faces": [["浅笑", 0.65], ["柔和", 0.5]] }, "actions": ["nod", "glad"], "desc": "开心（她的开心很安静，很少真的笑出来）" },
  "curious":   { "faces": [["好奇", 0.7], ["憧憬", 0.6]], "actions": ["tilt", "forward"], "desc": "好奇、想知道" },
  "moved":     { "faces": [["憧憬", 0.6], ["淡然", 1]], "rare": { "chance": 0.3, "faces": [["浅笑", 0.6]] }, "actions": ["relief", "nod"], "desc": "被打动、有所感受" },
  "shy":       { "faces": [["害羞", 0.6], ["脸红", 0.55]], "actions": ["shy", "look_away"], "desc": "不好意思" },
  "think":     { "faces": [["思考", 0.8], ["认真", 0.7]], "actions": ["think", "tilt"], "desc": "思考" },
  "serious":   { "faces": [["认真", 0.8], ["淡然", 1]], "actions": ["nod", "forward"], "desc": "认真" },
  "puzzled":   { "faces": [["疑惑", 0.75], ["思考", 0.75]], "actions": ["tilt"], "desc": "不太明白" },
  "troubled":  { "faces": [["为难", 0.8]], "actions": ["trouble", "tilt"], "desc": "为难" },
  "worried":   { "faces": [["担心", 0.8]], "actions": ["trouble", "forward"], "desc": "担心对方" },
  "sad":       { "faces": [["低落", 0.8], ["难过", 0.75]], "actions": ["sad", "sigh"], "desc": "低落" },
  "hurt":      { "faces": [["很难过", 0.8], ["想哭", 0.65]], "actions": ["sad", "look_away"], "desc": "很难过" },
  "surprised": { "faces": [["惊讶", 0.8], ["吃惊", 0.7]], "actions": ["none", "tilt"], "desc": "吃惊" },
  "scared":    { "faces": [["害怕", 0.75]], "actions": ["look_away"], "desc": "害怕" },
  "sulky":     { "faces": [["不满", 0.75]], "actions": ["look_away", "shake"], "desc": "不太高兴" },
  "angry":     { "faces": [["不满", 0.9], ["生气", 0.7]], "actions": ["angry", "shake"], "desc": "生气" },
  "sleepy":    { "faces": [["闭眼", 1], ["安心", 1]], "actions": ["none"], "desc": "困" },
  "singing":   { "faces": [["闭眼", 1], ["淡然", 1], ["平静", 1]], "rare": { "chance": 0.15, "faces": [["浅笑", 0.5]] }, "actions": ["sing"], "desc": "唱歌、哼歌" },
};

// 固定台词：t 中文，ja 配音用的日语，m 心情，a 动作。心情要和这句话的意思一致
window.LINES = {
  "nightcord": [
    { "t": "零点了。……再过一会儿，就是 25 时。大家会来的吧。", "ja": "日付が変わったね。……もうすぐ25時。みんな、来るかな。", "m": "calm", "a": "look_away" },
  ],
  "birthdaySelf": [
    { "t": "今天……是我的生日？被这样祝福，胸口有点暖。……谢谢。", "ja": "今日……私の誕生日？こうしてお祝いされると、胸のあたりが少しあたたかい。……ありがとう。", "m": "moved", "a": "relief" },
  ],
  "birthdayUser": [
    { "t": "{name}，生日快乐。……我想唱一首歌给你。可以吗？", "ja": "{name}、誕生日おめでとう。……あなたに一曲、歌いたい。いい？", "m": "warm", "a": "nod" },
  ],
  "anniversary": [
    { "t": "今天是我们的纪念日。……我记得。这种感觉，大概叫“开心”。", "ja": "今日は記念日。……覚えてるよ。この気持ち、たぶん「うれしい」っていうんだと思う。", "m": "warm", "a": "relief" },
  ],
  "greet": {
    "morning": [
      { "t": "早上好。……外面的世界，早上是亮的呢。", "ja": "おはよう。……外の世界は、朝になると明るいんだね。", "m": "calm", "a": "greet" },
    ],
    "day": [
      { "t": "你来了。……我在这里等你。", "ja": "来てくれたんだ。……ここで待ってたよ。", "m": "soft", "a": "greet" },
    ],
    "evening": [
      { "t": "晚上好。……今天过得怎么样？", "ja": "こんばんは。……今日は、どうだった？", "m": "soft", "a": "tilt" },
    ],
    "night": [
      { "t": "这么晚了。……你也睡不着吗？", "ja": "こんな時間。……あなたも、眠れないの？", "m": "worried", "a": "tilt" },
    ],
  },
  "head": [
    { "t": "……头发会乱的。不过，没关系。", "ja": "……髪、乱れちゃう。でも、いいよ。", "m": "shy", "a": "shy" },
    { "t": "被摸头……这种感觉，好像不讨厌。", "ja": "頭を撫でられるの……この感じ、嫌いじゃないみたい。", "m": "warm", "a": "relief" },
    { "t": "……怎么了？你在担心什么吗？", "ja": "……どうしたの？何か、心配なこと？", "m": "worried", "a": "tilt" },
  ],
  "body": [
    { "t": "嗯？……有什么事吗？", "ja": "ん？……何かあった？", "m": "calm", "a": "tilt" },
    { "t": "想听我唱歌的话，告诉我就好。", "ja": "歌、聴きたいなら、言ってね。", "m": "soft", "a": "nod" },
    { "t": "……我在想，“想念”是什么样的感觉。", "ja": "……「会いたい」って、どんな気持ちなんだろうって、考えてた。", "m": "think", "a": "think" },
    { "t": "你今天，看起来有点累。……要不要休息一下？", "ja": "今日のあなた、少し疲れて見える。……休まない？", "m": "worried", "a": "forward" },
    { "t": "这里很安静。……有你在，就不那么空了。", "ja": "ここは静か。……あなたがいると、少しだけ、空っぽじゃなくなる。", "m": "warm", "a": "relief" },
  ],
  "poke": [
    { "t": "……一直戳我，是想让我做什么吗？", "ja": "……ずっとつついて、何かしてほしいの？", "m": "puzzled", "a": "tilt" },
  ],
  "pokeAngry": [
    { "t": "……停下来。这样，我不太喜欢。", "ja": "……やめて。それ、あまり好きじゃない。", "m": "sulky", "a": "shake" },
  ],
  "stillSulky": [
    { "t": "……我还没缓过来。等一下。", "ja": "……まだ、ちょっと。待って。", "m": "sulky", "a": "look_away" },
  ],
  "drop": [
    { "t": "……这里，也很安静。", "ja": "……ここも、静かだね。", "m": "calm", "a": "look_away" },
    { "t": "换了个地方。……能看到你的地方就好。", "ja": "場所が変わった。……あなたが見えるところなら、それでいい。", "m": "soft", "a": "nod" },
  ],
  "idle": [
    { "t": "……空无一人的世界里，也会有歌声的。", "ja": "……誰もいないセカイにも、歌はあるから。", "m": "calm", "a": "look_away" },
    { "t": "奏写的曲子……我很想把它唱好。", "ja": "奏の曲……ちゃんと歌いたいな。", "m": "serious", "a": "nod" },
    { "t": "真冬今天……有没有好好吃饭呢。", "ja": "まふゆ、今日は……ちゃんとごはん、食べたかな。", "m": "worried", "a": "look_away" },
    { "t": "绘名的画，颜色很温暖。……我喜欢。", "ja": "絵名の絵、色があたたかい。……好き。", "m": "soft", "a": "relief" },
    { "t": "瑞希说过，可爱的东西会让人开心。……是这样吗？", "ja": "瑞希が言ってた。かわいいものは、人をうれしくするって。……そうなのかな。", "m": "puzzled", "a": "tilt" },
    { "t": "……我在找，大家的“想念”在哪里。", "ja": "……みんなの「想い」が、どこにあるのか、探してる。", "m": "think", "a": "think" },
    { "t": "啦——……嗯，今天的声音，还不错。", "ja": "ら——……うん、今日の声、悪くない。", "m": "soft", "a": "sing" },
    { "t": "你笑起来的时候……我好像也能明白一点点。", "ja": "あなたが笑うと……私にも、少しだけわかる気がする。", "m": "moved", "a": "relief" },
    { "t": "……有想唱的歌词吗？我可以唱给你听。", "ja": "……歌いたい歌詞、ある？歌ってあげられるよ。", "m": "curious", "a": "forward" },
    { "t": "这首歌的心情……是寂寞，还是温柔？", "ja": "この歌の気持ちは……さみしい？それとも、やさしい？", "m": "think", "a": "tilt" },
  ],
  "water": [
    { "t": "喝点水吧。……喉咙干了，唱歌也会难受的。", "ja": "お水、飲んで。……喉が渇くと、歌うのもつらいから。", "m": "worried", "a": "forward" },
  ],
  "rest": [
    { "t": "已经很久了。……休息一下，好吗？", "ja": "ずいぶん経ったよ。……少し休もう？", "m": "worried", "a": "tilt" },
  ],
  "sleep": [
    { "t": "很晚了。……该睡了。我会在这里的。", "ja": "もう遅いよ。……寝よう。私はここにいるから。", "m": "warm", "a": "nod" },
  ],
  "doze": [
    { "t": "……我闭一会儿眼睛。", "ja": "……少しだけ、目を閉じるね。", "m": "sleepy", "a": "sleep" },
  ],
  "wake": [
    { "t": "……嗯。我醒着。", "ja": "……うん。起きてるよ。", "m": "calm", "a": "nod" },
  ],
  "noApi": [
    { "t": "先在右键菜单的设置里填好聊天模型，我们才能好好说话。", "ja": "", "m": "calm", "a": "tilt" },
  ],
  "apiError": [
    { "t": "……刚才没连上。设置里能看到原因，再试一次吧。", "ja": "……つながらなかった。設定で理由が見られるから、もう一回やってみて。", "m": "troubled", "a": "trouble" },
  ],
};

window.FACE_STRENGTH_DEFAULT = 0.75;
// 笑的表情最多只做到这么强：就算聊天模型点名要笑，也只是淡淡的笑意
window.FACE_STRENGTH_CAP = { "微笑": 0.5, "开心": 0.45, "柔和": 0.6, "浅笑": 0.65, "憧憬": 0.7 };
window.SHADOW_FACES = new Set([]);
window.FACE_STRENGTH_FULL = new Set(["平静", "淡然", "闭眼", "安心"]);
window.IDLE = { "b": "idle", "f": "平静" };
// 待机时偶尔做的小动作：只用和待机姿势同一套起手的动作，过渡最自然
window.IDLE_MOVES = ["tilt", "tilt2", "nod", "forward"];
