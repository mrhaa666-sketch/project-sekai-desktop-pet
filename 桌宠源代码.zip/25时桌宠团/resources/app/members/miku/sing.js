'use strict';
/* 未来唱歌（主进程）：整理歌词和旋律、用复刻音色逐行合成、保存、让桌宠唱出来
 *
 * MiniMax 官方的音乐生成接口（/v1/music_generation）不能指定复刻音色，所以这里用的是：
 *  语音合成接口 POST {平台}/v1/t2a_v2 + 你复刻的 voice_id（“设置 → 语音”里填的那个），
 *  把一行歌词按“一个音一个音、中间用 <#0.3#> 停顿”念出来；切分、变调、和导入的曲子混音都在本机完成（src/sing-dsp.js），不合成任何乐器。
 *  导入了曲子时，“唱的调子”由聊天模型根据曲子的本机分析（速度、调性、段落、每小节和弦）和可选的听曲描述来编。
 * 歌词的读音和旋律由聊天模型整理（没有聊天模型时用本地规则：只支持假名和中文）。
 * 密钥只在主进程使用，不发给页面，不写日志。只有在唱歌窗口里点按钮时才会请求。
 */
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const { BrowserWindow, ipcMain, dialog, app } = require('electron');
const llm = require('./llm');
const DSP = require('./src/sing-dsp.js');

const LIMITS = { maxLyrics: 1200, maxLines: 24, maxUnits: 24, minBpm: 50, maxBpm: 160 };
const BEATS = [0.25, 0.5, 0.75, 1, 1.5, 2, 3, 4];
const ERR = { 1002: '请求太频繁', 1004: 'MiniMax 鉴权失败，请检查“语音”设置里的密钥', 1008: 'MiniMax 账户余额不足', 1026: '歌词里有被判定为敏感的内容', 2013: '参数不被接受（模型名或音色 ID 可能不对）', 2049: 'MiniMax 密钥无效' };

class SingError extends Error { constructor(m, extra = {}) { super(m); Object.assign(this, extra); } }
const aborted = (signal) => (signal.reason instanceof SingError ? signal.reason : new SingError('已取消', { canceled: true }));

function chatCfg(s) {
  return { apiType: s.apiType || '', apiBase: s.apiBase, apiKey: s.apiKey, model: String(s.singModel || s.model || '').trim(), temperature: 0.8, keyLabel: '聊天模型的 API 密钥' };
}

/* ---------- 歌词 → 每行的音和旋律 ---------- */
function splitLines(text) {
  return String(text || '').replace(/\r/g, '').split('\n').map((l) => l.replace(/^\s*\[[^\]]*\]\s*$/, '').trim()).filter(Boolean).slice(0, LIMITS.maxLines);
}
const MOOD_LIST = ['calm', 'soft', 'warm', 'happy', 'moved', 'sad', 'hurt', 'serious', 'singing'];
function buildPrompt({ lyrics, theme, bpm, minor, music, listen }) {
  const onSong = !!music;
  const system = `你是「25时、Nightcord见。」的世界里的初音未来，要把歌词唱出来。你负责把歌词整理成“每个要唱的音”，并${onSong ? '在听过的这首曲子上编出唱的调子（人声旋律）' : '编出旋律'}。
只输出一个 JSON 对象：
{"title":"歌名","bpm":数字,"minor":true或false,"lines":[{"text":"这一行原来的歌词","units":["音","音"],"notes":[[半音,拍数],...],"mood":"心情"${onSong ? ',"bar":从第几小节开始,"beat":在这一小节的第几拍开始（0 起）' : ''}}]}
规则：
- units：这一行要唱出来的每一个音。日语歌词把汉字换成平假名读音，一拍（一个假名）一个音，小写的ゃゅょ等并到前一个音里，っ和ー也算一个音；中文一个字一个音；英文一个音节一个音。
- notes：和 units 一一对应、数量必须完全相同。半音是相对主音的整数（-5 到 14），拍数只能是 ${BEATS.join('、')}。每行总拍数不超过 16，行末的音长一些。
- 旋律要好唱、有起伏，相同结构的行可以用相似的旋律；副歌比主歌高一些。${onSong ? `
- 这是给一首现成曲子配的人声：半音相对这首曲子的主音（主音就是曲子调性的主音）；bpm 写曲子的速度；minor 按曲子的调性。
- 每行的 bar、beat 决定从曲子的哪里开始唱：把歌词放进有人声感觉的段落（不要放在前奏、像器乐段的地方），主歌放主歌、副歌放副歌；同一行不要跨进下一段；行与行不要重叠（前一行结束后再开始下一行）。
- 每一拍的音尽量用当时和弦里的音（根音、三度、五度），经过音可以短一些；长音落在和弦音上。` : ''}
- mood 只能是：${MOOD_LIST.join('、')}（按这一行歌词的情绪选）。
- 每行最多 ${LIMITS.maxUnits} 个音，太长就拆成两行。`;
  const songInfo = onSong ? `\n\n这首曲子（本机分析的结果，段落、和弦都是推测）：\n${music}${listen ? `\n听曲模型听了其中一段后的描述：${listen}` : ''}` : '';
  const user = (lyrics
    ? `歌词：\n${lyrics}\n\n${onSong ? '' : bpm ? `速度 ${bpm} BPM。` : '速度你来定。'}${!onSong && minor === true ? '用小调。' : !onSong && minor === false ? '用大调。' : ''}不要改动歌词的意思和字。`
    : `请先写一段歌词再整理（4 到 8 行，可以分主歌和副歌），主题：${theme}。用简体中文或日语（看主题用什么语言写的就用什么）。${!onSong && bpm ? `速度 ${bpm} BPM。` : ''}`) + songInfo;
  return { system, user };
}
function extractJSON(text) {
  const s = String(text || ''), a = s.indexOf('{'), b = s.lastIndexOf('}');
  if (a < 0 || b <= a) throw new SingError('模型没有按格式回答', { invalid: true });
  try { return JSON.parse(s.slice(a, b + 1)); } catch (e) { throw new SingError('模型回答的格式不对', { invalid: true }); }
}
// 检查并修正：音和旋律数量不一致、拍数不合规、音太高太低，都在这里修好；返回 { plan, notes:[修正说明] }
function normalizePlan(raw, req = {}) {
  const fixes = [];
  const lines = [];
  for (const l of (Array.isArray(raw && raw.lines) ? raw.lines : []).slice(0, LIMITS.maxLines)) {
    const text = String(l && l.text || '').trim().slice(0, 80);
    let units = Array.isArray(l && l.units) ? l.units.map((u) => String(u).trim()).filter(Boolean) : DSP.syllabify(text);
    if (!units.length) units = DSP.syllabify(text);
    if (!units.length) continue;
    if (units.length > LIMITS.maxUnits) { units = units.slice(0, LIMITS.maxUnits); fixes.push(`“${text}”太长，只唱前 ${LIMITS.maxUnits} 个音`); }
    // 旋律里可以有休止（半音写 null），休止不占歌词
    let notes = Array.isArray(l && l.notes) ? l.notes.filter((n) => Array.isArray(n) && (n[0] === null || Number.isFinite(+n[0])) && Number.isFinite(+n[1])).map((n) => [n[0] === null ? null : Math.round(+n[0]), +n[1]]) : [];
    if (DSP.sungCount(notes) !== units.length) {
      const fill = DSP.localMelody([units.length], { seed: lines.length + 3, minor: !!raw.minor })[0];
      if (notes.length) fixes.push(`“${text}”的旋律和字数对不上（${DSP.sungCount(notes)} 个音 / ${units.length} 个字），已补齐`);
      const sung = notes.filter((n) => n[0] != null);
      notes = units.map((_, i) => sung[i] || fill[i]);
    }
    notes = notes.map(([s, b]) => [s == null ? null : Math.max(-12, Math.min(19, s)), BEATS.reduce((p, x) => (Math.abs(x - b) < Math.abs(p - b) ? x : p), 1)]);
    const mood = MOOD_LIST.includes(l && l.mood) ? l.mood : 'singing';
    const line = { text: text || units.join(''), units, notes, mood };
    if (req.bars) {   // 有导入的曲子：每行从第几小节第几拍开始
      line.bar = Math.max(0, Math.min(req.bars - 1, Math.round(+l.bar) || 0));
      line.beat = Math.max(0, Math.min(7, Math.round((+l.beat || 0) * 2) / 2));
    }
    lines.push(line);
  }
  if (!lines.length) throw new SingError('没有可以唱的歌词', { invalid: true });
  // 有曲子时：行不要重叠，重叠的往后挪到前一行结束之后的小节
  if (req.bars && req.bpm) {
    const bpb = req.beatsPerBar || 4;
    let endBeat = -1;
    for (const l of lines) {
      const start = l.bar * bpb + l.beat, len = l.notes.reduce((s, n) => s + n[1], 0);
      if (start < endBeat) { const nb = Math.ceil(endBeat / bpb); fixes.push(`“${l.text}”和上一行重叠，挪到第 ${nb} 小节`); l.bar = Math.min(req.bars - 1, nb); l.beat = 0; }
      endBeat = l.bar * bpb + l.beat + len;
    }
  }
  let bpm = Math.round(Number(req.bpm || raw.bpm) || 88);
  bpm = Math.max(LIMITS.minBpm, Math.min(LIMITS.maxBpm, bpm));
  const minor = req.minor === true || req.minor === false ? req.minor : !!raw.minor;
  return { plan: { title: String(raw.title || '').trim().slice(0, 30) || '未命名', bpm, minor, lines }, fixes };
}
// 没有聊天模型：本地切音、本地旋律（日语里有汉字时读音不确定，直接提示）
function localPlan({ lyrics, bpm, minor }) {
  const ls = splitLines(lyrics);
  if (!ls.length) throw new SingError('先写下要唱的歌词');
  if (ls.some(DSP.hasKanjiWithKana)) throw new SingError('日语歌词里有汉字，需要聊天模型帮忙转成读音（设置 → 聊天模型）。也可以把歌词全部写成假名。', { noConfig: true });
  const units = ls.map((l) => DSP.syllabify(l).slice(0, LIMITS.maxUnits));
  const mel = DSP.localMelody(units.map((u) => u.length), { minor: !!minor });
  return normalizePlan({ title: '', bpm: bpm || 88, minor: !!minor, lines: ls.map((t, i) => ({ text: t, units: units[i], notes: mel[i], mood: 'singing' })) }, { bpm, minor });
}

/* ---------- 歌曲接口：插件、聊天、导入导出都用这个格式 ----------
 * { title, bpm, mode: 'major'|'minor', key: -12~12（升降调）, lyrics: '多行歌词', melody: '多行简谱', theme }
 * 也可以写成 lines: [{ lyrics: '一行歌词', melody: '这一行的简谱' }]
 */
function cleanSong(p = {}) {
  const lines = Array.isArray(p.lines) ? p.lines.slice(0, LIMITS.maxLines) : null;
  const lyrics = lines ? lines.map((l) => String(l && l.lyrics || '').replace(/\n/g, ' ')).join('\n') : String(p.lyrics || '');
  const melody = lines ? lines.map((l) => String(l && l.melody || '').replace(/\n/g, ' ')).join('\n') : String(p.melody || '');
  const bpm = Math.round(+p.bpm);
  return {
    title: String(p.title || '').slice(0, 30), lyrics: lyrics.slice(0, LIMITS.maxLyrics), melody: melody.slice(0, 4000), theme: String(p.theme || '').slice(0, 200),
    bpm: bpm >= LIMITS.minBpm && bpm <= LIMITS.maxBpm ? bpm : '', mode: ['major', 'minor'].includes(p.mode) ? p.mode : '', key: Math.max(-12, Math.min(12, Math.round(+p.key) || 0)),
  };
}

/* ---------- 复刻音色逐音合成（MiniMax 语音合成） ---------- */
function ttsCfg(s) {
  return { base: String(s.ttsBase || 'https://api.minimaxi.com').trim().replace(/\/+$/, ''), key: llm.cleanKey(s.ttsKey), voiceId: String(s.ttsVoiceId || '').trim(), model: s.ttsModel || 'speech-2.8-hd', groupId: String(s.ttsGroupId || '').trim(), gap: Math.max(0.2, Math.min(0.8, Number(s.singGap) || 0.35)) };
}
function ttsText(units, gap) { return units.join(`<#${gap.toFixed(2)}#>`); }
async function speakUnits(s, units, { signal, cacheDir }) {
  const c = ttsCfg(s);
  if (!c.key || !c.voiceId) throw new SingError('还没有填 MiniMax 密钥和复刻音色 ID（右键 → 设置 → 语音）。唱歌用的是你在 MiniMax 复刻的音色。', { noConfig: true });
  { const ki = llm.keyIssue(c.key, 'MiniMax 密钥'); if (ki) throw new SingError(ki, { noConfig: true }); }
  const text = ttsText(units, c.gap);
  const lang = units.some((u) => /[぀-ヿ]/.test(u)) ? 'Japanese' : units.some((u) => /[㐀-鿿]/.test(u)) ? 'Chinese' : 'auto';
  const hash = crypto.createHash('sha1').update([c.voiceId, c.model, lang, text].join('|')).digest('hex');
  const file = cacheDir && path.join(cacheDir, hash + '.mp3');
  if (file && fs.existsSync(file)) return { b64: fs.readFileSync(file).toString('base64'), cached: true };
  let url = c.base + '/v1/t2a_v2';
  if (c.groupId) url += '?GroupId=' + encodeURIComponent(c.groupId);
  let res;
  try {
    res = await fetch(url, {
      method: 'POST', signal,
      headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + c.key },
      body: JSON.stringify({ model: c.model, text, stream: false, language_boost: lang, output_format: 'hex',
        voice_setting: { voice_id: c.voiceId, speed: 0.9, vol: 1, pitch: 0 },
        audio_setting: { sample_rate: 32000, bitrate: 128000, format: 'mp3', channel: 1 } }),
    });
  } catch (e) { if (signal.aborted) throw aborted(signal); throw new SingError('连不上 MiniMax：' + (e.cause && e.cause.code || e.message)); }
  const body = await res.text().catch(() => '');
  if (!res.ok) throw new SingError(`MiniMax 返回 ${res.status}：${body.slice(0, 120)}`);
  let j; try { j = JSON.parse(body); } catch (e) { throw new SingError('MiniMax 返回的内容不是 JSON'); }
  const code = j && j.base_resp && j.base_resp.status_code;
  if (code) throw new SingError(`MiniMax 出错（${code}）${ERR[code] ? '：' + ERR[code] : ''} ${String(j.base_resp.status_msg || '').slice(0, 80)}`.trim());
  const hex = j && j.data && j.data.audio;
  if (!hex || !/^[0-9a-fA-F]+$/.test(hex.slice(0, 200))) throw new SingError('MiniMax 没有返回音频');
  const buf = Buffer.from(hex, 'hex');
  if (file) { try { fs.mkdirSync(cacheDir, { recursive: true }); fs.writeFileSync(file, buf); } catch (e) {} }
  return { b64: buf.toString('base64') };
}

/* ---------- 窗口和 IPC ---------- */
module.exports = function setupSing({ getSettings, icon, appDir, userData, sayLine, note, getPetWin }) {
  let win = null, pending = null;
  const jobs = new Map();
  const cacheDir = path.join(userData, 'sing-cache');
  const send = (ch, v) => { if (win && !win.isDestroyed()) win.webContents.send(ch, v); };
  const fromWin = (e) => win && !win.isDestroyed() && e.sender === win.webContents;
  let timeoutOverride = 0;
  const timeoutMs = (s) => timeoutOverride || Math.max(30, Math.min(900, Number(s.singTimeout) || 300)) * 1000;

  function open(prefill) {
    if (prefill && typeof prefill === 'object') pending = cleanSong(prefill);
    if (win && !win.isDestroyed()) { win.focus(); if (pending) { send('sing-prefill', pending); pending = null; } return win; }
    win = new BrowserWindow({
      width: 1000, height: 760, minWidth: 780, minHeight: 580, title: '初音未来桌宠 · 未来的歌',
      icon, autoHideMenuBar: true, backgroundColor: '#f4f6f7',
      webPreferences: { preload: path.join(appDir, 'preload-sing.js'), contextIsolation: true },
    });
    win.loadFile(path.join(appDir, 'src', 'sing.html'));
    win.on('closed', () => { for (const j of jobs.values()) j.abort(new SingError('窗口关闭，已取消', { canceled: true })); jobs.clear(); win = null; });
    return win;
  }

  // 每个请求都有编号、超时和取消
  async function job(id, s, fn) {
    const ctl = new AbortController();
    jobs.set(String(id), { abort: (why) => ctl.abort(why) });
    const to = setTimeout(() => ctl.abort(new SingError(`超过 ${timeoutMs(s) / 1000} 秒没有完成，已停止（可以在设置 → 唱歌 里调长）`, { timeout: true })), timeoutMs(s));
    try { return await fn(ctl.signal); }
    catch (e) {
      const se = e instanceof SingError ? e : new SingError(ctl.signal.aborted ? aborted(ctl.signal).message : String(e && e.message || e));
      return { error: se.message, canceled: !!se.canceled || (ctl.signal.aborted && !se.timeout), timeout: !!se.timeout, noConfig: !!se.noConfig, invalid: !!se.invalid };
    } finally { clearTimeout(to); jobs.delete(String(id)); }
  }

  async function prepare(p, onProgress) {
    const s = getSettings();
    return job(p.id, s, async (signal) => {
      const lyrics = splitLines(p.lyrics).join('\n').slice(0, LIMITS.maxLyrics);
      const theme = String(p.theme || '').trim().slice(0, 200);
      const bpm = p.bpm ? Math.round(+p.bpm) : 0;
      if (bpm && (bpm < LIMITS.minBpm || bpm > LIMITS.maxBpm)) throw new SingError(`速度要在 ${LIMITS.minBpm}–${LIMITS.maxBpm} 之间，或者选“自动”`);
      const minor = p.mode === 'minor' ? true : p.mode === 'major' ? false : null;
      if (!lyrics && !theme) throw new SingError('先写下歌词，或者给一个主题让她写');
      const cfg = chatCfg(s);
      // 有导入的曲子：歌唱的调子由聊天模型根据这首曲子的信息来编（本机分析 + 可选的听曲描述）
      const music = p.music && typeof p.music === 'object' && typeof p.music.brief === 'string' ? p.music : null;
      if (music) {
        if (!llm.hasChatApi(cfg) || !cfg.model) throw new SingError('按曲子编调子需要聊天模型（右键 → 设置 → 聊天模型）', { noConfig: true });
        const mbpm = Math.round(+music.bpm) || 0;
        if (!mbpm) throw new SingError('这首曲子的节拍不够清楚，没法把歌词对齐到小节上。换一首节拍清楚的曲子，或者不导入曲子清唱。');
        const pr = buildPrompt({ lyrics, theme, music: music.brief.slice(0, 6000), listen: String(p.listen || '').slice(0, 800) });
        onProgress({ stage: 'compose', chars: 0 });
        let t = 0;
        const r = await llm.request(cfg, { system: pr.system, messages: [{ role: 'user', content: pr.user }], stream: true, json: true, maxTokens: 7000, signal,
          onText: (acc) => { const now = Date.now(); if (now - t > 200) { t = now; onProgress({ stage: 'compose', chars: acc.length }); } } })
          .catch((e) => { if (signal.aborted) throw aborted(signal); return { error: '连接失败：' + (e.cause && e.cause.code || e.message) }; });
        if (signal.aborted) throw aborted(signal);
        if (r.error) throw new SingError('聊天模型出错：' + r.error);
        const n = normalizePlan(extractJSON(r.data.choices[0].message.content), { bpm: mbpm, minor: music.minor === true, bars: Math.max(1, +music.bars || 1), beatsPerBar: +music.beatsPerBar || 4 });
        return { ok: true, ...n, by: cfg.model };
      }
      if (!llm.hasChatApi(cfg) || !cfg.model) {
        if (!lyrics) throw new SingError('让她写歌词需要聊天模型（右键 → 设置 → 聊天模型）', { noConfig: true });
        const r = localPlan({ lyrics, bpm, minor });
        return { ok: true, ...r, by: 'local' };
      }
      const pr = buildPrompt({ lyrics, theme, bpm, minor });
      onProgress({ stage: 'compose', chars: 0 });
      let t = 0;
      const r = await llm.request(cfg, { system: pr.system, messages: [{ role: 'user', content: pr.user }], stream: true, json: true, maxTokens: 6000, signal,
        onText: (acc) => { const now = Date.now(); if (now - t > 200) { t = now; onProgress({ stage: 'compose', chars: acc.length }); } } })
        .catch((e) => { if (signal.aborted) throw aborted(signal); return { error: '连接失败：' + (e.cause && e.cause.code || e.message) }; });
      if (signal.aborted) throw aborted(signal);
      if (r.error) throw new SingError('聊天模型出错：' + r.error);
      const n = normalizePlan(extractJSON(r.data.choices[0].message.content), { bpm, minor });
      return { ok: true, ...n, by: cfg.model };
    });
  }

  ipcMain.handle('sing-config', (e) => {
    const s = getSettings(), c = ttsCfg(s), cc = chatCfg(s);
    const prefill = fromWin(e) && pending ? pending : null;
    if (prefill) pending = null;
    return { voiceReady: !!(c.key && c.voiceId), voiceId: c.voiceId, ttsModel: c.model, chatReady: llm.hasChatApi(cc) && !!cc.model, chatModel: cc.model, listenModel: String(s.singListenModel || '').trim(), timeoutSec: timeoutMs(s) / 1000, limits: LIMITS, prefill };
  });
  ipcMain.handle('sing-prepare', (e, p = {}) => (fromWin(e) ? prepare(p, (x) => send('sing-progress', { id: p.id, ...x })) : { error: '只能在唱歌窗口里使用' }));
  ipcMain.handle('sing-voice', (e, p = {}) => {
    if (!fromWin(e)) return { error: '只能在唱歌窗口里使用' };
    const s = getSettings();
    return job(p.id, s, async (signal) => {
      const units = Array.isArray(p.units) ? p.units.map(String).filter(Boolean).slice(0, LIMITS.maxUnits) : [];
      if (!units.length) throw new SingError('这一行没有要唱的音');
      return { ok: true, ...(await speakUnits(s, units, { signal, cacheDir })) };
    });
  });
  // 听曲：把截取的一小段（勾选后才会上传）交给听曲模型，得到一段描述
  ipcMain.handle('sing-listen', (e, p = {}) => {
    if (!fromWin(e)) return { error: '只能在唱歌窗口里使用' };
    const s = getSettings();
    return job(p.id, s, async (signal) => {
      const model = String(s.singListenModel || '').trim();
      if (!model) throw new SingError('还没有填听曲模型（设置 → 唱歌）。官方文档只标注 Qwen3-Omni 系列支持音频输入。不勾选“让她听一段”也能编，只用本机分析的结果。', { noConfig: true });
      const base = String(s.visionBase || 'https://api.siliconflow.cn/v1').trim().replace(/\/+$/, '');
      const key = llm.cleanKey(s.visionKey || s.embKey || s.asrKey);
      if (!key) throw new SingError('听曲用的是“看图”设置里的平台和密钥，请先填好（设置 → 看图）', { noConfig: true });
      { const ki = llm.keyIssue(key, '看图 API 密钥'); if (ki) throw new SingError(ki, { noConfig: true }); }
      const clip = String(p.clip || '');
      if (!/^[A-Za-z0-9+/=]+$/.test(clip) || clip.length < 100 || clip.length > 16 * 1024 * 1024) throw new SingError('要听的那一段没有准备好');
      let res;
      try {
        res = await fetch(base + '/chat/completions', { method: 'POST', signal, headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + key },
          body: JSON.stringify({ model, max_tokens: 500, messages: [{ role: 'user', content: [
            { type: 'audio_url', audio_url: { url: 'data:audio/wav;base64,' + clip } },
            { type: 'text', text: '这是一首歌（或伴奏）的一段。用简体中文描述：有没有人声、主旋律大概在什么音区、节奏和律动、情绪、适合什么样的人声旋律（长音多还是短音多、起伏大不大）。150 字以内。' },
          ] }] }) });
      } catch (err) { if (signal.aborted) throw aborted(signal); throw new SingError('听曲模型连不上：' + (err.cause && err.cause.code || err.message)); }
      const text = await res.text().catch(() => '');
      if (!res.ok) throw new SingError(res.status === 400 ? `听曲模型拒绝了音频输入（400），这个模型可能不支持听音频。${text.slice(0, 100)}` : `听曲模型返回 ${res.status}：${text.slice(0, 120)}`);
      let j; try { j = JSON.parse(text); } catch (err) { throw new SingError('听曲模型返回的内容不是 JSON'); }
      const out = String(j.choices && j.choices[0] && j.choices[0].message && j.choices[0].message.content || '').trim();
      if (!out) throw new SingError('听曲模型没有回答');
      return { ok: true, text: out.slice(0, 800) };
    });
  });
  ipcMain.on('sing-cancel', (e, id) => { if (!fromWin(e)) return; const j = jobs.get(String(id)); if (j) j.abort(new SingError('已取消', { canceled: true })); });
  ipcMain.handle('sing-save', async (e, { name, bytes } = {}) => {
    if (!fromWin(e)) return { error: 'denied' };
    if (!bytes || !bytes.byteLength) return { error: '还没有唱好的歌' };
    const safe = (String(name || '未来的歌').replace(/[\\/:*?"<>|\r\n]/g, '_').trim() || '未来的歌').slice(0, 60);
    let dir; try { dir = app.getPath('music'); } catch (err) { dir = app.getPath('home'); }
    const r = await dialog.showSaveDialog(win, { title: '保存歌曲', defaultPath: path.join(dir, `${safe}.wav`), filters: [{ name: 'WAV 音频', extensions: ['wav'] }] });
    if (r.canceled || !r.filePath) return { canceled: true };
    try { fs.writeFileSync(r.filePath, Buffer.from(bytes)); }
    catch (err) { return { error: '保存失败：' + (err.code === 'EACCES' || err.code === 'EPERM' ? '没有写入权限，换个文件夹试试' : err.code === 'ENOSPC' ? '磁盘空间不够' : err.message) }; }
    return { ok: true, path: r.filePath };
  });
  // 导出歌曲文件（歌词 + 简谱 + 速度等，JSON）
  ipcMain.handle('sing-export', async (e, song = {}) => {
    if (!fromWin(e)) return { error: 'denied' };
    const s = cleanSong(song);
    const safe = (s.title || '未来的歌').replace(/[\\/:*?"<>|\r\n]/g, '_').slice(0, 60);
    let dir; try { dir = app.getPath('documents'); } catch (err) { dir = app.getPath('home'); }
    const r = await dialog.showSaveDialog(win, { title: '导出歌曲文件', defaultPath: path.join(dir, `${safe}.json`), filters: [{ name: '歌曲文件', extensions: ['json'] }] });
    if (r.canceled || !r.filePath) return { canceled: true };
    try { fs.writeFileSync(r.filePath, JSON.stringify({ format: 'miku-song', version: 1, ...s }, null, 2)); } catch (err) { return { error: '导出失败：' + err.message }; }
    return { ok: true, path: r.filePath };
  });
  // 让桌宠唱：把混好的音频、每行的时间和心情、口型用的人声响度交给桌宠页面
  ipcMain.handle('sing-to-pet', (e, p = {}) => {
    if (!fromWin(e)) return { error: 'denied' };
    const pet = getPetWin();
    if (!pet || pet.isDestroyed()) return { error: '桌宠没有在显示' };
    if (!p.bytes || !p.bytes.byteLength) return { error: '还没有唱好的歌' };
    const lines = (Array.isArray(p.lines) ? p.lines : []).slice(0, LIMITS.maxLines).map((l) => ({ t0: +l.t0 || 0, t1: +l.t1 || 0, text: String(l.text || '').slice(0, 80), mood: MOOD_LIST.includes(l.mood) ? l.mood : 'singing' }));
    pet.webContents.send('sing-play', { b64: Buffer.from(p.bytes).toString('base64'), env: Array.isArray(p.env) ? p.env.slice(0, 60000) : [], envRate: +p.envRate || 50, lines, title: String(p.title || '').slice(0, 30) });
    if (note) note(`你唱了一首${p.title ? '《' + String(p.title).slice(0, 20) + '》' : '歌'}给对方听`);
    return { ok: true };
  });
  ipcMain.on('sing-stop-pet', (e) => { if (!fromWin(e)) return; const pet = getPetWin(); if (pet && !pet.isDestroyed()) pet.webContents.send('sing-stop'); });
  ipcMain.on('sing-done', (e, { title } = {}) => {
    if (!fromWin(e)) return;
    sayLine(`……唱好了${title ? '，《' + String(title).slice(0, 20) + '》' : ''}。要听吗？`, '……歌えたよ。聴いてくれる？', 'soft', 'nod');
  });
  return { open, _test: { prepare, speakUnits: (s, units, signal) => speakUnits(s, units, { signal: signal || new AbortController().signal, cacheDir: null }), cancel: (id) => { const j = jobs.get(String(id)); if (j) j.abort(new SingError('已取消', { canceled: true })); }, setTimeoutMs: (ms) => { timeoutOverride = ms; } } };
};
module.exports.normalizePlan = normalizePlan;
module.exports.cleanSong = cleanSong;
module.exports.localPlan = localPlan;
module.exports.buildPrompt = buildPrompt;
module.exports.splitLines = splitLines;
module.exports.ttsText = ttsText;
module.exports.speakUnits = speakUnits;
module.exports.LIMITS = LIMITS;
