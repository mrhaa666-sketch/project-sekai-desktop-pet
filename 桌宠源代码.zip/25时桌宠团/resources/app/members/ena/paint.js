'use strict';
/* 绘名的画室（主进程）：文生图、图生图、曲生图
 *
 * 用到两类模型，都在“设置 → 画画”里由用户自己填写：
 *  - 绘图模型：硅基流动官方图片生成接口 POST {地址}/images/generations
 *    （官方文档：https://docs.siliconflow.cn/cn/api-reference/images/images-generations）
 *    字段：model、prompt（必填），negative_prompt、image_size（"宽x高"，Qwen-Image-Edit 系列不支持）、seed、
 *    num_inference_steps（1–100）、guidance_scale（0–20，文档注明只对 Kwai-Kolors/Kolors 有效）、
 *    image（图生图的输入图，base64 data URI 或网址）。返回 images[].url，链接一小时后失效，所以生成后立即下载到本机内存。
 *  - 解析模型：
 *    · 图生图：先用“看图”设置里的视觉模型描述你给的图片；
 *    · 曲生图：在画室窗口里本地分析音乐（速度、调性、段落、力度、音色明暗），不上传；
 *      只有你勾选“让模型听一段”并点生成时，才把截取的一小段音频发给你填的听曲模型（官方文档只标注 Qwen3-Omni 系列支持音频输入）；
 *    · 再由聊天模型（或单独指定的提示词模型）把这些信息整理成绘图提示词。
 * 密钥只在主进程使用，不发给页面，不写日志。只有用户在窗口里点“生成”才会发请求。
 */
const path = require('path');
const fs = require('fs');
const { BrowserWindow, ipcMain, dialog, app, clipboard, nativeImage } = require('electron');
const llm = require('./llm');

const DEFAULT_BASE = 'https://api.siliconflow.cn/v1';
const LIMITS = { maxIdea: 800, maxImageBytes: 8 * 1024 * 1024, maxAudioBytes: 12 * 1024 * 1024, minSteps: 1, maxSteps: 100, minGuidance: 0, maxGuidance: 20 };
// 官方文档推荐的尺寸（其他尺寸文档没说会被拒绝，但推荐值效果最好）
const SIZES = {
  kolors: ['1024x1024', '960x1280', '768x1024', '720x1440', '720x1280'],
  qwen: ['1328x1328', '1664x928', '928x1664', '1472x1140', '1140x1472', '1584x1056', '1056x1584'],
};
const ASPECTS = { square: '1:1', portrait: '3:4', tall: '9:16', landscape: '4:3', wide: '16:9' };
const isKolors = (m) => /kolors/i.test(m);
const isQwenEdit = (m) => /qwen-image-edit/i.test(m);
const isQwenImage = (m) => /qwen-image/i.test(m) && !isQwenEdit(m);
// 按模型和画面比例挑一个文档推荐的尺寸；Qwen-Image-Edit 系列不传尺寸（文档注明不支持）
function sizeFor(model, aspect) {
  if (isQwenEdit(model)) return null;
  if (isKolors(model)) return { square: '1024x1024', portrait: '960x1280', tall: '720x1280', landscape: '1024x1024', wide: '1024x1024' }[aspect] || '1024x1024';
  if (isQwenImage(model)) return { square: '1328x1328', portrait: '1140x1472', tall: '928x1664', landscape: '1472x1140', wide: '1664x928' }[aspect] || '1328x1328';
  return { square: '1024x1024', portrait: '768x1024', tall: '720x1280', landscape: '1024x768', wide: '1280x720' }[aspect] || '1024x1024';
}

class PaintError extends Error { constructor(m, extra = {}) { super(m); Object.assign(this, extra); } }
const aborted = (signal) => (signal.reason instanceof Error ? signal.reason : new PaintError('已取消', { canceled: true }));

/* ---------- 检查窗口发来的请求 ---------- */
function cleanReq(p = {}) {
  const mode = ['text', 'image', 'music'].includes(p.mode) ? p.mode : null;
  if (!mode) throw new PaintError('请先选择文生图、图生图或曲生图');
  const idea = String(p.idea || '').trim().slice(0, LIMITS.maxIdea);
  if (mode === 'text' && idea.length < 2) throw new PaintError('先写下想画什么（画面、人物、氛围、风格都可以）');
  const aspect = ASPECTS[p.aspect] ? p.aspect : 'square';
  const style = String(p.style || '').trim().slice(0, 60);
  const refine = p.refine !== false;
  let seed = p.seed === '' || p.seed == null ? null : Math.round(Number(p.seed));
  if (seed !== null && !(seed >= 0 && seed <= 9999999999)) throw new PaintError('种子要在 0–9999999999 之间，或留空随机');
  const out = { mode, idea, aspect, style, refine, seed };
  if (mode === 'image') {
    const img = String(p.image || '');
    const m = /^data:(image\/(png|jpeg|webp));base64,([A-Za-z0-9+/=]+)$/.exec(img);
    if (!m) throw new PaintError('先选一张图片（PNG、JPG 或 WebP）');
    const bytes = Math.floor(m[3].length * 3 / 4);
    if (bytes > LIMITS.maxImageBytes) throw new PaintError('图片太大了（超过 8MB），请换一张小一点的');
    out.image = img; out.imageMime = m[1]; out.imageB64 = m[3];
    out.strength = ['light', 'medium', 'strong'].includes(p.strength) ? p.strength : 'medium';
  }
  if (mode === 'music') {
    const brief = String(p.musicBrief || '').trim();
    if (brief.length < 10) throw new PaintError('先选一首曲子并完成本地分析');
    out.musicBrief = brief.slice(0, 4000);
    out.musicName = String(p.musicName || '').slice(0, 80);
    if (p.listen) {
      const a = String(p.audioClip || '');
      if (!/^[A-Za-z0-9+/=]+$/.test(a) || a.length < 100) throw new PaintError('要让模型听的那一段音频没有准备好，请重新分析');
      if (a.length * 3 / 4 > LIMITS.maxAudioBytes) throw new PaintError('截取的音频太大');
      out.audioClip = a;
    }
  }
  return out;
}

/* ---------- 各个模型的配置（只在主进程里拼，密钥不出主进程） ---------- */
function paintCfg(s) {
  const base = String(s.paintBase || DEFAULT_BASE).trim().replace(/\/+$/, '');
  const own = llm.cleanKey(s.paintKey);
  const key = own || llm.cleanKey(s.visionKey || s.embKey || s.asrKey);
  const keyLabel = own ? '画画 API 密钥' : s.visionKey ? '看图 API 密钥（画画借用了它）' : s.embKey ? '长期记忆的 embedding 密钥（画画借用了它）' : '语音识别 API 密钥（画画借用了它）';
  return { base, key, keyLabel, t2i: String(s.paintModel || 'Kwai-Kolors/Kolors').trim(), i2i: String(s.paintEditModel || 'Qwen/Qwen-Image-Edit-2509').trim(),
    steps: Math.max(LIMITS.minSteps, Math.min(LIMITS.maxSteps, parseInt(s.paintSteps, 10) || 20)),
    guidance: Math.max(LIMITS.minGuidance, Math.min(LIMITS.maxGuidance, Number(s.paintGuidance) || 7.5)), negative: String(s.paintNegative || '').slice(0, 500) };
}
function promptCfg(s) {
  return { apiType: s.apiType || '', apiBase: s.apiBase, apiKey: s.apiKey, model: String(s.paintPromptModel || s.model || '').trim(), temperature: 0.8, keyLabel: '聊天模型的 API 密钥' };
}
function visionCfg(s) {
  const keyLabel = s.visionKey ? '看图 API 密钥' : s.embKey ? '长期记忆的 embedding 密钥（看图借用了它）' : '语音识别 API 密钥（看图借用了它）';
  return { apiType: s.visionType || '', apiBase: String(s.visionBase || DEFAULT_BASE).trim(), apiKey: llm.cleanKey(s.visionKey || s.embKey || s.asrKey), keyLabel, model: String(s.visionModel || '').trim(), temperature: 0.3 };
}
function listenCfg(s) {
  const p = paintCfg(s);
  return { apiType: 'openai', apiBase: p.base, apiKey: p.key, keyLabel: p.keyLabel, model: String(s.paintAudioModel || '').trim(), temperature: 0.3 };
}

/* ---------- 提示词 ---------- */
const PROMPT_SYSTEM = `你是东云绘名，一个擅长人物插画、注重配色和服装细节的画手，正在帮对方把想法整理成给图片生成模型的提示词。
只输出一个 JSON 对象：{"prompt": "...", "negative_prompt": "...", "title": "...", "comment": "..."}
- prompt：给图片生成模型看的画面描述，用简体中文，具体写出主体、构图、镜头、光线、配色、画风、细节，150 字以内，不要写成对话。
- negative_prompt：不想出现的东西（如 低质量、模糊、多余的手指、文字水印），40 字以内。
- title：这幅画的标题，12 字以内。
- comment：绘名对这幅画的一句话说明（第一人称、口语、可以有点小得意），30 字以内。
不要编造对方没提到的真实人物；不要画真实存在的公众人物；不要写版权角色的名字。`;

function buildPromptRequest(req, extra = {}) {
  const L = [];
  if (req.mode === 'text') L.push(`对方想画：${req.idea}`);
  if (req.mode === 'image') {
    L.push(`这是图生图：在对方给的原图基础上改画。原图内容（看图模型的描述）：${extra.imageDesc || '（没有描述）'}`);
    L.push(`对方的要求：${req.idea || '（没有特别要求，保持构图，画得更精致好看）'}`);
    L.push(`改动幅度：${{ light: '小改，尽量保留原图的构图和主体', medium: '适度改画，保留主体和大致构图', strong: '大胆重画，只保留主题' }[req.strength]}`);
    L.push('prompt 要写成“对原图做什么修改、改成什么样”的完整描述。');
  }
  if (req.mode === 'music') {
    L.push(`这是“曲生图”：根据一首曲子的感觉画一张图（不是画乐谱，也不是画演奏者，除非对方要求）。`);
    if (req.musicName) L.push(`曲子文件名：${req.musicName}（文件名不一定代表内容）`);
    L.push(`本地分析结果（只是信号特征的推测）：\n${req.musicBrief}`);
    if (extra.listenDesc) L.push(`听曲模型听了其中一段后的描述：${extra.listenDesc}`);
    if (req.idea) L.push(`对方补充的要求：${req.idea}`);
    L.push('把速度、调性明暗、力度起伏、音色明暗转译成画面的场景、色调、光线、动势和构图；不要在画面里放文字。');
  }
  if (req.style) L.push(`画风偏好：${req.style}`);
  L.push(`画面比例：${ASPECTS[req.aspect]}`);
  return L.join('\n');
}
function parsePromptJSON(text) {
  const s = String(text || '');
  const a = s.indexOf('{'), b = s.lastIndexOf('}');
  if (a < 0 || b <= a) throw new PaintError('提示词模型没有按格式回答', { invalid: true });
  let j; try { j = JSON.parse(s.slice(a, b + 1)); } catch (e) { throw new PaintError('提示词模型回答的格式不对', { invalid: true }); }
  const prompt = String(j.prompt || '').trim();
  if (prompt.length < 4) throw new PaintError('提示词模型没有写出画面描述', { invalid: true });
  return { prompt: prompt.slice(0, 1200), negative: String(j.negative_prompt || '').trim().slice(0, 300), title: String(j.title || '').trim().slice(0, 30), comment: String(j.comment || '').trim().slice(0, 80) };
}
// 没有聊天模型或不润色：直接用原话拼提示词
function plainPrompt(req, extra = {}) {
  const parts = [];
  if (req.mode === 'image') parts.push(req.idea || '保持原图构图，画得更精致');
  else if (req.mode === 'music') parts.push(req.idea || '', `根据音乐的感觉作画：${req.musicBrief.split('\n').slice(0, 2).join('；')}`, extra.listenDesc || '');
  else parts.push(req.idea);
  if (req.style) parts.push(req.style);
  return { prompt: parts.filter(Boolean).join('，').slice(0, 1200), negative: '', title: '', comment: '' };
}

/* ---------- 各步骤 ---------- */
async function describeInput(s, req, { signal }) {
  const v = visionCfg(s);
  if (!v.apiKey && !llm.isLocal(v.apiBase)) throw new PaintError('图生图要先看懂原图：请在 设置 → 看图 里填好视觉模型（也可以关掉“先让模型看图”直接改画）', { noConfig: true });
  if (!v.model) throw new PaintError('还没有填看图模型名（设置 → 看图）', { noConfig: true });
  const system = '你是画手的助手。用简体中文客观、具体地描述这张图：主体、人物外貌和服装、动作姿势、构图和镜头、背景、光线、配色、画风。不要评价，200 字以内。';
  const r = await llm.request(v, { system, messages: [{ role: 'user', content: [{ type: 'image', mime: req.imageMime, b64: req.imageB64 }, { type: 'text', text: '请描述这张图片，用来做改画参考。' }] }], json: false, maxTokens: 700, signal })
    .catch((e) => { if (signal.aborted) throw aborted(signal); return { error: '连接失败：' + (e.cause && e.cause.code || e.message) }; });
  if (signal.aborted) throw aborted(signal);
  if (r.error) throw new PaintError('看图模型出错：' + r.error);
  const text = String(r.data.choices[0].message.content || '').trim();
  if (!text) throw new PaintError('看图模型没有回答');
  return text.slice(0, 1200);
}

async function listenClip(s, req, { signal }) {
  const c = listenCfg(s);
  if (!c.model) throw new PaintError('勾选了“让模型听一段”，但还没有填听曲模型（设置 → 画画）。官方文档只标注 Qwen3-Omni 系列支持音频输入。', { noConfig: true });
  if (!c.apiKey) throw new PaintError('还没有填画画用的 API 密钥（设置 → 画画）', { noConfig: true });
  const ki = llm.keyIssue(c.apiKey, c.keyLabel); if (ki) throw new PaintError(ki, { noConfig: true });
  let res;
  try {
    res = await fetch(c.apiBase + '/chat/completions', {
      method: 'POST', signal, headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + c.apiKey },
      body: JSON.stringify({ model: c.model, max_tokens: 500, messages: [{ role: 'user', content: [
        { type: 'audio_url', audio_url: { url: 'data:audio/wav;base64,' + req.audioClip } },
        { type: 'text', text: '用简体中文描述这段音乐给人的画面感：情绪、氛围、乐器音色、明暗、动静、像什么场景或季节。150 字以内，不要分析乐理术语。' },
      ] }] }),
    });
  } catch (e) { if (signal.aborted) throw aborted(signal); throw new PaintError('听曲模型连不上：' + (e.cause && e.cause.code || e.message)); }
  const text = await res.text().catch(() => '');
  if (!res.ok) throw new PaintError(res.status === 400 ? `听曲模型拒绝了音频输入（400）。这个模型可能不支持直接听音频。${text.slice(0, 120)}` : `听曲模型返回 ${res.status}：${text.slice(0, 160)}`);
  let j; try { j = JSON.parse(text); } catch (e) { throw new PaintError('听曲模型返回的内容不是 JSON'); }
  const out = String(j.choices && j.choices[0] && j.choices[0].message && j.choices[0].message.content || '').trim();
  if (!out) throw new PaintError('听曲模型没有回答');
  return out.slice(0, 800);
}

async function writePrompt(s, req, extra, { signal, onProgress }) {
  const cfg = promptCfg(s);
  if (!req.refine) return plainPrompt(req, extra);
  if (!llm.hasChatApi(cfg) || !cfg.model) {
    if (req.mode === 'text') return plainPrompt(req, extra);
    throw new PaintError('图生图和曲生图需要聊天模型把信息整理成提示词：请在 设置 → 聊天模型 里填好（或者关掉“让绘名整理提示词”）', { noConfig: true });
  }
  onProgress({ stage: 'prompt', chars: 0 });
  let t = 0;
  const r = await llm.request(cfg, {
    system: PROMPT_SYSTEM, messages: [{ role: 'user', content: buildPromptRequest(req, extra) }], stream: true, json: true, maxTokens: 900, signal,
    onText: (acc) => { const now = Date.now(); if (now - t > 150) { t = now; onProgress({ stage: 'prompt', chars: acc.length }); } },
  }).catch((e) => { if (signal.aborted) throw aborted(signal); return { error: '连接失败：' + (e.cause && e.cause.code || e.message) }; });
  if (signal.aborted) throw aborted(signal);
  if (r.error) throw new PaintError('提示词模型出错：' + r.error);
  return parsePromptJSON(r.data.choices[0].message.content);
}

const IMAGE_ERRORS = { 400: '参数不被接受（模型名、尺寸或输入图可能不对）', 401: 'API 密钥不对', 403: '没有权限（密钥或账户未开通这个模型）', 404: '地址或模型名不对', 429: '请求太频繁或额度用完了', 503: '模型太忙了，稍后再试', 504: '平台处理超时' };
function imageBody(cfg, req, pr) {
  const model = req.mode === 'image' ? cfg.i2i : cfg.t2i;
  const body = { model, prompt: pr.prompt };
  const neg = [pr.negative, cfg.negative].filter(Boolean).join('，');
  if (neg) body.negative_prompt = neg.slice(0, 500);
  const size = sizeFor(model, req.aspect);
  if (size) body.image_size = size;
  body.num_inference_steps = cfg.steps;
  if (isKolors(model)) { body.guidance_scale = cfg.guidance; body.batch_size = 1; }
  if (req.seed !== null) body.seed = req.seed;
  if (req.mode === 'image') body.image = req.image;
  return body;
}
async function generateImage(s, req, pr, { signal, onProgress }) {
  const cfg = paintCfg(s);
  if (!cfg.key) throw new PaintError('还没有填画画用的 API 密钥（右键 → 设置 → 画画）。', { noConfig: true });
  { const ki = llm.keyIssue(cfg.key, cfg.keyLabel); if (ki) throw new PaintError(ki, { noConfig: true }); }
  const body = imageBody(cfg, req, pr);
  if (!body.model) throw new PaintError('还没有填绘图模型名（设置 → 画画）', { noConfig: true });
  onProgress({ stage: 'draw', model: body.model, size: body.image_size || '跟随原图' });
  let res;
  try {
    res = await fetch(cfg.base + '/images/generations', { method: 'POST', signal, headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + cfg.key }, body: JSON.stringify(body) });
  } catch (e) { if (signal.aborted) throw aborted(signal); throw new PaintError('连不上绘图接口：' + (e.cause && e.cause.code || e.message)); }
  const text = await res.text().catch(() => '');
  if (!res.ok) {
    let msg = text.slice(0, 160);
    try { const j = JSON.parse(text); msg = String(j.message || j.error && j.error.message || msg).slice(0, 160); } catch (e) {}
    throw new PaintError(`绘图接口返回 ${res.status}${IMAGE_ERRORS[res.status] ? '（' + IMAGE_ERRORS[res.status] + '）' : ''}：${msg}`);
  }
  let j; try { j = JSON.parse(text); } catch (e) { throw new PaintError('绘图接口返回的内容不是 JSON', { invalid: true }); }
  const url = j && Array.isArray(j.images) && j.images[0] && (j.images[0].url || j.images[0].b64_json && 'b64:' + j.images[0].b64_json);
  if (!url || typeof url !== 'string') throw new PaintError('绘图接口没有返回图片', { invalid: true });
  // 链接一小时后失效：马上下载到内存
  onProgress({ stage: 'download' });
  let bytes;
  if (url.startsWith('b64:')) bytes = Buffer.from(url.slice(4), 'base64');
  else {
    if (!/^https?:\/\//i.test(url)) throw new PaintError('绘图接口返回的图片地址不对', { invalid: true });
    let r2;
    try { r2 = await fetch(url, { signal }); } catch (e) { if (signal.aborted) throw aborted(signal); throw new PaintError('图片已生成，但下载失败：' + (e.cause && e.cause.code || e.message)); }
    if (!r2.ok) throw new PaintError(`图片已生成，但下载失败（${r2.status}）`);
    bytes = Buffer.from(await r2.arrayBuffer());
  }
  const type = sniff(bytes);
  if (!type) throw new PaintError('下载到的不是图片文件', { invalid: true });
  return { bytes, type, model: body.model, size: body.image_size || '', seed: Number.isFinite(j.seed) ? j.seed : null, inference: j.timings && Number(j.timings.inference) || null, sent: { ...body, image: body.image ? '（原图）' : undefined } };
}
function sniff(b) {
  if (!b || b.length < 12) return null;
  if (b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47) return 'png';
  if (b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return 'jpg';
  if (b.slice(0, 4).toString('latin1') === 'RIFF' && b.slice(8, 12).toString('latin1') === 'WEBP') return 'webp';
  return null;
}

/* ---------- 窗口和 IPC ---------- */
module.exports = function setupPaint({ getSettings, icon, appDir, sayLine, note }) {
  let win = null, pendingIdea = null;
  const jobs = new Map();
  const send = (ch, v) => { if (win && !win.isDestroyed()) win.webContents.send(ch, v); };
  const fromWin = (e) => win && !win.isDestroyed() && e.sender === win.webContents;

  function open(prefill) {
    if (prefill && typeof prefill === 'object') pendingIdea = { mode: ['text', 'image', 'music'].includes(prefill.mode) ? prefill.mode : 'text', idea: String(prefill.idea || '').slice(0, LIMITS.maxIdea) };
    if (win && !win.isDestroyed()) { win.focus(); if (pendingIdea) { send('paint-prefill', pendingIdea); pendingIdea = null; } return win; }
    win = new BrowserWindow({
      width: 1060, height: 780, minWidth: 820, minHeight: 600, title: '绘名桌宠 · 绘名的画室',
      icon, autoHideMenuBar: true, backgroundColor: '#fbf6f1',
      webPreferences: { preload: path.join(appDir, 'preload-paint.js'), contextIsolation: true },
    });
    win.loadFile(path.join(appDir, 'src', 'paint.html'));
    win.on('closed', () => { for (const j of jobs.values()) j.abort(new PaintError('窗口关闭，已取消', { canceled: true })); jobs.clear(); win = null; });
    return win;
  }

  ipcMain.handle('paint-config', (e) => {
    const s = getSettings(), p = paintCfg(s), pc = promptCfg(s), v = visionCfg(s);
    const prefill = fromWin(e) && pendingIdea ? pendingIdea : null;
    if (prefill) pendingIdea = null;
    return {
      paintReady: !!p.key, keyLabel: p.keyLabel, base: p.base, t2i: p.t2i, i2i: p.i2i, steps: p.steps, guidance: p.guidance,
      promptReady: llm.hasChatApi(pc) && !!pc.model, promptModel: pc.model,
      visionReady: !!(v.apiKey || llm.isLocal(v.apiBase)) && !!v.model, visionModel: v.model,
      audioModel: String(s.paintAudioModel || '').trim(), audioLikely: /omni/i.test(String(s.paintAudioModel || '')),
      timeoutSec: timeoutMs(s) / 1000, limits: LIMITS, aspects: ASPECTS, prefill,
    };
  });
  let timeoutOverride = 0;   // 只给测试脚本用
  const timeoutMs = (s) => timeoutOverride || Math.max(30, Math.min(600, Number(s.paintTimeout) || 180)) * 1000;

  async function run(p, onProgress) {
    const id = String(p.id || Date.now());
    const s = getSettings();
    const ctl = new AbortController();
    jobs.set(id, { abort: (why) => ctl.abort(why) });
    const t0 = Date.now();
    const tick = setInterval(() => onProgress({ id, stage: 'tick', elapsed: Math.round((Date.now() - t0) / 1000) }), 1000);
    const to = setTimeout(() => ctl.abort(new PaintError(`超过 ${timeoutMs(s) / 1000} 秒没有完成，已停止（可以在设置 → 画画 里把超时调长）`, { timeout: true })), timeoutMs(s));
    try {
      const req = cleanReq(p);
      const prog = (x) => onProgress({ id, ...x, elapsed: Math.round((Date.now() - t0) / 1000) });
      // 先检查绘图密钥，免得前面的步骤白跑
      if (!paintCfg(s).key) throw new PaintError('还没有填画画用的 API 密钥（右键 → 设置 → 画画）。', { noConfig: true });
      const extra = {};
      if (req.mode === 'image' && p.describe !== false) { prog({ stage: 'look' }); extra.imageDesc = await describeInput(s, req, { signal: ctl.signal }); }
      if (req.mode === 'music' && req.audioClip) { prog({ stage: 'listen' }); extra.listenDesc = await listenClip(s, req, { signal: ctl.signal }); }
      const pr = await writePrompt(s, req, extra, { signal: ctl.signal, onProgress: prog });
      prog({ stage: 'prompted', prompt: pr.prompt, negative: pr.negative });
      const img = await generateImage(s, req, pr, { signal: ctl.signal, onProgress: prog });
      return { ok: true, id, mode: req.mode, b64: img.bytes.toString('base64'), type: img.type, model: img.model, size: img.size, seed: img.seed, inference: img.inference,
        prompt: pr.prompt, negative: pr.negative, title: pr.title, comment: pr.comment, imageDesc: extra.imageDesc || '', listenDesc: extra.listenDesc || '', elapsed: Math.round((Date.now() - t0) / 1000) };
    } catch (e) {
      const pe = e instanceof PaintError ? e : new PaintError(ctl.signal.aborted ? aborted(ctl.signal).message : String(e && e.message || e), { canceled: ctl.signal.aborted && !(ctl.signal.reason && ctl.signal.reason.timeout) });
      return { error: pe.message, canceled: !!pe.canceled, timeout: !!pe.timeout, noConfig: !!pe.noConfig, invalid: !!pe.invalid };
    } finally { clearInterval(tick); clearTimeout(to); jobs.delete(id); }
  }

  ipcMain.handle('paint-generate', (e, p = {}) => (fromWin(e) ? run(p, (x) => send('paint-progress', x)) : { error: '只能在画室窗口里使用' }));
  ipcMain.on('paint-cancel', (e, id) => { if (!fromWin(e)) return; const j = jobs.get(String(id)); if (j) j.abort(new PaintError('已取消', { canceled: true })); });
  ipcMain.handle('paint-save', async (e, { name, b64, type } = {}) => {
    if (!fromWin(e)) return { error: 'denied' };
    const bytes = Buffer.from(String(b64 || ''), 'base64');
    const t = sniff(bytes);
    if (!t) return { error: '没有可以保存的图片' };
    const safe = (String(name || '绘名的画').replace(/[\\/:*?"<>|\r\n]/g, '_').trim() || '绘名的画').slice(0, 60);
    let dir; try { dir = app.getPath('pictures'); } catch (err) { dir = app.getPath('home'); }
    const r = await dialog.showSaveDialog(win, { title: '保存图片', defaultPath: path.join(dir, `${safe}.${t}`), filters: [{ name: t.toUpperCase() + ' 图片', extensions: [t] }] });
    if (r.canceled || !r.filePath) return { canceled: true };
    try { fs.writeFileSync(r.filePath, bytes); }
    catch (err) { return { error: '保存失败：' + (err.code === 'EACCES' || err.code === 'EPERM' ? '没有写入权限，换个文件夹试试' : err.code === 'ENOSPC' ? '磁盘空间不够' : err.code === 'ENOENT' ? '保存位置的文件夹不存在' : err.message) }; }
    return { ok: true, path: r.filePath };
  });
  ipcMain.handle('paint-copy', (e, { b64 } = {}) => {
    if (!fromWin(e)) return { error: 'denied' };
    const img = nativeImage.createFromBuffer(Buffer.from(String(b64 || ''), 'base64'));
    if (img.isEmpty()) return { error: '这张图片没法复制（格式不支持）' };
    clipboard.writeImage(img);
    return { ok: true };
  });
  ipcMain.on('paint-done', (e, { title, comment } = {}) => {
    if (!fromWin(e)) return;
    const c = String(comment || '').trim().slice(0, 60);
    sayLine(c || `画好了${title ? '，《' + String(title).slice(0, 20) + '》' : ''}。……怎么样？老实说。`, '描けたよ。……どう？正直に言って。', 'proud', 'forward');
    if (note) note(`你刚在画室里画完了一张${title ? '《' + String(title).slice(0, 20) + '》' : '画'}`);
  });
  return { open, _test: { run, cleanReq, imageBody, sizeFor, parsePromptJSON, buildPromptRequest, paintCfg, cancel: (id) => { const j = jobs.get(String(id)); if (j) j.abort(new PaintError('已取消', { canceled: true })); }, setTimeoutMs: (ms) => { timeoutOverride = ms; } } };
};
module.exports.cleanReq = cleanReq;
module.exports.imageBody = imageBody;
module.exports.sizeFor = sizeFor;
module.exports.parsePromptJSON = parsePromptJSON;
module.exports.buildPromptRequest = buildPromptRequest;
module.exports.paintCfg = paintCfg;
module.exports.plainPrompt = plainPrompt;
module.exports.sniff = sniff;
module.exports.LIMITS = LIMITS;
module.exports.SIZES = SIZES;
