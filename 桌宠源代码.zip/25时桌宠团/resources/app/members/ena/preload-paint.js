// 绘名的画室窗口：只暴露这个窗口需要的接口（密钥不会传到页面）
const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('paintAPI', {
  config: () => ipcRenderer.invoke('paint-config'),
  generate: (p) => ipcRenderer.invoke('paint-generate', p),
  cancel: (id) => ipcRenderer.send('paint-cancel', id),
  onProgress: (cb) => ipcRenderer.on('paint-progress', (_e, v) => cb(v)),
  onPrefill: (cb) => ipcRenderer.on('paint-prefill', (_e, v) => cb(v)),
  save: (v) => ipcRenderer.invoke('paint-save', v),
  copy: (v) => ipcRenderer.invoke('paint-copy', v),
  done: (v) => ipcRenderer.send('paint-done', v),
  openSettings: () => ipcRenderer.send('paint-open-settings'),
});
