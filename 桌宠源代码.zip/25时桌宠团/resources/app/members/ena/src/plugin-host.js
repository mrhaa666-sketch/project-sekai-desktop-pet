'use strict';
/* 桌宠页面里的插件宿主：运行插件的 renderer 脚本，给它一个受限的 pet 对象。
 * 插件脚本以 new Function 方式运行（页面的安全策略允许 unsafe-eval，不需要放开外部脚本）。 */
(function () {
  const api = window.petAPI;
  if (!api || !api.onPluginRenderer) return;
  const loaded = new Map();   // id → { msg:Set, unload:[], els:Set, click:Set }
  let layer = null;
  const getLayer = () => {
    if (!layer || !layer.isConnected) {
      layer = document.createElement('div');
      layer.id = 'pluginLayer';
      layer.style.cssText = 'position:fixed;inset:0;pointer-events:none;z-index:40;overflow:hidden';
      document.body.appendChild(layer);
    }
    return layer;
  };
  // 读取 renderer.js / lines.js 里的全局函数和常量（脚本之间共享全局作用域）
  const G = () => ({
    react: typeof react === 'function' ? react : null,
    MOODS: typeof MOODS !== 'undefined' ? MOODS : {},
    ACTIONS: typeof ACTIONS !== 'undefined' ? ACTIONS : {},
    settings: typeof settings !== 'undefined' ? settings : null,
  });
  const report = (id, e) => { try { api.pluginSend(id, { __error: String((e && (e.stack || e.message)) || e) }); } catch (_) {} };

  function makePet(id, rec) {
    return Object.freeze({
      id,
      /** 让她说一句（只在页面里，不经过模型）：pet.say('好呀', { mood: 'happy', action: 'nod', ja: '' }) */
      say(text, o = {}) {
        const { react, MOODS, ACTIONS } = G();
        if (typeof react !== 'function' || !text) return false;
        if (window.Call && Call.active) return false;
        react({ t: String(text).slice(0, 500), m: MOODS[o.mood] ? o.mood : 'calm', a: ACTIONS[o.action] ? o.action : 'none', autoAction: !o.action }, { raw: true, ja: String(o.ja || '') });
        return true;
      },
      /** 发给插件主脚本（api.renderer.onMessage 收到） */
      send(data) { api.pluginSend(id, data); },
      /** 接收插件主脚本 api.renderer.send(data) 发来的消息 */
      onMessage(fn) { rec.msg.add(fn); return () => rec.msg.delete(fn); },
      /** 插件停用或重新加载前调用，用来清理 */
      onUnload(fn) { rec.unload.push(fn); },
      /** 在人物窗口上放一个元素；clickable 为 true 时它能接收鼠标（不会被当成拖动人物） */
      mount(el, { clickable = false } = {}) {
        el.dataset.plugin = id;
        if (clickable) { el.classList.add('plugin-ui'); el.style.pointerEvents = 'auto'; rec.click.add(el); }
        getLayer().appendChild(el);
        rec.els.add(el);
        return el;
      },
      unmount(el) { rec.els.delete(el); rec.click.delete(el); el.remove(); },
      get settings() { const s = G().settings; return s ? JSON.parse(JSON.stringify(s)) : {}; },
      get moods() { return Object.keys(G().MOODS); },
      get actions() { return Object.keys(G().ACTIONS); },
    });
  }

  function unload(id) {
    const rec = loaded.get(id);
    if (!rec) return;
    loaded.delete(id);
    for (const fn of rec.unload.splice(0)) { try { fn(); } catch (e) { report(id, e); } }
    for (const el of rec.els) el.remove();
    rec.els.clear(); rec.click.clear(); rec.msg.clear();
  }
  function load(id, code) {
    unload(id);
    const rec = { msg: new Set(), unload: [], els: new Set(), click: new Set() };
    loaded.set(id, rec);
    try { new Function('pet', '"use strict";\n' + code + '\n//# sourceURL=plugin://' + id + '/renderer.js')(makePet(id, rec)); }
    catch (e) { report(id, e); unload(id); }
  }

  api.onPluginRenderer((m) => {
    if (!m || !m.id) return;
    if (m.op === 'load') load(m.id, String(m.code || ''));
    else if (m.op === 'unload') unload(m.id);
    else if (m.op === 'message') { const rec = loaded.get(m.id); if (rec) for (const fn of rec.msg) { try { fn(m.data); } catch (e) { report(m.id, e); } } }
  });

  window.PetPluginHost = Object.freeze({
    /** renderer.js 的 hitTest 调用：鼠标是否在插件的可点元素上 */
    hit(x, y) {
      for (const rec of loaded.values()) for (const el of rec.click) {
        const r = el.getBoundingClientRect();
        if (r.width > 0 && x >= r.left - 2 && x <= r.right + 2 && y >= r.top - 2 && y <= r.bottom + 2) return true;
      }
      return false;
    },
    list: () => [...loaded.keys()],
  });
})();
