'use strict';
/* 曲生图用的曲子分析（纯计算，不联网）
 *
 * analyzeAudio(samples, sampleRate, onProgress)
 *   对导入的音乐做本地信号分析：节拍/BPM、拍号推测、小节、段落（自相似矩阵 + 新颖度曲线）、
 *   段落之间的重复关系、每段的能量、调性（色度 + Krumhansl 调性轮廓）、节奏密度，
 *   以及整体的力度起伏和音色明暗（频谱重心）。曲生图把这些特征交给提示词模型，转译成画面的色调、光线和动势。
 *
 * 所有结果都只来自曲子本身的数据；推测出来的部分（段落名称、拍号等）会标明“推测”。
 * 浏览器（Web Worker）和 Node（测试）里都能用。
 */
(function (root) {
  const PC = ['C', 'C#', 'D', 'Eb', 'E', 'F', 'F#', 'G', 'Ab', 'A', 'Bb', 'B'];
  const MAJOR = [6.35, 2.23, 3.48, 2.33, 4.38, 4.09, 2.52, 5.19, 2.39, 3.66, 2.29, 2.88];
  const MINOR = [6.33, 2.68, 3.52, 5.38, 2.60, 3.53, 2.54, 4.75, 3.98, 2.69, 3.34, 3.17];

  const r1 = (x) => Math.round(x * 10) / 10;
  const r2 = (x) => Math.round(x * 100) / 100;
  const clamp = (x, a, b) => Math.max(a, Math.min(b, x));
  const mean = (a) => (a.length ? a.reduce((s, x) => s + x, 0) / a.length : 0);
  const std = (a) => { const m = mean(a); return Math.sqrt(mean(a.map((x) => (x - m) * (x - m)))); };
  const mmss = (s) => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`;

  /* ---------- FFT（基 2，原地） ---------- */
  function makeFFT(n) {
    const rev = new Uint32Array(n), bits = Math.log2(n);
    for (let i = 0; i < n; i++) { let r = 0; for (let b = 0; b < bits; b++) r |= ((i >> b) & 1) << (bits - 1 - b); rev[i] = r; }
    const cos = new Float64Array(n / 2), sin = new Float64Array(n / 2);
    for (let i = 0; i < n / 2; i++) { cos[i] = Math.cos(-2 * Math.PI * i / n); sin[i] = Math.sin(-2 * Math.PI * i / n); }
    return function fft(re, im) {
      for (let i = 0; i < n; i++) { const j = rev[i]; if (j > i) { let t = re[i]; re[i] = re[j]; re[j] = t; t = im[i]; im[i] = im[j]; im[j] = t; } }
      for (let size = 2; size <= n; size <<= 1) {
        const half = size >> 1, step = n / size;
        for (let i = 0; i < n; i += size) {
          for (let j = 0, k = 0; j < half; j++, k += step) {
            const a = i + j, b = a + half;
            const tr = re[b] * cos[k] - im[b] * sin[k], ti = re[b] * sin[k] + im[b] * cos[k];
            re[b] = re[a] - tr; im[b] = im[a] - ti; re[a] += tr; im[a] += ti;
          }
        }
      }
    };
  }

  function cosine(a, b) {
    let s = 0, na = 0, nb = 0;
    for (let i = 0; i < a.length; i++) { s += a[i] * b[i]; na += a[i] * a[i]; nb += b[i] * b[i]; }
    return na && nb ? s / Math.sqrt(na * nb) : 0;
  }
  function corr(a, b) {
    const ma = mean(a), mb = mean(b);
    let s = 0, na = 0, nb = 0;
    for (let i = 0; i < a.length; i++) { const x = a[i] - ma, y = b[i] - mb; s += x * y; na += x * x; nb += y * y; }
    return na && nb ? s / Math.sqrt(na * nb) : 0;
  }

  /* ================================================================
     音频分析
     ================================================================ */
  function analyzeAudio(x, sr, onProgress = () => {}) {
    const N = 2048, hop = 512, fr = sr / hop;
    const nFrames = Math.max(0, Math.floor((x.length - N) / hop) + 1);
    const duration = x.length / sr;
    if (duration < 8 || nFrames < 64) throw new Error('曲子太短（少于 8 秒），没法分析节奏和段落');

    // 1) 逐帧特征
    const fft = makeFFT(N), win = new Float64Array(N);
    for (let i = 0; i < N; i++) win[i] = 0.5 - 0.5 * Math.cos(2 * Math.PI * i / (N - 1));
    const re = new Float64Array(N), im = new Float64Array(N);
    const bins = N / 2 + 1, binHz = sr / N;
    const pcOf = new Int8Array(bins).fill(-1);
    for (let k = 1; k < bins; k++) { const f = k * binHz; if (f >= 60 && f <= 5000) pcOf[k] = ((Math.round(12 * Math.log2(f / 440) + 69) % 12) + 12) % 12; }
    const kLow = Math.ceil(200 / binHz), kMid = Math.ceil(2000 / binHz);
    const rms = new Float32Array(nFrames), flux = new Float32Array(nFrames), lowFlux = new Float32Array(nFrames), cent = new Float32Array(nFrames);
    const chroma = new Float32Array(nFrames * 12), band = new Float32Array(nFrames * 3);
    let prev = new Float32Array(bins), cur = new Float32Array(bins);
    for (let f = 0; f < nFrames; f++) {
      const o = f * hop;
      let e = 0;
      for (let i = 0; i < N; i++) { const v = x[o + i]; e += v * v; re[i] = v * win[i]; im[i] = 0; }
      rms[f] = Math.sqrt(e / N);
      fft(re, im);
      let fl = 0, lf = 0, num = 0, den = 0, bl = 0, bm = 0, bh = 0;
      for (let k = 1; k < bins; k++) {
        const m = Math.sqrt(re[k] * re[k] + im[k] * im[k]);
        const lm = Math.log1p(100 * m);
        cur[k] = lm;
        const d = lm - prev[k];
        if (d > 0) { fl += d; if (k < kLow) lf += d; }
        num += k * m; den += m;
        const p = m * m;
        if (k < kLow) bl += p; else if (k < kMid) bm += p; else bh += p;
        if (pcOf[k] >= 0) chroma[f * 12 + pcOf[k]] += m;
      }
      flux[f] = fl; lowFlux[f] = lf; cent[f] = den ? (num / den) * binHz : 0;
      band[f * 3] = Math.log10(1e-9 + bl); band[f * 3 + 1] = Math.log10(1e-9 + bm); band[f * 3 + 2] = Math.log10(1e-9 + bh);
      const t = prev; prev = cur; cur = t;
      if ((f & 255) === 0) onProgress(0.05 + 0.55 * f / nFrames, '逐帧计算频谱');
    }
    onProgress(0.62, '估计节拍');

    // 2) 起音强度曲线（去掉慢变化，只留突增）
    const onset = new Float32Array(nFrames);
    const avgW = Math.round(fr * 0.5);
    {
      let s = 0; const q = [];
      for (let f = 0; f < nFrames; f++) {
        q.push(flux[f]); s += flux[f]; if (q.length > avgW) s -= q.shift();
        onset[f] = Math.max(0, flux[f] - s / q.length);
      }
    }

    // 3) 节拍：起音曲线的自相关，在 55–200 BPM 之间找周期，偏好 120 附近
    const lagMin = Math.floor(fr * 60 / 200), lagMax = Math.ceil(fr * 60 / 55);
    const om = mean(Array.from(onset));
    const oc = Float32Array.from(onset, (v) => v - om);
    const ac = new Float64Array(lagMax * 2 + 2);
    for (let L = lagMin; L <= Math.min(lagMax * 2, nFrames - 1); L++) {
      let s = 0; for (let f = 0; f + L < nFrames; f++) s += oc[f] * oc[f + L];
      ac[L] = s / (nFrames - L);
    }
    let best = 0, bestL = 0;
    const scores = [];
    for (let L = lagMin; L <= lagMax; L++) {
      const bpm = 60 * fr / L;
      const w = Math.exp(-0.5 * Math.pow(Math.log2(bpm / 120) / 0.9, 2));
      const s = (ac[L] + 0.5 * (ac[2 * L] || 0)) * w;
      scores.push(s);
      if (s > best) { best = s; bestL = L; }
    }
    // 抛物线插值让周期更准
    let period = bestL;
    if (bestL > lagMin && bestL < lagMax) {
      const a = ac[bestL - 1], b = ac[bestL], c = ac[bestL + 1], den = a - 2 * b + c;
      if (den) period = bestL + clamp(0.5 * (a - c) / den, -0.5, 0.5);
    }
    // 倍速/半速纠正：慢于 80 时，如果一半周期上也有明显的规律，就按两倍速；快于 170 时反过来
    const acAt = (L) => { const i = Math.round(L); return ac[i] || 0; };
    if (60 * fr / period < 80 && acAt(period / 2) >= 0.45 * acAt(period) && 120 * fr / period <= 200) period /= 2;
    else if (60 * fr / period > 170 && acAt(period * 2) >= 0.8 * acAt(period)) period *= 2;
    let bpm = 60 * fr / period;
    const sm = mean(scores), ss = std(scores) || 1;
    // 把握程度：节拍周期上的自相关占总能量的比例（噪声、长音铺底这类没有节拍的音乐会很低）
    let ac0 = 0; for (let f = 0; f < nFrames; f++) ac0 += oc[f] * oc[f]; ac0 /= nFrames;
    const periodicity = ac0 > 0 ? (ac[bestL] || 0) / ac0 : 0;
    const tempoConf = clamp(periodicity / 0.35, 0, 1);
    const tempoReliable = best > 0 && periodicity > 0.12 && (best - sm) / ss > 1.2;

    // 节拍相位：哪一个起点让节拍格子上的起音总和最大
    let bestPh = 0, bestSum = -1;
    for (let ph = 0; ph < period; ph += 0.5) {
      let s = 0; for (let t = ph; t < nFrames; t += period) s += onset[Math.round(t)] || 0;
      if (s > bestSum) { bestSum = s; bestPh = ph; }
    }
    const beatFrames = [];
    for (let t = bestPh; t < nFrames; t += period) beatFrames.push(t);

    // 4) 拍号推测：3 拍还是 4 拍一小节（比较按小节周期的低频起音规律）
    const lowAt = (t) => { let s = 0; for (let d = -2; d <= 2; d++) s += lowFlux[Math.round(t) + d] || 0; return s; };
    const meterScore = (m) => {
      let bestOff = 0, bestV = -1;
      for (let off = 0; off < m; off++) {
        let on = 0, offv = 0, n1 = 0, n2 = 0;
        beatFrames.forEach((t, i) => { if ((i - off) % m === 0) { on += lowAt(t); n1++; } else { offv += lowAt(t); n2++; } });
        const v = (n1 ? on / n1 : 0) / ((n2 ? offv / n2 : 0) + 1e-9);
        if (v > bestV) { bestV = v; bestOff = off; }
      }
      return { v: bestV, off: bestOff };
    };
    const m4 = meterScore(4), m3 = meterScore(3);
    const beatsPerBar = m3.v > m4.v * 1.15 ? 3 : 4;
    const barOff = beatsPerBar === 3 ? m3.off : m4.off;

    // 5) 小节（节拍不可靠时退回每 2 秒一格）
    let units = [];   // [{start, end}] 单位：帧
    if (tempoReliable && beatFrames.length >= beatsPerBar * 6) {
      for (let i = barOff; i + beatsPerBar <= beatFrames.length; i += beatsPerBar) units.push({ start: beatFrames[i], end: beatFrames[i + beatsPerBar] || nFrames });
      if (barOff > 0) units.unshift({ start: 0, end: beatFrames[barOff], pickup: true });
    } else {
      const step = Math.round(fr * 2);
      for (let f = 0; f < nFrames; f += step) units.push({ start: f, end: Math.min(nFrames, f + step) });
    }
    onProgress(0.72, '划分段落');

    // 每个单位的特征：色度（12）+ 三个频段（3）+ 响度（1）
    const feats = units.map((u) => {
      const a = Math.max(0, Math.floor(u.start)), b = Math.max(a + 1, Math.min(nFrames, Math.floor(u.end)));
      const ch = new Float64Array(12), bd = new Float64Array(3);
      let e = 0, on = 0;
      for (let f = a; f < b; f++) {
        for (let k = 0; k < 12; k++) ch[k] += chroma[f * 12 + k];
        for (let k = 0; k < 3; k++) bd[k] += band[f * 3 + k];
        e += rms[f]; on += onset[f];
      }
      const n = b - a, cs = ch.reduce((s, v) => s + v, 0) || 1;
      return { chroma: Array.from(ch, (v) => v / cs), band: Array.from(bd, (v) => v / n), rms: e / n, onset: on / n };
    });
    // 统一尺度：每一维减均值除标准差
    const dims = feats.map((f) => [...f.chroma, ...f.band, Math.log10(1e-6 + f.rms)]);
    const D = dims[0].length, mu = [], sd = [];
    for (let d = 0; d < D; d++) { const col = dims.map((v) => v[d]); mu.push(mean(col)); sd.push(std(col) || 1); }
    // 标准化之后再加权：音色/力度（频段、响度）的变化对段落划分更重要，12 维色度合起来不能盖过它们
    const W = dims[0].map((_, d) => (d < 12 ? 0.6 : d < 15 ? 1.6 : 2.4));
    const Z = dims.map((v) => v.map((x, d) => W[d] * (x - mu[d]) / sd[d]));
    const U = Z.length;
    const S = Z.map((a) => Z.map((b) => cosine(a, b)));

    // 新颖度：沿对角线滑动的棋盘核
    const K = U >= 24 ? 4 : U >= 12 ? 3 : 2;
    const nov = new Float64Array(U);
    for (let i = K; i <= U - K; i++) {
      let s = 0, n = 0;
      for (let a = -K; a < K; a++) for (let b = -K; b < K; b++) {
        const w = Math.exp(-((a + 0.5) ** 2 + (b + 0.5) ** 2) / (2 * K * K));
        const sign = (a < 0) === (b < 0) ? 1 : -1;
        s += sign * w * S[i + a][i + b]; n += w;
      }
      nov[i] = Math.max(0, s / n);
    }
    const nm = mean(Array.from(nov)), ns = std(Array.from(nov));
    const nmed = Array.from(nov).sort((a, b) => a - b)[Math.floor(U / 2)];
    const minLen = tempoReliable ? 4 : 4;
    const peaks = [];
    for (let i = 1; i < U - 1; i++) {
      if (!(nov[i] >= nov[i - 1] && nov[i] >= nov[i + 1])) continue;
      // 显著性：峰值要明显高于前后 K 个单位里的最低点（避免把平缓的起伏当成边界）
      let lo = Infinity; for (let k = Math.max(0, i - K); k <= Math.min(U - 1, i + K); k++) lo = Math.min(lo, nov[k]);
      if (nov[i] > Math.max(0.06, nmed + 0.2 * ns) && nov[i] - lo > 0.05) peaks.push(i);
    }
    // 太近的边界只留更明显的那个
    peaks.sort((a, b) => nov[b] - nov[a]);
    const bounds = [];
    for (const p of peaks) if (bounds.every((q) => Math.abs(q - p) >= minLen) && p >= minLen - 1 && U - p >= minLen - 1) bounds.push(p);
    bounds.sort((a, b) => a - b);
    const maxSections = clamp(Math.round(duration / 14), 3, 14);
    while (bounds.length + 1 > maxSections) {   // 段落太碎时去掉最弱的边界
      let wi = 0; for (let i = 1; i < bounds.length; i++) if (nov[bounds[i]] < nov[bounds[wi]]) wi = i;
      bounds.splice(wi, 1);
    }
    const edges = [0, ...bounds, U];
    const unitTime = (i) => (i >= U ? duration : units[i].start / fr);
    let secs = [];
    for (let i = 0; i + 1 < edges.length; i++) {
      const a = edges[i], b = edges[i + 1];
      const idx = []; for (let k = a; k < b; k++) idx.push(k);
      const vec = Z[0].map((_, d) => mean(idx.map((k) => Z[k][d])));
      const e = mean(idx.map((k) => feats[k].rms));
      const on = mean(idx.map((k) => feats[k].onset));
      const c = mean(idx.map((k) => mean(Array.from(cent.subarray(Math.floor(units[k].start), Math.max(Math.floor(units[k].start) + 1, Math.floor(units[k].end)))))));
      secs.push({ a, b, units: b - a, start: unitTime(a), end: unitTime(b), vec, rms: e, onset: on, centroid: c });
    }
    onProgress(0.85, '比较段落');

    // 6) 段落之间的相似（块平均）→ 重复关系
    const blockSim = (p, q) => {
      // 长度对齐比较：取较短那段的长度，在较长那段里滑动找最像的位置
      const lp = p.b - p.a, lq = q.b - q.a, L = Math.min(lp, lq);
      let bestS = -1;
      for (let off = 0; off <= Math.abs(lp - lq); off++) {
        let s = 0;
        for (let k = 0; k < L; k++) s += lp >= lq ? S[p.a + off + k][q.a + k] : S[p.a + k][q.a + off + k];
        bestS = Math.max(bestS, s / L);
      }
      return bestS * Math.min(1, (2 * L) / (lp + lq) + 0.25);
    };
    const n = secs.length;
    const sim = secs.map((p) => secs.map((q) => (p === q ? 1 : blockSim(p, q))));
    const group = new Array(n).fill(-1);
    let g = 0;
    for (let i = 0; i < n; i++) {
      if (group[i] >= 0) continue;
      group[i] = g;
      for (let j = i + 1; j < n; j++) if (group[j] < 0 && sim[i][j] > 0.55) group[j] = g;
      g++;
    }
    const letters = 'ABCDEFGHIJKLMNOP';
    const eDb = secs.map((s) => 20 * Math.log10(1e-6 + s.rms));
    const eMax = Math.max(...eDb), eMed = [...eDb].sort((a, b) => a - b)[Math.floor(n / 2)];

    // 7) 段落名称（推测）：响亮且重复出现的 → 副歌
    const groupInfo = {};
    secs.forEach((s, i) => { (groupInfo[group[i]] = groupInfo[group[i]] || { idx: [], e: [] }).idx.push(i); groupInfo[group[i]].e.push(eDb[i]); });
    let chorusG = -1, bestE = -Infinity;
    for (const [k, v] of Object.entries(groupInfo)) {
      const em = mean(v.e) + (v.idx.length >= 2 ? 3 : 0);
      if (v.idx.length >= 2 && em > bestE && !(v.idx.length === 1 && v.idx[0] === 0)) { bestE = em; chorusG = +k; }
    }
    if (chorusG < 0) {   // 没有重复：最响的那段当高潮
      let bi = 0; eDb.forEach((v, i) => { if (v > eDb[bi] && i > 0) bi = i; });
      chorusG = group[bi];
    }
    const names = new Array(n).fill('');
    const firstChorus = group.indexOf(chorusG);
    secs.forEach((s, i) => {
      if (group[i] === chorusG) names[i] = '副歌';
      else if (i === 0 && n > 2 && s.end - s.start <= 30 && eDb[i] < eMed) names[i] = '前奏';
      else if (i === n - 1 && n > 2 && eDb[i] < eMed - 1) names[i] = '尾奏';
    });
    secs.forEach((s, i) => {
      if (names[i]) return;
      const nextIsChorus = names[i + 1] === '副歌';
      const maxUnits = Math.max(...secs.map((q) => q.units));
      if (nextIsChorus && i > 1 && names[i - 1] !== '前奏' && names[i - 1] !== '副歌' && s.units <= Math.max(4, maxUnits / 2) && eDb[i] > (eDb[i - 1] ?? -99)) names[i] = '预副歌';
      else if (i > firstChorus && firstChorus >= 0 && groupInfo[group[i]].idx.length === 1 && secs.slice(i + 1).some((_, k) => names[i + 1 + k] === '副歌')) names[i] = '桥段';
      else names[i] = '主歌';
    });
    // 编号：主歌1、主歌2……
    const count = {}, total = {};
    names.forEach((nm) => { total[nm] = (total[nm] || 0) + 1; });
    const labels = names.map((nm) => { count[nm] = (count[nm] || 0) + 1; return total[nm] > 1 && !['前奏', '尾奏'].includes(nm) ? nm + count[nm] : nm; });

    // 8) 调性
    const chTotal = new Float64Array(12);
    for (let f = 0; f < nFrames; f++) for (let k = 0; k < 12; k++) chTotal[k] += chroma[f * 12 + k];
    let key = { tonic: 'C', mode: '大调', score: -2 };
    const keyScores = [];
    for (let t = 0; t < 12; t++) {
      const rot = Array.from({ length: 12 }, (_, k) => chTotal[(k + t) % 12]);
      const sM = corr(rot, MAJOR), sm2 = corr(rot, MINOR);
      keyScores.push(sM, sm2);
      if (sM > key.score) key = { tonic: PC[t], mode: '大调', score: sM };
      if (sm2 > key.score) key = { tonic: PC[t], mode: '小调', score: sm2 };
    }
    const sortedKS = keyScores.sort((a, b) => b - a);
    const keyConf = clamp((sortedKS[0] - sortedKS[2]) * 4, 0, 1);

    // 9) 整体情绪特征（只是从数据推出来的描述，供作画参考）
    const dyn = Math.max(...eDb) - Math.min(...eDb);
    const centAll = mean(secs.map((s) => s.centroid));
    const tempoWord = !tempoReliable ? '节奏不明显（可能是自由节奏或长音为主）' : bpm < 76 ? '慢' : bpm < 100 ? '中慢' : bpm < 126 ? '中速' : bpm < 150 ? '偏快' : '很快';
    const moodWords = [];
    if (key.mode === '小调') moodWords.push('小调色彩（偏忧郁、内省）'); else moodWords.push('大调色彩（偏明亮）');
    if (dyn > 9) moodWords.push('前后起伏大，有明显的高潮');
    else if (dyn < 4) moodWords.push('整体力度变化小，比较平稳');
    if (centAll > 2600) moodWords.push('音色偏亮'); else if (centAll < 1400) moodWords.push('音色偏暗、偏温暖');

    // 10) 每段的长度估计（行数、字数沿用分析器原有格式，曲生图只用段落、力度和节奏密度）
    const barSec = tempoReliable ? beatsPerBar * 60 / bpm : 2;
    const barsPerLine = Math.max(1, Math.round(3.8 / barSec));
    const onsetRateAll = mean(secs.map((s) => s.onset));
    const sections = secs.map((s, i) => {
      const len = s.end - s.start;
      const instrumental = labels[i] === '前奏' || labels[i] === '尾奏';
      const lines = instrumental ? 0 : clamp(Math.round(s.units / barsPerLine), 1, 12);
      const lineSec = lines ? len / lines : 0;
      const busy = clamp(s.onset / (onsetRateAll || 1), 0.6, 1.5);
      const rate = clamp(2.2 * busy * (names[i] === '副歌' ? 0.9 : 1), 1.3, 3.4);
      const syl = lines ? clamp(Math.round(lineSec * rate), 4, 16) : 0;
      return {
        label: labels[i], repeat: letters[group[i]] || '?', start: r1(s.start), end: r1(s.end), time: `${mmss(s.start)}–${mmss(s.end)}`,
        bars: tempoReliable ? s.units : null, seconds: r1(len),
        energy: r1(eDb[i] - eMax), energyLevel: eDb[i] - eMax > -3 ? '强' : eDb[i] - eMax > -8 ? '中' : '弱',
        density: busy > 1.15 ? '密' : busy < 0.85 ? '疏' : '中', lines, syllables: syl ? `${Math.max(3, syl - 1)}–${syl + 1}` : '', instrumental,
      };
    });
    onProgress(0.95, '整理结果');

    // 画图用：每 0.25 秒的响度
    const step = Math.max(1, Math.round(fr / 4));
    const curve = [];
    for (let f = 0; f < nFrames; f += step) { let m = 0; for (let k = f; k < Math.min(nFrames, f + step); k++) m = Math.max(m, rms[k]); curve.push(r2(m)); }

    return {
      kind: 'audio',
      method: '本地信号分析：频谱 → 起音强度自相关估 BPM → 节拍网格与小节 → 每小节色度/频段/响度特征 → 自相似矩阵新颖度划分段落 → 段落相似度找重复 → Krumhansl 调性轮廓估调',
      duration: r1(duration), sampleRate: sr,
      tempo: { bpm: tempoReliable ? Math.round(bpm) : null, raw: r1(bpm), confidence: r2(tempoConf), reliable: tempoReliable, word: tempoWord },
      meter: { beatsPerBar, guessed: true, text: tempoReliable ? `${beatsPerBar}/4（推测）` : '无法判断' },
      key: { tonic: key.tonic, mode: key.mode, text: `${key.tonic} ${key.mode}`, confidence: r2(keyConf) },
      mood: moodWords, brightness: Math.round(centAll), dynamicRangeDb: r1(dyn), barsPerLine, barSeconds: r2(barSec),
      sections, curve,
      notes: [
        '段落名称（主歌/副歌等）是根据重复和响度推测的，不一定和原曲完全一致。',
        tempoReliable ? '拍号是推测的；BPM 可能是实际速度的一半或两倍。' : '节拍不够清晰，段落按每 2 秒为单位划分。',
        '本地分析只看信号特征，听不出有没有人声，也不识别歌词。',
      ],
    };
  }


  /* ---------- 交给提示词模型的文字摘要（曲生图） ---------- */
  function promptBrief(a) {
    const L = [];
    L.push(`时长 ${a.duration} 秒；速度 ${a.tempo.reliable ? '约 ' + a.tempo.bpm + ' BPM（' + a.tempo.word + '）' : '节奏不明显（' + a.tempo.word + '）'}；调性 ${a.key.text}（把握 ${Math.round(a.key.confidence * 100)}%）；整体：${a.mood.join('；')}；力度起伏约 ${a.dynamicRangeDb} dB。`);
    L.push('段落走向（名称是推测，字母相同表示音乐相近）：' + a.sections.map((s) => `${s.label}${s.repeat} ${s.time} 力度${s.energyLevel} 节奏${s.density}`).join('；'));
    const peak = a.sections.reduce((m, s) => (s.energy > m.energy ? s : m), a.sections[0]);
    if (peak) L.push(`最响的段落在 ${peak.time}（${peak.label}）。`);
    return L.join('\n');
  }

  root.MusicAnalysis = { analyzeAudio, promptBrief };
  if (typeof module !== 'undefined' && module.exports) module.exports = root.MusicAnalysis;
})(typeof self !== 'undefined' ? self : typeof globalThis !== 'undefined' ? globalThis : this);
