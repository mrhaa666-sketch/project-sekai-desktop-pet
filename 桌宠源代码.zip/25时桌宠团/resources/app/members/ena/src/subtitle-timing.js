'use strict';
// Pure timing logic shared by renderer and regression tests. Positions are Unicode characters.
(function (root) {
  function timeline(text, words, duration) {
    const n = Array.from(text || '').length;
    const ms = Number.isFinite(duration) && duration > 0 ? duration : 1;
    const times = Array.from({ length: n }, (_, i) => ms * i / Math.max(1, n));
    const valid = (Array.isArray(words) ? words : []).filter(w =>
      Number.isInteger(w.b) && Number.isInteger(w.e) && w.b >= 0 && w.e > w.b && w.e <= n &&
      Number.isFinite(w.t0) && Number.isFinite(w.t1) && w.t0 >= 0 && w.t1 > w.t0 && w.t0 < ms
    ).sort((a,b) => a.b - b.b);
    const anchors = new Map();
    for (const w of valid) for (let i=w.b; i<w.e; i++)
      anchors.set(i, Math.min(ms, w.t0 + (Math.min(ms,w.t1)-w.t0)*(i-w.b)/(w.e-w.b)));
    // Fill untimed punctuation/gaps between timed words without destroying pauses inside valid words.
    if (anchors.size) {
      const points = [[-1,0], ...anchors.entries(), [n,ms]].sort((a,b)=>a[0]-b[0]);
      for (let p=0;p<points.length-1;p++) {
        const [a,t0]=points[p], [b,t1]=points[p+1];
        for(let i=Math.max(0,a);i<b;i++) times[i]=anchors.has(i)?anchors.get(i):t0+(Math.max(t0,t1)-t0)*(i-a)/(b-a);
      }
    }
    for(let i=1;i<n;i++) times[i]=Math.max(times[i-1],times[i]);
    return times;
  }
  const api = { timeline };
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.SubtitleTiming = api;
})(typeof globalThis !== 'undefined' ? globalThis : this);
