'use strict';
/* 记忆窗口的标签：支持键盘（Tab 选中后按回车或空格切换） */
document.querySelectorAll('.tab').forEach((t) => t.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); t.click(); }
}));
