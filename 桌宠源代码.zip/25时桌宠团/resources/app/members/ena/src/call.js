'use strict';
/* 语音通话（第一版：轮流对话）
 * 你说话 → 说话检测（静音够久算说完）→ 语音识别 → 大模型回日语 + 中文字幕 → 按句合成日语 → 播放日语、同时显示中文字幕
 *
 * 这一版的限制（照实说明）：
 *  - 识别是「说完一句再整段识别」，不是边说边出字的流式识别。
 *  - 绘名说话时麦克风照常开着，但不提交识别（半双工），所以不会把绘名自己的声音当成你说的话；
 *    想打断绘名，点「停止」按钮。开口直接打断，留到以后再做。
 *  - 字幕按句出现；日语优先使用配音时间点跟读，缺失时按时长估算；中文按句内进度高亮。
 */

const Call = {
  active: false,
  callId: Date.now() % 1e9,   // 每次通话一个编号（从启动时间开始，页面重新加载也不会和之前取消过的编号重复）
  turnId: 0,          // 每一轮一个编号；编号变了，旧结果一律丢弃
  state: 'idle',
  muted: false,
  startedAt: 0,
  // 麦克风
  stream: null, ctx: null, node: null, srcNode: null,
  // 说话检测
  floor: 0.004, calib: 0, capturing: false, ptt: false,
  frames: [], pre: [], voiced: 0, silent: 0, startFrames: 0,
  cooldownUntil: 0,
  // 回复
  reply: null, heard: 0, replying: false,
  timers: [],
  times: {},
};
window.Call = Call;

const FRAME_MS = 20;
const LEVELS = {            // 说话检测灵敏度：开始说话要比环境噪声大多少倍 / 最低音量
  low:    { ratio: 4.0, min: 0.020 },
  normal: { ratio: 3.0, min: 0.012 },
  high:   { ratio: 2.2, min: 0.007 },
};
const MIN_SPEECH_MS = 350;  // 有声部分太短（咳嗽、敲桌子）就不提交
const PRE_ROLL = 15;        // 开始说话前多留 300ms，免得吃掉第一个字
const START_FRAMES = 4;     // 连续 80ms 够响才算开始说话
const AFTER_REPLY_MS = 500; // 绘名说完后稍等一下再开始听，避开余音

const $c = (id) => document.getElementById(id);
// 排查用日志：只记事件和音量，不记你说的内容，也不录音
function dbg(msg) { try { api && api.callDebug(msg); } catch (e) {} }
const callKey = () => `${Call.callId}:${Call.turnId}`;

/* ---------- 界面 ---------- */
const STATE_TEXT = {
  idle: '', starting: '正在打开麦克风…', listening: '正在聆听', capturing: '在听你说…',
  recognizing: '识别中…', thinking: '思考中…', replying: '正在回复', muted: '麦克风已静音', error: '出错了',
};
function setState(st, detail) {
  if (st !== Call.state || detail) dbg(`状态 ${Call.state} → ${st}${detail ? '（' + detail + '）' : ''}`);
  Call.state = st;
  const p = $c('call');
  if (!p) return;
  p.dataset.state = st;
  $c('callState').textContent = detail || STATE_TEXT[st] || '';
  $c('callStop').disabled = !(st === 'thinking' || st === 'replying');
}
function showUserText(t, cls = '') {
  const el = $c('callUser');
  el.textContent = t ? '你：' + t : '';
  el.className = cls;
}
function tickTimer() {
  if (!Call.active) return;
  const s = Math.floor((Date.now() - Call.startedAt) / 1000);
  $c('callTime').textContent = String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0');
}

/* ---------- 开始 / 结束 ---------- */
Call.start = async function () {
  if (Call.active) return;
  if (!api) { say('（通话只能在桌宠程序里用）', 3000); return; }
  if (typeof closeChat === 'function' && chatOpen) closeChat();
  speechSeq++; // 使普通台词尚未返回的配音失效
  stopVoice(); hideBubble();
  Call.active = true;
  Call.carry = null; Call.lastAsk = null; Call.echo = null;
  Call.callId++;
  Call.turnId++; // 页面生命周期内单调递增，拒绝上一通话迟到的结果
  Call.muted = false;
  Call.startedAt = Date.now();
  $c('call').classList.add('show');
  $c('callBtn').classList.remove('show');
  chatBtn.classList.remove('show');
  setIgnore(false);
  api.focus();
  showUserText('');
  tickTimer();
  Call.timers.push(setInterval(tickTimer, 1000));
  $c('callMute').classList.remove('on');
  wakeIfDozing(false);

  dbg(`开始通话：聊天API ${settings.hasApi ? '有' : '无'}，识别API ${settings.hasAsr ? '有' : '无'}，配音 ${settings.hasVoice ? '有' : '无'}`);
  if (!settings.hasApi) { setState('error', '还没填聊天 API（右键 → 设置）'); return; }
  if (!settings.hasAsr) { setState('error', '还没填语音识别 API（右键 → 设置）'); return; }
  await openMic();
};

async function openMic() {
  // 每次初始化拥有自己的资源；重试/挂断后，旧等待只能清理旧资源。
  closeMic();
  const myCall = Call.callId, attempt = Call.micAttempt;
  const current = () => Call.active && myCall === Call.callId && attempt === Call.micAttempt;
  let stream = null, ctx = null, node = null, srcNode = null;
  const dispose = () => {
    try { if (node) { node.port.onmessage = null; node.disconnect(); } } catch (e) {}
    try { if (srcNode) srcNode.disconnect(); } catch (e) {}
    try { if (stream) stream.getTracks().forEach(t => { t.onended = null; t.stop(); }); } catch (e) {}
    try { if (ctx && ctx.state !== 'closed') { const p = ctx.close(); if (p && p.catch) p.catch(() => {}); } } catch (e) {}
    if (Call.stream === stream) Call.stream = null;
    if (Call.ctx === ctx) Call.ctx = null;
    if (Call.node === node) Call.node = null;
    if (Call.srcNode === srcNode) Call.srcNode = null;
  };
  setState('starting');
  try {
    stream = await navigator.mediaDevices.getUserMedia({
      audio: { channelCount: 1, echoCancellation: true, noiseSuppression: true, autoGainControl: true },
    });
    if (!current()) { dispose(); return; }
    Call.stream = stream;
    stream.getAudioTracks().forEach(t => {
      t.onended = () => { if (current()) { setState('error', '麦克风断开了，点这里重试'); closeMic(); } };
    });
    const tr = stream.getAudioTracks()[0];
    dbg(`麦克风：${tr ? tr.label : '无'}`);
    ctx = new AudioContext({ sampleRate: 16000 });
    Call.ctx = ctx;
    if (ctx.state !== 'running') await ctx.resume();
    if (!current()) { dispose(); return; }
    await ctx.audioWorklet.addModule('vad-worklet.js');
    if (!current()) { dispose(); return; }
    srcNode = ctx.createMediaStreamSource(stream);
    node = new AudioWorkletNode(ctx, 'frame-tap');
    node.port.onmessage = e => { if (current()) onFrame(e.data); };
    srcNode.connect(node);
    Call.srcNode = srcNode; Call.node = node;
    resetVad();
    Call.calib = 15;
    Call.levels = { max: 0, frames: 0, quietSince: Date.now() };
    dbg(`音频处理：${ctx.state}，采样率 ${ctx.sampleRate}`);
    setState('listening');
    Call.micTimer = setInterval(() => { if (current()) checkMicLevel(); }, 3000);
    Call.timers.push(Call.micTimer);
  } catch (e) {
    const valid = current();
    dispose();
    if (!valid) return;
    dbg(`麦克风打开失败：${e && e.name} ${e && e.message}`);
    const msg = e && e.name === 'NotAllowedError' ? '没有麦克风权限（Windows 设置 → 隐私 → 麦克风）'
      : e && e.name === 'NotFoundError' ? '没找到麦克风' : '麦克风打不开：' + (e && e.message);
    setState('error', msg + '，点这里重试');
    resetVad();
  }
}

function closeMic() {
  Call.micAttempt = (Call.micAttempt || 0) + 1;
  if (Call.micTimer) { clearInterval(Call.micTimer); Call.micTimer = null; }
  try { if (Call.node) { Call.node.port.onmessage = null; Call.node.disconnect(); } } catch (e) {}
  try { if (Call.srcNode) Call.srcNode.disconnect(); } catch (e) {}
  try { if (Call.stream) Call.stream.getTracks().forEach(t => { t.onended = null; t.stop(); }); } catch (e) {}
  try { if (Call.ctx && Call.ctx.state !== 'closed') { const p = Call.ctx.close(); if (p && p.catch) p.catch(() => {}); } } catch (e) {}
  Call.node = Call.srcNode = Call.ctx = null;
  Call.lastStream = Call.stream; Call.stream = null;
  resetVad();
}

Call.end = function () {
  if (!Call.active) return;
  Call.stopReply(false);
  api.callCancel(String(Call.callId));      // 取消这次通话里所有还没回来的请求
  Call.active = false;
  Call.callId++;                            // 迟到的结果因为编号对不上，全部丢弃
  closeMic();
  Call.timers.forEach((t) => clearInterval(t)); Call.timers = [];
  $c('call').classList.remove('show');
  setState('idle');
  hideBubble();
  setIgnore(true);
  if (pendingRemind) { const t = pendingRemind; pendingRemind = null; setTimeout(() => remind(t), 800); }
};

Call.toggleMute = function () {
  if (!Call.active) return;
  Call.muted = !Call.muted;
  $c('callMute').classList.toggle('on', Call.muted);
  if (Call.stream) Call.stream.getAudioTracks().forEach((t) => { t.enabled = !Call.muted; });
  if (Call.muted) { resetVad(); if (Call.state === 'listening' || Call.state === 'capturing') setState('muted'); }
  else if (Call.state === 'muted') setState('listening');
};

/* ---------- 说话检测 ---------- */
function resetVad() {
  Call.bargeFrames = 0; Call.bargeWin = [];
  Call.capturing = false; Call.frames = []; Call.pre = []; Call.voiced = 0; Call.silent = 0; Call.startFrames = 0;
}
function rmsOf(f) { let s = 0; for (let i = 0; i < f.length; i++) s += f[i] * f[i]; return Math.sqrt(s / f.length); }

function checkMicLevel() {
  if (!Call.active || !Call.levels) return;
  const L = Call.levels;
  dbg(`3秒内：收到 ${L.frames} 帧，最大音量 ${L.max.toFixed(4)}，环境噪声 ${Call.floor.toFixed(4)}，门槛 ${startThreshold().toFixed(4)}，状态 ${Call.state}`);
  if (L.frames === 0) {
    if (Call.state === 'listening' && !/收不到/.test($c('callState').textContent)) setState('listening', '收不到麦克风数据，试试挂断重拨');
  } else if (L.max < 0.002 && !Call.muted) {
    if (Date.now() - L.quietSince > 6000 && Call.state === 'listening' && !/听不到/.test($c('callState').textContent)) setState('listening', '听不到声音：检查麦克风有没有选对、Windows 麦克风权限');
  } else {
    L.quietSince = Date.now();
    if (Call.state === 'listening' && $c('callState').textContent !== STATE_TEXT.listening && /听不到|收不到/.test($c('callState').textContent)) setState('listening');
  }
  L.max = 0; L.frames = 0;
}
function startThreshold() {
  const lv = LEVELS[settings.vadLevel] || LEVELS.normal;
  return Math.max(lv.min, Call.floor * lv.ratio);
}

function onFrame(f) {
  if (!Call.active) return;
  const rms = rmsOf(f);
  if (Call.levels) { Call.levels.frames++; if (rms > Call.levels.max) Call.levels.max = rms; }
  $c('callDot').style.setProperty('--lv', Math.min(1, rms * 25).toFixed(2));
  if (Call.muted) return;
  // 开口打断（设置里打开时）：绘名在思考或说话时，听到你明显在说话就停下来听你说
  if (settings.bargeIn && (Call.state === 'replying' || Call.state === 'thinking')) { bargeCheck(f, rms); return; }
  // 只在「聆听」阶段收声；识别、思考、绘名说话时不提交（半双工）
  const open = (Call.state === 'listening' || Call.state === 'capturing') && Date.now() >= Call.cooldownUntil;
  if (!open) return;   // 识别、思考、绘名说话时不收声，也不更新环境噪声
  if (Call.calib > 0) { Call.calib--; updateFloor(rms, 0.3); return; }

  const lv = LEVELS[settings.vadLevel] || LEVELS.normal;
  const startTh = Math.max(lv.min, Call.floor * lv.ratio);
  const keepTh = Math.max(lv.min * 0.6, Call.floor * lv.ratio * 0.55);   // 说话中降低门槛，自然停顿不算结束

  if (Call.ptt) { Call.frames.push(f); if (rms > keepTh) Call.voiced++; return; }

  if (!Call.capturing) {
    Call.pre.push(f); if (Call.pre.length > PRE_ROLL) Call.pre.shift();
    if (rms > startTh) {
      if (++Call.startFrames >= START_FRAMES) {
        Call.capturing = true;
        Call.frames = Call.pre.slice(); Call.pre = [];
        Call.voiced = Call.startFrames; Call.silent = 0;
        Call.times = { speechStart: performance.now() };
        setState('capturing');
      }
    } else { Call.startFrames = 0; updateFloor(rms); }
    return;
  }
  Call.frames.push(f);
  if (rms > keepTh) { Call.voiced++; Call.silent = 0; } else Call.silent++;
  const silenceMs = Call.silent * FRAME_MS;
  const totalMs = Call.frames.length * FRAME_MS;
  if (silenceMs >= (settings.vadSilenceMs || 900) || totalMs >= (settings.vadMaxSec || 15) * 1000) finishCapture();
}

// 打断判断：回声消除后，绘名自己的声音仍可能漏进麦克风一点（回声残留）。
// 一边估计这个残留有多大（echo），一边要求：最近 400ms 里有六成以上的时间你的声音明显更大，才算你开口了。
// （说话是一个个音节，中间本来就有很短的停顿，所以不要求每一帧都响）
const BARGE_WINDOW = 20, BARGE_FRAMES = 12;
function bargeCheck(f, rms) {
  Call.pre.push(f); if (Call.pre.length > PRE_ROLL) Call.pre.shift();
  if (Call.echo == null) Call.echo = Call.floor;
  // 每句刚开始播放的 0.7 秒只用来学习回声残留，不判断打断
  if (performance.now() < (Call.bargeArmAt || 0)) { Call.echo = Math.max(Call.echo, Call.echo * 0.85 + rms * 0.15); Call.bargeWin = []; return; }
  const lv = LEVELS[settings.vadLevel] || LEVELS.normal;
  const th = Math.max(lv.min * 2.5, Call.floor * lv.ratio * 1.5, Call.echo * 3.5);
  Call.bargeWin = Call.bargeWin || [];
  Call.bargeWin.push(rms > th); if (Call.bargeWin.length > BARGE_WINDOW) Call.bargeWin.shift();
  Call.bargeFrames = Call.bargeWin.filter(Boolean).length;
  if (rms > th) {
    if (Call.bargeFrames >= BARGE_FRAMES) {
      dbg(`开口打断：音量 ${rms.toFixed(3)}，门槛 ${th.toFixed(3)}，回声残留 ${Call.echo.toFixed(3)}，打断时状态 ${Call.state}`);
      const frames = Call.pre.slice();
      const wasThinking = Call.state === 'thinking' && !(Call.reply && Call.reply.stream && Call.heard > 0);
      if (wasThinking && Call.lastAsk) Call.carry = Call.lastAsk;   // 绘名还没开口：你前后两句合在一起交给绘名
      Call.stopReply(false);
      Call.bargeFrames = 0; Call.bargeWin = []; Call.echo = null;
      // 从你开口前 300ms 开始收这句话
      Call.capturing = true; Call.frames = frames; Call.voiced = BARGE_FRAMES; Call.silent = 0;
      Call.cooldownUntil = 0;
      Call.times = { speechStart: performance.now(), barge: true };
      setState('capturing', '在听你说…（打断了绘名）');
    }
  } else {
    Call.echo = Call.echo * 0.97 + rms * 0.03;    // 慢慢跟上回声残留的水平
  }
}

function updateFloor(rms, k = 0.05) {
  Call.floor = Math.max(0.002, Math.min(0.05, Call.floor * (1 - k) + rms * k));
}

function finishCapture() {
  const frames = Call.frames, voicedMs = Call.voiced * FRAME_MS;
  dbg(`一句说完：总长 ${frames.length * FRAME_MS}ms，有声 ${voicedMs}ms，${voicedMs >= MIN_SPEECH_MS ? '提交识别' : '太短，当作噪声'}`);
  Call.vadLog = (Call.vadLog || []).concat([{ at: Math.round(performance.now()), totalMs: frames.length * FRAME_MS, voicedMs, floor: +Call.floor.toFixed(4), submitted: voicedMs >= MIN_SPEECH_MS }]).slice(-30);
  resetVad();
  if (voicedMs < MIN_SPEECH_MS) { setState('listening'); return; }   // 太短，多半是噪声
  submitAudio(frames);
}

// 按住说话（备用）
Call.pttDown = function () {
  if (!Call.active || Call.muted || !Call.ctx) return;
  if (Call.state === 'thinking' || Call.state === 'replying') Call.stopReply(true);
  resetVad();
  Call.ptt = true; Call.capturing = true;
  Call.times = { speechStart: performance.now() };
  setState('capturing', '按住说话中…');
};
Call.pttUp = function () {
  if (!Call.ptt) return;
  Call.ptt = false;
  const frames = Call.frames, voicedMs = Call.voiced * FRAME_MS;
  resetVad();
  if (frames.length * FRAME_MS < 300 || voicedMs < 150) { setState('listening'); return; }
  submitAudio(frames);
};

/* ---------- 一轮对话 ---------- */
function toWav(frames) {
  const n = frames.reduce((a, f) => a + f.length, 0);
  const buf = new ArrayBuffer(44 + n * 2), v = new DataView(buf);
  const w = (o, s) => { for (let i = 0; i < s.length; i++) v.setUint8(o + i, s.charCodeAt(i)); };
  w(0, 'RIFF'); v.setUint32(4, 36 + n * 2, true); w(8, 'WAVE'); w(12, 'fmt ');
  v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, 1, true); v.setUint32(24, 16000, true);
  v.setUint32(28, 32000, true); v.setUint16(32, 2, true); v.setUint16(34, 16, true); w(36, 'data'); v.setUint32(40, n * 2, true);
  let o = 44;
  for (const f of frames) for (let i = 0; i < f.length; i++, o += 2) v.setInt16(o, Math.max(-1, Math.min(1, f[i])) * 0x7fff, true);
  return buf;
}

async function submitAudio(frames) {
  const myTurn = ++Call.turnId, key = callKey();
  const myCall = Call.callId;
  const stale = () => !Call.active || myTurn !== Call.turnId || myCall !== Call.callId;
  Call.times.asrStart = performance.now();
  setState('recognizing');
  lastActive = Date.now();
  const r = await api.callAsr(toWav(frames), key);
  if (stale()) return;
  Call.times.asrEnd = performance.now();
  dbg(`识别结果：${r.error ? '出错 ' + r.error : r.text ? '有文字（' + Array.from(r.text).length + '字）' : '空的/无效'}`);
  if (r.error) {
    if (r.error === 'aborted') return;
    setState('listening', r.error === 'noasr' ? '还没填语音识别 API' : '没识别成功，再说一次或用打字');
    showUserText(r.error === 'noasr' ? '' : '（' + r.error + '）', 'err');
    return;
  }
  if (!r.text) { setState('listening', '没听清，再说一次？'); return; }   // 空的、无效的识别结果不进对话
  let text = r.text;
  if (Call.carry) { text = Call.carry + '\n' + text; Call.carry = null; }   // 绘名思考时被你打断：前后两句一起交给绘名
  showUserText(text.replace('\n', ' '));
  Call.lastAsk = text;
  await runTurn(text, myTurn, key);
}

// 一轮回复的流：心情/动作和每一句可能陆续到达（流式），也可能最后一次性到达
let curStream = null;
if (api && api.onCallStream) api.onCallStream((m) => {
  const st = curStream;
  if (!st || m.key !== st.key) return;            // 不是当前这一轮的，丢掉
  if (m.type === 'meta') applyMeta(st, m.data);
  else if (m.type === 'seg') addSeg(st, m.data);
});

function applyMeta(st, meta) {
  if (st.metaApplied || !meta) return;
  st.metaApplied = true; st.mood = meta.mood;
  // 表情和动作：整条回复做一次（拿到心情就做，不等句子）
  react({ t: '', m: MOODS[meta.mood] ? meta.mood : 'calm', a: ACTIONS[meta.action] ? meta.action : 'none',
          f: FACES[meta.face] ? meta.face : undefined, autoAction: true, intensity: typeof meta.intensity === 'number' ? meta.intensity : undefined },
        { silent: true, hold: 6000 });
}

function addSeg(st, g) {
  if (!g || (!g.ja && !g.zh) || st.segs.some((x) => x.id === g.id)) return;
  st.segs.push(g);
  if (!st.times.firstSeg) { st.times.firstSeg = performance.now(); Call.times.llmFirst = st.times.firstSeg; }
  // 一到就开始合成这句的日语配音（按到达顺序）
  const voiceOk = settings.hasVoice && !settings.muted;
  g.tts = voiceOk && g.ja ? api.callTts({ key: st.key, ja: g.ja, mood: st.mood || 'calm' }) : Promise.resolve({ error: voiceOk ? 'nolang' : 'novoice' });
  if (st.wake) { const w = st.wake; st.wake = null; w(); }
}

async function runTurn(text, myTurn, key) {
  const myCall = Call.callId;
  const stale = () => !Call.active || myTurn !== Call.turnId || myCall !== Call.callId;
  setState('thinking');
  { const [f, fs] = pick(MOODS.think.faces); playFace(f, { strength: Math.min(fs, 0.6) }); }
  const moods = {}, actions = {}, faces = {};
  for (const k in MOODS) moods[k] = MOODS[k].desc;
  for (const k in ACTIONS) actions[k] = ACTIONS[k].desc;
  for (const k in FACES) faces[k] = FACES[k][1];
  Call.times.llmStart = performance.now();
  const st = curStream = { key, turn: myTurn, segs: [], done: false, wake: null, times: {}, mood: null, metaApplied: false, final: null };
  Call.reply = { total: 0, turn: myTurn, stream: st };
  Call.heard = 0;
  api.callTurn({ key, text, moods, actions, faces }).then((r) => {
    if (curStream !== st) return;
    st.final = r || { error: '没有回复' };
    Call.times.llmEnd = performance.now();
    dbg(`大模型：${!r || r.error ? '出错 ' + (r && r.error) : '回复 ' + (r.segments || []).length + ' 句' + (r.streamed ? '（流式，先到 ' + r.streamed + ' 句）' : '')}`);
    if (r && !r.error) {
      applyMeta(st, r);                                              // 流式没拿到心情时，用最终结果
      (r.segments || []).forEach((g) => addSeg(st, g));              // 流式漏掉的句子补上（按 id 去重）
    }
    st.done = true;
    if (st.wake) { const w = st.wake; st.wake = null; w(); }
  });
  await playStream(st, myTurn, key);
}

// 按句播放：句子陆续到达，每句的配音在到达时就开始合成；音频真正开始播放时才出这句的字幕
async function playStream(st, myTurn, key) {
  const myCall = Call.callId;
  const stale = () => !Call.active || myTurn !== Call.turnId || myCall !== Call.callId;
  let ttsWarned = false;
  for (let i = 0; ; i++) {
    while (i >= st.segs.length && !st.done) {
      await new Promise((res) => { st.wake = res; });
      if (stale()) return;
    }
    if (stale()) return;
    if (i >= st.segs.length) break;                 // 全部说完
    const g = st.segs[i];
    if (i === 0) setState('replying');
    const r = await g.tts;
    if (stale()) return;
    if (i === 0) Call.times.ttsFirst = performance.now();

    // 字幕：中文是这句日语的翻译；缺翻译就显示日语并注明；没有日语就只显示中文、不配音
    const zh = g.zh || g.ja;
    const tag = g.zhMissing ? '这句没有中文翻译' : g.jaMissing ? '这句没有日语，不配音' : '';
    const jaLine = settings.callShowJa && g.ja && !g.zhMissing ? g.ja : '';

    Call.heard = i + 1;
    if (r && r.audio) {
      const played = await playSegment(r.audio, () => {
        Call.bargeArmAt = performance.now() + 700;
        say(zh, 600000, tag, jaLine, { instant: true, spokenJa: g.ja, source: 'call' });
        if (i === 0) { Call.times.playStart = performance.now(); logTimes(); }
      }, myTurn, r.words);
      if (played === false && !stale()) await waitMs(Math.max(1600, Array.from(zh).length * 180), myTurn);
    } else {
      if (r && r.error && !['nolang', 'novoice', 'aborted'].includes(r.error) && !ttsWarned) {
        ttsWarned = true; showUserText('（配音失败：' + r.error + '，只显示字幕）', 'err');
      }
      say(zh, 600000, tag, jaLine, { instant: true, spokenJa: g.ja, source: 'call' });
      if (i === 0) { Call.times.playStart = performance.now(); logTimes(); }
      await waitMs(Math.max(1600, Array.from(zh).length * 180), myTurn);
    }
    if (stale()) return;
  }
  // 一句都没有：出错
  if (!st.segs.length) {
    const r = st.final || {};
    if (r.error === 'aborted') return;
    setState('listening', r.error === 'noapi' ? '还没填聊天 API' : '绘名没回上来：' + (r.error || '没有回复'));
    idleFace(0.6);
    Call.reply = null;
    return;
  }
  Call.reply = null;
  if (curStream === st) curStream = null;
  extendBubble(2500);
  Call.cooldownUntil = Date.now() + AFTER_REPLY_MS;
  resetVad();
  setState('listening');
}

function waitMs(ms, myTurn) {
  return new Promise((res) => {
    const t = setTimeout(res, ms);
    Call.waitCancel = () => { clearTimeout(t); res(); };
  });
}

// 播放一句：用和平时一样的口型；返回在播完（或被停止）时结束
// 日语字幕跟读：按配音服务给的逐字时间点，念到哪里亮到哪里
let cancelKaraoke = null;
function karaoke(words, src, startAt, duration) {
  if (cancelKaraoke) cancelKaraoke();
  if (settings.callKaraoke === false) return;
  const ja = bubble.querySelector('.ja');
  const zh = bubble.querySelector('.zh');
  if (!ja && !zh) return;
  const source = ja || zh;
  const times = SubtitleTiming.timeline(source.textContent, ja ? words : [], duration * 1000);
  const decorate = (el) => {
    if (!el) return [];
    const chars = Array.from(el.textContent);
    el.textContent = ''; el.classList.add('karaoke');
    return chars.map(c => { const sp = document.createElement('span'); sp.textContent = c; sp.className = 'k'; el.appendChild(sp); return sp; });
  };
  const sourceSpans = decorate(source);
  const translated = ja && zh ? decorate(zh) : [];
  let frame = null, stopped = false;
  cancelKaraoke = () => { stopped = true; if (frame !== null) cancelAnimationFrame(frame); };
  const tick = () => {
    // A stopped/replaced sentence stays at its last position. Never flash the unspoken text.
    if (stopped || !source.isConnected || !bubble.classList.contains('show')) return;
    if (voiceSrc !== src) return;
    const ms = Math.max(0, (audioCtx.currentTime - startAt) * 1000);
    let count = 0;
    for (let i=0;i<sourceSpans.length;i++) {
      const on = ms >= times[i]; sourceSpans[i].classList.toggle('on',on); if(on) count++;
    }
    // Translation follows sentence progress, not a fabricated Japanese/Chinese word alignment.
    const translatedCount = Math.floor(count * translated.length / Math.max(1, sourceSpans.length));
    translated.forEach((sp,i) => sp.classList.toggle('on',i<translatedCount));
    frame = requestAnimationFrame(tick);
  };
  tick();
}

function playSegment(b64, onStart, myTurn, words) {
  const myCall = Call.callId;
  return new Promise(async (resolve) => {
    let ticket = null;
    try {
      if (!audioCtx) audioCtx = new AudioContext();
      if (audioCtx.state === 'suspended') await audioCtx.resume();
      const bin = atob(b64), bytes = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
      const buf = await audioCtx.decodeAudioData(bytes.buffer);
      if (!Call.active || myTurn !== Call.turnId || myCall !== Call.callId) return resolve();
      if (settings.muted) { onStart(); return resolve(false); }
      stopVoice();
      ticket = await takeVoiceTurn(() => Call.active && myTurn === Call.turnId && myCall === Call.callId && !settings.muted);
      if (ticket === null) return resolve();
      const src = audioCtx.createBufferSource(); src.buffer = buf;
      const gain = audioCtx.createGain(); gain.gain.value = settings.volume ?? 0.9;
      const an = audioCtx.createAnalyser(); an.fftSize = 1024;
      src.connect(gain); gain.connect(an); an.connect(audioCtx.destination);
      src.onended = () => { releaseVoiceTurn(ticket); if (voiceSrc === src) { voiceSrc = null; analyser = null; voicePlaying = false; extendBubble(1200); } resolve(true); };
      voiceSrc = src; analyser = an; voicePlaying = true;
      Call.stopCurrent = () => { releaseVoiceTurn(ticket); try { src.onended = null; src.stop(); } catch (e) {} if (voiceSrc === src) { voiceSrc = null; analyser = null; voicePlaying = false; } resolve(); };
      const startAt = audioCtx.currentTime;
      src.start();
      onStart();
      clearTimeout(bubbleTimer);
      karaoke(words, src, startAt, buf.duration);
    } catch (e) {
      releaseVoiceTurn(ticket);
      console.warn('segment play failed', e);
      if (!Call.active || myTurn !== Call.turnId || myCall !== Call.callId) return resolve();
      onStart();
      resolve(false);
    }
  });
}

// 停止当前回复：立刻停声音、清空队列、丢弃还没回来的结果
Call.stopReply = function (backToListening = true) {
  const st = Call.reply && Call.reply.stream;
  const wasReplying = !!Call.reply && Call.state === 'replying';
  const heard = Call.heard, total = st && st.done ? st.segs.length : 0;
  const key = callKey();
  curStream = null;
  if (st && st.wake) { const w = st.wake; st.wake = null; w(); }
  Call.turnId++;                       // 旧轮次的结果一律作废
  api.callCancel(key);
  if (Call.stopCurrent) Call.stopCurrent();
  if (Call.waitCancel) Call.waitCancel();
  stopVoice();
  Call.reply = null;
  if (wasReplying) {
    api.callInterrupted({ heard, total, key });   // 记下这条回复没说完
    extendBubble(1200);
  } else if (Call.state === 'thinking') {
    hideBubble();
  }
  Call.reply = null;
  idleFace(0.4);
  resetVad();
  Call.cooldownUntil = Date.now() + 300;
  if (backToListening && Call.active) setState(Call.muted ? 'muted' : 'listening');
};

function logTimes() {
  const t = Call.times, f = (a, b) => (t[a] && t[b] ? ((t[b] - t[a]) / 1000).toFixed(1) + 's' : '-');
  const line = `识别 ${f('asrStart', 'asrEnd')} · 首句生成 ${f('llmStart', 'llmFirst')} · 首句配音 ${f('llmFirst', 'ttsFirst')} · 说完到开口 ${f('asrStart', 'playStart')}`;
  $c('callState').title = line;
  api.callTiming(line);
}

/* ---------- 按钮 ---------- */
document.getElementById('callBtn').addEventListener('click', () => Call.start());
$c('callEnd').addEventListener('click', () => Call.end());
$c('callMute').addEventListener('click', () => Call.toggleMute());
$c('callStop').addEventListener('click', () => Call.stopReply(true));
$c('callState').addEventListener('click', () => { if (Call.active && Call.state === 'error' && settings.hasApi && settings.hasAsr) openMic(); });
const ptt = $c('callPtt');
ptt.addEventListener('pointerdown', (e) => { ptt.setPointerCapture(e.pointerId); ptt.classList.add('on'); Call.pttDown(); });
const pttRelease = () => { ptt.classList.remove('on'); Call.pttUp(); };
ptt.addEventListener('pointerup', pttRelease);
ptt.addEventListener('pointercancel', pttRelease);

window.__call = Call;
