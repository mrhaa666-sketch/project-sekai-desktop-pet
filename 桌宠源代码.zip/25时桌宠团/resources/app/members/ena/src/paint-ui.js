'use strict';
/* 绘名的画室窗口：文生图 / 图生图 / 曲生图 */
const api = window.paintAPI;
const $ = (id) => document.getElementById(id);
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const mmss = (s) => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`;
const setMsg = (id, t, cls = '') => { const e = $(id); e.textContent = t; e.className = 'msg' + (cls ? ' ' + cls : ''); };
const MIN_SEC = 8, MAX_SEC = 15 * 60;

let cfg = null, job = null;
let inputImage = null;      // { dataUrl, w, h, name }
let music = null;           // { name, analysis, clipB64 }
let decoded = null, worker = null, anaJob = 0;
const works = [];           // 这次画的：{ b64, type, title, ... }
let current = null;

const mode = () => document.querySelector('input[name=mode]:checked').value;

/* ---------- 设置状态 ---------- */
async function loadConfig() {
  cfg = await api.config();
  const pill = $('cfgPill');
  pill.textContent = cfg.paintReady ? `绘图：${cfg.t2i}` : '画画的 API 密钥未设置';
  pill.className = 'pill ' + (cfg.paintReady ? 'ok' : 'bad');
  pill.title = cfg.paintReady ? `文生图：${cfg.t2i}；图生图：${cfg.i2i}；密钥：${cfg.keyLabel}；地址：${cfg.base}` : '右键桌宠 → 设置 → 画画';
  const lh = $('listenHint');
  lh.textContent = !cfg.audioModel ? '设置 → 画画 里还没有填听曲模型；不勾选也能画，只用本地分析的结果。'
    : `听曲模型：${cfg.audioModel}` + (cfg.audioLikely ? '' : '。注意：官方文档只标注 Qwen3-Omni 系列支持音频输入，这个模型可能会拒绝音频。');
  if (cfg.prefill) applyPrefill(cfg.prefill);
  updateFlow(); refresh();
}
$('openSettings').onclick = () => api.openSettings();
window.addEventListener('focus', () => { if (!job) loadConfig(); });
api.onPrefill((p) => applyPrefill(p));
function applyPrefill(p) {
  if (!p) return;
  const r = document.querySelector(`input[name=mode][value=${p.mode || 'text'}]`);
  if (r) { r.checked = true; onMode(); }
  if (p.idea) $('idea').value = p.idea;
}

/* ---------- 模式切换 ---------- */
const IDEA = {
  text: ['描述', '比如：放学后的天台，傍晚的逆光，一个短发女孩抱着速写本回头看，暖橙和淡紫的天空，柔和的水彩质感。'],
  image: ['想怎么改', '比如：改成夜晚，加上霓虹灯的倒影；或者：保持人物，把背景换成下雪的街道。留空就是整体画得更精致。'],
  music: ['补充要求（可选）', '比如：画成一个人物；或者：只画风景，不要人。留空就交给绘名按曲子的感觉来画。'],
};
// 三种方式各自记住写过的要求，切换时不串
const ideas = { text: '', image: '', music: '' };
let shownMode = 'text';
function onMode() {
  const m = mode();
  if (m !== shownMode) { ideas[shownMode] = $('idea').value; $('idea').value = ideas[m] || ''; shownMode = m; }
  $('paneImage').hidden = m !== 'image';
  $('paneMusic').hidden = m !== 'music';
  $('ideaLabel').textContent = IDEA[m][0];
  $('idea').placeholder = IDEA[m][1];
  updateFlow(); refresh();
}
for (const r of document.querySelectorAll('input[name=mode]')) r.addEventListener('change', onMode);
for (const id of ['refine', 'describe', 'listen']) $(id).addEventListener('change', () => { updateFlow(); refresh(); });

function flowSteps() {
  const m = mode(), refine = $('refine').checked;
  const s = [];
  if (m === 'image' && $('describe').checked) s.push(['look', `看图模型看懂原图${cfg && cfg.visionModel ? '（' + cfg.visionModel + '）' : ''}`]);
  if (m === 'music') s.push(['analyze', '本地分析曲子（已在选文件时完成）']);
  if (m === 'music' && $('listen').checked) s.push(['listen', `听曲模型听一段${cfg && cfg.audioModel ? '（' + cfg.audioModel + '）' : ''}`]);
  if (refine) s.push(['prompt', `绘名整理提示词${cfg && cfg.promptModel ? '（' + cfg.promptModel + '）' : ''}`]);
  s.push(['draw', `绘图模型作画${cfg ? '（' + (m === 'image' ? cfg.i2i : cfg.t2i) + '）' : ''}`]);
  s.push(['download', '下载图片到本机']);
  return s;
}
function updateFlow() {
  if (!cfg) return;
  const m = mode();
  const sent = [];
  if (m === 'image') sent.push('原图会发给绘图模型' + ($('describe').checked ? '和看图模型' : ''));
  if (m === 'music') sent.push($('listen').checked ? '只有勾选的约 30 秒片段会发给听曲模型，整首曲子不会上传' : '曲子不会上传，只把本地分析出的文字特征发给提示词模型');
  if ($('refine').checked) sent.push('文字要求会发给聊天模型');
  $('flowNote').innerHTML = `<b>流程：</b>${flowSteps().map((x) => esc(x[1])).join(' → ')}<br>${esc(sent.join('；'))}${sent.length ? '。' : ''}` +
    (m !== 'text' && !$('refine').checked ? '<br>没有整理提示词时，会直接用你写的话作为提示词。' : '');
}

function refresh() {
  const busy = !!job, m = mode();
  $('gen').disabled = busy || (m === 'image' && !inputImage) || (m === 'music' && !(music && music.analysis));
  $('cancel').disabled = !busy;
  for (const el of document.querySelectorAll('#idea, #aspect, #style, #seed, #refine, #describe, #listen, #strength, input[name=mode], #pickMusic')) el.disabled = busy;
  let hint = '';
  if (!busy && cfg) {
    if (!cfg.paintReady) hint = '先在设置 → 画画 里填好 API 密钥';
    else if (m === 'image' && !inputImage) hint = '先选一张原图';
    else if (m === 'music' && !(music && music.analysis)) hint = worker ? '正在分析曲子…' : '先选一首曲子';
    else if ($('refine').checked && !cfg.promptReady && m !== 'text') hint = '整理提示词需要先设置聊天模型';
  }
  $('genHint').textContent = hint;
}

/* ---------- 图生图：原图 ---------- */
$('imgDrop').onclick = (e) => { if (e.target.closest('.x')) return; if (!job) $('imgFile').click(); };
$('imgDrop').onkeydown = (e) => { if ((e.key === 'Enter' || e.key === ' ') && !job) { e.preventDefault(); $('imgFile').click(); } };
$('imgFile').onchange = (e) => { takeImage(e.target.files[0]); e.target.value = ''; };
$('imgDrop').addEventListener('dragover', (e) => { e.preventDefault(); $('imgDrop').classList.add('over'); });
$('imgDrop').addEventListener('dragleave', () => $('imgDrop').classList.remove('over'));
$('imgDrop').addEventListener('drop', (e) => { e.preventDefault(); $('imgDrop').classList.remove('over'); const f = [...(e.dataTransfer.files || [])].find((x) => /^image\//.test(x.type)); if (f) takeImage(f); });
document.addEventListener('paste', (e) => {
  if (job) return;
  const it = [...(e.clipboardData && e.clipboardData.items || [])].find((x) => x.type.startsWith('image/'));
  if (!it) return;
  e.preventDefault();
  document.querySelector('input[name=mode][value=image]').checked = true; onMode();
  takeImage(it.getAsFile());
});
// 最长边缩到 1536，转成 JPEG（透明部分垫白），控制上传大小
async function takeImage(file, name) {
  if (!file) return;
  if (!/^image\/(png|jpeg|webp)$/.test(file.type)) { setMsg('msg', '只支持 PNG、JPG、WebP 图片。', 'err'); return; }
  try {
    const bmp = await createImageBitmap(file);
    const k = Math.min(1, 1536 / Math.max(bmp.width, bmp.height));
    const c = document.createElement('canvas');
    c.width = Math.max(1, Math.round(bmp.width * k)); c.height = Math.max(1, Math.round(bmp.height * k));
    const g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); g.drawImage(bmp, 0, 0, c.width, c.height);
    const dataUrl = c.toDataURL('image/jpeg', 0.92);
    setInputImage({ dataUrl, w: c.width, h: c.height, name: name || file.name || '粘贴的图片' });
    setMsg('msg', '');
  } catch (e) { setMsg('msg', '这张图片打不开。', 'err'); }
}
function setInputImage(v) {
  inputImage = v;
  const d = $('imgDrop');
  if (!v) { d.innerHTML = '<span id="imgEmpty">选择一张 PNG / JPG / WebP 图片</span>'; refresh(); return; }
  d.innerHTML = `<img src="${v.dataUrl}" alt="原图"><button class="small x" title="移除">✕</button>`;
  d.querySelector('.x').onclick = (e) => { e.stopPropagation(); if (!job) setInputImage(null); };
  d.title = `${v.name} · ${v.w}×${v.h}`;
  // 跟着原图的比例选画面比例（图生图模型一般跟随原图，这里只影响支持尺寸的模型）
  const r = v.w / v.h;
  $('aspect').value = r > 1.6 ? 'wide' : r > 1.15 ? 'landscape' : r < 0.62 ? 'tall' : r < 0.87 ? 'portrait' : 'square';
  refresh();
}

/* ---------- 曲生图：本地分析 ---------- */
$('pickMusic').onclick = () => $('musicFile').click();
$('musicFile').onchange = (e) => { const f = e.target.files[0]; e.target.value = ''; if (f) analyzeMusic(f); };
$('anaCancel').onclick = () => { stopAnalysis(); $('anaHint').textContent = '已停止分析。'; };
function stopAnalysis() { if (worker) { worker.terminate(); worker = null; } anaJob++; $('anaCancel').hidden = true; refresh(); }
async function analyzeMusic(file) {
  stopAnalysis();
  const my = ++anaJob;
  music = null; decoded = null;
  $('musicName').textContent = file.name; $('musicChips').innerHTML = ''; $('wave').hidden = true;
  $('anaCancel').hidden = false;
  const hint = (t) => { if (my === anaJob) $('anaHint').textContent = t; };
  try {
    hint('读取文件…');
    const buf = await file.arrayBuffer();
    if (my !== anaJob) return;
    hint('解码音频…');
    try { decoded = await new OfflineAudioContext(1, 1, 44100).decodeAudioData(buf); }
    catch (e) { throw new Error('解码失败：文件可能已损坏，或者编码格式不受支持。'); }
    if (decoded.duration < MIN_SEC) throw new Error(`曲子太短（${decoded.duration.toFixed(1)} 秒），至少需要 ${MIN_SEC} 秒。`);
    if (decoded.duration > MAX_SEC) throw new Error(`曲子太长（${mmss(decoded.duration)}），本地分析最多 15 分钟。`);
    hint('转成单声道…');
    const sr = 22050;
    const oc = new OfflineAudioContext(1, Math.ceil(decoded.duration * sr), sr);
    const src = oc.createBufferSource(); src.buffer = decoded; src.connect(oc.destination); src.start();
    const mono = (await oc.startRendering()).getChannelData(0).slice();
    if (my !== anaJob) return;
    worker = new Worker('paint-worker.js');
    refresh();
    const result = await new Promise((resolve, reject) => {
      worker.onmessage = (e) => {
        const d = e.data;
        if (d.progress != null) hint(`本地分析 ${Math.round(d.progress * 100)}% · ${d.stage || ''}`);
        if (d.result) resolve(d.result);
        if (d.error) reject(new Error(d.error));
      };
      worker.onerror = (e) => reject(new Error('分析线程出错：' + (e.message || '未知错误')));
      worker.postMessage({ id: my, samples: mono, sampleRate: sr }, [mono.buffer]);
    });
    if (my !== anaJob) return;
    music = { name: file.name, analysis: result, duration: decoded.duration };
    showMusic(result);
    hint('分析完成（在本机完成，没有上传）。');
  } catch (e) {
    if (my === anaJob) { $('anaHint').textContent = e.message; music = null; }
  } finally {
    if (my === anaJob) { if (worker) { worker.terminate(); worker = null; } $('anaCancel').hidden = true; refresh(); }
  }
}
function showMusic(a) {
  const chips = [
    ['时长', mmss(a.duration)], ['速度', a.tempo.reliable ? `${a.tempo.bpm} BPM` : '不明显'], ['调性', a.key.text],
    ['音色', a.brightness > 2600 ? '偏亮' : a.brightness < 1400 ? '偏暗' : '适中'], ['段落', a.sections.length + ' 段'],
  ];
  $('musicChips').innerHTML = chips.map(([k, v]) => `<span class="chip">${k} <b>${esc(v)}</b></span>`).join('');
  const cv = $('wave'), g = cv.getContext('2d');
  cv.hidden = false;
  g.clearRect(0, 0, cv.width, cv.height);
  const c = a.curve || [], mx = Math.max(1e-6, ...c);
  g.fillStyle = '#ccaa88';
  for (let i = 0; i < c.length; i++) {
    const x = i / c.length * cv.width, h = Math.max(2, c[i] / mx * (cv.height - 16));
    g.fillRect(x, (cv.height - h) / 2, Math.max(1, cv.width / c.length - 0.5), h);
  }
  g.fillStyle = '#8f5e38'; g.font = '20px sans-serif';
  for (const s of a.sections) { const x = s.start / a.duration * cv.width; g.fillRect(x, 0, 2, cv.height); g.fillText(s.label, x + 5, 22); }
}
// 截取最响段落附近约 30 秒，16kHz 单声道 WAV（只有勾选“让模型听一段”并点“画！”时才会用到）
async function clipB64() {
  if (!decoded || !music) throw new Error('曲子没有准备好');
  const a = music.analysis;
  const peak = a.sections.reduce((m, s) => (s.energy > m.energy ? s : m), a.sections[0]);
  const len = Math.min(30, decoded.duration);
  let start = peak ? Math.max(0, Math.min(decoded.duration - len, (peak.start + peak.end) / 2 - len / 2)) : 0;
  const sr = 16000, oc = new OfflineAudioContext(1, Math.ceil(len * sr), sr);
  const src = oc.createBufferSource(); src.buffer = decoded; src.connect(oc.destination); src.start(0, start, len);
  const d = (await oc.startRendering()).getChannelData(0);
  const buf = new ArrayBuffer(44 + d.length * 2), v = new DataView(buf);
  const w = (o, s) => { for (let i = 0; i < s.length; i++) v.setUint8(o + i, s.charCodeAt(i)); };
  w(0, 'RIFF'); v.setUint32(4, 36 + d.length * 2, true); w(8, 'WAVE'); w(12, 'fmt '); v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, 1, true);
  v.setUint32(24, sr, true); v.setUint32(28, sr * 2, true); v.setUint16(32, 2, true); v.setUint16(34, 16, true); w(36, 'data'); v.setUint32(40, d.length * 2, true);
  for (let i = 0; i < d.length; i++) v.setInt16(44 + i * 2, Math.max(-1, Math.min(1, d[i])) * 32767, true);
  const bytes = new Uint8Array(buf);
  let bin = '';
  for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
  return { b64: btoa(bin), start, len };
}

/* ---------- 阶段进度 ---------- */
let stageKeys = [];
function initStages() {
  const s = flowSteps().filter((x) => x[0] !== 'analyze');
  stageKeys = s.map((x) => x[0]);
  $('stages').innerHTML = s.map(([k, t]) => `<li data-k="${k}">${esc(t)}<span class="d"></span></li>`).join('');
  $('stages').hidden = false; $('barWrap').hidden = false; $('bar').style.width = '3%';
}
function stage(k, detail = '') {
  const i = stageKeys.indexOf(k);
  if (i < 0) return;
  [...$('stages').children].forEach((li, j) => { li.className = j < i ? 'done' : j === i ? 'on' : ''; if (j === i) li.querySelector('.d').textContent = detail; });
  $('bar').style.width = Math.round(((i + 0.5) / stageKeys.length) * 100) + '%';
}
function stagesEnd(ok) {
  const lis = [...$('stages').children];
  if (ok) { lis.forEach((li) => { li.className = 'done'; }); $('bar').style.width = '100%'; return; }
  const on = lis.find((li) => li.className === 'on');
  if (on) on.className = 'fail';
}
let curStage = '';
api.onProgress((p) => {
  if (!job || p.id !== job.id) return;
  if (p.stage === 'tick') { $('genHint').textContent = `已用 ${p.elapsed} 秒（最多 ${cfg ? cfg.timeoutSec : '?'} 秒）`; return; }
  curStage = p.stage;
  if (p.stage === 'look') stage('look', '');
  if (p.stage === 'listen') stage('listen', '');
  if (p.stage === 'prompt') stage('prompt', p.chars ? `${p.chars} 字` : '');
  if (p.stage === 'prompted') { $('genHint').textContent = ''; job.prompt = p.prompt; }
  if (p.stage === 'draw') stage('draw', `${p.model}${p.size ? ' · ' + p.size : ''}`);
  if (p.stage === 'download') stage('download', '');
});

/* ---------- 生成 ---------- */
async function generate() {
  if (job) return;
  const m = mode();
  const id = 'p' + Date.now();
  job = { id };
  refresh(); setMsg('msg', ''); setMsg('saveMsg', '');
  initStages();
  try {
    const p = { id, mode: m, idea: $('idea').value, aspect: $('aspect').value, style: $('style').value, seed: $('seed').value, refine: $('refine').checked };
    if (m === 'image') { p.image = inputImage && inputImage.dataUrl; p.strength = $('strength').value; p.describe = $('describe').checked; }
    if (m === 'music') {
      p.musicBrief = MusicAnalysis.promptBrief(music.analysis); p.musicName = music.name;
      if ($('listen').checked) { const c = await clipB64(); p.listen = true; p.audioClip = c.b64; job.clip = c; }
    }
    if (!job || job.id !== id) return;
    stage(stageKeys[0]);
    const r = await api.generate(p);
    if (!job || job.id !== id) return;
    if (r.error) {
      stagesEnd(false);
      setMsg('msg', r.canceled ? '已取消。' : r.error, r.canceled ? 'warn' : 'err');
      if (r.noConfig) setMsg('msg', r.error + '\n（点右上角“设置”去填写）', 'err');
      return;
    }
    stagesEnd(true);
    const w = { ...r, idea: p.idea, style: p.style, aspect: p.aspect, musicName: p.musicName || '', clip: job.clip || null, at: new Date() };
    works.unshift(w);
    showWork(w); renderGallery();
    setMsg('msg', `画好了，用时 ${r.elapsed} 秒。`, 'ok');
    api.done({ title: r.title, comment: r.comment });
  } catch (e) {
    stagesEnd(false);
    setMsg('msg', String(e && e.message || e), 'err');
  } finally {
    job = null; $('genHint').textContent = ''; refresh();
  }
}
$('gen').onclick = generate;
$('cancel').onclick = () => { if (job) { api.cancel(job.id); setMsg('msg', '正在取消…', 'warn'); } };

const MODE_NAME = { text: '文生图', image: '图生图', music: '曲生图' };
function showWork(w) {
  current = w;
  $('empty').hidden = true; $('result').hidden = false;
  $('img').src = `data:image/${w.type === 'jpg' ? 'jpeg' : w.type};base64,${w.b64}`;
  $('title').textContent = w.title || '（没有标题）';
  $('comment').hidden = !w.comment; $('comment').textContent = w.comment || '';
  const chips = [['方式', MODE_NAME[w.mode]], ['模型', w.model], w.size ? ['尺寸', w.size] : null, w.seed != null ? ['种子', String(w.seed)] : null, w.inference ? ['推理', w.inference.toFixed(1) + ' 秒'] : null].filter(Boolean);
  $('chips').innerHTML = chips.map(([k, v]) => `<span class="chip">${k} <b>${esc(v)}</b></span>`).join('');
  $('resultMeta').textContent = `${w.at.getHours()}:${String(w.at.getMinutes()).padStart(2, '0')} 画的`;
  const D = [];
  if (w.idea) D.push('你的要求：' + w.idea);
  if (w.imageDesc) D.push('看图模型对原图的描述：' + w.imageDesc);
  if (w.musicName) D.push('曲子：' + w.musicName + (w.clip ? `（上传给听曲模型的片段：${mmss(w.clip.start)} 起 ${Math.round(w.clip.len)} 秒）` : '（没有上传音频）'));
  if (w.listenDesc) D.push('听曲模型的描述：' + w.listenDesc);
  D.push('提示词：' + w.prompt);
  if (w.negative) D.push('不想出现：' + w.negative);
  $('detail').textContent = D.join('\n\n');
  for (const b of document.querySelectorAll('#gallery button')) b.classList.toggle('cur', b.dataset.i === String(works.indexOf(w)));
}
function renderGallery() {
  $('galleryCard').hidden = works.length < 2;
  $('gallery').innerHTML = works.map((w, i) => `<button data-i="${i}" title="${esc(w.title || MODE_NAME[w.mode])}"${w === current ? ' class="cur"' : ''}><img src="data:image/${w.type === 'jpg' ? 'jpeg' : w.type};base64,${w.b64}" alt=""></button>`).join('');
  for (const b of document.querySelectorAll('#gallery button')) b.onclick = () => showWork(works[+b.dataset.i]);
}
$('save').onclick = async () => {
  if (!current) return;
  const r = await api.save({ name: current.title || '绘名的画', b64: current.b64, type: current.type });
  if (r.ok) setMsg('saveMsg', '已保存到 ' + r.path, 'ok'); else if (r.error) setMsg('saveMsg', r.error, 'err');
};
$('copy').onclick = async () => {
  if (!current) return;
  const r = await api.copy({ b64: current.b64 });
  setMsg('saveMsg', r.ok ? '已复制到剪贴板。' : (r.error || '复制失败'), r.ok ? 'ok' : 'err');
};
$('reuse').onclick = async () => {
  if (!current || job) return;
  document.querySelector('input[name=mode][value=image]').checked = true; onMode();
  // 直接从已下载的图片数据生成文件（页面不允许 fetch data: 地址）
  const bin = atob(current.b64), bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  const mime = 'image/' + (current.type === 'jpg' ? 'jpeg' : current.type);
  await takeImage(new File([bytes], (current.title || '绘名的画') + '.' + current.type, { type: mime }), current.title || '上一张作品');
  $('idea').focus();
};
$('again').onclick = () => { if (!job) generate(); };

window.__paint = { works, get current() { return current; }, get music() { return music; }, setInputImage, takeImage, analyzeMusic, generate, flowSteps };
onMode();
loadConfig();
