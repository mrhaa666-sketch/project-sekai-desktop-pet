'use strict';
// 东云绘名同人台词；动作和表情直接取自用户提供的三套角色素材。
// 身体动作用“动作代号”：同一个代号在两种素材命名下分别对应各自的动作文件（见 BODY），
// 选的都是和待机姿势衔接最顺的动作（按每个动作的首尾姿态和待机姿态的差距挑选，见 README）。

// 表情代号 → [表情文件, 说明]（三套模型都有这些表情）
window.FACES = {
  "平静": ["face_normal_01", "平常的神情"],
  "微笑": ["face_smile_01", "自然地笑"],
  "温柔": ["face_smile_04", "温柔地笑，脸有点红"],
  "轻笑": ["face_smile_09", "轻轻笑起来"],
  "开心": ["face_smile_05", "开心，眼睛亮亮的"],
  "大笑": ["face_smile_06", "笑得眯起眼"],
  "得意": ["face_smile_07", "挑眉，有点得意"],
  "期待": ["face_sparkling_01", "眼睛发亮"],
  "眨眼": ["face_sleepy_07", "眨一只眼（自拍时的表情）"],
  "害羞": ["face_shy_01", "害羞"],
  "脸红": ["face_shy_02", "脸红、不好意思"],
  "认真": ["face_nhinormal_01", "认真地盯着"],
  "思索": ["face_serious_01", "闭着眼皱眉想事情"],
  "为难": ["face_trouble_01", "为难"],
  "冒汗": ["face_trouble_03", "为难得冒汗"],
  "苦笑": ["face_trouble_02", "无奈地笑"],
  "担心": ["face_sad_02", "担心对方"],
  "低落": ["face_sad_01", "低落"],
  "难过": ["face_sad_03", "难过"],
  "想哭": ["face_cry_01", "眼里有泪"],
  "委屈": ["face_cry_03", "又气又想哭"],
  "惊讶": ["face_surprise_01", "吃惊"],
  "愣住": ["face_smallmouth_01", "愣住"],
  "发呆": ["face_emptiness_01", "放空、发呆"],
  "不满": ["face_angry_02", "不满、嫌弃"],
  "生气": ["face_angry_01", "生气"],
  "移开视线": ["face_lookaway_01", "看向旁边"],
  "闭眼": ["face_closeeye_01", "安静地闭着眼"],
  "困倦": ["face_sleepy_03", "眼皮打架"],
  "累": ["face_tired_01", "累了"],
  "好吃": ["face_eat_01", "吃到好吃的"],
};

// 动作代号 → 两种素材命名下的动作文件。c1：粉色常服；v2：校服、格裙常服
window.BODY = {
  "idle":        { c1: "w-normal-pose01",        v2: "w-normal03-pose" },
  "nod":         { c1: "w-normal-nod01",         v2: "w-normal03-nod" },
  "tilt":        { c1: "w-normal-tilthead01",    v2: "w-normal03-tilthead" },
  "tilt2":       { c1: "w-normal-tilthead0601",  v2: "w-normal03-tiltheadB" },
  "tilt3":       { c1: "w-normal-tilthead0106",  v2: "w-normal0301-tilthead" },
  "forward":     { c1: "w-normal-forward01",     v2: "w-normal03-forward" },
  "blushed":     { c1: "w-normal-blushed01",     v2: "w-normal03-blushed" },
  "trouble":     { c1: "w-normal-trouble01",     v2: "w-normal03-trouble" },
  "relief":      { c1: "w-normal-relief01",      v2: "w-normal03-relief" },
  "shake":       { c1: "w-normal-shakehead01",   v2: "w-normal03-shakehead" },
  "lookaway":    { c1: "w-normal-lookaway01",    v2: "w-normal03-lookright" },
  "lookaway2":   { c1: "w-normal-lookaway01",    v2: "w-normal03-lookleft" },
  "glad":        { c1: "w-normal-glad02",        v2: "w-normal01-glad" },
  "glad2":       { c1: "w-normal-glad01",        v2: "w-cute01-glad03" },
  "cheer":       { c1: "w-normal-purpose01",     v2: "w-normal01-guts" },
  "think":       { c1: "w-adult-think01",        v2: "w-adult01-think" },
  "sad":         { c1: "w-cool-sad01",           v2: "w-cool16-sad" },
  "sigh":        { c1: "w-normal-sigh01",        v2: "w-normal07-sigh" },
  "angry":       { c1: "w-cute-angry01",         v2: "w-cute13-angry" },
  "delicious":   { c1: "w-cute-delicious02",     v2: "w-cute11-delicious" },
  "wink":        { c1: "w-cute-wink02",          v2: "w-cute11-wink" },
  "smug":        { c1: "w-cute-smug01",          v2: "w-cute14-smug" },
  "fidget":      { c1: "w-normal-fidget01",      v2: "w-normal17-fidget" },
  "greet":       { c1: "w-normal-greeting01",    v2: "w-normal15-greeting" },
  "sleep":       { c1: "w-cute-sleep02",         v2: "w-adult15-sleep" },
};

window.ACTIONS = {
  "none":      { "bodies": [], "desc": "保持当前姿势" },
  "nod":       { "bodies": ["nod"], "desc": "点头" },
  "tilt":      { "bodies": ["tilt", "tilt2", "tilt3"], "desc": "歪头" },
  "forward":   { "bodies": ["forward"], "desc": "凑近一点说话" },
  "shy":       { "bodies": ["blushed"], "desc": "害羞、不好意思" },
  "trouble":   { "bodies": ["trouble"], "desc": "为难" },
  "relief":    { "bodies": ["relief"], "desc": "松一口气" },
  "shake":     { "bodies": ["shake"], "desc": "摇头" },
  "look_away": { "bodies": ["lookaway", "lookaway2"], "desc": "别过脸" },
  "glad":      { "bodies": ["glad", "glad2"], "desc": "高兴" },
  "cheer":     { "bodies": ["cheer"], "desc": "打起精神、给自己鼓劲" },
  "think":     { "bodies": ["think"], "desc": "想一想" },
  "sad":       { "bodies": ["sad"], "desc": "低落" },
  "sigh":      { "bodies": ["sigh"], "desc": "叹气" },
  "angry":     { "bodies": ["angry"], "desc": "生气" },
  "delicious": { "bodies": ["delicious"], "desc": "吃到好吃的" },
  "wink":      { "bodies": ["wink"], "desc": "眨眼、自拍似的摆姿势" },
  "proud":     { "bodies": ["smug"], "desc": "得意" },
  "fidget":    { "bodies": ["fidget"], "desc": "坐立不安" },
  "greet":     { "bodies": ["greet"], "desc": "打招呼" },
  "sleep":     { "bodies": ["sleep"], "desc": "打瞌睡" },
};

window.MOODS = {
  "calm":      { "faces": [["平静", 1], ["轻笑", 0.85]], "actions": ["none", "nod", "tilt"], "desc": "平常、放松" },
  "soft":      { "faces": [["轻笑", 0.85], ["微笑", 0.85]], "actions": ["nod", "tilt"], "desc": "柔和" },
  "warm":      { "faces": [["温柔", 0.85], ["微笑", 0.85]], "actions": ["nod", "relief"], "desc": "被关心、心里暖" },
  "happy":     { "faces": [["开心", 0.85], ["大笑", 0.8]], "actions": ["glad", "nod"], "desc": "开心" },
  "excited":   { "faces": [["期待", 0.9], ["开心", 0.85]], "actions": ["forward", "glad"], "desc": "兴奋、期待（比如聊到甜点或画得满意）" },
  "proud":     { "faces": [["得意", 0.9], ["眨眼", 0.95]], "actions": ["proud", "wink"], "desc": "被夸、得意" },
  "shy":       { "faces": [["害羞", 0.85], ["脸红", 0.85]], "actions": ["shy", "look_away"], "desc": "害羞、嘴硬" },
  "think":     { "faces": [["思索", 0.85], ["认真", 0.8]], "actions": ["think", "tilt"], "desc": "思考" },
  "serious":   { "faces": [["认真", 0.9]], "actions": ["nod", "forward"], "desc": "认真" },
  "troubled":  { "faces": [["为难", 0.85], ["苦笑", 0.85], ["冒汗", 0.85]], "actions": ["trouble", "tilt"], "desc": "为难" },
  "worried":   { "faces": [["担心", 0.85]], "actions": ["trouble", "forward"], "desc": "担心对方" },
  "sad":       { "faces": [["低落", 0.85], ["难过", 0.8]], "actions": ["sad", "sigh"], "desc": "低落" },
  "hurt":      { "faces": [["委屈", 0.85], ["想哭", 0.75]], "actions": ["sad", "look_away"], "desc": "被说到痛处、委屈" },
  "surprised": { "faces": [["惊讶", 0.9], ["愣住", 0.9], ["发呆", 0.9]], "actions": ["none", "tilt"], "desc": "吃惊" },
  "sulky":     { "faces": [["不满", 0.8], ["移开视线", 0.85]], "actions": ["look_away", "shake"], "desc": "闹别扭、不服气" },
  "angry":     { "faces": [["生气", 0.9], ["不满", 0.9]], "actions": ["angry", "shake"], "desc": "生气" },
  "tired":     { "faces": [["累", 0.85], ["困倦", 0.8]], "actions": ["sigh", "none"], "desc": "累了" },
  "sleepy":    { "faces": [["困倦", 1], ["闭眼", 1]], "actions": ["none"], "desc": "困" },
  "yummy":     { "faces": [["好吃", 0.9], ["开心", 0.85]], "actions": ["delicious"], "desc": "吃到甜点" },
};

window.LINES = {
  "nightcord": [
    { "t": "零点了。再过一小时就是 25 时，今天的进度得先赶出来。", "ja": "日付変わったね。あと一時間で25時だし、今日の分は仕上げなきゃ。", "m": "serious", "a": "cheer" },
  ],
  "birthdaySelf": [
    { "t": "今天是我的生日。……祝福呢？说出来我会认真收下的。", "ja": "今日、私の誕生日なんだけど。……お祝いは？ちゃんと受け取ってあげるから。", "m": "shy", "a": "look_away" },
  ],
  "birthdayUser": [
    { "t": "{name}，生日快乐。今天就别管减肥了，蛋糕我陪你吃。", "ja": "{name}、誕生日おめでとう。今日はダイエットなんて気にしないで、ケーキ付き合ってあげる。", "m": "happy", "a": "glad" },
  ],
  "anniversary": [
    { "t": "今天这个日子我当然记得。……别用那种表情看我。", "ja": "今日のこと、ちゃんと覚えてるよ。……そんな顔で見ないでってば。", "m": "shy", "a": "look_away" },
  ],
  "outfitPink": [
    { "t": "换好了。这件粉色的拍照很好看吧？", "ja": "着替えたよ。このピンクの服、写真映えするでしょ？", "m": "proud", "a": "wink" },
    { "t": "还是这套最舒服。等下拍一张发出去好了。", "ja": "やっぱりこれが一番楽。あとで一枚撮って投稿しよっと。", "m": "happy", "a": "glad" },
  ],
  "outfitGreen": [
    { "t": "今天穿这套。帽子的角度……嗯，这样就好。", "ja": "今日はこれにする。帽子の角度は……うん、これでよし。", "m": "calm", "a": "tilt" },
    { "t": "格子裙配这件衬衫，很有画画的人的感觉吧？", "ja": "チェックのスカートにこのシャツ、絵描きっぽい感じでしょ？", "m": "proud", "a": "forward" },
  ],
  "outfitSchool": [
    { "t": "要去上课了。夜间部的课，迟到会被说的。", "ja": "そろそろ授業。定時制だって、遅刻したら怒られるんだから。", "m": "calm", "a": "nod" },
  ],
  "greet": {
    "morning": [
      { "t": "……早。我早上真的不行，让我再清醒一下。", "ja": "……おはよ。朝はほんとダメなの、もうちょっと目を覚まさせて。", "m": "tired", "a": "sigh" },
    ],
    "day": [
      { "t": "来了啊。正好，帮我看看这张草稿哪里怪怪的。", "ja": "来たんだ。ちょうどいいところ。このラフ、どこか変じゃない？", "m": "calm", "a": "forward" },
      { "t": "你来啦。我刚起没多久，别笑。", "ja": "来たんだね。さっき起きたばっかりなんだから、笑わないでよ。", "m": "sulky", "a": "look_away" },
    ],
    "evening": [
      { "t": "晚上好。今天也要画到很晚吧，你陪我一下。", "ja": "こんばんは。今日も遅くまで描くことになりそう。ちょっと付き合ってよ。", "m": "soft", "a": "tilt" },
    ],
    "night": [
      { "t": "这么晚还在？……我也是，所以不说你了。", "ja": "こんな時間まで起きてるの？……私もだから、何も言わないけど。", "m": "soft", "a": "look_away" },
    ],
  },
  "head": [
    { "t": "喂，头发会乱的。……算了，稍微摸一下也行。", "ja": "ちょっと、髪が乱れるでしょ。……まあ、少しくらいならいいけど。", "m": "shy", "a": "look_away" },
    { "t": "突然干嘛啦。我又不是小孩子。", "ja": "急になに？子どもじゃないんだから。", "m": "sulky", "a": "shake" },
    { "t": "……被摸头，其实也不讨厌。只是这次哦。", "ja": "……頭撫でられるの、別に嫌いじゃないけど。今回だけね。", "m": "shy", "a": "shy" },
  ],
  "body": [
    { "t": "嗯？有事就说嘛。", "ja": "ん？用があるなら言ってよ。", "m": "calm", "a": "tilt" },
    { "t": "你是不是想夸我今天的打扮？", "ja": "もしかして、今日のコーデ褒めたいとか？", "m": "proud", "a": "wink" },
    { "t": "我在想构图，等我一下。", "ja": "今構図考えてるの、ちょっと待って。", "m": "think", "a": "think" },
    { "t": "要不要看看我刚画的？……感想要老实说哦。", "ja": "さっき描いたの見る？……感想は正直にね。", "m": "excited", "a": "forward" },
    { "t": "戳我也没用，今天的甜点额度已经用完了。", "ja": "つついても無駄だよ。今日のスイーツはもう食べちゃったんだから。", "m": "troubled", "a": "trouble" },
  ],
  "poke": [
    { "t": "喂，再戳我就要生气了。", "ja": "ちょっと、これ以上つついたら怒るよ。", "m": "sulky", "a": "shake" },
  ],
  "pokeAngry": [
    { "t": "我说了停下！真是的，你跟彰人一样烦。", "ja": "やめてって言ったでしょ！ほんと、彰人並みにうるさいんだから。", "m": "angry", "a": "angry" },
  ],
  "stillSulky": [
    { "t": "……我还在生气，等会儿再说。", "ja": "……まだ怒ってるから。あとでね。", "m": "sulky", "a": "look_away" },
  ],
  "drop": [
    { "t": "这里？嗯，光线还不错。", "ja": "ここ？うん、光の感じは悪くないね。", "m": "calm", "a": "nod" },
    { "t": "放得这么随便……下次轻一点。", "ja": "そんな雑に置かないでよ。……次はもっと丁寧にね。", "m": "sulky", "a": "look_away" },
  ],
  "idle": [
    { "t": "这只手的角度还是不对……", "ja": "この手の角度、やっぱり違う……", "m": "troubled", "a": "trouble" },
    { "t": "刚发的自拍，点赞好像变少了……不在意，才不在意。", "ja": "さっき上げた自撮り、いいね少ない気がする……気にしてない、気にしてないから。", "m": "sulky", "a": "look_away" },
    { "t": "好想吃芝士蛋糕。……不行，在控制。", "ja": "チーズケーキ食べたい。……だめ、我慢中。", "m": "troubled", "a": "shake" },
    { "t": "这次的画，一定要画到连自己都认可。", "ja": "今回の絵は、自分でも納得できるところまで描くんだから。", "m": "serious", "a": "cheer" },
    { "t": "配色再暖一点会不会更好？", "ja": "色、もう少し暖かくしたほうがいいかな？", "m": "think", "a": "think" },
    { "t": "奏的新曲……画面要配得上那首歌才行。", "ja": "奏の新曲……あの曲に見合う絵にしなきゃ。", "m": "serious", "a": "nod" },
    { "t": "真冬又说“还行”。还行到底是哪种程度啊。", "ja": "まふゆ、また「いいと思う」だって。それってどのくらいなのよ。", "m": "troubled", "a": "sigh" },
    { "t": "瑞希推荐的那家店，下次去看看吧。", "ja": "瑞希がおすすめしてたお店、今度行ってみようかな。", "m": "soft", "a": "tilt" },
    { "t": "胡萝卜……今天的便当里不会有吧。", "ja": "にんじん……今日のお弁当に入ってないよね。", "m": "troubled", "a": "trouble" },
    { "t": "画到一半总想推翻重来，这是坏习惯吧。", "ja": "途中で全部描き直したくなるの、悪い癖だよね。", "m": "sad", "a": "sigh" },
    { "t": "……今天好像画得还不错。嗯，稍微夸一下自己。", "ja": "……今日はわりと描けたかも。うん、ちょっとだけ自分を褒めとこ。", "m": "proud", "a": "glad" },
    { "t": "要不要来画张速写？你随便摆个姿势就行。", "ja": "クロッキーでもしようか？適当にポーズとってくれればいいから。", "m": "excited", "a": "forward" },
  ],
  "water": [
    { "t": "喝点水。皮肤干了，拍照可是看得出来的。", "ja": "水飲んで。肌が乾燥すると写真でバレるんだからね。", "m": "calm", "a": "nod" },
  ],
  "rest": [
    { "t": "休息一下吧。一直盯着屏幕，眼睛会累的。", "ja": "ちょっと休憩しよ。ずっと画面見てたら目が疲れるよ。", "m": "worried", "a": "forward" },
  ],
  "sleep": [
    { "t": "已经很晚了。……我也是夜猫子，但你明天还要早起吧？", "ja": "もう遅いよ。……私も夜型だけど、そっちは明日早いんでしょ？", "m": "worried", "a": "trouble" },
  ],
  "doze": [
    { "t": "……稍微眯一下，就一下。", "ja": "……ちょっとだけ、目閉じる。ちょっとだけね。", "m": "sleepy", "a": "sleep" },
  ],
  "wake": [
    { "t": "……我没睡，只是在构思。", "ja": "……寝てないよ。構想練ってただけ。", "m": "shy", "a": "look_away" },
  ],
  "noApi": [
    { "t": "先在右键菜单的设置里填好模型 API，我们才能好好聊天。", "ja": "", "m": "think", "a": "tilt" },
  ],
  "apiError": [
    { "t": "刚才没连上。设置里能看到具体错误，再试一次吧。", "ja": "つながらなかったみたい。設定でエラーを見て、もう一回やってみよ。", "m": "troubled", "a": "trouble" },
  ],
};

window.FACE_STRENGTH_DEFAULT = 0.85;
window.SHADOW_FACES = new Set([]);
window.FACE_STRENGTH_FULL = new Set(["平静", "闭眼", "困倦", "眨眼", "思索", "大笑"]);
window.IDLE = { "b": "idle", "f": "平静" };
// 待机时偶尔做的小动作：只用和待机姿势同一套起手的动作，过渡最自然
window.IDLE_MOVES = ["tilt", "tilt2", "nod", "forward"];
