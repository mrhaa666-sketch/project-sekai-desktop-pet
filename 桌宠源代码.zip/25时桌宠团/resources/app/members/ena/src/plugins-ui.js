'use strict';
const P = window.pluginsAPI;
const $ = (id) => document.getElementById(id);
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
let busy = new Set();
let toastT;
function toast(t) { const el = $('toast'); el.textContent = t; el.classList.add('show'); clearTimeout(toastT); toastT = setTimeout(() => el.classList.remove('show'), 2600); }

function statusOf(p) {
  if (p.problem) return ['problem', '不可用：' + p.problem];
  if (p.status === 'active') return ['active', '运行中' + (p.hasRenderer ? ' · 含页面脚本' : '') + (p.menuCount ? ` · ${p.menuCount} 个菜单项` : '')];
  if (p.status === 'error') return ['error', '启用失败：' + p.error];
  return ['stopped', p.enabled ? '等待启用' : '已停用'];
}
function render(list) {
  const box = $('list');
  if (!list || !list.length) { box.innerHTML = '<div class="empty">还没有插件。<br>点“打开插件文件夹”，把插件放进去后点“刷新列表”。</div>'; return; }
  box.innerHTML = list.map((p) => {
    const [cls, text] = statusOf(p);
    const on = p.enabled && !p.problem;
    const b = busy.has(p.id);
    return `<div class="card ${p.status === 'active' ? 'on' : ''}" data-id="${esc(p.id)}">
      <div class="row">
        <div class="info">
          <div class="name">${esc(p.name)} ${p.version ? `<span class="badge">v${esc(p.version)}</span>` : ''}<span class="badge">${p.source === 'bundled' ? '自带' : '自装'}</span></div>
          ${p.description ? `<div class="desc">${esc(p.description)}</div>` : ''}
          <div class="status ${cls}"><span class="dot"></span><span>${esc(text)}</span></div>
        </div>
        <label class="switch" title="${on ? '停用' : '启用'}"><input type="checkbox" data-act="toggle" ${on ? 'checked' : ''} ${p.problem || b ? 'disabled' : ''} aria-label="启用 ${esc(p.name)}"><span></span></label>
      </div>
      <div class="actions">
        <button data-act="reload" ${p.problem || b || !p.enabled ? 'disabled' : ''}>重新加载</button>
        <button data-act="folder">打开所在文件夹</button>
      </div>
      ${p.logs && p.logs.length ? `<details><summary>最近日志（${p.logs.length}）</summary><pre>${esc(p.logs.join('\n'))}</pre></details>` : ''}
      <div class="sub" style="margin-top:8px">ID：${esc(p.id)}</div>
    </div>`;
  }).join('');
}
async function act(id, what, el) {
  if (busy.has(id)) return;
  busy.add(id);
  try {
    if (what === 'folder') { P.openFolder(id); return; }
    let r;
    if (what === 'toggle') r = await P.set(id, el.checked);
    if (what === 'reload') r = await P.reload(id);
    if (r && r.list) cache = r.list;
    if (r && r.error) toast(r.error);
    else if (r && r.status === 'error') toast('启用失败，详情见卡片上的说明');
    else if (what === 'toggle') toast(el.checked ? '已启用' : '已停用');
    else if (what === 'reload') toast('已重新加载');
  } finally { busy.delete(id); render(cache); }
}
let cache = [];
$('list').addEventListener('click', (e) => {
  const b = e.target.closest('button[data-act]'); if (!b) return;
  act(b.closest('.card').dataset.id, b.dataset.act, b);
});
$('list').addEventListener('change', (e) => {
  const i = e.target.closest('input[data-act="toggle"]'); if (!i) return;
  act(i.closest('.card').dataset.id, 'toggle', i);
});
$('openDir').onclick = () => P.openFolder();
$('docs').onclick = () => P.openFolder('docs');
$('log').onclick = () => P.openFolder('log');
$('rescan').onclick = async () => { cache = await P.rescan(); render(cache); toast(`找到 ${cache.length} 个插件`); };

(async () => {
  const info = await P.info();
  if (!info) return;
  const t = info.theme || {};
  for (const [k, v] of Object.entries(t)) if (/^#[0-9a-f]{3,8}$/i.test(String(v))) document.documentElement.style.setProperty('--' + k, v);
  if (t.mark) document.querySelector('.mark').textContent = t.mark;
  document.title = `${info.petName}桌宠 · 插件管理`;
  $('title').textContent = `${info.petName}的插件`;
  $('note').title = info.userDir;
  cache = info.list; render(cache);
  P.onChanged((list) => { cache = list; render(cache); });
})();
