// 插件自己打开的窗口：页面里用 window.pluginAPI 和插件主脚本通信
const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('pluginAPI', {
  /** 调用插件主脚本里 api.ipc.handle(channel, fn) 注册的函数，返回它的结果 */
  invoke: (channel, data) => ipcRenderer.invoke('plugin-window-invoke', { channel: String(channel), data }),
  /** 接收插件主脚本 api.windows.post(win, channel, data) 发来的消息 */
  on: (channel, cb) => {
    const fn = (_e, m) => { if (m && m.channel === String(channel)) cb(m.data); };
    ipcRenderer.on('plugin-window-event', fn);
    return () => ipcRenderer.removeListener('plugin-window-event', fn);
  },
});
