// 好感值（隐性变量）和心情余韵
// 好感存在 userData/affection.json：0~100，由聊天模型每次自己判断要不要变（大多数时候不变）。
// 心情余韵：上一次比较强的心情不会马上消失，随时间慢慢回落（半衰期默认 20 分钟）。
const fs = require('fs');
const path = require('path');

// 好感分段：给模型看的描述（决定他的态度）
const BANDS = [
  {
    "min": 0,
    "name": "疏远",
    "desc": "最近和{name}有些隔阂，会避开亲密话题，也会直接说出不舒服的地方；不故意伤人，不为迎合而装开心"
  },
  {
    "min": 20,
    "name": "拘谨",
    "desc": "还在观察和试探，日常说话仍用普通口语，暂时不愿多讲自己的心事，不变成公事公办的客服语气"
  },
  {
    "min": 40,
    "name": "平常",
    "desc": "像熟悉的人一样随意接话，有时开小玩笑，有时认真说自己的看法，不刻意表演可爱"
  },
  {
    "min": 60,
    "name": "亲近",
    "desc": "信任{name}，相处时放松，能自然调侃，也能坦率说自己的想法；分享近况以真实聊天内容为准，不编造刚发生的事"
  },
  {
    "min": 80,
    "name": "信赖",
    "desc": "很信任{name}，愿意分享在意的事，也能放心安静下来；亲近表现得自然，不强制每句告白、撒娇或安慰"
  }
];
const bandOf = (v) => BANDS.slice().reverse().find((b) => v >= b.min) || BANDS[0];

// 哪些心情会留下余韵，以及余韵怎么描述
const LINGER = {
  angry: '还有点生气', sulky: '还在闹别扭', hurt: '心里还有点难受', sad: '还有些低落', troubled: '还有点烦',
  warm: '还留着被关心后的好心情', soft: '心情还很平静柔和', shy: '还有点不好意思', flustered: '还有点慌', happy: '心情还很好',
};

class Affection {
  constructor(file, getCfg) {
    this.file = file;
    this.getCfg = getCfg;
    this.state = { value: 55, log: [], mood: null };   // mood: { mood, intensity, at }
    this.load();
  }
  load() {
    try { this.state = { ...this.state, ...JSON.parse(fs.readFileSync(this.file, 'utf8')) }; } catch (e) {}
    this.state.value = clamp(this.state.value, 0, 100);
    if (!Array.isArray(this.state.log)) this.state.log = [];
  }
  save() {
    try {
      fs.mkdirSync(path.dirname(this.file), { recursive: true });
      fs.writeFileSync(this.file + '.tmp', JSON.stringify(this.state, null, 2));
      fs.renameSync(this.file + '.tmp', this.file);
    } catch (e) {}
  }
  cfg() {
    const s = this.getCfg();
    return {
      on: s.affectionEnabled !== false,
      maxStep: clamp(+s.affectionMaxStep || 3, 1, 10),       // 一次最多变多少
      dayCap: clamp(+s.affectionDayCap || 10, 1, 50),        // 一天最多累计变多少（防止一下子大起大落）
      halfLife: clamp(+s.moodHalfLife || 20, 1, 240),        // 心情余韵的半衰期（分钟）
    };
  }

  // 模型给的变化：{ delta, reason }。按单次上限、每日上限裁剪后再记
  apply(change, source = '聊天') {
    const c = this.cfg();
    if (!c.on || !change) return null;
    let d = Math.round(Number(change.delta));
    if (!Number.isFinite(d) || d === 0) return null;
    d = clamp(d, -c.maxStep, c.maxStep);
    const since = Date.now() - 24 * 3600000;
    const today = this.state.log.filter((x) => x.at > since).reduce((a, x) => a + x.delta, 0);
    // 当天已经往这个方向变了很多：只允许变到上限为止
    // 今天这个方向还剩多少额度（不会小于 0：上限调低了、或手动改过，额度用完就是 0，绝不能反过来变）
    if (d > 0) d = Math.min(d, Math.max(0, c.dayCap - Math.max(0, today)));
    else d = -Math.min(-d, Math.max(0, c.dayCap + Math.min(0, today)));
    if (d === 0) return { delta: 0, capped: true };
    const before = this.state.value;
    this.state.value = clamp(before + d, 0, 100);
    const real = this.state.value - before;
    if (!real) return null;
    const item = { at: Date.now(), delta: real, value: this.state.value, reason: String(change.reason || '').slice(0, 60), source };
    this.state.log.push(item);
    this.state.log = this.state.log.slice(-200);
    this.save();
    return item;
  }

  // 记下这次回复的心情（强一点的才算）
  feel(mood, intensity) {
    if (!LINGER[mood]) return;
    const k = intensity == null ? 0.4 : Number(intensity);
    if (!(k >= 0.3)) return;
    const cur = this.lingering();
    // 新心情不比余韵弱，或者是另一种心情：替换
    if (!cur || cur.mood !== mood || k >= cur.level) this.state.mood = { mood, intensity: k, at: Date.now() };
    this.save();
  }
  // 现在还剩多少余韵：{ mood, level(0~1), text }；太弱就算没有了
  lingering() {
    const m = this.state.mood;
    if (!m || !LINGER[m.mood]) return null;
    const mins = (Date.now() - m.at) / 60000;
    const level = m.intensity * Math.pow(0.5, mins / this.cfg().halfLife);
    if (level < 0.15) return null;
    return { mood: m.mood, level: +level.toFixed(2), text: LINGER[m.mood] + (level < 0.3 ? '（快过去了）' : '') };
  }

  // 附在消息末尾的那一段
  tailText(name) {
    const parts = [];
    if (this.cfg().on) {
      const v = this.state.value, b = bandOf(v);
      parts.push(`你对${name}的好感：${v}/100（${b.name}：${b.desc.replace(/\{name\}/g, name)}）`);
    }
    const l = this.lingering();
    if (l) parts.push(`你现在的心情：${l.text}`);
    return parts.join('；');
  }

  // 调试页用
  info() {
    const v = this.state.value;
    return { value: v, band: bandOf(v).name, bands: BANDS.map((b) => ({ min: b.min, name: b.name })), log: this.state.log.slice(-30).reverse(), lingering: this.lingering(), cfg: this.cfg() };
  }
  set(v, reason = '手动调整') {
    v = clamp(Math.round(+v), 0, 100);
    const d = v - this.state.value;
    this.state.value = v;
    if (d) this.state.log.push({ at: Date.now(), delta: d, value: v, reason, source: '手动' });
    this.save();
    return this.info();
  }
  clearMood() { this.state.mood = null; this.save(); }
}

function clamp(v, a, b) { v = Number(v); return Number.isFinite(v) ? Math.max(a, Math.min(b, v)) : a; }

module.exports = { Affection, BANDS };
