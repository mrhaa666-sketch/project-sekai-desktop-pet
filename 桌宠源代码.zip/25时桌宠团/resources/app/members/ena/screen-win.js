// Windows 单帧截图。只在收到请求时复制像素；辅助进程空闲时不采集画面。
const { app } = require('electron');
const { spawn } = require('child_process');
const path = require('path');
const { performance } = require('perf_hooks');

class WinScreenCapture {
  constructor(options = {}) {
    this.spawn = options.spawn || spawn;
    this.script = options.script || path.join(__dirname, 'screen-win.ps1');
    this.startupTimeout = options.startupTimeout || 15000;
    this.captureTimeout = options.captureTimeout || 6000;
    this.child = null; this.ready = false; this.starting = null; this.startup = null;
    this.pending = null; this.buffer = ''; this.stderr = ''; this.seq = 0; this.busy = false;
  }
  start() {
    if (this.ready && this.child) return Promise.resolve();
    if (this.starting) return this.starting;
    let child;
    try {
      const exe = path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe');
      child = this.spawn(exe, ['-NoLogo', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', this.script], {
        windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'],
      });
    } catch (e) { return Promise.reject(e); }
    this.child = child; this.buffer = ''; this.stderr = ''; this.ready = false;
    const promise = new Promise((resolve, reject) => {
      const timer = setTimeout(() => this.fail(child, new Error('Windows 截图服务启动超时')), this.startupTimeout);
      this.startup = { resolve, reject, timer };
    });
    this.starting = promise;
    promise.then(() => { if (this.child === child) this.starting = null; }, () => { if (!this.child || this.child === child) this.starting = null; });
    child.stdout.setEncoding('utf8'); child.stderr.setEncoding('utf8');
    child.stdout.on('data', (chunk) => {
      if (this.child !== child) return;
      this.buffer += chunk;
      if (this.buffer.length > 16 * 1024 * 1024) return this.fail(child, new Error('截图返回的数据过大'));
      let newline;
      while ((newline = this.buffer.indexOf('\n')) >= 0) {
        const line = this.buffer.slice(0, newline).trim(); this.buffer = this.buffer.slice(newline + 1);
        if (!line) continue;
        let message;
        try { message = JSON.parse(line); } catch (e) { this.fail(child, new Error('Windows 截图服务返回格式错误')); return; }
        this.receive(child, message);
        if (this.child !== child) return;
      }
    });
    child.stderr.on('data', (chunk) => { if (this.child === child) this.stderr = (this.stderr + chunk).slice(-500); });
    child.stdin.on('error', () => this.fail(child, new Error('Windows 截图服务通信中断')));
    child.on('error', (e) => this.fail(child, new Error('无法启动 Windows 截图服务：' + e.message)));
    child.on('exit', (code) => this.fail(child, new Error('Windows 截图服务已退出（' + code + '）' + (this.stderr ? '：' + this.stderr : ''))));
    return promise;
  }
  receive(child, message) {
    if (!message || typeof message !== 'object') return this.fail(child, new Error('截图服务返回格式错误'));
    if ('ready' in message) {
      if (!this.startup) return;
      if (message.ready !== true) return this.fail(child, new Error('Windows 截图服务初始化失败：' + String(message.error || '未知错误')));
      this.ready = true;
      const startup = this.startup; this.startup = null;
      clearTimeout(startup.timer); startup.resolve();
      return;
    }
    const pending = this.pending;
    if (!pending || message.id !== pending.id) return;
    this.pending = null; clearTimeout(pending.timer);
    if (message.error) pending.reject(new Error('Windows 单帧截图失败：' + String(message.error)));
    else if (typeof message.b64 !== 'string' || !message.b64.startsWith('/9j/')) pending.reject(new Error('Windows 截图服务没有返回 JPEG'));
    else pending.resolve({ b64: message.b64, timings: message.timings || {} });
  }
  fail(child, error) {
    if (this.child !== child) return;
    this.child = null; this.ready = false; this.buffer = '';
    const startup = this.startup; this.startup = null;
    if (startup) { clearTimeout(startup.timer); startup.reject(error); }
    const pending = this.pending; this.pending = null;
    if (pending) { clearTimeout(pending.timer); pending.reject(error); }
    this.starting = null;
    try { child.stdin.end(); } catch (e) {}
    try { child.kill(); } catch (e) {}
  }
  async capture({ rect, maxSide = 1280 }) {
    if (this.busy) throw new Error('Windows 截图正在进行');
    if (!rect || !['x', 'y', 'width', 'height'].every((k) => Number.isSafeInteger(rect[k])) || rect.width < 1 || rect.height < 1 || rect.width > 16384 || rect.height > 16384 || rect.width * rect.height > 67108864 || Math.abs(rect.x) > 200000 || Math.abs(rect.y) > 200000) throw new Error('截图区域无效');
    if (!Number.isSafeInteger(maxSide) || maxSide < 128 || maxSide > 1920) throw new Error('截图尺寸无效');
    this.busy = true;
    const started = performance.now();
    let lagMs = 0, lastTick = started;
    const heartbeat = setInterval(() => { const now = performance.now(); lagMs = Math.max(lagMs, now - lastTick - 25); lastTick = now; }, 25);
    try {
      const reusedWorker = this.ready && !!this.child;
      await this.start();
      const readyAt = performance.now(), child = this.child, id = ++this.seq;
      const result = await new Promise((resolve, reject) => {
        const timer = setTimeout(() => this.fail(child, new Error('Windows 单帧截图超时，已停止辅助进程')), this.captureTimeout);
        this.pending = { id, resolve, reject, timer };
        try {
          child.stdin.write(JSON.stringify({ id, op: 'capture', rect, maxSide }) + '\n', (e) => { if (e) this.fail(child, new Error('无法发送截图请求：' + e.message)); });
        } catch (e) { this.fail(child, e); }
      });
      return { ...result, workerReadyMs: Math.round(readyAt - started), reusedWorker, eventLoopLagMs: Math.round(Math.max(0, lagMs)), requestMs: Math.round(performance.now() - readyAt) };
    } finally { clearInterval(heartbeat); this.busy = false; }
  }
  close() { if (this.child) this.fail(this.child, new Error('Windows 截图服务已关闭')); }
}

const worker = new WinScreenCapture();
if (app && app.once) app.once('will-quit', () => worker.close());
module.exports = { prepare: () => worker.start(), capture: (options) => worker.capture(options), close: () => worker.close(), WinScreenCapture };
