const { cleanKey, keyIssue } = require('./llm');
// 语音识别：把一段录音（16kHz 单声道 WAV）交给 OpenAI 兼容的 /audio/transcriptions 接口。
// 默认是硅基流动的 SenseVoice；换别家只要在设置里改地址和模型名。
// 这一版是「分段识别」：说完一句才上传识别，不是边说边出字的流式识别。

// 常见的“没说话却识别出字”的幻觉，直接当作无效
const JUNK = [/^[\s\p{P}\p{S}]*$/u, /^(谢谢观看|谢谢收看|感谢观看|字幕由.*|请不吝点赞.*|ご視聴ありがとうございました)[。！!.]*$/u];

function cleanText(t) {
  return String(t || '')
    .replace(/<\|[^|]*\|>/g, '')          // SenseVoice 的语言/情绪标签
    .replace(/[\u{1F300}-\u{1FAFF}☀-➿]/gu, '')   // 表情符号
    .replace(/\s+/g, ' ')
    .trim();
}

function isJunk(t) {
  return !t || JUNK.some((r) => r.test(t));
}

async function transcribe(cfg, wav, signal) {
  if (signal && signal.aborted) return { error: 'aborted' };
  if (!cfg.asrKey) return { error: 'noasr' };
  const ctrl = new AbortController();
  const abort = () => ctrl.abort();
  const timer = setTimeout(abort, 30000);
  if (signal) { signal.addEventListener('abort', abort, { once: true }); if (signal.aborted) abort(); }
  try {
    if (ctrl.signal.aborted) return { error: 'aborted' };
    const ki = keyIssue(cfg.asrKey, '语音识别 API 密钥');
    if (ki) return { error: ki };
    const url = (cfg.asrBase || 'https://api.siliconflow.cn').replace(/\/+$/, '') + '/v1/audio/transcriptions';
    const form = new FormData();
    form.append('file', new Blob([wav], { type: 'audio/wav' }), 'speech.wav');
    form.append('model', cfg.asrModel || 'FunAudioLLM/SenseVoiceSmall');
    if (cfg.asrLang) form.append('language', cfg.asrLang);
    const res = await fetch(url, { method: 'POST', headers: { Authorization: `Bearer ${cleanKey(cfg.asrKey)}` }, body: form, signal: ctrl.signal });
    if (!res.ok) {
      const body = await res.text().catch(e => { if (ctrl.signal.aborted) throw e; return ''; });
      if (ctrl.signal.aborted) throw new Error('aborted');
      const hint = { 401: '识别服务密钥不对', 402: '识别服务余额不足', 403: '识别服务没有权限', 429: '识别请求太频繁', 404: '识别地址或模型名不对' }[res.status] || '识别服务出错';
      return { error: `${res.status} ${hint} ${body.slice(0, 100)}`.trim() };
    }
    const data = await res.json().catch(e => { if (ctrl.signal.aborted) throw e; return {}; });
    if (ctrl.signal.aborted) throw new Error('aborted');
    const text = cleanText(data.text);
    if (isJunk(text)) return { text: '', empty: true };
    return { text };
  } catch (e) {
    if (signal && signal.aborted) return { error: 'aborted' };
    if (ctrl.signal.aborted) return { error: '识别超时，请重试' };
    return { error: '连不上识别服务：' + e.message };
  } finally {
    clearTimeout(timer);
    if (signal) signal.removeEventListener('abort', abort);
  }
}

module.exports = { transcribe, cleanText, isJunk };
