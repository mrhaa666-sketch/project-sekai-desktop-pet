'use strict';
const fs = require('fs');
const path = require('path');

const MAX_ITEMS = 100;
const MAX_CHARS = 15000;
const SOURCE_LABELS = Object.freeze({
  idle: '待机', fixed: '被点到/反应', generated: '回复',
  call: '通话', doze: '打瞌睡', direct: '其他',
});


// 补充实际显示/播放过、但没有进入模型对话历史的发言。
// 不伪造用户消息，不把音频合成预取当成已经说出口。
class SpeechContext {
  constructor(brain, file, log = () => {}) {
    this.brain = brain; this.file = file; this.log = log;
    this.entries = []; this.ids = new Set();
    this.load();
    const tail = brain.tail;
    brain.tail = (...args) => {
      // 普通 tail() 用于存档；仅请求模型时显式开启，避免把补充记录反复写入聊天历史。
      const original = tail.apply(brain, args), extra = args[1] && args[1].speech ? this.context(args[1].history) : '';
      return original + (extra ? `\n\n【最近你自己说出口的话（按时间先后，包括待机时的自言自语、被点到时的反应和回复；这些都是你说的，不是用户说的，被问起或延续话题时要能接上）】\n${extra}` : '');
    };
    const clear = brain.clear;
    brain.clear = (...args) => { const result = clear.apply(brain, args); this.clear(); return result; };
  }
  load() {
    let fd;
    try {
      fd = fs.openSync(this.file, 'r');
      const size = fs.fstatSync(fd).size, start = Math.max(0, size - 512 * 1024);
      const data = Buffer.alloc(size - start);
      fs.readSync(fd, data, 0, data.length, start);
      const lines = data.toString('utf8').split('\n');
      if (start) lines.shift();
      for (const line of lines) {
        try {
          const e = JSON.parse(line);
          if (e && typeof e.tag === 'string' && e.tag.includes('出错')) continue;
          if (e && e.type === 'clear') { this.entries = []; this.ids.clear(); continue; }
          if (e && typeof e.text === 'string' && e.id && !this.ids.has(e.id)) { this.entries.push(e); this.ids.add(e.id); }
        } catch (_) {}
      }
      this.trim();
    } catch (_) {} finally { if (fd !== undefined) fs.closeSync(fd); }
  }
  trim() {
    if (this.entries.length > 300) this.entries.splice(0, this.entries.length - 300);
    this.ids = new Set(this.entries.map(e => e.id));
  }
  append(e) {
    try { fs.mkdirSync(path.dirname(this.file), { recursive: true }); fs.appendFileSync(this.file, JSON.stringify(e) + '\n', 'utf8'); }
    catch (err) { this.log('发言记录保存失败：' + err.message); }
  }
  record(payload) {
    if (!payload || typeof payload !== 'object' || typeof payload.text !== 'string') return false;
    if (typeof payload.tag === 'string' && payload.tag.includes('出错')) return false;
    const text = payload.text.trim(), ja = typeof payload.ja === 'string' ? payload.ja.trim() : '';
    if (!text || text.length > 20000 || ja.length > 20000) return false;
    const id = typeof payload.id === 'string' && payload.id.length <= 180 ? payload.id : `${Date.now()}-${Math.random().toString(36).slice(2)}`;
    if (this.ids.has(id)) return false;
    const source = ['idle','fixed','generated','call','direct','doze'].includes(payload.source) ? payload.source : 'direct';
    const e = { id, at: Date.now(), text, ja, source, tag: typeof payload.tag === 'string' ? payload.tag.slice(0,100) : '' };
    this.entries.push(e); this.ids.add(id); this.trim(); this.append(e);
    return true;
  }
  context(history = this.brain.history || []) {
    const model = history.filter(h => h.role === 'assistant').map(h => {
      try { return typeof h.content === 'string' ? JSON.parse(h.content) : h.content; } catch (_) { return null; }
    }).filter(Boolean);
    const omitted = e => {
      if (e.source === 'generated') return model.some(h => h.reply === e.text && (!e.ja || !h.ja || h.ja === e.ja));
      if (e.source === 'call') return model.some(h => h.via === 'call' && ((e.ja && String(h.ja || '').includes(e.ja)) || String(h.reply || '').includes(e.text)));
      return false;
    };
    const lines = []; let size = 0;
    for (const e of this.entries.slice(-MAX_ITEMS).reverse()) {
      if (omitted(e)) continue;
      const d = new Date(e.at);
      const pad2 = n => String(n).padStart(2, '0');
      const time = `${d.getMonth() + 1}月${d.getDate()}日 ${pad2(d.getHours())}:${pad2(d.getMinutes())}`;
      const source = SOURCE_LABELS[e.source] || SOURCE_LABELS.direct;
      const tag = typeof e.tag === 'string' ? e.tag.replace(/\s+/g, ' ').trim() : '';
      const prefix = `[${time}｜${source}${tag ? '｜' + tag : ''}] `;
      const text = e.text.replace(/\s+/g, ' ').trim();
      const remaining = MAX_CHARS - size - (lines.length ? 1 : 0);
      if (remaining <= prefix.length + 2) break;
      let line = prefix + text;
      if (line.length > remaining) {
        const keep = remaining - prefix.length - 2;
        // 超长的一条只保留结尾；不截出半个emoji字符。
        const tail = text.slice(-keep).replace(/^[\uDC00-\uDFFF]/, '');
        line = prefix + '……' + tail;
      }
      size += line.length + (lines.length ? 1 : 0);
      lines.push(line);
    }
    return lines.reverse().join('\n');
  }
  clear() {
    this.entries = []; this.ids.clear();
    try { fs.mkdirSync(path.dirname(this.file), {recursive:true}); fs.writeFileSync(this.file, '', 'utf8'); }
    catch (_) { this.append({type:'clear',at:Date.now()}); }
  }
}
module.exports = { SpeechContext };
