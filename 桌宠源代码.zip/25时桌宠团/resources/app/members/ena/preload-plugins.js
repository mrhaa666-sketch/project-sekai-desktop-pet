// 插件管理窗口
const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('pluginsAPI', {
  info: () => ipcRenderer.invoke('plugins-info'),
  set: (id, on) => ipcRenderer.invoke('plugins-set', { id, on }),
  reload: (id) => ipcRenderer.invoke('plugins-reload', id),
  rescan: () => ipcRenderer.invoke('plugins-rescan'),
  openFolder: (which) => ipcRenderer.send('plugins-open-folder', which),
  onChanged: (cb) => ipcRenderer.on('plugins-changed', (_e, list) => cb(list)),
});
