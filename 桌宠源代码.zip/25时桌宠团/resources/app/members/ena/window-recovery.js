'use strict';

// 只约束人物窗口的位置，不把透明字幕区误当作人物仍在屏幕内。
function fitPosition(base, size, displays, primary) {
  const [w, h] = size;
  const areas = displays.map((d) => d.workArea).filter((a) => a && a.width > 0 && a.height > 0);
  const fallback = primary.workArea;
  let x = Number.isFinite(base.x) ? base.x : fallback.x + fallback.width - w - 40;
  let y = Number.isFinite(base.y) ? base.y : fallback.y + fallback.height - h;
  const cx = x + w / 2, cy = y + h / 2;
  let best = fallback, distance = Infinity;
  for (const a of areas) {
    const dx = Math.max(a.x - cx, 0, cx - a.x - a.width);
    const dy = Math.max(a.y - cy, 0, cy - a.y - a.height);
    const d = dx * dx + dy * dy;
    if (d < distance) { distance = d; best = a; }
  }
  x = Math.round(Math.max(best.x, Math.min(x, best.x + Math.max(0, best.width - w))));
  y = Math.round(Math.max(best.y, Math.min(y, best.y + Math.max(0, best.height - h))));
  return { x, y };
}

class WindowRecovery {
  constructor({ win, screen, settings, repairPosition, cancelDrag, log }) {
    Object.assign(this, { win, screen, settings, repairPosition, cancelDrag, log });
    this.disposed = false;
    this.reloads = [];
    this.listeners = [];
    this.pending = this.contextTimer = this.displayTimer = this.hangTimer = null;
    this.contextLost = this.reloading = false;
    const on = (target, name, fn) => { target.on(name, fn); this.listeners.push([target, name, fn]); };
    on(win, 'blur', () => cancelDrag());
    for (const name of ['show', 'hide', 'minimize', 'restore']) on(win, name, () => this.record(name));
    on(win.webContents, 'render-process-gone', (_e, d) => this.schedule('页面退出：' + d.reason, 1500));
    on(win.webContents, 'unresponsive', () => {
      this.record('页面无响应');
      if (this.hangTimer) return;
      this.hangTimer = setTimeout(() => { this.hangTimer = null; this.schedule('页面持续无响应', 0); }, 10000);
    });
    on(win.webContents, 'responsive', () => { clearTimeout(this.hangTimer); this.hangTimer = null; });
    on(win.webContents, 'did-start-loading', () => {
      clearTimeout(this.contextTimer); this.contextTimer = null; this.contextLost = false;
      clearTimeout(this.hangTimer); this.hangTimer = null;
    });
    on(win.webContents, 'did-finish-load', () => { this.reloading = false; repairPosition(); });
    on(win.webContents, 'did-fail-load', () => { this.reloading = false; this.record('页面加载失败'); });
    for (const name of ['display-added', 'display-removed', 'display-metrics-changed']) on(screen, name, () => {
      clearTimeout(this.displayTimer);
      this.displayTimer = setTimeout(() => {
        this.displayTimer = null;
        if (!this.alive()) return;
        cancelDrag(); repairPosition(); this.record('显示模式变化');
      }, 350);
    });
    on(win, 'closed', () => this.dispose());
  }

  alive() { return !this.disposed && !this.win.isDestroyed(); }

  record(reason) {
    if (!this.alive()) return;
    this.log(reason + ' ' + JSON.stringify({ visible: this.win.isVisible(), minimized: this.win.isMinimized(), bounds: this.win.getBounds() }));
  }

  renderState(state) {
    if (!this.alive() || this.reloading) return;
    if (state === 'webgl-lost') {
      if (this.contextLost) return;
      this.contextLost = true; this.record('WebGL 绘图环境丢失');
      this.contextTimer = setTimeout(() => {
        this.contextTimer = null;
        this.schedule('WebGL 8 秒未恢复', 0);
      }, 8000);
    } else if (state === 'webgl-restored' && this.contextLost) {
      clearTimeout(this.contextTimer); this.contextTimer = null;
      // Live2D 持有自己的 GPU 缓冲，恢复事件后重新载入，避免只恢复 PIXI 贴图。
      this.schedule('WebGL 恢复后重建模型', 500);
    }
  }

  gpuGone(details) {
    if (details.type === 'GPU' && details.reason !== 'clean-exit') this.schedule('GPU 进程退出：' + details.reason, 1500);
  }

  schedule(reason, delay) {
    if (!this.alive() || this.pending || this.reloading) return;
    this.record(reason);
    this.pending = setTimeout(() => { this.pending = null; this.reload(reason); }, delay);
  }

  reload(reason, manual = false) {
    if (!this.alive() || (this.reloading && !manual)) return false;
    const now = Date.now();
    // 允许手动救回卡在加载中的页面；快速连点仍只执行一次。
    if (manual && this.lastManual && now - this.lastManual < 1000) return false;
    if (manual) this.lastManual = now;
    this.reloads = this.reloads.filter((t) => now - t < 600000);
    if (!manual && this.reloads.length >= 3) { this.record('10 分钟内已恢复 3 次，停止自动重载'); return false; }
    clearTimeout(this.pending); this.pending = null;
    clearTimeout(this.contextTimer); this.contextTimer = null;
    clearTimeout(this.hangTimer); this.hangTimer = null;
    this.contextLost = false;
    this.reloads.push(now); this.reloading = true;
    this.cancelDrag(); this.repairPosition();
    this.win.setIgnoreMouseEvents(true, { forward: true });
    if (manual) {
      if (this.win.isMinimized()) this.win.restore();
      this.win.setOpacity(1);
      // 只在用户明确恢复时重建显隐和层级，不在游戏中循环抢前台。
      this.win.hide();
      this.win.setAlwaysOnTop(!!this.settings().alwaysOnTop);
      this.win.showInactive();
      if (this.settings().alwaysOnTop) this.win.moveTop();
    }
    this.record((manual ? '手动' : '自动') + '重载画面：' + reason);
    try { this.win.webContents.reload(); }
    catch (e) { this.reloading = false; this.log('重载失败：' + e.message); return false; }
    return true;
  }

  dispose() {
    this.disposed = true;
    for (const key of ['pending', 'contextTimer', 'displayTimer', 'hangTimer']) clearTimeout(this[key]);
    for (const [target, name, fn] of this.listeners) target.removeListener(name, fn);
    this.listeners = [];
  }
}

module.exports = { WindowRecovery, fitPosition };
