# 东云绘名桌宠 1.0.0

Windows Electron 桌宠。入口 main.js，界面 src/index.html。三套模型：src/model（粉色常服）、src/model_school（校服）、src/model_casual（格裙常服）。

main.js：窗口、托盘菜单、聊天、语音、记忆、好感、看屏幕、提醒、备份、插件，以及换装时间表（工作日 18:00–21:00 校服，其余时间两套常服随机换）。
brain.js：绘名的人设与聊天协议。src/lines.js：表情代号、动作代号（BODY 把同一个动作对应到两套命名的文件）、心情和固定台词。
src/renderer.js：模型渲染、动作分层与过渡（按姿势差距自动决定过渡时长）、换装、布局（三套模型共用同一个显示框）。

画室：paint.js（主进程：请求硅基流动图片生成接口 /images/generations、看图、听曲、整理提示词，密钥只在主进程），
preload-paint.js，src/paint.html、src/paint-ui.js（窗口），src/music-analysis.js、src/paint-worker.js（曲生图的本地分析）。

插件接口与其他桌宠相同：plugins.js、src/plugin-host.js、plugins/插件开发说明.md。

UI 主题：代表色 #CCAA88，暖奶茶色底与深棕色文字，主按钮焦糖棕 #8F5E38。
本包不含任何密钥或私人数据。验证用的自动测试在程序根目录的“验证”文件夹。

## 发言上下文规则

实际发言按原有 JSONL 格式保存在本机；待机自言自语单独标为“待机”，点击及其他固定反应标为“被点到/反应”。请求模型时，补充上下文使用本地月日与时分、中文来源及可选标签，每条一行，不再重复附带日语译文。最多读取最近100条、合计约15000字符；超长条目只保留结尾并标注“……”。已在本次聊天历史中的回复、通话继续去重；标签含“出错”的新旧提示均不作为角色发言。聊天历史格式、人设和 memoryTurns 规则不变。
