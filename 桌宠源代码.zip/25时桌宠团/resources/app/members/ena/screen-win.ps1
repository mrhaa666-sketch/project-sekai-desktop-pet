﻿# 按请求单次复制屏幕像素；不枚举 Electron 来源、不启动录屏、不写图片到磁盘。
$ErrorActionPreference = 'Stop'
[Console]::InputEncoding = New-Object System.Text.UTF8Encoding($false)
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
$taskInit = [System.Diagnostics.Stopwatch]::StartNew()
try {
    Add-Type -AssemblyName System.Drawing
    Add-Type -ReferencedAssemblies System.Drawing -TypeDefinition @'
using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;

public sealed class MafuyuScreenResult {
    public string b64;
    public int width, height;
    public long allocateMs, copyMs, resizeMs, encodeMs, totalMs;
}
public static class MafuyuSingleFrame {
    [DllImport("user32.dll")] private static extern IntPtr SetThreadDpiAwarenessContext(IntPtr context);
    private static readonly ImageCodecInfo Jpeg = FindJpeg();
    private static ImageCodecInfo FindJpeg() {
        foreach (ImageCodecInfo codec in ImageCodecInfo.GetImageEncoders())
            if (codec.FormatID == ImageFormat.Jpeg.Guid) return codec;
        throw new InvalidOperationException("JPEG encoder unavailable");
    }
    public static MafuyuScreenResult Capture(int x, int y, int width, int height, int maxSide) {
        if (width < 1 || height < 1 || width > 16384 || height > 16384 || (long)width * height > 67108864)
            throw new ArgumentException("Invalid capture dimensions");
        if (Math.Abs((long)x) > 200000 || Math.Abs((long)y) > 200000 || maxSide < 128 || maxSide > 1920)
            throw new ArgumentException("Invalid capture coordinates");
        IntPtr previous = IntPtr.Zero;
        try { previous = SetThreadDpiAwarenessContext(new IntPtr(-4)); } catch (EntryPointNotFoundException) { }
        var total = Stopwatch.StartNew();
        var step = Stopwatch.StartNew();
        var result = new MafuyuScreenResult();
        try {
            using (var original = new Bitmap(width, height, PixelFormat.Format24bppRgb)) {
                result.allocateMs = step.ElapsedMilliseconds;
                step.Restart();
                using (var graphics = Graphics.FromImage(original))
                    graphics.CopyFromScreen(x, y, 0, 0, new Size(width, height), CopyPixelOperation.SourceCopy);
                result.copyMs = step.ElapsedMilliseconds;
                double scale = Math.Min(1.0, (double)maxSide / Math.Max(width, height));
                int outWidth = Math.Max(1, (int)Math.Round(width * scale));
                int outHeight = Math.Max(1, (int)Math.Round(height * scale));
                step.Restart();
                using (var resized = new Bitmap(outWidth, outHeight, PixelFormat.Format24bppRgb)) {
                    using (var graphics = Graphics.FromImage(resized)) {
                        graphics.InterpolationMode = InterpolationMode.HighQualityBilinear;
                        graphics.DrawImage(original, new Rectangle(0, 0, outWidth, outHeight));
                    }
                    result.resizeMs = step.ElapsedMilliseconds;
                    step.Restart();
                    using (var memory = new MemoryStream())
                    using (var parameters = new EncoderParameters(1)) {
                        parameters.Param[0] = new EncoderParameter(System.Drawing.Imaging.Encoder.Quality, 80L);
                        resized.Save(memory, Jpeg, parameters);
                        result.b64 = Convert.ToBase64String(memory.ToArray());
                    }
                    result.encodeMs = step.ElapsedMilliseconds;
                    result.width = outWidth; result.height = outHeight;
                }
            }
            result.totalMs = total.ElapsedMilliseconds;
            return result;
        } finally {
            if (previous != IntPtr.Zero) SetThreadDpiAwarenessContext(previous);
        }
    }
}
'@
    [Console]::Out.WriteLine((@{ ready = $true; initMs = $taskInit.ElapsedMilliseconds } | ConvertTo-Json -Compress))
    [Console]::Out.Flush()
} catch {
    [Console]::Out.WriteLine((@{ ready = $false; error = $_.Exception.Message } | ConvertTo-Json -Compress))
    [Console]::Out.Flush()
    exit 1
}
while ($null -ne ($taskLine = [Console]::ReadLine())) {
    $taskId = 0
    try {
        $taskRequest = $taskLine | ConvertFrom-Json
        $taskId = [int]$taskRequest.id
        if ($taskRequest.op -ne 'capture') { throw 'Unknown capture operation' }
        $taskRect = $taskRequest.rect
        $taskResult = [MafuyuSingleFrame]::Capture([int]$taskRect.x, [int]$taskRect.y, [int]$taskRect.width, [int]$taskRect.height, [int]$taskRequest.maxSide)
        $taskReply = @{ id = $taskId; b64 = $taskResult.b64; timings = @{
            width = $taskResult.width; height = $taskResult.height; allocateMs = $taskResult.allocateMs;
            copyMs = $taskResult.copyMs; resizeMs = $taskResult.resizeMs; encodeMs = $taskResult.encodeMs; totalMs = $taskResult.totalMs
        } }
    } catch { $taskReply = @{ id = $taskId; error = $_.Exception.Message } }
    [Console]::Out.WriteLine(($taskReply | ConvertTo-Json -Compress -Depth 4))
    [Console]::Out.Flush()
}
