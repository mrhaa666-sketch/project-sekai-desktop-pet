// 最小插件：启用时加一个菜单项；停用时菜单项会被自动移除，不用自己清理。
exports.activate = (api) => {
  api.menu.add({
    label: '打个招呼',
    click: () => api.pet.say('嗯，插件已经能用了。', { mood: 'happy', action: 'nod' }),
  });
};
exports.deactivate = () => {};
