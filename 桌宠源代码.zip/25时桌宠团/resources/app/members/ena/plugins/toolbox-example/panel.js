const $ = (id) => document.getElementById(id);
function showNotes(list) {
  $('notes').innerHTML = '';
  for (const n of (list || []).slice().reverse()) { const li = document.createElement('li'); li.textContent = n.text; $('notes').appendChild(li); }
  if (!list || !list.length) $('notes').innerHTML = '<li>（空）</li>';
}
(async () => {
  const s = await pluginAPI.invoke('state');
  $('h').textContent = `${s.petName} · 小工具箱`;
  $('chime').checked = s.chime;
  $('stat').textContent = `插件启用后，她回复了 ${s.replies} 次。`;
  for (const m of ['calm', ...s.moods.filter((x) => x !== 'calm')]) { const o = document.createElement('option'); o.value = o.textContent = m; $('mood').appendChild(o); }
  showNotes(s.notes);
})();
$('say').onclick = async () => { const text = $('text').value.trim(); if (text) await pluginAPI.invoke('say', { text, mood: $('mood').value }); };
$('text').onkeydown = (e) => { if (e.key === 'Enter') $('say').click(); };
$('chime').onchange = () => pluginAPI.invoke('chime', $('chime').checked);
$('clear').onclick = async () => { await pluginAPI.invoke('clear-notes'); showNotes([]); };
pluginAPI.on('notes', showNotes);
