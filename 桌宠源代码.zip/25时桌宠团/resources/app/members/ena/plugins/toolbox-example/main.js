'use strict';
// 完整示例：演示插件接口的每一部分。复制这个文件夹改一改，就是你自己的插件。
const pad = (n) => String(n).padStart(2, '0');
let panel = null;

exports.activate = (api) => {
  const name = api.host.petName;
  api.log(`在 ${name} 上启用，接口版本 v${api.apiVersion}`);

  // 1) 菜单：普通项 + 勾选项（勾选状态存在插件自己的数据里）
  api.menu.add({ label: '小工具箱面板…', click: () => openPanel(api) });
  const chime = api.menu.add({
    label: '整点报时',
    type: 'checkbox',
    checked: api.storage.get('chime', false),
    click: ({ checked }) => { api.storage.set('chime', checked); api.pet.say(checked ? '整点的时候告诉你。' : '不报时了。', { mood: 'calm' }); },
  });

  // 2) 定时器：停用插件时自动清除
  let lastHour = new Date().getHours();
  api.timers.setInterval(() => {
    const d = new Date();
    if (d.getHours() !== lastHour) {
      lastHour = d.getHours();
      if (api.storage.get('chime', false)) api.pet.say(`${pad(d.getHours())}:00 了。`, { mood: 'calm', action: 'nod' });
    }
  }, 20000);

  // 3) 聊天指令：在聊天框输入 / 开头的指令，插件直接回答，不发给模型
  api.events.on('chat:before', (e) => {
    if (e.proactive) return;
    const t = e.text.trim();
    if (t === '/时间') {
      const d = new Date();
      e.cancel = true; e.reply = `现在是 ${pad(d.getHours())}:${pad(d.getMinutes())}。`; e.mood = 'calm';
    } else if (/^\/骰子/.test(t)) {
      const n = Math.max(2, Math.min(100, parseInt(t.replace('/骰子', ''), 10) || 6));
      e.cancel = true; e.reply = `${n} 面骰子……是 ${1 + Math.floor(Math.random() * n)}。`; e.mood = 'happy';
    } else if (/^\/备忘\s*/.test(t)) {
      const note = t.replace(/^\/备忘\s*/, '');
      const notes = api.storage.get('notes', []);
      if (note) { notes.push({ at: Date.now(), text: note.slice(0, 200) }); api.storage.set('notes', notes.slice(-50)); }
      e.cancel = true;
      e.reply = note ? `记下了：${note.slice(0, 40)}` : (notes.length ? `备忘有 ${notes.length} 条，最近一条：${notes[notes.length - 1].text}` : '还没有备忘。用“/备忘 内容”记一条。');
      if (panel && !panel.isDestroyed()) api.windows.post(panel, 'notes', api.storage.get('notes', []));
    }
  });

  // 4) 其它事件
  api.events.on('chat:reply', (r) => { if (!r.error) api.storage.set('replies', api.storage.get('replies', 0) + 1); });
  api.events.on('remind', ({ type }) => api.log('桌宠提醒了：' + type));
  api.events.on('pet:loaded', () => api.renderer.send({ type: 'hello', count: api.storage.get('replies', 0) }));

  // 5) 和页面脚本（renderer.js）通信：点人物旁的小按钮时收到
  api.renderer.onMessage((m) => {
    if (m && m.type === 'clicked') api.pet.say('要用小工具吗？右键 → 插件 → 小工具箱面板。', { mood: 'calm', action: 'tilt' });
  });

  // 6) 面板窗口里 pluginAPI.invoke(...) 调用的处理函数
  api.ipc.handle('state', () => ({ petName: name, notes: api.storage.get('notes', []), chime: api.storage.get('chime', false), replies: api.storage.get('replies', 0), moods: api.pet.moods }));
  api.ipc.handle('say', ({ text, mood } = {}) => ({ ok: api.pet.say(String(text || '').slice(0, 120), { mood: mood || 'calm' }) }));
  api.ipc.handle('chime', (on) => { api.storage.set('chime', !!on); chime.update({ checked: !!on }); return { ok: true }; });
  api.ipc.handle('clear-notes', () => { api.storage.set('notes', []); return { ok: true }; });

  api.onDispose(() => { panel = null; });
};

function openPanel(api) {
  if (panel && !panel.isDestroyed()) { panel.focus(); return; }
  panel = api.windows.open({ file: 'panel.html', width: 400, height: 470, title: '小工具箱' });
}

exports.deactivate = () => { /* 菜单、定时器、事件、窗口都会自动清理；这里放插件自己额外要收尾的东西 */ };
