'use strict';
/* 插件系统（主进程）
 *
 * 插件放在两个地方：
 *   1. 程序自带：resources/app/plugins/<插件文件夹>/
 *   2. 你自己装的：%APPDATA%\<数据目录>\plugins\<插件文件夹>\   （右键 → 插件 → 插件管理 → 打开插件文件夹）
 * 每个插件文件夹里要有 plugin.json（清单）和清单里 main 指向的主进程脚本；
 * 可选 renderer 脚本，会在桌宠页面里运行（能让她说话、在人物周围放小控件）。
 *
 * 生命周期：发现 → 启用（activate(api)）→ 停用（deactivate()，然后自动清理插件注册过的所有东西）。
 * 启用状态记在数据目录的 plugins.json；新发现的插件默认不启用，需要在插件管理里手动打开。
 * 详细说明见 resources/app/plugins/插件开发说明.md。
 */
const path = require('path');
const fs = require('fs');
const { BrowserWindow, ipcMain, shell } = require('electron');

const API_VERSION = 1;
const ID_RE = /^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$/;
const EVENTS = ['chat:before', 'chat:reply', 'remind', 'settings:changed', 'pet:loaded', 'pet:visibility', 'quit'];

function withTimeout(p, ms, what) {
  if (!p || typeof p.then !== 'function') return Promise.resolve(p);
  let t;
  return Promise.race([
    p.finally(() => clearTimeout(t)),
    new Promise((_r, rej) => { t = setTimeout(() => rej(new Error(`${what}超过 ${ms / 1000} 秒没有完成`)), ms); }),
  ]);
}
const errText = (e) => String((e && (e.message || e)) || '未知错误').slice(0, 400);

class PluginManager {
  /**
   * host：桌宠主进程提供的能力
   *   appId, petName, appVersion, userData, bundledDir, icon, theme(颜色), preloadDir
   *   getWin() → 桌宠窗口
   *   say(text, ja, mood, action)       让她说一句
   *   trigger(key)                      'chat' | 'call' | 'sleep' | lines.js 里的台词组名
   *   publicSettings()                  不含密钥和人设的设置
   *   refreshMenu()                     重建托盘菜单
   *   moods / actions                   （可选）可用的心情、动作名
   */
  constructor(host) {
    this.host = host;
    this.userDir = path.join(host.userData, 'plugins');
    this.dataDir = path.join(host.userData, 'plugin-data');
    this.stateFile = path.join(host.userData, 'plugins.json');
    this.logFile = path.join(host.userData, 'plugins.log');
    this.records = new Map();      // id → 记录
    this.order = [];
    this.state = { enabled: {} };
    this.mgrWin = null;
    this.winOwners = new Map();    // webContents.id → 插件 id（插件自己开的窗口）
    this.attached = null;
    this._ipc();
    this._loadState();
  }

  /* ---------- 状态与日志 ---------- */
  _loadState() {
    try {
      const s = JSON.parse(fs.readFileSync(this.stateFile, 'utf8'));
      if (s && s.enabled && typeof s.enabled === 'object' && !Array.isArray(s.enabled)) this.state.enabled = s.enabled;
    } catch (e) {}
  }
  _saveState() {
    try {
      fs.mkdirSync(path.dirname(this.stateFile), { recursive: true });
      fs.writeFileSync(this.stateFile + '.tmp', JSON.stringify(this.state, null, 2));
      fs.renameSync(this.stateFile + '.tmp', this.stateFile);
    } catch (e) {}
  }
  log(id, level, msg) {
    const line = `${new Date().toISOString()} [${level}] ${id ? '[' + id + '] ' : ''}${msg}`;
    try {
      fs.mkdirSync(path.dirname(this.logFile), { recursive: true });
      // 日志超过 1MB 时换一个新文件，旧的留一份 plugins.old.log
      if ((this._logN = (this._logN || 0) + 1) % 100 === 1 && fs.existsSync(this.logFile) && fs.statSync(this.logFile).size > 1024 * 1024) fs.renameSync(this.logFile, this.logFile.replace(/\.log$/, '.old.log'));
      fs.appendFileSync(this.logFile, line + '\n');
    } catch (e) {}
    const r = id && this.records.get(id);
    if (r) { r.logs.push(line); if (r.logs.length > 40) r.logs.splice(0, r.logs.length - 40); }
  }

  /* ---------- 发现 ---------- */
  scan() {
    try { fs.mkdirSync(this.userDir, { recursive: true }); } catch (e) {}
    const found = [];
    for (const [source, dir] of [['bundled', this.host.bundledDir], ['user', this.userDir]]) {
      let names = [];
      try { names = fs.readdirSync(dir, { withFileTypes: true }).filter((d) => d.isDirectory()).map((d) => d.name).sort(); } catch (e) { continue; }
      for (const name of names) found.push(this._readManifest(source, path.join(dir, name)));
    }
    const seen = new Set();
    for (const r of found) {
      if (!r.id) continue;
      if (seen.has(r.id)) { r.problem = r.problem || `ID「${r.id}」和另一个插件重复，已忽略`; r.id = r.id + '@' + r.source + ':' + path.basename(r.dir); }
      seen.add(r.id);
    }
    // 保留已经在运行的记录；目录被删掉的插件先停用再移除
    const next = new Map();
    for (const r of found) {
      const old = this.records.get(r.id);
      if (old && old.dir === r.dir && old.status === 'active') { Object.assign(old, { manifest: r.manifest, name: r.name, version: r.version, description: r.description }); next.set(r.id, old); }
      else next.set(r.id, r);
    }
    for (const [id, old] of this.records) if (!next.has(id) && old.status === 'active') this._deactivate(old).catch(() => {});
    this.records = next;
    this.order = [...next.keys()];
    return this.list();
  }
  _readManifest(source, dir) {
    const base = { source, dir, status: 'stopped', error: '', problem: '', logs: [], id: '', name: path.basename(dir), version: '', description: '', manifest: null };
    let m;
    try { m = JSON.parse(fs.readFileSync(path.join(dir, 'plugin.json'), 'utf8').replace(/^﻿/, '')); }
    catch (e) { return { ...base, id: 'invalid@' + source + ':' + path.basename(dir), problem: fs.existsSync(path.join(dir, 'plugin.json')) ? 'plugin.json 不是有效的 JSON：' + errText(e) : '缺少 plugin.json' }; }
    if (!m || typeof m !== 'object' || Array.isArray(m)) return { ...base, id: 'invalid@' + source + ':' + path.basename(dir), problem: 'plugin.json 必须是 JSON 对象' };
    const r = { ...base, manifest: m, id: String(m.id || ''), name: String(m.name || m.id || path.basename(dir)), version: String(m.version || ''), description: String(m.description || ''), author: String(m.author || '') };
    if (!ID_RE.test(r.id)) { r.problem = 'plugin.json 里的 id 只能用英文字母、数字、点、下划线和连字符'; r.id = 'invalid@' + source + ':' + path.basename(dir); return r; }
    const main = String(m.main || 'main.js');
    const inside = (f) => { const p = path.resolve(dir, f); return p.startsWith(path.resolve(dir) + path.sep) ? p : null; };
    r.mainFile = inside(main);
    if (!r.mainFile || !fs.existsSync(r.mainFile)) r.problem = `找不到主脚本 ${main}`;
    if (m.renderer) { r.rendererFile = inside(String(m.renderer)); if (!r.rendererFile || !fs.existsSync(r.rendererFile)) r.problem = `找不到页面脚本 ${m.renderer}`; }
    const api = Number(m.apiVersion || 1);
    if (api > API_VERSION) r.problem = `需要插件接口 v${api}，本桌宠只支持到 v${API_VERSION}`;
    const pets = Array.isArray(m.pets) ? m.pets.map(String) : ['*'];
    if (!pets.includes('*') && !pets.includes(this.host.appId)) r.problem = `这个插件只适用于：${pets.join('、')}`;
    return r;
  }
  list() {
    return this.order.map((id) => this.records.get(id)).filter(Boolean).map((r) => ({
      id: r.id, name: r.name, version: r.version, description: r.description, author: r.author || '',
      source: r.source, dir: r.dir, status: r.status, error: r.error, problem: r.problem,
      enabled: !!this.state.enabled[r.id], hasRenderer: !!r.rendererFile, logs: r.logs.slice(-12),
      menuCount: r.ctx ? r.ctx.menu.length : 0,
    }));
  }

  /* ---------- 启动 / 启用 / 停用 ---------- */
  async start() {
    this.scan();
    for (const id of this.order) {
      const r = this.records.get(id);
      if (r && this.state.enabled[id] && !r.problem && r.status !== 'active') await this._activate(r);
    }
    this._changed();
  }
  async setEnabled(id, on) {
    const r = this.records.get(id);
    if (!r) return { error: '没有这个插件' };
    if (on && r.problem) return { error: r.problem };
    this.state.enabled[id] = !!on;
    this._saveState();
    if (on && r.status !== 'active') await this._activate(r);
    if (!on && r.status === 'active') await this._deactivate(r);
    this._changed();
    return { ok: true, status: r.status, error: r.error };
  }
  async reload(id) {
    const r0 = this.records.get(id);
    if (!r0) return { error: '没有这个插件' };
    if (r0.status === 'active') await this._deactivate(r0);
    this.scan();
    const r = this.records.get(id);
    if (r && this.state.enabled[id] && !r.problem) await this._activate(r);
    this._changed();
    return r ? { ok: true, status: r.status, error: r.error } : { error: '插件文件夹不见了' };
  }
  async stopAll() {
    for (const r of [...this.records.values()].reverse()) if (r.status === 'active') await this._deactivate(r).catch(() => {});
  }

  async _activate(r) {
    r.error = '';
    const ctx = this._context(r);
    r.ctx = ctx;
    try {
      // 每次启用都重新读取插件代码（改完插件点“重新加载”即可生效）
      const root = path.resolve(r.dir) + path.sep;
      for (const k of Object.keys(require.cache)) if (k.startsWith(root)) delete require.cache[k];
      const mod = require(r.mainFile);
      r.module = mod;
      if (mod && typeof mod.activate === 'function') await withTimeout(mod.activate(ctx.api), 8000, '启用');
      r.status = 'active';
      if (r.rendererFile) {
        r.rendererCode = fs.readFileSync(r.rendererFile, 'utf8');
        this._sendRenderer({ op: 'load', id: r.id, code: r.rendererCode });
      }
      this.log(r.id, 'info', `已启用 ${r.version || ''}`.trim());
    } catch (e) {
      r.error = errText(e);
      r.status = 'error';
      this.log(r.id, 'error', '启用失败：' + (e && e.stack || e));
      await this._dispose(r);
    }
    this._menuChanged();
  }
  async _deactivate(r) {
    try {
      if (r.module && typeof r.module.deactivate === 'function') await withTimeout(r.module.deactivate(), 5000, '停用');
    } catch (e) { this.log(r.id, 'error', '停用时出错：' + errText(e)); }
    await this._dispose(r);
    r.status = 'stopped';
    r.module = null;
    this.log(r.id, 'info', '已停用');
    this._menuChanged();
  }
  async _dispose(r) {
    const ctx = r.ctx;
    if (!ctx) return;
    r.ctx = null;
    if (r.rendererFile) this._sendRenderer({ op: 'unload', id: r.id });
    for (const fn of ctx.disposers.splice(0).reverse()) { try { await fn(); } catch (e) { this.log(r.id, 'error', '清理时出错：' + errText(e)); } }
  }

  /* ---------- 给插件的 API ---------- */
  _context(r) {
    const mgr = this, host = this.host, id = r.id;
    const disposers = [];
    const listeners = new Map();      // 事件名 → Set<fn>
    const handlers = new Map();       // 插件窗口 invoke 的频道 → fn
    const rendererMsg = new Set();
    const menu = [];
    const windows = new Set();
    const onDispose = (fn) => { disposers.push(fn); return fn; };
    const guard = (fn, what) => (...a) => { try { const v = fn(...a); if (v && typeof v.catch === 'function') v.catch((e) => mgr.log(id, 'error', `${what}出错：${errText(e)}`)); return v; } catch (e) { mgr.log(id, 'error', `${what}出错：${errText(e)}`); } };

    let store = null;
    const storeFile = path.join(this.dataDir, id + '.json');
    const loadStore = () => { if (!store) { try { store = JSON.parse(fs.readFileSync(storeFile, 'utf8')) || {}; } catch (e) { store = {}; } } return store; };
    const saveStore = () => { try { fs.mkdirSync(mgr.dataDir, { recursive: true }); fs.writeFileSync(storeFile + '.tmp', JSON.stringify(store, null, 2)); fs.renameSync(storeFile + '.tmp', storeFile); } catch (e) { mgr.log(id, 'error', '保存数据失败：' + errText(e)); } };
    const clone = (v) => (v === undefined ? undefined : JSON.parse(JSON.stringify(v)));

    const timers = new Set();
    onDispose(() => { for (const t of timers) { clearTimeout(t); clearInterval(t); } timers.clear(); });
    onDispose(() => { listeners.clear(); handlers.clear(); rendererMsg.clear(); menu.splice(0); });
    onDispose(() => { for (const w of windows) { try { if (!w.isDestroyed()) w.destroy(); } catch (e) {} } windows.clear(); });

    const api = Object.freeze({
      apiVersion: API_VERSION,
      id,
      dir: r.dir,
      dataDir: path.join(this.dataDir, id),
      manifest: clone(r.manifest),
      host: Object.freeze({ appId: host.appId, petName: host.petName, appVersion: host.appVersion, platform: process.platform }),

      log: (...a) => mgr.log(id, 'info', a.map((x) => (typeof x === 'string' ? x : JSON.stringify(x))).join(' ')),
      warn: (...a) => mgr.log(id, 'warn', a.map((x) => (typeof x === 'string' ? x : JSON.stringify(x))).join(' ')),

      pet: Object.freeze({
        /** 让她说一句：say('你好', { ja: 'こんにちは', mood: 'happy', action: 'nod' }) */
        say(text, opts = {}) {
          const t = String(text == null ? '' : text).slice(0, 500);
          if (!t) return false;
          host.say(t, String(opts.ja || '').slice(0, 500), String(opts.mood || 'calm'), String(opts.action || 'none'));
          return true;
        },
        /** 触发桌宠自带的行为：'chat' 打开聊天框，'call' 语音通话，'sleep' 打盹，或 lines.js 里的台词组名（如 'body'） */
        trigger(key) { host.trigger(String(key)); },
        openChat() { host.trigger('chat'); },
        isVisible() { const w = host.getWin(); return !!(w && !w.isDestroyed() && w.isVisible()); },
        getBounds() { const w = host.getWin(); return w && !w.isDestroyed() ? w.getBounds() : null; },
        moods: Object.freeze([...(host.moods || [])]),
        actions: Object.freeze([...(host.actions || [])]),
      }),

      settings: Object.freeze({ get: () => clone(host.publicSettings()) }),

      storage: Object.freeze({
        get(key, def) { const s = loadStore(); return key in s ? clone(s[key]) : def; },
        set(key, value) { const s = loadStore(); if (value === undefined) delete s[key]; else s[key] = clone(value); saveStore(); },
        delete(key) { const s = loadStore(); delete s[key]; saveStore(); },
        all() { return clone(loadStore()); },
        clear() { store = {}; saveStore(); },
      }),

      events: Object.freeze({
        names: EVENTS,
        on(name, fn) {
          if (!EVENTS.includes(name)) throw new Error(`没有这个事件：${name}（可用：${EVENTS.join('、')}）`);
          if (typeof fn !== 'function') throw new Error('events.on 的第二个参数要是函数');
          if (!listeners.has(name)) listeners.set(name, new Set());
          listeners.get(name).add(fn);
          return () => { const s = listeners.get(name); if (s) s.delete(fn); };
        },
        once(name, fn) { const off = api.events.on(name, (...a) => { off(); return fn(...a); }); return off; },
      }),

      menu: Object.freeze({
        /** 在“插件”子菜单里加一项：add({ label, click, type: 'normal'|'checkbox', checked }) → { update(patch), remove() } */
        add(item) {
          if (!item || !item.label) throw new Error('菜单项需要 label');
          const it = { label: String(item.label).slice(0, 60), type: item.type === 'checkbox' ? 'checkbox' : 'normal', checked: !!item.checked, enabled: item.enabled !== false, click: typeof item.click === 'function' ? guard(item.click, '菜单点击') : null };
          menu.push(it);
          mgr._menuChanged();
          return {
            update(p = {}) { if ('label' in p) it.label = String(p.label).slice(0, 60); if ('checked' in p) it.checked = !!p.checked; if ('enabled' in p) it.enabled = p.enabled !== false; mgr._menuChanged(); },
            remove() { const i = menu.indexOf(it); if (i >= 0) { menu.splice(i, 1); mgr._menuChanged(); } },
          };
        },
      }),

      timers: Object.freeze({
        setTimeout(fn, ms) { const t = setTimeout(() => { timers.delete(t); guard(fn, '定时器')(); }, ms); timers.add(t); return t; },
        setInterval(fn, ms) { const t = setInterval(guard(fn, '定时器'), Math.max(200, +ms || 0)); timers.add(t); return t; },
        clear(t) { clearTimeout(t); clearInterval(t); timers.delete(t); },
      }),

      renderer: Object.freeze({
        /** 发消息给插件的页面脚本（renderer） */
        send(data) { mgr._sendRenderer({ op: 'message', id, data: clone(data) }); },
        onMessage(fn) { rendererMsg.add(fn); return () => rendererMsg.delete(fn); },
      }),

      ipc: Object.freeze({
        /** 插件窗口里 pluginAPI.invoke(channel, data) 会调用这里注册的函数 */
        handle(channel, fn) { handlers.set(String(channel), fn); return () => handlers.delete(String(channel)); },
      }),

      windows: Object.freeze({
        /** 打开插件自己的窗口：open({ file: 'panel.html', width, height, title }) → BrowserWindow。停用时自动关闭 */
        open(o = {}) {
          const file = path.resolve(r.dir, String(o.file || 'index.html'));
          if (!file.startsWith(path.resolve(r.dir) + path.sep)) throw new Error('窗口页面必须放在插件文件夹里');
          const w = new BrowserWindow({
            width: o.width || 420, height: o.height || 480, minWidth: 260, minHeight: 200,
            title: `${host.petName}桌宠 · ${o.title || r.name}`, icon: host.icon, autoHideMenuBar: true,
            backgroundColor: o.backgroundColor || (host.theme && host.theme.bg) || '#ffffff', show: false,
            webPreferences: { preload: path.join(host.preloadDir, 'preload-plugin-window.js'), contextIsolation: true, nodeIntegration: false, sandbox: false },
          });
          const wcId = w.webContents.id;
          mgr.winOwners.set(wcId, id);
          windows.add(w);
          w.on('closed', () => { windows.delete(w); mgr.winOwners.delete(wcId); });
          w.once('ready-to-show', () => w.show());
          w.loadFile(file);
          return w;
        },
        post(w, channel, data) { if (w && !w.isDestroyed()) w.webContents.send('plugin-window-event', { channel: String(channel), data: clone(data) }); },
      }),

      openPath(p) { return shell.openPath(String(p)); },
      onDispose,
    });

    return { api, disposers, listeners, handlers, rendererMsg, menu, windows };
  }

  /* ---------- 事件分发（由 main.js 调用） ---------- */
  _targets(name) {
    const out = [];
    for (const id of this.order) {
      const r = this.records.get(id);
      if (r && r.status === 'active' && r.ctx) { const s = r.ctx.listeners.get(name); if (s) for (const fn of s) out.push([r, fn]); }
    }
    return out;
  }
  emit(name, payload) {
    for (const [r, fn] of this._targets(name)) {
      try { const v = fn(payload); if (v && typeof v.catch === 'function') v.catch((e) => this.log(r.id, 'error', `${name} 事件出错：${errText(e)}`)); }
      catch (e) { this.log(r.id, 'error', `${name} 事件出错：${errText(e)}`); }
    }
  }
  /** chat:before：插件可以改写 e.text（返回 Promise 也行，最多等 1.5 秒）；e.cancel = true 则这条消息不发给模型 */
  async filterChat(text, info = {}) {
    const e = { text: String(text), proactive: !!info.proactive, image: !!info.image, cancel: false, reply: '' };
    for (const [r, fn] of this._targets('chat:before')) {
      try { await withTimeout(Promise.resolve(fn(e)), 1500, 'chat:before'); }
      catch (err) { this.log(r.id, 'error', `chat:before 事件出错：${errText(err)}`); }
      if (typeof e.text !== 'string') e.text = String(text);
    }
    return e;
  }

  /* ---------- 菜单 ---------- */
  menuTemplate() {
    const items = [];
    for (const id of this.order) {
      const r = this.records.get(id);
      if (!r || r.status !== 'active' || !r.ctx) continue;
      for (const it of r.ctx.menu) {
        items.push({ label: it.label, type: it.type, checked: it.type === 'checkbox' ? it.checked : undefined, enabled: it.enabled, click: (m) => { if (it.type === 'checkbox') it.checked = !!m.checked; it.click && it.click({ checked: it.checked }); } });
      }
    }
    const active = [...this.records.values()].filter((r) => r.status === 'active').length;
    return {
      label: active ? `插件（${active} 个运行中）` : '插件',
      submenu: [
        ...(items.length ? items : [{ label: active ? '运行中的插件没有添加菜单项' : '还没有启用插件', enabled: false }]),
        { type: 'separator' },
        { label: '插件管理…', click: () => this.openManager() },
      ],
    };
  }
  _menuChanged() {
    clearTimeout(this._menuT);
    this._menuT = setTimeout(() => { try { this.host.refreshMenu(); } catch (e) {} }, 30);
  }
  _changed() {
    if (this.mgrWin && !this.mgrWin.isDestroyed()) this.mgrWin.webContents.send('plugins-changed', this.list());
  }

  /* ---------- 桌宠页面里的插件脚本 ---------- */
  attachWindow(win) {
    if (!win || this.attached === win) return;
    this.attached = win;
    win.webContents.on('did-finish-load', () => {
      // 页面刚加载（包括崩溃后重新加载）：把所有已启用插件的页面脚本重新放进去
      for (const id of this.order) {
        const r = this.records.get(id);
        if (r && r.status === 'active' && r.rendererCode) this._sendRenderer({ op: 'load', id: r.id, code: r.rendererCode }, true);
      }
      setTimeout(() => this.emit('pet:loaded', {}), 800);
    });
    win.on('show', () => this.emit('pet:visibility', { visible: true }));
    win.on('hide', () => this.emit('pet:visibility', { visible: false }));
  }
  _sendRenderer(msg, loaded = false) {
    const w = this.host.getWin();
    // 页面还在加载时先不发：加载完成（did-finish-load）时会统一补发
    if (!w || w.isDestroyed() || (!loaded && w.webContents.isLoading())) return;
    try { w.webContents.send('plugin-renderer', msg); } catch (e) {}
  }

  /* ---------- 管理窗口 ---------- */
  openManager() {
    if (this.mgrWin && !this.mgrWin.isDestroyed()) { this.mgrWin.focus(); return; }
    const t = this.host.theme || {};
    this.mgrWin = new BrowserWindow({
      width: 600, height: 640, minWidth: 460, minHeight: 440, title: `${this.host.petName}桌宠 · 插件管理`,
      icon: this.host.icon, autoHideMenuBar: true, backgroundColor: t.bg || '#ffffff',
      webPreferences: { preload: path.join(this.host.preloadDir, 'preload-plugins.js'), contextIsolation: true },
    });
    this.mgrWin.loadFile(path.join(this.host.preloadDir, 'src', 'plugins.html'));
    this.mgrWin.on('closed', () => { this.mgrWin = null; });
  }

  _ipc() {
    const fromMgr = (e) => this.mgrWin && !this.mgrWin.isDestroyed() && e.sender === this.mgrWin.webContents;
    ipcMain.handle('plugins-info', (e) => (fromMgr(e) ? { list: this.scan(), userDir: this.userDir, petName: this.host.petName, apiVersion: API_VERSION, theme: this.host.theme || {} } : null));
    ipcMain.handle('plugins-set', (e, { id, on } = {}) => (fromMgr(e) ? this.setEnabled(String(id), !!on).then((r) => ({ ...r, list: this.list() })) : null));
    ipcMain.handle('plugins-reload', (e, id) => (fromMgr(e) ? this.reload(String(id)).then((r) => ({ ...r, list: this.list() })) : null));
    ipcMain.handle('plugins-rescan', (e) => (fromMgr(e) ? this.list(this.scan()) : null));
    ipcMain.on('plugins-open-folder', (e, which) => {
      if (!fromMgr(e)) return;
      if (which === 'docs') { shell.openPath(path.join(this.host.bundledDir, '插件开发说明.md')); return; }
      if (which === 'log') { if (fs.existsSync(this.logFile)) shell.showItemInFolder(this.logFile); else shell.openPath(this.host.userData); return; }
      const r = which && this.records.get(String(which));
      if (r) { shell.openPath(r.dir); return; }
      fs.mkdirSync(this.userDir, { recursive: true });
      shell.openPath(this.userDir);
    });
    // 桌宠页面里的插件脚本发回来的消息
    ipcMain.on('plugin-renderer-msg', (e, { id, data } = {}) => {
      const w = this.host.getWin();
      if (!w || e.sender !== w.webContents) return;
      const r = this.records.get(String(id));
      if (!r || r.status !== 'active' || !r.ctx) return;
      if (data && data.__error) { this.log(r.id, 'error', '页面脚本出错：' + String(data.__error).slice(0, 600)); return; }
      for (const fn of r.ctx.rendererMsg) { try { fn(data); } catch (err) { this.log(r.id, 'error', '页面消息处理出错：' + errText(err)); } }
    });
    // 插件自己的窗口
    ipcMain.handle('plugin-window-invoke', async (e, { channel, data } = {}) => {
      const id = this.winOwners.get(e.sender.id);
      const r = id && this.records.get(id);
      if (!r || !r.ctx) return { error: '插件没有在运行' };
      const fn = r.ctx.handlers.get(String(channel));
      if (!fn) return { error: `插件没有处理「${channel}」` };
      try { return await fn(data, { sender: e.sender }); }
      catch (err) { this.log(r.id, 'error', `ipc ${channel} 出错：${errText(err)}`); return { error: errText(err) }; }
    });
  }
}

module.exports = { PluginManager, API_VERSION, EVENTS };
