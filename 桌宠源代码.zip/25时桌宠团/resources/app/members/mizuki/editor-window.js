'use strict';
const { app, BrowserWindow, ipcMain, dialog, shell } = require('electron');
const path = require('node:path');
const fs = require('node:fs/promises');
const { pathToFileURL } = require('node:url');
const editor = require('./video-editor');

module.exports = function createEditor({ getSettings, onDone }) {
  let window = null, state = null;
  const view = a => ({ ...a, path: undefined, url: pathToFileURL(a.path).href });
  function openEditor(hint = '') {
    if (window && !window.isDestroyed()) {
      window.show(); window.focus();
      if (hint) { state.hint = hint; window.webContents.send('editor-hint', hint); }
      return;
    }
    const local = state = { assets: [], hint, job: null, output: null };
    window = new BrowserWindow({ width: 1060, height: 820, minWidth: 800, minHeight: 620, title: '瑞希的视频剪辑', autoHideMenuBar: true, backgroundColor: '#fff8fc', icon: path.join(__dirname,'icon.png'), webPreferences: { preload: path.join(__dirname,'preload-editor.js'), contextIsolation: true, nodeIntegration: false, sandbox: true } });
    const w = window;
    w.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
    w.webContents.on('will-navigate', e => e.preventDefault());
    w.on('closed', () => { local.job?.abort(); if (window === w) { window = null; state = null; } });
    w.loadFile(path.join(__dirname,'src/editor.html'));
  }
  const handle = (name, fn) => ipcMain.handle('editor-'+name, async (event, data) => {
    if (!window || event.sender !== window.webContents || !state) return { error: '剪辑窗口已关闭' };
    const local = state, w = window;
    try { return await fn(data,local,w); }
    catch(e) { return { error: e.name === 'AbortError' ? '已取消' : String(e.message || e).slice(0,2500) }; }
  });
  const idle = s => { if (s.job) throw new Error('请先等待或取消当前任务'); };
  const safeSend = (w,ch,v) => { if (!w.isDestroyed()) w.webContents.send(ch,v); };
  const job = async (s, fn) => {
    idle(s); const ctrl = s.job = new AbortController();
    try { return await fn(ctrl.signal); }
    finally { if (s.job === ctrl) s.job = null; }
  };
  handle('state', (_,s) => ({ assets:s.assets.map(view), hint:s.hint }));
  handle('import', async (_,s,w) => job(s, async signal => {
    const r = await dialog.showOpenDialog(w,{ title:'选择视频或配乐',properties:['openFile','multiSelections'],filters:[{name:'音视频',extensions:['mp4','mov','mkv','webm','avi','m4v','mp3','wav','m4a','aac','flac','ogg']}] });
    if (r.canceled) return { canceled:true };
    if (s.assets.length+r.filePaths.length>100) throw new Error('最多导入100个素材');
    const next = [...s.assets], errors = [];
    for (const p of r.filePaths) {
      if (next.some(a=>a.path.toLowerCase()===p.toLowerCase())) continue;
      try { next.push(await editor.probe(p,{signal})); } catch(e) { if(signal.aborted) throw e; errors.push(path.basename(p)+'：'+e.message); }
    }
    if(signal.aborted) throw new Error('已取消');
    s.assets=next; return { assets:s.assets.map(view), warning:errors.join('\n') };
  }));
  handle('generate', async (data,s) => job(s, async signal => ({ plan:await editor.generatePlan(getSettings(),s.assets,String(data?.prompt||''),{signal}) })));
  handle('validate', (data,s) => ({ plan:editor.validatePlan(data,s.assets) }));
  handle('export', async (data,s,w) => job(s, async signal => {
    const plan = editor.validatePlan(data,s.assets);
    const title = plan.title.replace(/[<>:"/\\|?*\x00-\x1f]/g,'_').replace(/[. ]+$/,'') || '瑞希的剪辑';
    const r = await dialog.showSaveDialog(w,{title:'导出 MP4',defaultPath:path.join(app.getPath('videos'),title+'.mp4'),filters:[{name:'MP4 视频',extensions:['mp4']}]});
    if(r.canceled || !r.filePath) return {canceled:true};
    const out = await editor.exportVideo(plan,s.assets,r.filePath,{signal,onProgress:p=>safeSend(w,'editor-progress',p)});
    s.output=out.path; onDone?.(plan.title);
    return {...out,url:pathToFileURL(out.path).href};
  }));
  handle('cancel',(_,s)=>{s.job?.abort();return {ok:true};});
  handle('save', async(data,s,w)=>{
    idle(s); const plan=editor.validatePlan(data,s.assets);
    const r=await dialog.showSaveDialog(w,{title:'保存剪辑工程',defaultPath:'瑞希剪辑工程.json',filters:[{name:'剪辑工程',extensions:['json']}]});
    if(r.canceled || !r.filePath) return {canceled:true};
    const target=path.resolve(r.filePath).toLowerCase();
    if(s.assets.some(a=>path.resolve(a.path).toLowerCase()===target)) throw new Error('不能用剪辑工程覆盖原素材');
    if(path.extname(r.filePath).toLowerCase()!=='.json') throw new Error('剪辑工程请保存为 JSON 文件');
    await fs.writeFile(r.filePath,JSON.stringify({app:'mizuki-editor',version:1,assets:s.assets.map(({id,path})=>({id,path})),plan},null,2),'utf8');
    return {ok:true};
  });
  handle('load', async(_,s,w)=>job(s,async signal=>{
    const r=await dialog.showOpenDialog(w,{title:'打开剪辑工程',properties:['openFile'],filters:[{name:'剪辑工程',extensions:['json']}]});
    if(r.canceled) return {canceled:true};
    const file=r.filePaths[0]; if((await fs.stat(file)).size>2e6) throw new Error('工程文件过大');
    const o=JSON.parse(await fs.readFile(file,'utf8'));
    if(o.app!=='mizuki-editor'||o.version!==1||!Array.isArray(o.assets)||o.assets.length>100) throw new Error('不支持的工程文件');
    const next=[],ids=new Set();
    for(const a of o.assets){
      if(!a||typeof a.id!=='string'||ids.has(a.id)||typeof a.path!=='string'||!path.isAbsolute(a.path)) throw new Error('工程素材引用无效');
      ids.add(a.id); const asset=await editor.probe(a.path,{signal}); next.push({...asset,id:a.id});
    }
    const plan=editor.validatePlan(o.plan,next); s.assets=next;
    return {assets:next.map(view),plan};
  }));
  handle('reveal',async(_,s)=>{if(s.output) shell.showItemInFolder(s.output);return {ok:true};});
  app.on('before-quit',()=>state?.job?.abort());
  return openEditor;
};
