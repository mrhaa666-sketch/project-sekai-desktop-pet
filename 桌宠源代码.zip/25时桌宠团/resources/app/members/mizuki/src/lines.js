'use strict';
// 瑞希同人台词；动作直接取自用户提供的角色素材。
window.FACES = {
  "平静": [
    "face_normal_01",
    "平常的神情"
  ],
  "微笑": [
    "face_smile_01",
    "自然地笑"
  ],
  "轻笑": [
    "face_smile_03",
    "轻轻笑起来"
  ],
  "开心": [
    "face_smile_02",
    "开心"
  ],
  "闭眼笑": [
    "face_closeeye_07",
    "闭眼笑"
  ],
  "得意": [
    "face_smug_01",
    "有点得意"
  ],
  "眨眼": [
    "face_wink_01",
    "俏皮地眨眼"
  ],
  "期待": [
    "face_sparkling_01",
    "眼睛发亮"
  ],
  "害羞": [
    "face_shy_01",
    "有点害羞"
  ],
  "认真": [
    "face_serious_01",
    "认真注视"
  ],
  "思考": [
    "face_serious_03",
    "思考"
  ],
  "为难": [
    "face_trouble_01",
    "为难"
  ],
  "苦笑": [
    "face_trouble_02",
    "为难的神情"
  ],
  "担心": [
    "face_worry_01",
    "担心"
  ],
  "低落": [
    "face_sad_01",
    "低落"
  ],
  "难过": [
    "face_sad_03",
    "难过"
  ],
  "想哭": [
    "face_cry_01",
    "想哭"
  ],
  "惊讶": [
    "face_surprise_01",
    "吃惊"
  ],
  "不满": [
    "face_disgust_01",
    "有些不满"
  ],
  "生气": [
    "face_angry_01",
    "生气"
  ],
  "移开视线": [
    "face_lookaway_01",
    "看向旁边"
  ],
  "闭眼": [
    "face_closeeye_01",
    "闭眼"
  ],
  "困倦": [
    "face_sleepy_01",
    "困倦"
  ],
  "愣住": [
    "face_smallmouth_01",
    "愣住"
  ]
};
window.ACTIONS = {
  "none": {
    "bodies": [],
    "desc": "保持当前姿势"
  },
  "nod": {
    "bodies": [
      "w-cute12-nod",
      "w-cute02-nod"
    ],
    "desc": "点头"
  },
  "tilt": {
    "bodies": [
      "w-cute11-tilthead",
      "w-cute11-tilthead02"
    ],
    "desc": "歪头"
  },
  "think": {
    "bodies": [
      "w-adult01-think"
    ],
    "desc": "想一想"
  },
  "shy": {
    "bodies": [
      "w-cute11-shy02"
    ],
    "desc": "害羞"
  },
  "glad": {
    "bodies": [
      "w-cute11-glad",
      "w-cute11-glad02"
    ],
    "desc": "高兴"
  },
  "proud": {
    "bodies": [
      "w-cute14-smug"
    ],
    "desc": "有点得意"
  },
  "look_down": {
    "bodies": [
      "w-cute12happy16-shakeheadsad"
    ],
    "desc": "低落地垂下视线"
  },
  "sigh": {
    "bodies": [
      "w-cute12happy16-shakeheadsad"
    ],
    "desc": "叹气、收敛下来"
  },
  "trouble": {
    "bodies": [
      "w-adult01-think"
    ],
    "desc": "迟疑、思考"
  },
  "shake": {
    "bodies": [
      "w-cute12-shakehead"
    ],
    "desc": "摇头"
  },
  "look_away": {
    "bodies": [
      "w-cute11-nbtilthead"
    ],
    "desc": "移开视线"
  },
  "surprise": {
    "bodies": [
      "w-cute11-forward"
    ],
    "desc": "在意地向前倾"
  },
  "angry": {
    "bodies": [
      "w-cute13-angry"
    ],
    "desc": "不高兴"
  },
  "sleep": {
    "bodies": [
      "w-cute01-sleep05"
    ],
    "desc": "打瞌睡"
  },
  "wink": {
    "bodies": [
      "w-cute11-wink"
    ],
    "desc": "俏皮地眨眼"
  }
};
window.MOODS = {
  "calm": {
    "faces": [
      [
        "平静",
        1
      ],
      [
        "轻笑",
        0.85
      ]
    ],
    "actions": [
      "none",
      "nod",
      "tilt"
    ],
    "desc": "平常、放松"
  },
  "soft": {
    "faces": [
      [
        "轻笑",
        0.85
      ],
      [
        "微笑",
        0.85
      ]
    ],
    "actions": [
      "nod",
      "tilt"
    ],
    "desc": "柔和、安心"
  },
  "warm": {
    "faces": [
      [
        "微笑",
        0.85
      ],
      [
        "轻笑",
        0.85
      ]
    ],
    "actions": [
      "nod",
      "glad"
    ],
    "desc": "被关心、暖心"
  },
  "happy": {
    "faces": [
      [
        "开心",
        0.85
      ],
      [
        "期待",
        0.85
      ]
    ],
    "actions": [
      "glad",
      "wink"
    ],
    "desc": "开心，聊到喜欢的东西"
  },
  "shy": {
    "faces": [
      [
        "害羞",
        0.85
      ]
    ],
    "actions": [
      "shy",
      "look_away"
    ],
    "desc": "害羞"
  },
  "flustered": {
    "faces": [
      [
        "害羞",
        0.85
      ],
      [
        "为难",
        0.85
      ]
    ],
    "actions": [
      "shy",
      "tilt"
    ],
    "desc": "被说中、有点慌"
  },
  "proud": {
    "faces": [
      [
        "得意",
        0.85
      ],
      [
        "眨眼",
        0.85
      ]
    ],
    "actions": [
      "proud",
      "wink"
    ],
    "desc": "有点得意、打趣"
  },
  "think": {
    "faces": [
      [
        "思考",
        0.85
      ],
      [
        "平静",
        1
      ]
    ],
    "actions": [
      "think",
      "tilt"
    ],
    "desc": "思考"
  },
  "serious": {
    "faces": [
      [
        "认真",
        0.85
      ]
    ],
    "actions": [
      "think",
      "nod"
    ],
    "desc": "认真、专注"
  },
  "sad": {
    "faces": [
      [
        "低落",
        0.85
      ]
    ],
    "actions": [
      "look_down",
      "sigh"
    ],
    "desc": "低落"
  },
  "hurt": {
    "faces": [
      [
        "难过",
        0.85
      ],
      [
        "想哭",
        0.85
      ]
    ],
    "actions": [
      "look_down"
    ],
    "desc": "受伤"
  },
  "troubled": {
    "faces": [
      [
        "为难",
        0.85
      ],
      [
        "苦笑",
        0.85
      ]
    ],
    "actions": [
      "trouble",
      "shake"
    ],
    "desc": "困扰"
  },
  "worried": {
    "faces": [
      [
        "担心",
        0.85
      ]
    ],
    "actions": [
      "tilt",
      "think"
    ],
    "desc": "担心"
  },
  "surprised": {
    "faces": [
      [
        "惊讶",
        0.85
      ],
      [
        "愣住",
        0.85
      ]
    ],
    "actions": [
      "surprise",
      "tilt"
    ],
    "desc": "吃惊"
  },
  "sleepy": {
    "faces": [
      [
        "困倦",
        1
      ],
      [
        "闭眼",
        1
      ]
    ],
    "actions": [
      "sleep"
    ],
    "desc": "困了"
  },
  "sulky": {
    "faces": [
      [
        "不满",
        0.85
      ],
      [
        "移开视线",
        0.85
      ]
    ],
    "actions": [
      "shake",
      "look_away"
    ],
    "desc": "闹别扭"
  },
  "angry": {
    "faces": [
      [
        "生气",
        0.85
      ]
    ],
    "actions": [
      "angry",
      "shake"
    ],
    "desc": "生气、表达边界"
  }
};
window.LINES = {
  "nightcord": [
    {
      "t": "零点了。剩下的明天再继续吧，你困了就先休息哦。",
      "ja": "0時だね。続きは明日にしようよ。眠かったら先に休んでね。",
      "m": "soft",
      "a": "nod"
    }
  ],
  "birthdaySelf": [
    {
      "t": "今天想选一件最喜欢的衣服。生日嘛，稍微任性一点也可以吧？",
      "ja": "今日は一番好きな服にしようかな。誕生日だし、ちょっとわがままでもいいよね？",
      "m": "happy",
      "a": "glad"
    }
  ],
  "birthdayUser": [
    {
      "t": "{name}，生日快乐！今天想怎么过？我想听你自己选。",
      "ja": "{name}、誕生日おめでとう！今日はどう過ごしたい？キミが選んでいいんだよ。",
      "m": "happy",
      "a": "glad"
    }
  ],
  "anniversary": [
    {
      "t": "今天这个日子，我有好好记着哦。一起待一会儿吧。",
      "ja": "今日のこと、ちゃんと覚えてるよ。少し一緒にいようよ。",
      "m": "warm",
      "a": "nod"
    }
  ],
  "outfitCasual": [
    {
      "t": "换好啦。这套搭配果然很可爱。",
      "ja": "着替えたよ。この組み合わせ、やっぱりかわいいね。",
      "m": "happy",
      "a": "glad"
    },
    {
      "t": "好啦，接下来慢慢挑视频素材吧。",
      "ja": "よし、次はゆっくり動画の素材を選ぼうかな。",
      "m": "soft",
      "a": "tilt"
    }
  ],
  "outfitUniform": [
    {
      "t": "制服也整理好了。今天的搭配怎么样？",
      "ja": "制服も整えたよ。今日のコーデ、どうかな？",
      "m": "soft",
      "a": "tilt"
    }
  ],
  "greet": {
    "morning": [
      {
        "t": "早呀，{name}。先慢慢清醒一下吧。",
        "ja": "おはよう、{name}。ゆっくり目を覚まそうよ。",
        "m": "soft",
        "a": "nod"
      }
    ],
    "day": [
      {
        "t": "来啦？正好，陪我看看这个配色怎么样。",
        "ja": "来たね？ちょうどよかった。この色の組み合わせ、どう思う？",
        "m": "happy",
        "a": "tilt"
      }
    ],
    "evening": [
      {
        "t": "辛苦啦。今天有什么想跟我说的吗？",
        "ja": "お疲れさま。今日、ボクに話したいことある？",
        "m": "soft",
        "a": "nod"
      }
    ],
    "night": [
      {
        "t": "还醒着呀。那就聊一小会儿，别忘了休息哦。",
        "ja": "まだ起きてたんだ。じゃあ少し話そうよ。休むのも忘れないでね。",
        "m": "soft",
        "a": "tilt"
      }
    ]
  },
  "head": [
    {
      "t": "哇，突然摸头。发饰可别弄歪了哦。",
      "ja": "わ、急に撫でるんだね。髪飾り、ずらさないでよ？",
      "m": "surprised",
      "a": "tilt"
    },
    {
      "t": "这么喜欢摸我的头呀？好吧，就一下。",
      "ja": "ボクの頭、そんなに撫でたいの？しょうがないな、ちょっとだけね。",
      "m": "shy",
      "a": "shy"
    },
    {
      "t": "怎么啦？我在听。",
      "ja": "どうしたの？ちゃんと聞いてるよ。",
      "m": "soft",
      "a": "nod"
    }
  ],
  "body": [
    {
      "t": "嗯？是想找我聊天吗？",
      "ja": "ん？ボクと話したくなった？",
      "m": "soft",
      "a": "tilt"
    },
    {
      "t": "可爱的东西，喜欢就是喜欢嘛。",
      "ja": "かわいいものは、好きだから好きなんだよね。",
      "m": "happy",
      "a": "glad"
    },
    {
      "t": "想剪什么样的视频？素材和感觉都可以慢慢选。",
      "ja": "どんな動画にしたい？素材も雰囲気も、ゆっくり選ぼうよ。",
      "m": "serious",
      "a": "think"
    },
    {
      "t": "一直忙着呀。那我先在旁边陪你。",
      "ja": "ずっと忙しそうだね。じゃあ、そばにいるよ。",
      "m": "warm",
      "a": "nod"
    },
    {
      "t": "这个颜色再搭一点粉色，会不会很好看？",
      "ja": "この色に少しピンクを合わせたら、かわいくない？",
      "m": "happy",
      "a": "tilt"
    }
  ],
  "poke": [
    {
      "t": "喂，再戳的话，我可要分心啦。",
      "ja": "ねえ、そんなにつつかれたら集中できないよ。",
      "m": "troubled",
      "a": "shake"
    }
  ],
  "pokeAngry": [
    {
      "t": "我说了先停一下。这个不是开玩笑。",
      "ja": "ちょっとやめてって言ったよね。今は冗談じゃないよ。",
      "m": "angry",
      "a": "angry"
    }
  ],
  "stillSulky": [
    {
      "t": "现在先让我缓一缓，好吗？",
      "ja": "今は少し、落ち着かせてくれる？",
      "m": "sulky",
      "a": "look_away"
    }
  ],
  "drop": [
    {
      "t": "这里呀。嗯，这个位置不错。",
      "ja": "ここ？うん、いい場所だね。",
      "m": "soft",
      "a": "nod"
    },
    {
      "t": "搬家完成！接下来要做什么？",
      "ja": "お引っ越し完了！次は何する？",
      "m": "happy",
      "a": "tilt"
    }
  ],
  "idle": [
    {
      "t": "这个转场，干脆一点也许更好。",
      "ja": "この切り替え、思い切ってシンプルにしてもいいかも。",
      "m": "think",
      "a": "think"
    },
    {
      "t": "想收集一点新的素材了。",
      "ja": "新しい素材、少し集めたいな。",
      "m": "soft",
      "a": "tilt"
    },
    {
      "t": "蝴蝶结换个位置，感觉就不一样了呢。",
      "ja": "リボンの位置を変えるだけで、雰囲気が違うね。",
      "m": "happy",
      "a": "tilt"
    },
    {
      "t": "喜欢的东西，想好好留在身边。",
      "ja": "好きなものは、大切にそばに置いておきたいな。",
      "m": "soft",
      "a": "nod"
    },
    {
      "t": "{name}，眼睛累了就离开屏幕一会儿吧。",
      "ja": "{name}、目が疲れたら、少し画面から離れようよ。",
      "m": "worried",
      "a": "tilt"
    },
    {
      "t": "不想说的话，也可以先不说。我会等你。",
      "ja": "話したくないことは、今は話さなくていいよ。待ってるから。",
      "m": "warm",
      "a": "nod"
    },
    {
      "t": "早饭吃了吗？空着肚子可没精神。",
      "ja": "朝ごはん食べた？お腹が空いてたら元気出ないよ。",
      "m": "soft",
      "a": "tilt",
      "when": "morning"
    },
    {
      "t": "制服穿好了，发饰也再检查一下。",
      "ja": "制服も着たし、髪飾りも確認しようっと。",
      "m": "soft",
      "a": "nod",
      "outfit": "uniform"
    },
    {
      "t": "常服果然能搭出更多花样呢。",
      "ja": "普段着だと、いろいろ合わせられるね。",
      "m": "happy",
      "a": "tilt",
      "outfit": "casual"
    },
    {
      "t": "晚上安静下来了。剪辑也记得留个休息时间。",
      "ja": "夜は静かだね。編集も、休む時間を残しておこうよ。",
      "m": "soft",
      "a": "nod",
      "when": "night"
    }
  ],
  "water": [
    {
      "t": "喝点水吧。我也停一下。",
      "ja": "お水飲もうよ。ボクも少し休憩する。",
      "m": "soft",
      "a": "nod"
    }
  ],
  "rest": [
    {
      "t": "先休息五分钟吧，回来再继续也来得及。",
      "ja": "まず五分休もうよ。戻ってから続けても大丈夫。",
      "m": "soft",
      "a": "tilt"
    }
  ],
  "sleep": [
    {
      "t": "剩下的明天再继续吧。晚安，{name}。",
      "ja": "続きは明日にしようよ。おやすみ、{name}。",
      "m": "soft",
      "a": "nod"
    }
  ],
  "doze": [
    {
      "t": "有点困了。我眯一会儿哦。",
      "ja": "ちょっと眠くなってきた。少しだけ目を閉じるね。",
      "m": "sleepy",
      "a": "sleep"
    }
  ],
  "wake": [
    {
      "t": "嗯？你回来啦。",
      "ja": "ん？戻ってきたんだね。",
      "m": "soft",
      "a": "tilt"
    }
  ],
  "noApi": [
    {
      "t": "先在右键菜单的设置里填好模型 API，就能和我聊天啦。",
      "ja": "",
      "m": "think",
      "a": "tilt"
    }
  ],
  "apiError": [
    {
      "t": "刚才没连上。设置里可以看看具体错误，我们再试一下。",
      "ja": "うまくつながらなかったみたい。もう一度試そうよ。",
      "m": "troubled",
      "a": "tilt"
    }
  ]
};
window.FACE_STRENGTH_DEFAULT = 0.85;
window.SHADOW_FACES = new Set([]);
window.FACE_STRENGTH_FULL = new Set(["平静", "闭眼", "困倦"]);
window.IDLE = {
  "b": "w-cute11-pose",
  "f": "平静"
};
window.IDLE_MOVES = [
  "w-cute11-tilthead",
  "w-cute11-tilthead02",
  "w-cute12-nod"
];
