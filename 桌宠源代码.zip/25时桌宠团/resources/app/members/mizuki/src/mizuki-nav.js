'use strict';
/* 设置页顶部的分区导航：点一下跳到对应分区，滚动时高亮当前分区 */
(function () {
  const nav = document.getElementById('mzNav');
  if (!nav) return;
  const secs = [...document.querySelectorAll('main section[data-nav]')];
  const links = secs.map((s) => {
    const a = document.createElement('a');
    a.href = '#' + s.id; a.textContent = s.dataset.nav;
    a.onclick = (e) => { e.preventDefault(); s.scrollIntoView({ behavior: 'smooth', block: 'start' }); };
    nav.appendChild(a);
    return a;
  });
  const top = document.querySelector('.mz-top');
  function spy() {
    const y = (top ? top.getBoundingClientRect().bottom : 0) + 24;
    let cur = 0;
    secs.forEach((s, i) => { if (s.getBoundingClientRect().top <= y) cur = i; });
    if (window.innerHeight + window.scrollY >= document.documentElement.scrollHeight - 4) cur = secs.length - 1;
    links.forEach((a, i) => a.classList.toggle('on', i === cur));
    const on = links[cur];
    if (on && (on.offsetLeft < nav.scrollLeft || on.offsetLeft + on.offsetWidth > nav.scrollLeft + nav.clientWidth)) nav.scrollTo({ left: on.offsetLeft - 12, behavior: 'smooth' });
  }
  window.addEventListener('scroll', spy, { passive: true });
  window.addEventListener('resize', spy);
  spy();
})();
