const $ = (id) => document.getElementById(id);
const fields = ['name', 'apiType', 'apiBase', 'apiKey', 'model', 'memoryTurns', 'persona',
  'ttsBase', 'ttsKey', 'ttsGroupId', 'ttsVoiceId', 'ttsModel', 'ttsSpeed', 'jaName', 'volume',
  'asrBase', 'asrKey', 'asrModel', 'asrLang', 'vadSilenceMs', 'vadMaxSec', 'vadLevel', 'embBase', 'embKey', 'embModel', 'memoryTopK', 'proactiveRate', 'userBirthday', 'anniversary', 'visionType', 'visionBase', 'visionKey', 'visionModel', 'screenLookRate', 'screenLookScope', 'screenLookBlock', 'idleTalk'];
const checks = ['screenLook', 'screenLookFallback', 'autoBackup', 'proactiveEnabled', 'dndFullscreen', 'quietNight', 'nightcord', 'memoryEnabled', 'ttsEnabled', 'ttsEmotion', 'showJa', 'voiceFixed', 'callShowJa', 'callKaraoke', 'callStream', 'bargeIn'];
let defaults = '';
const status = (t, cls = '') => { $('status').textContent = t; $('status').className = cls; };
const values = () => ({
  ...Object.fromEntries(fields.map((f) => [f, $(f).value])),
  ...Object.fromEntries(checks.map((f) => [f, $(f).checked])),
});
const showRange = () => {
  $('speedVal').textContent = Number($('ttsSpeed').value).toFixed(2) + ' 倍'; $('volVal').textContent = Math.round($('volume').value * 100) + '%';
  $('silVal').textContent = (Number($('vadSilenceMs').value) / 1000).toFixed(1) + ' 秒'; $('maxVal').textContent = $('vadMaxSec').value + ' 秒';
};
$('ttsSpeed').oninput = showRange; $('volume').oninput = showRange; $('vadSilenceMs').oninput = showRange; $('vadMaxSec').oninput = showRange;
const vstatus = (t, cls = '') => { $('voiceStatus').textContent = t; $('voiceStatus').className = cls; };

window.setAPI.get().then((s) => {
  for (const f of fields) $(f).value = s[f] ?? '';
  for (const f of checks) $(f).checked = !!s[f];
  if (!$('ttsBase').value) $('ttsBase').value = 'https://api.minimaxi.com';
  if (!$('vadLevel').value) $('vadLevel').value = 'normal';
  showRange();
  defaults = s.defaultPersona;
  $('histInfo').textContent = `现在保存了 ${Math.floor(s.historyCount)} 轮聊天。`;
  $('dndStatus').textContent = s.dndStatus ? '（' + s.dndStatus + '）' : '';
  if (!$('proactiveRate').value) $('proactiveRate').value = 'normal';
  if (!$('idleTalk').value) $('idleTalk').value = 'normal';
  if (!$('screenLookRate').value) $('screenLookRate').value = 'sometimes';
  if (!$('screenLookScope').value) $('screenLookScope').value = 'screen';
  $('lookStatus').textContent = '上一次：' + (s.lookStatus || '还没看过。');
  if (s.memoryStats) $('memStatus').textContent = `瑞希现在记得 ${s.memoryStats.memory} 件事，资料库里有 ${s.memoryStats.sources} 份资料（${s.memoryStats.knowledge} 段）。`;
});

$('showKey').onclick = () => {
  const k = $('apiKey'); const show = k.type === 'password';
  k.type = show ? 'text' : 'password'; $('showKey').textContent = show ? '隐藏' : '显示';
};
const toggleKey = (input, btn) => () => {
  const k = $(input); const show = k.type === 'password';
  k.type = show ? 'text' : 'password'; $(btn).textContent = show ? '隐藏' : '显示';
};
$('showTtsKey').onclick = toggleKey('ttsKey', 'showTtsKey');
$('showAsrKey').onclick = toggleKey('asrKey', 'showAsrKey');
$('showEmbKey').onclick = toggleKey('embKey', 'showEmbKey');
$('showVisionKey').onclick = toggleKey('visionKey', 'showVisionKey');
const hstat = (id, t, ok) => { const st = $(id); st.style.color = ok === true ? '#4b8a5f' : ok === false ? '#b0475a' : ''; st.textContent = t; };
$('visionTest').onclick = async () => {
  hstat('visionStatus', '测试中…（第一次会先找合适的模型）');
  const r = await window.setAPI.visionTest(values());
  if (r && r.ok) { if (!$('visionModel').value) $('visionModel').value = r.model; hstat('visionStatus', `能用（${r.model}）。它看到的：${r.text.slice(0, 60).replace(/[。.]+$/, '')}。记得点“保存”。`, true); }
  else hstat('visionStatus', '失败：' + (r && r.error), false);
};
const localTime = (iso) => { const d = new Date(iso); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')} ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`; };
const sumText = (s) => `${s.at ? localTime(s.at) + ' 的备份' : '备份'}：${s.chats} 轮聊天、${s.memories} 条记忆/资料、好感 ${s.affection ?? '—'}${s.withKeys ? '、含密钥' : '、不含密钥'}`;
$('backupExport').onclick = async () => {
  const r = await window.setAPI.backupExport({ withKeys: $('backupKeys').checked });
  if (r && r.path) hstat('backupStatus', '已导出到 ' + r.path + '。' + sumText(r.summary), true);
};
$('backupPick').onclick = async () => {
  const r = await window.setAPI.backupPick();
  if (!r || (!r.summary && !r.error)) return;
  if (r.error) { hstat('backupStatus', r.error, false); return; }
  hstat('backupStatus', `「${r.name}」 ${sumText(r.summary)}。恢复后会覆盖现在的数据（恢复前会自动把现在的数据另存一份）。`);
  $('restoreRow').style.display = '';
};
$('backupCancel').onclick = () => { $('restoreRow').style.display = 'none'; hstat('backupStatus', '已取消'); };
$('backupRestore').onclick = async () => {
  const r = await window.setAPI.backupRestore();
  if (r && r.ok) hstat('backupStatus', '恢复好了，马上重启……', true); else hstat('backupStatus', '恢复失败：' + (r && r.error), false);
};
$('backupFolder').onclick = () => window.setAPI.backupOpenFolder();
// 3 秒后再看：留时间切到你想让瑞希看的窗口（最大化的也行）
$('lookNow').onclick = async () => {
  if ($('lookNow').disabled) return;
  $('lookNow').disabled = true;
  try {
    await window.setAPI.save(values());
    for (let n = 3; n > 0; n--) { hstat('lookStatus', `${n} 秒后看一眼……现在可以切到你想让她看的窗口`); await new Promise((r) => setTimeout(r, 1000)); }
    hstat('lookStatus', '在看……');
    const r = await window.setAPI.lookNow();
    hstat('lookStatus', '上一次：' + (r?.skip || r?.status || r?.error || '没有返回结果'), r?.ok ? true : r?.error ? false : undefined);
  } catch (e) { hstat('lookStatus', '看屏幕失败：' + String(e?.message || e), false); }
  finally { $('lookNow').disabled = false; }
};
window.setAPI.onLookStatus && window.setAPI.onLookStatus((t) => { $('lookStatus').style.color = ''; $('lookStatus').textContent = '上一次：' + t; });
$('memOpen').onclick = () => window.setAPI.openMemory();
$('affOpen').onclick = () => window.setAPI.openAffection();
$('memTest').onclick = async () => {
  const st = $('memStatus'); st.style.color = ''; st.textContent = '连接中…';
  const r = await window.setAPI.memTest(values());
  if (r && r.ok) { st.style.color = '#4b8a5f'; st.textContent = `连上了（向量长度 ${r.dim}）。记得点“保存”。`; }
  else { st.style.color = '#b0475a'; st.textContent = '失败：' + (r && r.error); }
};
$('asrTest').onclick = async () => {
  const st = $('asrStatus'); st.style.color = ''; st.textContent = '连接中…';
  const r = await window.setAPI.asrTest(values());
  if (r && !r.error) { st.style.color = '#4b8a5f'; st.textContent = '连上了（测试用的是一段静音，所以没有识别出文字）。记得点“保存”。'; }
  else { st.style.color = '#b0475a'; st.textContent = r && r.error === 'noasr' ? '还没填识别 API 密钥' : '失败：' + (r && r.error); }
};
$('voiceClear').onclick = async () => { await window.setAPI.voiceClearCache(); vstatus('语音缓存已清除', 'ok'); };
$('voiceTest').onclick = async () => {
  vstatus('合成中…');
  const r = await window.setAPI.voiceTest(values());
  if (r && r.audio) {
    const a = new Audio('data:audio/mpeg;base64,' + r.audio);
    a.volume = Number($('volume').value);
    a.play();
    vstatus('正在播放。听起来对的话，记得点“保存”。', 'ok');
  } else if (r && r.error === 'novoice') vstatus('还没填 MiniMax 密钥或音色 ID', 'err');
  else vstatus('失败：' + (r && r.error), 'err');
};
$('preset').onchange = () => {
  const v = $('preset').value; if (!v) return;
  const [type, base, model] = v.split('|');
  $('apiType').value = type; $('apiBase').value = base;
  $('model').placeholder = model || '平台控制台里能看到模型名';
  if (model) $('model').value = model;
  else if (/deepseek/i.test($('model').value)) $('model').value = '';
  $('modelList').innerHTML = '';
  $('modelHint').textContent = model ? '已填好。' : '地址已填好。填上密钥后点“读取模型列表”，再选一个模型。';
  $('preset').value = '';
};
$('fetchModels').onclick = async () => {
  const h = $('modelHint'); h.style.color = ''; h.textContent = '读取中…';
  const r = await window.setAPI.listModels(values());
  if (r && r.models && r.models.length) {
    $('modelList').innerHTML = '';
    for (const m of r.models) { const o = document.createElement('option'); o.value = m; $('modelList').appendChild(o); }
    h.style.color = '#4b8a5f'; h.textContent = `读到 ${r.models.length} 个模型。点一下模型名输入框（或清空后输入几个字）就能选。`;
  } else { h.style.color = '#b0475a'; h.textContent = r && r.models ? '没有读到模型（这个平台可能不提供列表，直接手动填）' : '读取失败：' + (r && r.error) + '。也可以直接手动填模型名。'; }
};
$('reset').onclick = () => { $('persona').value = defaults; status('已恢复默认人设，记得保存'); };
$('clear').onclick = async () => { await window.setAPI.clearHistory(); $('histInfo').textContent = '聊天记录已清空。'; };
// 密钥里混进中文、全角字符时先提醒（空格、换行保存时会自动去掉）
const KEY_FIELDS = { apiKey: '聊天模型的 API 密钥', ttsKey: 'MiniMax 密钥', asrKey: '语音识别 API 密钥', embKey: '长期记忆的 embedding 密钥', visionKey: '看图 API 密钥' };
function badKey() {
  for (const [id, label] of Object.entries(KEY_FIELDS)) {
    const v = ($(id).value || '').replace(/[\s\u3000\u200B-\u200D\u2060\uFEFF]+/g, '');
    const c = [...v].find((ch) => ch.charCodeAt(0) < 0x21 || ch.charCodeAt(0) > 0x7e);
    if (c) return { id, msg: `${label}里有“${c}”，密钥只会是英文字母、数字和符号。请清空后重新粘贴` };
  }
  return null;
}
$('save').onclick = async () => {
  const b = badKey();
  if (b) { status(b.msg, 'err'); $(b.id).focus(); return; }
  await window.setAPI.save(values()); status('已保存', 'ok');
};
$('test').onclick = async () => {
  status('连接中…');
  const r = await window.setAPI.test(values());
  if (r && r.reply) status('连上了。瑞希说：' + r.reply, 'ok');
  else if (r && r.error === 'noapi') status('还没填 API 密钥', 'err');
  else status('失败：' + (r && r.error), 'err');
};
