'use strict';
/* 记忆管理窗口：瑞希记得的事 / 资料库 */
const $ = (id) => document.getElementById(id);
const api = window.memAPI;
let kind = 'memory', data = { items: [] }, hits = null;   // hits：搜索结果 {id: 分数}
const status = (t, cls = '') => { $('status').textContent = t; $('status').className = cls; };
const fmt = (ms) => { const d = new Date(ms); return `${d.getFullYear()}年${d.getMonth() + 1}月${d.getDate()}日 ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`; };
const el = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; };

// 点两次才执行（删除、清空这类操作）
function confirmBtn(btn, label, fn) {
  let armed = false, t = 0;
  btn.onclick = async () => {
    if (!armed) { armed = true; const old = btn.textContent; btn.textContent = label; t = setTimeout(() => { armed = false; btn.textContent = old; }, 2500); return; }
    clearTimeout(t); armed = false; await fn();
  };
}

async function load() {
  data = await api.list(kind);
  const nr = $('notReady');
  if (!data.ready) { nr.style.display = ''; nr.textContent = '还不能用：请在 右键 → 设置 → “长期记忆” 里打开记忆，并填好 embedding 的密钥（默认和语音识别共用硅基流动的密钥）。'; }
  else if (data.stats.stale) { nr.style.display = ''; nr.textContent = `有 ${data.stats.stale} 条是用别的模型算的向量，暂时搜不到；点下面的“全部重新计算向量”。`; }
  else nr.style.display = 'none';
  render();
  const r = data.lastRecall;
  $('recall').textContent = r && (r.mem.length || r.kno.length)
    ? `最近一次聊天瑞希想起了：${[...r.mem.map((m) => `${m.text}（相关度 ${m.score}）`), ...r.kno.map((m) => `资料「${m.text}…」（${m.score}）`)].join('；')}`
    : '最近一次聊天瑞希没有想起什么。';
  if (data.lastError) status('上次出错：' + data.lastError, 'err');
}

function render() {
  const list = $('list');
  list.textContent = '';
  let items = data.items;
  if (hits) items = items.filter((x) => hits[x.id] != null).sort((a, b) => hits[b.id] - hits[a.id]);
  if (kind === 'knowledge' && !hits) return renderSources(items);
  if (!items.length) {
    list.appendChild(el('div', 'empty', hits ? '没有找到相关的。' : kind === 'memory' ? '还没有记下什么。\n和瑞希多聊聊，或者在上面手动加一条。' : '资料库是空的。'));
    return;
  }
  for (const it of items) list.appendChild(itemView(it));
}

function itemView(it) {
  const box = el('div', 'item' + (hits && hits[it.id] != null ? ' hit' : ''));
  const text = el('div', 'text', it.text);
  box.appendChild(text);
  const meta = el('div', 'meta');
  meta.appendChild(el('span', '', fmt(it.at) + (it.source ? ' · ' + it.source : '')));
  if (hits && hits[it.id] != null) meta.appendChild(el('span', 'score', '相关度 ' + hits[it.id]));
  if (it.stale) meta.appendChild(el('span', 'stale', '向量需要重新计算'));
  meta.appendChild(el('span', 'sp'));
  const edit = el('button', 'small', '改');
  const del = el('button', 'small danger', '删');
  meta.append(edit, del);
  box.appendChild(meta);
  edit.onclick = () => {
    const ta = el('textarea'); ta.value = it.text; ta.maxLength = 2000;
    box.replaceChild(ta, text); ta.focus();
    edit.textContent = '保存';
    edit.onclick = async () => {
      status('保存中…');
      const r = await api.edit({ id: it.id, text: ta.value });
      if (r && r.error) status('没保存上：' + r.error, 'err'); else { status('已改好', 'ok'); load(); }
    };
  };
  confirmBtn(del, '确定删？', async () => { await api.remove(it.id); status('已删除', 'ok'); load(); });
  return box;
}

function renderSources(items) {
  const list = $('list');
  const by = new Map();
  for (const it of items) { const k = it.source || '资料'; if (!by.has(k)) by.set(k, []); by.get(k).push(it); }
  if (!by.size) { list.appendChild(el('div', 'empty', '资料库是空的。\n点“导入文件…”把 txt / md 放进来。')); return; }
  for (const [name, arr] of by) {
    const wrap = el('div');
    const row = el('div', 'src');
    row.append(el('span', 'name', name), el('span', 'n', `${arr.length} 段 · ${fmt(Math.max(...arr.map((x) => x.at)))}`));
    const del = el('button', 'small danger', '删除这份资料');
    row.appendChild(del);
    confirmBtn(del, '确定删？', async () => { await api.removeSource(name); status(`已删除「${name}」`, 'ok'); load(); });
    wrap.appendChild(row);
    const det = el('details'); det.appendChild(el('summary', '', '看看切成的段落'));
    for (const c of arr.slice(0, 50)) det.appendChild(el('div', 'chunk', c.text));
    if (arr.length > 50) det.appendChild(el('div', 'chunk', `……还有 ${arr.length - 50} 段`));
    wrap.appendChild(det);
    list.appendChild(wrap);
  }
}

/* ---------- 切换页 ---------- */
document.querySelectorAll('.tab').forEach((t) => t.onclick = () => {
  document.querySelectorAll('.tab').forEach((x) => x.classList.toggle('on', x === t));
  kind = t.dataset.k; hits = null; $('q').value = '';
  $('pMemory').style.display = kind === 'memory' ? '' : 'none';
  $('pKnow').style.display = kind === 'knowledge' ? '' : 'none';
  status(''); load();
});

/* ---------- 搜索、添加 ---------- */
async function search() {
  const q = $('q').value.trim();
  if (!q) { hits = null; render(); return; }
  status('搜索中…');
  const r = await api.search({ text: q, kind });
  if (r && r.error) { status('搜不了：' + r.error, 'err'); return; }
  hits = Object.fromEntries(r.map((x) => [x.id, x.score]));
  status(`按意思排了序，越靠前越相关（相关度 0.4 以下一般就不太相关了）`);
  render();
}
$('qBtn').onclick = search;
$('q').onkeydown = (e) => { if (e.key === 'Enter') search(); };
$('qClear').onclick = () => { $('q').value = ''; hits = null; status(''); render(); };
$('addMem').onclick = async () => {
  const t = $('newMem').value.trim(); if (!t) return;
  status('添加中…');
  const r = await api.add({ text: t, kind: 'memory' });
  if (r && r.error) status('没加上：' + r.error, 'err'); else { $('newMem').value = ''; status('加好了', 'ok'); load(); }
};
$('newMem').onkeydown = (e) => { if (e.key === 'Enter') $('addMem').click(); };
$('addKnow').onclick = async () => {
  const t = $('newKnow').value.trim(); if (!t) return;
  status('添加中…');
  const r = await api.add({ text: t, kind: 'knowledge' });
  if (r && r.error) status('没加上：' + r.error, 'err'); else { $('newKnow').value = ''; status('加好了', 'ok'); load(); }
};
$('import').onclick = async () => {
  status('选择文件…');
  const r = await api.importFiles();
  if (!r || r.canceled) { status(''); return; }
  if (r.error) { status('导入失败：' + r.error, 'err'); return; }
  const ok = r.done.filter((x) => x.ok), bad = r.done.filter((x) => x.error);
  status([ok.length ? '导入好了：' + ok.map((x) => `「${x.name}」${x.chunks} 段`).join('、') : '', bad.length ? '失败：' + bad.map((x) => `「${x.name}」${x.error}`).join('、') : ''].filter(Boolean).join('；'), bad.length ? 'err' : 'ok');
  load();
};
api.onProgress(({ d, n, name }) => status(`${name ? '「' + name + '」' : ''}计算向量中… ${d}/${n}`));
api.onChanged(() => { if (kind === 'memory' && !hits) load(); });

confirmBtn($('reembed'), '确定？会重新调用接口', async () => {
  status('重新计算中…');
  const r = await api.reembed();
  if (r && r.error) status('失败：' + r.error, 'err'); else { status(`全部 ${r.count} 条已重新计算`, 'ok'); load(); }
});
confirmBtn($('clearAll'), '确定清空？', async () => { await api.clear(kind); status('已清空', 'ok'); load(); });

load();
