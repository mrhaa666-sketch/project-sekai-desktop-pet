'use strict';
const $ = (id) => document.getElementById(id);
const api = window.affAPI;
const MOODNAME = { angry: '生气', sulky: '闹别扭', hurt: '受伤', sad: '低落', troubled: '烦', warm: '暖和', soft: '柔和', shy: '害羞', flustered: '慌', happy: '开心' };
const fmt = (ms) => { const d = new Date(ms); return `${d.getMonth() + 1}/${d.getDate()} ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`; };
async function load() {
  const i = await api.info();
  $('val').textContent = i.value; $('band').textContent = i.band;
  $('fill').style.width = i.value + '%';
  $('ticks').innerHTML = '';
  for (const b of i.bands) { const s = document.createElement('span'); s.style.left = b.min + '%'; s.textContent = b.min + ' ' + b.name; $('ticks').appendChild(s); }
  $('mood').textContent = i.lingering ? `${MOODNAME[i.lingering.mood] || i.lingering.mood}，还剩 ${Math.round(i.lingering.level * 100)}%（${i.lingering.text}）` : '没有（平静）';
  $('tail').textContent = i.tail || '（好感变化关着，也没有余韵）';
  const log = $('log'); log.textContent = '';
  if (!i.log.length) log.innerHTML = '<div><span class="r" style="color:#85647b">还没有变化过。</span></div>';
  for (const x of i.log) {
    const d = document.createElement('div');
    d.innerHTML = '<span class="d"></span><span class="r"></span><span class="t"></span>';
    d.children[0].textContent = (x.delta > 0 ? '+' : '') + x.delta; d.children[0].className = 'd ' + (x.delta > 0 ? 'up' : 'down');
    d.children[1].textContent = `${x.reason || '（没写原因）'} → ${x.value}`;
    d.children[2].textContent = `${x.source || ''} ${fmt(x.at)}`;
    log.appendChild(d);
  }
  for (const k of ['affectionMaxStep', 'affectionDayCap', 'moodHalfLife']) $(k).value = i.cfg[{ affectionMaxStep: 'maxStep', affectionDayCap: 'dayCap', moodHalfLife: 'halfLife' }[k]];
  $('affectionEnabled').checked = i.cfg.on;
  if (!$('setVal').value) $('setVal').value = i.value;
}
$('setBtn').onclick = async () => { await api.set(+$('setVal').value); load(); };
$('clearMood').onclick = async () => { await api.clearMood(); load(); };
$('openFile').onclick = () => api.openFile();
$('saveCfg').onclick = async () => {
  await api.saveCfg({ affectionEnabled: $('affectionEnabled').checked, affectionMaxStep: $('affectionMaxStep').value, affectionDayCap: $('affectionDayCap').value, moodHalfLife: $('moodHalfLife').value });
  $('ok').textContent = '已保存'; setTimeout(() => { $('ok').textContent = ''; }, 2000); load();
};
api.onChanged(load);
setInterval(load, 30000);
load();
