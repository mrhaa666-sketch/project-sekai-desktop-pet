'use strict';
/* 桌宠本体：渲染模型、动作分层、点击说话、拖动、视线跟随、提醒气泡 */

const api = window.petAPI || null;        // Electron 里由 preload 提供；浏览器里调试时为空
// 两套衣服：校服、常服（周一和周六 7:00–18:00 穿校服，其余时间穿常服，由主进程决定）
const OUTFITS = {
  uniform: { dir: 'model', file: '20mizuki_uniform2_4_t09.model3.json', name: '校服' },
  casual: { dir: 'model_casual', file: 'v2_20mizuki_casual_t06.model3.json', name: '常服' },
};
let outfit = OUTFITS[new URLSearchParams(location.search).get('outfit')] ? new URLSearchParams(location.search).get('outfit') : 'uniform';
const BUBBLE_SPACE = 222;                 // 窗口顶部留给气泡的高度（和 main.js 的 HEADROOM 一起改：92 + 130）
const SS = +(new URLSearchParams(location.search).get('ss') || 2);   // 超采样倍数

let settings = { name: '', view: new URLSearchParams(location.search).get('view') || 'full' };
const motionCache = new Map();
let app, model, core, bodyLayer, faceLayer;
let bodyName = '', faceName = '';

/* ---------- 工具 ---------- */
const lastPicked = new Map();
const pick = (arr) => {
  // 同一组台词不连续重复
  if (!arr || !arr.length) return null;
  let e, n = 0;
  do { e = arr[Math.floor(Math.random() * arr.length)]; } while (arr.length > 1 && e === lastPicked.get(arr) && ++n < 8);
  lastPicked.set(arr, e);
  return e;
};
const rand = (a, b) => a + Math.random() * (b - a);
// 没填称呼时：句首的“{name}，”直接省掉，其他地方说“你”
const fill = (s) => settings.name ? s.replace(/\{name\}/g, settings.name) : s.replace(/^\{name\}[，。、,.]\s*/, '').replace(/[，,]\s*\{name\}(?=[。！？…])/g, '').replace(/\{name\}/g, '你');
const fillJa = (s) => (settings.jaName || settings.name) ? s.replace(/\{name\}/g, settings.jaName || settings.name) : s.replace(/^\{name\}[、。,.]\s*/, '').replace(/[、,]\s*\{name\}(?=[。！？…])/g, '').replace(/\{name\}/g, 'あなた');

function loadJSON(url) {
  return new Promise((resolve, reject) => {
    const x = new XMLHttpRequest();
    x.open('GET', url);
    x.responseType = 'json';
    x.onload = () => (x.status === 0 || x.status === 200) && x.response ? resolve(x.response) : reject(new Error(url));
    x.onerror = () => reject(new Error(url));
    x.send();
  });
}

async function getMotion(name) {
  // 每套衣服用自己的动作文件
  const key = outfit + '|' + name, dir = OUTFITS[outfit].dir;
  if (!motionCache.has(key)) {
    // 表情用中文代号，放在 faces/；身体动作在 motions/
    const url = FACES[name] ? `${dir}/faces/${FACES[name][0]}.motion3.json` : `${dir}/motions/${name}.motion3.json`;
    motionCache.set(key, loadJSON(url).then((j) => new Motion(j)).catch((e) => { motionCache.delete(key); throw e; }));
  }
  return motionCache.get(key);
}

/* ---------- 初始化 ---------- */
async function init() {
  if (api) {
    try { settings = Object.assign(settings, await api.getSettings()); } catch (e) {}
  }

  app = new PIXI.Application({
    width: window.innerWidth,
    height: window.innerHeight,
    backgroundAlpha: 0,
    antialias: true,
    autoDensity: true,
    // 超采样：按屏幕密度的 2 倍渲染再缩小，线条和发丝更细腻（最高 3 倍）
    resolution: Math.min(3, (window.devicePixelRatio || 1) * SS),
    preserveDrawingBuffer: true,   // 为了读像素判断鼠标是否在人物身上
  });
  document.getElementById('stage').appendChild(app.view);
  setupRenderRecovery();

  if (settings.outfit && OUTFITS[settings.outfit] && !new URLSearchParams(location.search).get('outfit')) outfit = settings.outfit;
  await loadModel();
  if (!MANUAL) app.ticker.add(() => step(app.ticker.deltaMS));

  resizeStage();
  window.addEventListener('resize', resizeStage);

  await setIdle(true);
  step(16);
  const fadeIn = () => { model.alpha = Math.min(1, model.alpha + 0.06); if (model.alpha < 1) requestAnimationFrame(fadeIn); };
  if (MANUAL) model.alpha = 1; else fadeIn();
  setupPointer();
  setupGaze();
  if (!MANUAL) { scheduleIdleMove(); scheduleIdleTalk(); }   // 逐帧测试时不插入随机小动作和自言自语

  if (api) {
    api.onSpeechStop && api.onSpeechStop(() => { ++speechSeq; if (window.Call && Call.active) Call.stopReply(); stopVoice(); });
    api.onRemind((type) => remind(type));
    api.onExtra((v) => { extraSpace = v; expectGrow = false; layout(); });
    api.onSettings((s) => { const was = settings.idleTalk; if (s.muted && !settings.muted) { if (window.Call && Call.active && Call.stopCurrent) Call.stopCurrent(); stopVoice(); } settings = Object.assign(settings, s); baseH = 0; layout(); if (s.idleTalk !== was && !MANUAL) scheduleIdleTalk(); });
    // 不是聊天框发起的、他自己要说的话（比如写好旋律后）
    api.onAiSay && api.onAiSay((r) => {
      if (window.Call && Call.active) return;
      react({ t: r.t, m: MOODS[r.m] ? r.m : 'calm', a: ACTIONS[r.a] ? r.a : 'none', autoAction: true, intensity: r.intensity ?? undefined },
        { raw: true, ja: r.ja, audio: r.audio, words: r.words, tag: r.tag });
      if (r.tag) { proactiveAt = Date.now(); showChatBtn(20000); }
    });
    api.onLingering && api.onLingering((l) => {
      const changed = JSON.stringify(l && [l.mood, Math.round(l.level * 10)]) !== JSON.stringify(lingering && [lingering.mood, Math.round(lingering.level * 10)]);
      lingering = l;
      if (changed && !reacting && !dozing) idleFace(1.2);    // 慢慢变，不突兀
    });
    api.onProactive && api.onProactive((p) => proactive(p));
    api.onGrabFrame && api.onGrabFrame(grabFrame);
    api.onGrabFrameCancel && api.onGrabFrameCancel(cancelGrabFrame);
    api.onOutfit && api.onOutfit(async ({ outfit: o, manual }) => {
      await setOutfit(o);
      api.outfitResult && api.outfitResult({ outfit, requested: o });
      if (outfit !== o) return;
      // 到点自动换衣服时说一句；你手动换的、或者他在睡觉/聊天/通话时就不说
      if (!manual && !dozing && !chatOpen && !(window.Call && Call.active)) react(pick(LINES[o === 'casual' ? 'outfitCasual' : 'outfitUniform']));
    });
    api.onSay((key) => {
      if (key === 'chat') return openChat();
      if (key === 'call') return Call.start();
      if (key === 'sleep') { if (!dozing && !(window.Call && Call.active)) startDoze(); return; }
      // 听你写的曲子：他在睡觉、聊天、通话时就不插话
      react(pick(LINES[key]));
    });
  }

  if (!MANUAL) setTimeout(greet, 600);
}

function setupRenderRecovery() {
  app.view.addEventListener('webglcontextlost', (e) => {
    e.preventDefault();
    app.stop();
    if (api && api.renderHealth) api.renderHealth('webgl-lost');
  });
  app.view.addEventListener('webglcontextrestored', () => {
    if (api && api.renderHealth) api.renderHealth('webgl-restored');
    else app.start();
  });
}

// 载入当前这套衣服的模型（第一次启动和换衣服时用）
async function loadModel(preloaded = null) {
  const o = OUTFITS[outfit];
  const m = preloaded || await PIXI.live2d.Live2DModel.from(`${o.dir}/${o.file}`, { autoInteract: false, autoUpdate: false });
  model = m;
  limitMipmaps();
  model.alpha = 0;                       // 先藏起来，等第一个姿势套上再淡入
  app.stage.addChild(model);
  core = model.internalModel.coreModel;
  // 原库也会额外叠加一套呼吸和头部摆动；只保留素材与显式视线控制。
  model.internalModel.breath = null;
  model.internalModel.on('beforeModelUpdate', () => {
    core.setParameterValueById('ParamPositionX', 0);
    core.setParameterValueById('ParamPositionY', 0);
  });

  // 参数默认值
  const cm = core.getModel();
  const defaults = {};
  const ids = cm.parameters.ids;
  for (let i = 0; i < ids.length; i++) defaults[ids[i]] = cm.parameters.defaultValues[i];
  window.__paramInfo = { ids, min: cm.parameters.minimumValues, max: cm.parameters.maximumValues, def: cm.parameters.defaultValues };

  bodyLayer = new MotionLayer(defaults);
  faceLayer = new MotionLayer(defaults);
  // 每帧：在库自带的动作更新之前写入我们自己的参数
  model.internalModel.on('beforeMotionUpdate', () => applyFrame(frameDt, clock));
  calmBase = (await getMotion('平静')).sample(0);   // 表情强度的基准
  layout();
}

// 换衣服：淡出 → 换模型 → 接着原来的姿势和表情 → 淡入
let swapping = null;
let wantedOutfit = outfit;
let modelCommit = false;
function fadeModel(to, sec) {
  return new Promise((done) => {
    if (MANUAL) { model.alpha = to; done(); return; }
    const from = model.alpha, t0 = performance.now();
    const tick = () => {
      const k = Math.min(1, (performance.now() - t0) / (sec * 1000));
      model.alpha = from + (to - from) * k;
      k < 1 ? requestAnimationFrame(tick) : done();
    };
    tick();
  });
}
async function setOutfit(name) {
  if (!OUTFITS[name]) return;
  wantedOutfit = name;
  if (swapping) return swapping;
  if (name === outfit) return;
  swapping = (async () => {
    while (wantedOutfit !== outfit) {
    const next = wantedOutfit, spec = OUTFITS[next];
    // 先载入模型和所需表情；失败时当前人物仍保持显示。
    const prepared = await PIXI.live2d.Live2DModel.from(`${spec.dir}/${spec.file}`, { autoInteract: false, autoUpdate: false });
    if (next !== wantedOutfit) { prepared.destroy({ children: true }); continue; }
    const warmFace = faceName || IDLE.f;
    try {
      await Promise.all([loadJSON(`${spec.dir}/faces/${FACES['平静'][0]}.motion3.json`), loadJSON(`${spec.dir}/motions/${dozing ? bodyName : IDLE.b}.motion3.json`), loadJSON(`${spec.dir}/faces/${FACES[warmFace][0]}.motion3.json`)]);
    } catch (e) { prepared.destroy({ children: true }); throw e; }
    await fadeModel(0, 0.35);
    // 淡出期间表情仍可到期；只在模型提交时取快照并暂停模拟时钟。
    modelCommit = true;
    const keepFace = faceName || IDLE.f, keepStrength = faceStrengthTarget, wasDozing = dozing, keepBody = bodyName;
    const old = model;
    const previous = { outfit, core, bodyLayer, faceLayer, calmBase, info: window.__paramInfo };
    ++bodyRequestSeq; ++faceRequestSeq;
    outfit = next;
    try { await loadModel(prepared); }
    catch (e) {
      prepared.destroy({ children: true }); model = old; outfit = previous.outfit;
      core = previous.core; bodyLayer = previous.bodyLayer; faceLayer = previous.faceLayer; calmBase = previous.calmBase; window.__paramInfo = previous.info;
      old.alpha = 1; layout(); modelCommit = false;
      // 旧请求已失效，不能恢复它们的序号；重建可继续运行的待机动作。
      reacting = wasDozing;
      await playBody(wasDozing ? keepBody : IDLE.b, { loop: !wasDozing, fade: 0.6, endPose: wasDozing });
      await playFace(keepFace, { fade: 0.3, strength: keepStrength });
      throw e;
    }
    app.stage.removeChild(old);
    old.destroy({ children: true });
    // 睡着时换的衣服：换完接着睡（不再说话）；其他时候回到站姿
    reacting = wasDozing;
    await playBody(wasDozing ? keepBody : IDLE.b, { loop: !wasDozing, fade: 0, endPose: wasDozing });
    await playFace(keepFace, { fade: 0, strength: keepStrength });
    modelCommit = false;
    step(16);
    await fadeModel(1, 0.45);
    }
  })().catch((e) => {
    wantedOutfit = outfit; console.error('换装失败', e); say('换装没有成功，请检查模型文件后重试。', 5000);
  }).finally(() => { modelCommit = false; swapping = null; });
  return swapping;
}

// 贴图缩得太小时，相邻部件的颜色会混进来（比如嘴巴发绿），所以限制最多只缩小到 MIP_MAX 级
const MIP_MAX = +(new URLSearchParams(location.search).get('mip') ?? 1);
function limitMipmaps() {
  const r = app.renderer, gl = r.gl;
  if (!(gl instanceof WebGL2RenderingContext)) return;
  for (const t of model.textures) {
    const bt = t.baseTexture;
    r.texture.bind(bt, 0);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAX_LEVEL, MIP_MAX);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_LINEAR);
  }
}

// 模型画布 3000x4500，人物实际在下面这个范围里（模型坐标）
const REGIONS = {
  full: { x0: 450, x1: 2550, y0: 500, y1: 4850 },   // 两套模型共享固定坐标，显示常服裤脚
  half: { x0: 450, x1: 2550, y0: 500, y1: 2750 },   // 半身（到腰）
};
const HEAD = { x: 1500, y: 1100, bottom: 1450 };      // 脸的大致中心、下巴位置

let extraSpace = 0;      // 窗口为了放长气泡而往上多长出来的高度
let expectGrow = false;  // 已经请求变高、还没收到确认
let baseH = 0;           // 正常（没变高时）的窗口高度
function layout() {
  if (!model) return;
  const W = window.innerWidth, H = window.innerHeight;
  if (settings.winH > 0) baseH = Math.min(H, settings.winH);
  else if (!baseH || (extraSpace === 0 && !expectGrow)) baseH = H;
  const R = REGIONS[settings.view] || REGIONS.full;
  const rw = R.x1 - R.x0, rh = R.y1 - R.y0;
  // 按正常窗口高度算缩放，他始终贴着窗口底部，窗口变高也不会变大变小
  const s = Math.min(W / rw, (baseH - BUBBLE_SPACE) / rh);
  model.scale.set(s);
  model.x = W / 2 - ((R.x0 + R.x1) / 2) * s;
  model.y = H - R.y1 * s;
  // 气泡贴在他头顶上方（窗口顶上留的空间比较大，短句子不会飘得太高）
  const headTop = model.y + R.y0 * s;
  window.__layout = { W, H, s, headTop };
  placeBubble();
}

// 改变画布尺寸会清空 WebGL 缓冲；同一次回调里排版并重画，避免字幕收起时闪空一帧。
function resizeStage() {
  if (!app) return;
  const W = window.innerWidth, H = window.innerHeight;
  if (app.screen.width !== W || app.screen.height !== H) app.renderer.resize(W, H);
  layout();
  app.render();
}

// 窗口坐标 → 模型坐标
function toModel(x, y) {
  const s = window.__layout.s;
  return { x: (x - model.x) / s, y: (y - model.y) / s };
}

/* ---------- 时钟（统一用模拟时间，动作和表情的计时不会和画面错开） ---------- */
const MANUAL = new URLSearchParams(location.search).has('manual');  // 调试：手动逐帧
let clock = 0, frameDt = 0;
const timers = [];
function later(fn, ms) { const t = { at: clock + ms / 1000, fn }; timers.push(t); return t; }
function cancel(t) { const i = timers.indexOf(t); if (i >= 0) timers.splice(i, 1); }
function step(ms) {
  if (modelCommit) return;
  frameDt = Math.min(0.1, ms / 1000);
  clock += frameDt;
  for (const t of timers.slice()) if (t.at <= clock) { cancel(t); t.fn(); }
  model.update(frameDt * 1000);
}

/* ---------- 每帧参数 ---------- */
const blink = { next: 2, t: -1 };
const NOBLINK = new URLSearchParams(location.search).has('noblink');   // 调试：关掉眨眼
function applyFrame(dt, now) {
  const body = bodyLayer.update(dt);
  const face = faceLayer.update(dt);
  for (const id in body) core.setParameterValueById(id, body[id]);
  // 表情强度：把表情往「平静」那边拉回去一部分，强度平滑变化
  faceStrength += (faceStrengthTarget - faceStrength) * Math.min(1, dt * 6);
  const fsK = faceStrength;
  for (const id in face) {
    const base = calmBase && id in calmBase ? calmBase[id] : face[id];
    core.setParameterValueById(id, base + (face[id] - base) * fsK);
  }

  // 眨眼（模型没配自动眨眼，这里自己做）
  blink.next -= dt;
  if (blink.next <= 0 && blink.t < 0) blink.t = 0;
  let k = 1;
  if (blink.t >= 0) {
    blink.t += dt;
    const D = 0.16;
    const p = blink.t / D;
    k = p < 0.5 ? 1 - p * 2 : Math.min(1, (p - 0.5) * 2);
    if (blink.t >= D) {
      blink.t = -1; k = 1;
      blink.next = Math.random() < 0.18 ? 0.25 : rand(2.5, 6);  // 偶尔连眨两下
    }
  }
  if (k < 1 && !dozing && !NOBLINK) {
    for (const id of ['ParamEyeLOpen', 'ParamEyeROpen']) {
      core.setParameterValueById(id, core.getParameterValueById(id) * k);
    }
  }

  updateMouth();

  // 眼睛高光永远开着
  core.setParameterValueById('ParamEyeHlOn', 1);
  // 脸上的阴影只给明确选了阴影表情的时候用，其他时候一律去掉（避免突然变阴沉）
  if (!SHADOW_FACES.has(faceName)) core.setParameterValueById('ParamFaceShadow', 0);

  // 桌面定位固定，不把场景内平移或整个人物起伏带到桌面。
  core.setParameterValueById('ParamPositionX', 0);
  core.setParameterValueById('ParamPositionY', 0);
  core.setParameterValueById('ParamBreath', 0);
}

/* ---------- 动作控制 ---------- */
let reacting = false;
let faceTimer = null;
let dozing = false;

let bodyRequestSeq = 0, faceRequestSeq = 0;

async function playBody(name, { loop = false, fade = 0.45, onEnd, endPose = false } = {}) {
  const request = ++bodyRequestSeq, layer = bodyLayer;
  const mo = await getMotion(name).catch(() => null);
  if (request !== bodyRequestSeq || layer !== bodyLayer) return 0;
  if (!mo) { onEnd && onEnd(); return 0; }
  bodyName = name;
  bodyLayer.play(mo, { loop, fade, onEnd: () => {
    if (request === bodyRequestSeq && layer === bodyLayer && onEnd) onEnd();
  } });
  // 换装时直接恢复睡姿，避免重新播放入睡过程。
  if (endPose) bodyLayer.time = mo.duration;
  return mo.duration;
}

let faceStrength = 1, faceStrengthTarget = 1, calmBase = null;
// 心情余韵：强一点的心情过后，待机时脸上还留一点点（随时间回落）
let lingering = null;
function idleFace(fade = 0.6) {
  const mood = lingering && MOODS[lingering.mood];
  if (mood && mood.faces && mood.faces.length && lingering.level >= 0.15) {
    const [f, fs] = mood.faces[0];
    return playFace(f, { fade, strength: Math.max(0.08, Math.min(fs, fs * lingering.level * 1.2)) });
  }
  return playFace(IDLE.f, { fade });
}
async function playFace(name, { fade = 0.3, strength = 1 } = {}) {
  if (!name || !FACES[name]) name = IDLE.f;   // 不认识的代号一律用平静
  const request = ++faceRequestSeq, layer = faceLayer;
  const mo = await getMotion(name).catch(() => null);
  if (request !== faceRequestSeq || layer !== faceLayer || !mo) return;
  faceName = name;
  faceStrengthTarget = Math.max(0, Math.min(1, strength));
  faceLayer.play(mo, { loop: true, fade });
}

async function setIdle(first = false) {
  reacting = false;
  await playBody(IDLE.b, { loop: true, fade: first ? 0 : 0.6 });
  if (first) await playFace(IDLE.f, { fade: 0 });
}

// 把 {m: 心情, a: 动作} 换成具体的表情和身体动作
// 私下几乎面无表情：表情按强度淡淡地叠在「平静」上，心情主要靠动作表现
function resolve(entry) {
  const mood = MOODS[entry.m] || null;
  let f = null, fs = 1;
  if (entry.f) {                                   // 直接点名了表情（AI 或台词）
    f = entry.f;
    fs = entry.fs ?? (FACE_STRENGTH_FULL.has(f) ? 1 : FACE_STRENGTH_DEFAULT);
  } else if (mood) {
    const pool = mood.rare && Math.random() < mood.rare.chance ? mood.rare.faces : mood.faces;
    [f, fs] = pick(pool);
  }
  // intensity（0~1）：AI 给的这份心情有多强，用来调表情强度
  if (typeof entry.intensity === 'number' && fs < 1) fs = Math.max(0.1, Math.min(1, fs * (0.5 + entry.intensity)));
  // 动作：没指定（或 AI 给了 none）时，按心情挑一个常用动作
  let a = entry.a;
  if ((!a || a === 'none' && entry.autoAction) && mood && mood.actions) a = pick(mood.actions);
  const act = ACTIONS[a] || null;
  const b = entry.b || (act && act.bodies.length ? pick(act.bodies) : null);
  return { f, fs, b };
}

// 播放一句台词 + 动作 + 表情
async function react(entry, opts = {}) {
  if (!entry) return;
  if (swapping) await swapping.catch(() => {});
  const reaction = react.requestSeq = (react.requestSeq || 0) + 1;
  entry = Object.assign({}, entry, resolve(entry));
  wakeIfDozing(false);
  reacting = true;
  const text = opts.raw ? entry.t : fill(entry.t);
  const speakTime = opts.hold || Math.max(2800, 900 + text.length * 170);
  // 日语（配音用）：AI 回复直接带着；固定台词写在 lines.js 的 ja 里
  const ja = opts.raw ? (opts.ja || '') : fillJa(entry.ja || '');
  const seq = opts.silent ? speechSeq : ++speechSeq;
  if (!opts.silent) {
    stopVoice();
    const showText = (instant = false) => {
      if (seq === speechSeq) say(text, speakTime, opts.tag, settings.showJa && settings.hasVoice ? ja : '', { instant, spokenJa: ja, source: opts.raw ? 'generated' : opts.kind === 'idle' ? 'idle' : 'fixed' });
    };
    const fixedVoice = !opts.raw && ja && api && settings.hasVoice && settings.voiceFixed && !settings.muted;
    if (!settings.muted && (opts.audio || fixedVoice)) {
      hideBubble();
      // 合成和解码期间不抢先出字幕；失败则回到可阅读的纯文字。
      const audio = opts.audio ? Promise.resolve({ audio: opts.audio, words: opts.words })
        : Promise.resolve().then(() => api.speak({ ja, mood: entry.m }));
      audio.then(async (v) => {
        if (seq !== speechSeq) return;
        if (settings.muted || !v || !v.audio || !await playVoice(v.audio, seq, v.words, () => showText(true))) showText();
      }).catch(() => showText());
    } else showText();
  }

  if (entry.f) playFace(entry.f, { strength: entry.fs ?? 1 });
  cancel(faceTimer);

  // a = none 时身体保持原来的站姿，只换表情
  const dur = entry.b ? await playBody(entry.b, {
    loop: !!opts.loopBody,
    onEnd: () => { if (!opts.loopBody) setIdle(); },
  }) : (later(() => { reacting = false; }, speakTime), 0);
  if (reaction !== react.requestSeq) return;
  // 表情维持到说完话或动作结束，再回到平常的样子
  const keep = Math.max(dur * 1000, speakTime, (voiceEndAt - clock) * 1000 + 500) + 300;
  faceTimer = later(() => { if (!dozing) idleFace(0.6); }, keep);
}

/* ---------- 声音：播放 MiniMax 合成的语音，并按音量对口型 ---------- */
let audioCtx = null, voiceSrc = null, analyser = null, voicePlaying = false, speechSeq = 0;
let mouth = 0, voiceEndAt = 0, mouthHold = null;   // mouthHold：调试用，固定嘴巴张开程度
const ampBuf = new Float32Array(1024);

let voiceTicket = null, voiceTicketSeq = 0;
function releaseVoiceTurn(ticket = voiceTicket) {
  if (ticket == null) return;
  if (settings.teamMode && api && api.endSpeech) api.endSpeech(ticket);
  if (voiceTicket === ticket) voiceTicket = null;
}
async function takeVoiceTurn(current) {
  if (!settings.teamMode || !api || !api.startSpeech) return '';
  const ticket = 'voice-' + (++voiceTicketSeq);
  voiceTicket = ticket;
  try {
    const granted = await api.startSpeech(ticket);
    if (!granted || !current()) { releaseVoiceTurn(ticket); return null; }
    return ticket;
  } catch (e) { releaseVoiceTurn(ticket); return null; }
}

function stopVoice() {
  releaseVoiceTurn();
  if (typeof cancelKaraoke === 'function') cancelKaraoke();
  if (voiceSrc) { try { voiceSrc.onended = null; voiceSrc.stop(); } catch (e) {} }
  if (voiceSrc) extendBubble(1200);
  voiceSrc = null; analyser = null; voicePlaying = false;
}

async function playVoice(b64, seq, words, onStart) {
  let ticket = null;
  try {
    if (!audioCtx) audioCtx = new AudioContext();
    if (audioCtx.state === 'suspended') await audioCtx.resume();
    const bin = atob(b64);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    const buf = await audioCtx.decodeAudioData(bytes.buffer);
    if (seq !== speechSeq || settings.muted) return false;            // 等解码的时候他已经开始说别的了
    stopVoice();
    ticket = await takeVoiceTurn(() => seq === speechSeq && !settings.muted);
    if (ticket === null) return false;
    const src = audioCtx.createBufferSource();
    src.buffer = buf;
    const gain = audioCtx.createGain();
    gain.gain.value = settings.volume ?? 0.9;
    const an = audioCtx.createAnalyser();
    an.fftSize = 1024;
    src.connect(gain); gain.connect(an); an.connect(audioCtx.destination);
    src.onended = () => { releaseVoiceTurn(ticket); if (voiceSrc === src) { voiceSrc = null; analyser = null; voicePlaying = false; extendBubble(1200); } };
    voiceSrc = src; analyser = an; voicePlaying = true;
    const startAt = audioCtx.currentTime;
    src.start();
    if (onStart) onStart();
    karaoke(words, src, startAt, buf.duration);
    // 气泡和表情至少保持到说完
    const ms = buf.duration * 1000;
    voiceEndAt = clock + buf.duration;
    clearTimeout(bubbleTimer); // 由实际播放结束事件收起，避免暂停或调度延迟时提前消失
    reacting = true;
    cancel(faceTimer);
    faceTimer = later(() => { if (!dozing) idleFace(0.6); reacting = false; }, ms + 500);
    return true;
  } catch (e) {
    releaseVoiceTurn(ticket);
    console.warn('voice play failed', e);
    return false;
  }
}

// 每帧根据声音大小算嘴巴张开程度
function updateMouth() {
  let target = 0;
  if (mouthHold !== null) target = mouthHold;
  else if (analyser) {
    analyser.getFloatTimeDomainData(ampBuf);
    let sum = 0;
    for (let i = 0; i < ampBuf.length; i++) sum += ampBuf[i] * ampBuf[i];
    const rms = Math.sqrt(sum / ampBuf.length);
    target = Math.max(0, Math.min(1, (rms - 0.015) * 7));
  }
  mouth += (target - mouth) * (target > mouth ? 0.55 : 0.3);   // 张嘴快、合嘴稍慢
  if (mouth > 0.01) core.setParameterValueById('ParamMouthOpenY', mouth);
}

/* ---------- 气泡 ---------- */
const bubble = document.getElementById('bubble');
let bubbleTimer = null, typeTimer = null;
function hideBubble() {
  clearTimeout(bubbleTimer); clearInterval(typeTimer);
  bubble.classList.remove('show');
  // 等淡出结束再把窗口缩回去
  setTimeout(() => { if (!bubble.classList.contains('show') && api) api.bubbleSpace(0); }, 300);
}
// 气泡比顶部预留的空间高时，让窗口往上长出差的那一截
function fitBubble() {
  placeBubble();
  if (!api) return;
  // 气泡底边贴在头顶上方；只有特别长、头顶上放不下时，窗口才往上长（很少发生）
  const top = window.__layout ? window.__layout.headTop - 4 : BUBBLE_SPACE - 10;
  const need = Math.max(0, bubble.offsetHeight + 8 - top);   // 上边距 8
  if (need > 0) expectGrow = true;
  api.bubbleSpace(need);
}
// 贴着头顶放置；屏幕顶边空间不足时，字幕留在窗口内。
function placeBubble() {
  const pos = window.__layout;
  if (!pos) return;
  bubble.style.maxHeight = 'calc(100vh - 16px)';
  bubble.style.overflowY = bubble.offsetHeight >= pos.H - 17 ? 'auto' : 'visible';
  bubble.style.top = 'auto';
  bubble.style.bottom = Math.max(8, Math.min(Math.round(pos.H - pos.headTop + 4), pos.H - bubble.offsetHeight - 8)) + 'px';
}
function extendBubble(ms) {
  clearTimeout(bubbleTimer);
  bubbleTimer = setTimeout(hideBubble, ms);
}
const spokenSessionId = Date.now().toString(36) + '-' + Math.random().toString(36).slice(2);
let spokenSequence = 0;
function recordPetSpeech(text, ja, source, tag) {
  if (!api || !api.recordSpeech || !String(text || '').trim()) return;
  try { api.recordSpeech({ id: spokenSessionId + ':' + (++spokenSequence), text: String(text), ja: String(ja || ''), source, tag: tag || '' }); } catch (e) {}
}

function say(text, ms = 3000, tag, ja = '', { instant = false, spokenJa = '', source = 'direct', record = true } = {}) {
  lastSpokeAt = Date.now();
  clearTimeout(bubbleTimer); clearInterval(typeTimer);
  bubble.classList.toggle('notice', !!tag);
  bubble.innerHTML = '';
  if (tag) {
    const t = document.createElement('span');
    t.className = 'tag'; t.textContent = tag;
    bubble.appendChild(t);
  }
  // 先放好整句（未打出的字透明），气泡大小从一开始就固定，不会边打字边变宽
  const shown = document.createElement('span');
  shown.className = 'zh';
  const rest = document.createElement('span');
  rest.style.color = 'transparent';
  bubble.appendChild(shown); bubble.appendChild(rest);
  if (ja) {
    const j = document.createElement('span');
    j.className = 'ja'; j.textContent = ja; j.lang = 'ja';
    bubble.appendChild(j);
  }
  const chars = Array.from(text);
  rest.textContent = text;
  // 先按正常字号量一下高度，太高（超过窗口 40%）就换小一号字
  bubble.classList.remove('long');
  if (bubble.offsetHeight > 160) bubble.classList.add('long');
  fitBubble();
  bubble.scrollTop = 0;
  bubble.classList.add('show');
  if (record) recordPetSpeech(text, spokenJa || ja, source, tag);
  if (instant) {
    shown.textContent = chars.join('');
    rest.textContent = '';
    bubbleTimer = setTimeout(hideBubble, ms);
    return;
  }
  let i = 0;
  typeTimer = setInterval(() => {
    i++;
    shown.textContent = chars.slice(0, i).join('');
    rest.textContent = chars.slice(i).join('');
    if (i >= chars.length) clearInterval(typeTimer);
  }, 55);
  bubbleTimer = setTimeout(hideBubble, ms + chars.length * 55);
}

/* ---------- 问候、闲置、犯困 ---------- */
function greet() {
  const h = new Date().getHours();
  const key = h >= 5 && h < 11 ? 'morning' : h < 17 ? 'day' : h < 23 ? 'evening' : 'night';
  react(pick(LINES.greet[key]));
}

let idleMoveTimer = null;
/* ---------- 看屏幕：单任务、可取消、异步编码；截图结束立即关闭采集 ---------- */
let activeFrameGrab = null;

function frameAbortError(signal) {
  return signal.reason instanceof Error ? signal.reason : new Error('截图已取消');
}
function abortableFrame(promise, signal) {
  return new Promise((resolve, reject) => {
    const aborted = () => { signal.removeEventListener('abort', aborted); reject(frameAbortError(signal)); };
    Promise.resolve(promise).then(
      (value) => { signal.removeEventListener('abort', aborted); signal.aborted ? reject(frameAbortError(signal)) : resolve(value); },
      (error) => { signal.removeEventListener('abort', aborted); reject(error); }
    );
    if (signal.aborted) aborted();
    else signal.addEventListener('abort', aborted, { once: true });
  });
}
function stopFrameStream(stream) {
  if (stream) for (const track of stream.getTracks()) { try { track.stop(); } catch (e) {} }
}
function cancelGrabFrame({ id } = {}) {
  if (activeFrameGrab && activeFrameGrab.id === id) activeFrameGrab.ctrl.abort(new Error('截图已取消'));
}
window.addEventListener('pagehide', () => { if (activeFrameGrab) activeFrameGrab.ctrl.abort(new Error('页面已关闭')); });

function waitForScreenFrame(video, signal) {
  return new Promise((resolve, reject) => {
    let callbackId = null, timer = null, settled = false;
    const cleanup = () => {
      clearTimeout(timer);
      if (callbackId !== null && video.cancelVideoFrameCallback) video.cancelVideoFrameCallback(callbackId);
      video.removeEventListener('loadeddata', ready);
      video.removeEventListener('error', failed);
      signal.removeEventListener('abort', aborted);
    };
    const done = (error) => {
      if (settled) return;
      settled = true; cleanup(); error ? reject(error) : resolve();
    };
    const aborted = () => done(frameAbortError(signal));
    const failed = () => done(new Error('无法读取屏幕视频帧'));
    const ready = () => {
      if (settled) return;
      clearTimeout(timer);
      if (video.videoWidth > 0 && video.videoHeight > 0 && video.readyState >= 2) done();
      else timer = setTimeout(ready, 40);
    };
    if (signal.aborted) return aborted();
    signal.addEventListener('abort', aborted, { once: true });
    video.addEventListener('error', failed, { once: true });
    if (video.requestVideoFrameCallback) callbackId = video.requestVideoFrameCallback(() => done());
    else { video.addEventListener('loadeddata', ready, { once: true }); ready(); }
  });
}

function encodeScreenFrame(canvas, signal) {
  return new Promise((resolve, reject) => {
    let reader = null;
    const cleanup = () => {
      signal.removeEventListener('abort', aborted);
      if (reader) { reader.onload = reader.onerror = reader.onabort = null; }
    };
    const fail = (error) => { cleanup(); reject(error); };
    const aborted = () => {
      const current = reader;
      fail(frameAbortError(signal));
      if (current && current.readyState === 1) current.abort();
    };
    if (signal.aborted) return aborted();
    signal.addEventListener('abort', aborted, { once: true });
    try {
      canvas.toBlob((blob) => {
        if (signal.aborted) return;
        if (!blob) return fail(new Error('截图编码失败'));
        try {
          reader = new FileReader();
          reader.onload = () => {
            const value = String(reader.result || '');
            const comma = value.indexOf(',');
            if (comma < 0 || !value.slice(comma + 1)) return fail(new Error('截图编码结果为空'));
            cleanup(); resolve(value.slice(comma + 1));
          };
          reader.onerror = () => fail(new Error('读取截图数据失败'));
          reader.onabort = () => fail(new Error('读取截图已取消'));
          reader.readAsDataURL(blob);
        } catch (e) { fail(e); }
      }, 'image/jpeg', 0.8);
    } catch (e) { fail(e); }
  });
}

async function grabFrame({ id, sourceId, captureSize, crop, maxSide = 1280, timeoutMs = 6000 }) {
  if (activeFrameGrab) { api.grabFrameResult({ id, error: '截图正在进行，请稍后再试' }); return; }
  const job = { id, ctrl: new AbortController() };
  activeFrameGrab = job;
  const signal = job.ctrl.signal;
  const started = performance.now(), timings = {};
  let stream = null, video = null, canvas = null;
  const timer = setTimeout(() => job.ctrl.abort(new Error('取画面超时，已停止采集')), Math.max(100, Math.min(6000, timeoutMs)));
  try {
    const acquisition = navigator.mediaDevices.getUserMedia({ audio: false, video: { mandatory: {
      chromeMediaSource: 'desktop', chromeMediaSourceId: sourceId,
      maxWidth: captureSize.width, maxHeight: captureSize.height,
      minWidth: Math.min(640, captureSize.width), maxFrameRate: 5,
    } } });
    // getUserMedia 本身不能中止；取消后才返回的流也必须马上关闭。
    acquisition.then((lateStream) => { if (signal.aborted) stopFrameStream(lateStream); }, () => {});
    stream = await abortableFrame(acquisition, signal);
    timings.acquireMs = Math.round(performance.now() - started);
    video = document.createElement('video');
    video.muted = true; video.playsInline = true; video.srcObject = stream;
    const firstFrameAt = performance.now();
    await Promise.all([waitForScreenFrame(video, signal), abortableFrame(video.play(), signal)]);
    timings.firstFrameMs = Math.round(performance.now() - firstFrameAt);
    if (signal.aborted) throw frameAbortError(signal);
    const drawAt = performance.now(), W = video.videoWidth, H = video.videoHeight;
    if (!W || !H) throw new Error('屏幕画面尺寸为空');
    const c = crop || { x: 0, y: 0, w: 1, h: 1 };
    const sx = Math.max(0, Math.min(W - 1, Math.round(c.x * W)));
    const sy = Math.max(0, Math.min(H - 1, Math.round(c.y * H)));
    const sw = Math.max(1, Math.min(W - sx, Math.round(c.w * W)));
    const sh = Math.max(1, Math.min(H - sy, Math.round(c.h * H)));
    const scale = Math.min(1, maxSide / Math.max(sw, sh));
    canvas = document.createElement('canvas');
    canvas.width = Math.max(1, Math.round(sw * scale)); canvas.height = Math.max(1, Math.round(sh * scale));
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('无法创建截图画布');
    ctx.drawImage(video, sx, sy, sw, sh, 0, 0, canvas.width, canvas.height);
    timings.drawMs = Math.round(performance.now() - drawAt);
    timings.width = canvas.width; timings.height = canvas.height;
    // 已取到帧，编码前释放视频，避免等待编码时还在采集屏幕。
    video.pause(); video.srcObject = null; stopFrameStream(stream); stream = null;
    const encodeAt = performance.now();
    const b64 = await encodeScreenFrame(canvas, signal);
    timings.encodeMs = Math.round(performance.now() - encodeAt);
    timings.totalMs = Math.round(performance.now() - started);
    if (signal.aborted) throw frameAbortError(signal);
    api.grabFrameResult({ id, b64, timings });
  } catch (e) {
    job.ctrl.abort(e);
    api.grabFrameResult({ id, error: String(e && e.message || e) });
  } finally {
    clearTimeout(timer);
    stopFrameStream(stream);
    if (video) { video.pause(); video.srcObject = null; }
    if (canvas) { canvas.width = 0; canvas.height = 0; }
    if (activeFrameGrab === job) activeFrameGrab = null;
  }
}


/* ---------- 待机时的自言自语 ----------
   多久说一次看设置（关闭 / 很少 / 偶尔 / 常常）；刚说过话、你在聊天或通话、他在睡觉时不说。
   按时段和衣服挑台词，最近说过的不再说（记在本机，重启后也记得） */
const IDLE_TALK = { off: null, rare: [20, 40], normal: [8, 16], often: [4, 8] };   // 分钟
let idleTalkTimer = null, lastSpokeAt = 0;
function scheduleIdleTalk(delayMs) {
  clearTimeout(idleTalkTimer);
  const r = IDLE_TALK[settings.idleTalk || 'normal'];
  if (!r) return;
  idleTalkTimer = setTimeout(tryIdleTalk, delayMs ?? rand(r[0], r[1]) * 60000);
}
function tryIdleTalk() {
  const busy = reacting || dozing || dragging || voicePlaying || voiceTicket !== null || chatOpen || chatBusy || (window.Call && Call.active) || swapping;
  if (busy || Date.now() - lastSpokeAt < 3 * 60000) { scheduleIdleTalk(60000); return; }   // 一分钟后再看
  const line = nextIdleLine();
  if (line) react(line, { kind: 'idle', hold: Math.max(4500, 1400 + line.t.length * 220) });   // 留够时间看完
  scheduleIdleTalk();
}
function idleSlot() {
  const h = new Date().getHours();
  return h >= 5 && h < 11 ? 'morning' : h >= 11 && h < 17 ? 'day' : h >= 17 && h < 23 ? 'evening' : 'night';
}
function nextIdleLine() {
  const KEY = 'toya.idleRecent';
  let recent = [];
  try { recent = JSON.parse(localStorage.getItem(KEY) || '[]'); } catch (e) {}
  const slot = idleSlot();
  const pool = LINES.idle.filter((l) => (!l.when || l.when === slot) && (!l.outfit || l.outfit === outfit));
  if (!pool.length) return null;
  // 最近说过的（大约池子的 2/3）先不说
  const keep = Math.max(1, Math.floor(pool.length * 2 / 3));
  let fresh = pool.filter((l) => !recent.includes(l.t));
  if (!fresh.length) { recent = []; fresh = pool; }
  // 合时段的台词稍微优先
  const timed = fresh.filter((l) => l.when);
  const line = timed.length && Math.random() < 0.4 ? timed[Math.floor(Math.random() * timed.length)] : fresh[Math.floor(Math.random() * fresh.length)];
  recent = [line.t, ...recent.filter((t) => t !== line.t)].slice(0, keep);
  try { localStorage.setItem(KEY, JSON.stringify(recent)); } catch (e) {}
  return line;
}

function scheduleIdleMove() {
  clearTimeout(idleMoveTimer);
  idleMoveTimer = setTimeout(() => {
    if (!reacting && !dozing && !dragging && !voicePlaying && voiceTicket === null && !(window.Call && Call.active)) {
      // 这里只做小动作；自言自语单独排（见 scheduleIdleTalk），不再跟着小动作一起频繁冒出来
      reacting = true;
      playBody(pick(IDLE_MOVES), { onEnd: () => setIdle() });
    }
    scheduleIdleMove();
  }, rand(14000, 28000));
}

let lastActive = Date.now();
const DOZE_AFTER = 6 * 60 * 1000;   // 6 分钟没动鼠标就开始打瞌睡
setInterval(() => {
  if (!MANUAL && !dozing && !reacting && !(window.Call && Call.active) && Date.now() - lastActive > DOZE_AFTER) startDoze();
}, 5000);

function startDoze() {
  if (dozing) return;
  stopVoice();
  dozing = true;
  reacting = true;
  const e = Object.assign({}, LINES.doze[0], resolve(LINES.doze[0]));
  say(fill(e.t), 3000, undefined, '', { spokenJa: fillJa(e.ja || ''), source: 'doze' });
  playFace(e.f, { fade: 0.8 });
  // 入睡动作只播一次，动作层随后保持最后一帧，直到被唤醒。
  playBody(e.b, { loop: false, fade: 0.8 });
}

function wakeIfDozing(withLine = true) {
  if (!dozing) return;
  dozing = false;
  if (withLine) react(pick(LINES.wake));
}

/* ---------- 提醒 ---------- */
let pendingRemind = null;
function remind(type) {
  if (window.Call && Call.active) { pendingRemind = type; return; }   // 通话结束后再提醒
  if (type && typeof type === 'object') {         // 聊天里让他设的提醒
    react({ t: type.t, m: 'soft', a: 'nod' }, { raw: true, ja: type.ja, audio: type.audio, tag: '提醒', hold: 12000 });
    return;
  }
  const tag = { water: '喝水提醒', rest: '休息提醒', sleep: '该睡觉了' }[type];
  if (!LINES[type]) return;
  dozing = false;
  react(pick(LINES[type]), { tag, hold: 12000 });
}

/* ---------- 鼠标：命中判断、点击、拖动 ---------- */
let dragging = false;
let ignoring = null;
const px = new Uint8Array(4);

function inRect(el, x, y, pad = 0) {
  const r = el.getBoundingClientRect();
  return r.width > 0 && x >= r.left - pad && x <= r.right + pad && y >= r.top - pad && y <= r.bottom + pad;
}
function hitTest(x, y) {
  if (!app) return false;
  if (bubble.classList.contains('show') && inRect(bubble, x, y)) return true;
  if (window.PetPluginHost && PetPluginHost.hit(x, y)) return true;   // 插件放的可点元素
  if (chatBox.classList.contains('show') && inRect(chatBox, x, y, 4)) return true;
  if (chatBtn.classList.contains('show') && inRect(chatBtn, x, y, 4)) return true;
  const cp = document.getElementById('call'), cb = document.getElementById('callBtn');
  if (cp && cp.classList.contains('show') && inRect(cp, x, y, 4)) return true;
  if (cb && cb.classList.contains('show') && inRect(cb, x, y, 4)) return true;
  const gl = app.renderer.gl;
  if (!gl || gl.isContextLost()) return false;
  const res = app.renderer.resolution;
  const gx = Math.floor(x * res), gy = Math.floor(gl.drawingBufferHeight - y * res);
  if (gx < 0 || gy < 0 || gx >= gl.drawingBufferWidth || gy >= gl.drawingBufferHeight) return false;
  gl.readPixels(gx, gy, 1, 1, gl.RGBA, gl.UNSIGNED_BYTE, px);
  return px[3] > 24;
}

function setIgnore(v) {
  if (!api || ignoring === v) return;
  ignoring = v;
  api.setIgnoreMouse(v);
}

function isHead(y) {
  return toModel(0, y).y < HEAD.bottom;
}

const clicks = [];
const anger = { level: 0, at: 0 };
function setupPointer() {
  let down = null;
  setIgnore(true);

  window.addEventListener('mousemove', (e) => {
    lastActive = Date.now();
    if (down) {
      if (!dragging && Math.hypot(e.screenX - down.sx, e.screenY - down.sy) > 4) {
        dragging = true;
        api && api.dragStart(down.sx, down.sy);
      }
      if (dragging && api) api.dragMove();
      return;
    }
    const hit = hitTest(e.clientX, e.clientY);
    setIgnore(!hit);
    if (hit) showChatBtn();
  });

  window.addEventListener('mousedown', (e) => {
    if (e.button !== 0) return;
    if (e.target.closest && e.target.closest('#chat, #chatBtn, #call, #callBtn, .plugin-ui')) return;
    if (!hitTest(e.clientX, e.clientY)) return;
    down = { sx: e.screenX, sy: e.screenY, x: e.clientX, y: e.clientY };
  });

  window.addEventListener('mouseup', (e) => {
    if (e.button !== 0 || !down) return;
    const d = down; down = null;
    if (dragging) {
      dragging = false;
      api && api.dragEnd();
      if (Math.random() < 0.35) react(pick(LINES.drop));
      return;
    }
    onClick(d.x, d.y);
  });

  window.addEventListener('contextmenu', (e) => {
    e.preventDefault();
    if (hitTest(e.clientX, e.clientY) && api) api.showMenu();
  });

  // 切换全屏/焦点时可能收不到 mouseup，释放悬空的按下和拖动状态。
  const cancelPointer = () => {
    if (!down && !dragging) return;
    down = null;
    if (dragging) { dragging = false; api && api.dragEnd(); }
    if (!chatOpen) setIgnore(true);
  };
  window.addEventListener('blur', cancelPointer);
  window.addEventListener('pointercancel', cancelPointer);
  window.addEventListener('mouseleave', () => { if (!dragging && !chatOpen) setIgnore(true); });
}

function onClick(x, y) {
  lastActive = Date.now();
  if (window.Call && Call.active) return;   // 通话中点他不插话
  if (dozing) { wakeIfDozing(true); return; }
  const now = Date.now();
  clicks.push(now);
  while (clicks.length && now - clicks[0] > 4000) clicks.shift();
  if (clicks.length >= 5) {
    clicks.length = 0;
    // 越点越生气；1 分钟没惹他就消气
    if (now - anger.at > 60000) anger.level = 0;
    anger.level++; anger.at = now;
    if (anger.level === 1) react(pick(LINES.poke));
    else react(pick(LINES.pokeAngry));
    return;
  }
  // 刚生过气，摸头也还是有点别扭
  if (anger.level >= 2 && now - anger.at < 20000) { react(pick(LINES.stillSulky)); return; }
  react(isHead(y) ? pick(LINES.head) : pick(LINES.body));
}

/* ---------- 视线跟随鼠标 ---------- */
function setupGaze() {
  const look = (cx, cy) => {
    // cx, cy：鼠标相对窗口左上角的位置（可能在窗口外）
    const s = window.__layout.s;
    const headX = model.x + HEAD.x * s;
    const headY = model.y + HEAD.y * s;
    let nx = (cx - headX) / (window.innerWidth * 1.6);
    let ny = -(cy - headY) / (window.innerHeight * 1.4);
    nx = Math.max(-1, Math.min(1, nx)) * 0.55;
    ny = Math.max(-1, Math.min(1, ny)) * 0.45;
    if (dozing) { nx = 0; ny = 0; }
    model.internalModel.focusController.focus(nx, ny);   // 换衣服后模型会变，所以每次现取
  };
  if (api) {
    let lx = null, ly = null;
    api.onCursor(({ x, y }) => {
      if (lx !== null && (Math.abs(x - lx) > 2 || Math.abs(y - ly) > 2)) {
        lastActive = Date.now();
        if (dozing && Math.hypot(x - lx, y - ly) > 30) wakeIfDozing(true);
      }
      lx = x; ly = y;
      look(x, y);
    });
  } else {
    window.addEventListener('mousemove', (e) => look(e.clientX, e.clientY));
  }
}

/* ---------- 聊天（接 AI） ---------- */
const chatBox = document.getElementById('chat');
const chatInput = document.getElementById('chatInput');
const chatBtn = document.getElementById('chatBtn');
let voiceErrShown = false;
let chatOpen = false, chatBusy = false, chatBtnTimer = null, chatIdleTimer = null;

// 发给 AI 的心情、动作、表情列表（代号 → 说明）
function chatLists() {
  const moods = {}, actions = {}, faces = {};
  for (const k in MOODS) moods[k] = MOODS[k].desc;
  for (const k in ACTIONS) actions[k] = ACTIONS[k].desc;
  for (const k in FACES) faces[k] = FACES[k][1];
  return { moods, actions, faces };
}

// 他主动开口：你在忙（聊天、通话、拖动）或他在睡觉时就算了
let proactiveAt = 0;
async function proactive({ reason, kind, id, line, looked }) {
  const done = (status) => api && api.proactiveDone && api.proactiveDone({ id, status });
  if (!api || chatBusy || chatOpen || reacting || dozing || dragging || (window.Call && Call.active)) return done('busy');
  if (line) { react(pick(LINES[line])); proactiveAt = Date.now(); return done('done'); }   // 没接聊天模型：固定台词
  chatBusy = true;
  let r;
  try { r = await api.chat({ text: reason, proactive: true, ...chatLists() }); } catch (e) { r = null; }
  chatBusy = false;
  if (!r || (r.error && r.error !== '回复是空的')) return done('failed');
  if (!r.reply) return done('done');                                   // 他决定这次不说
  if (chatOpen || dragging || (window.Call && Call.active)) return done('busy');   // 你已经开始做别的了
  react({ t: r.reply, m: MOODS[r.mood] ? r.mood : 'calm', a: ACTIONS[r.action] ? r.action : 'none',
          f: FACES[r.face] ? r.face : undefined, autoAction: true, intensity: r.intensity ?? undefined }, { raw: true, ja: r.ja, audio: r.audio, words: r.words, tag: looked ? '看了一眼屏幕' : undefined });
  proactiveAt = Date.now();
  showChatBtn(20000);     // 想回他：点气泡或者聊天按钮
  done('done');
}
bubble.addEventListener('click', () => { if (Date.now() - proactiveAt < 60000 && !chatOpen) openChat(); });

function showChatBtn(ms = 2500) {
  if (chatOpen || (window.Call && Call.active)) return;
  const cb = document.getElementById('callBtn');
  chatBtn.classList.add('show'); cb && cb.classList.add('show');
  clearTimeout(chatBtnTimer);
  chatBtnTimer = setTimeout(() => { chatBtn.classList.remove('show'); cb && cb.classList.remove('show'); }, ms);
}

function openChat() {
  chatOpen = true;
  chatBtn.classList.remove('show');
  chatBox.classList.add('show');
  setIgnore(false);
  api && api.focus();
  setTimeout(() => chatInput.focus(), 50);
  armChatIdle();
}

function closeChat() {
  chatOpen = false;
  chatBox.classList.remove('show');
  chatInput.blur();
  clearTimeout(chatIdleTimer);
  setIgnore(true);
}

// 一分半钟没打字就自动收起来
function armChatIdle() {
  clearTimeout(chatIdleTimer);
  chatIdleTimer = setTimeout(() => { if (!chatBusy && !chatInput.value) closeChat(); }, 90000);
}

/* 发图片：选文件、Ctrl+V 粘贴、拖进来。先缩小到最长边 1280 再发 */
let pendingImg = null;
const chatImgEl = document.getElementById('chatImg');
function setPendingImg(v) {
  pendingImg = v;
  chatImgEl.classList.toggle('show', !!v);
  chatImgEl.querySelector('img').src = v ? `data:${v.mime};base64,${v.b64}` : '';
  chatInput.placeholder = v ? '说点什么，或直接发' : '和他说点什么…';
}
async function takeImage(file) {
  if (!file || !/^image\//.test(file.type)) return;
  try {
    const bmp = await createImageBitmap(file);
    const k = Math.min(1, 1280 / Math.max(bmp.width, bmp.height));
    const c = document.createElement('canvas');
    c.width = Math.round(bmp.width * k); c.height = Math.round(bmp.height * k);
    const g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); g.drawImage(bmp, 0, 0, c.width, c.height);
    const url = c.toDataURL('image/jpeg', 0.85);
    setPendingImg({ mime: 'image/jpeg', b64: url.split(',')[1] });
    if (!chatOpen) openChat();
    chatInput.focus();
  } catch (e) { say('（这张图片打不开）', 3000); }
}
chatImgEl.addEventListener('click', () => setPendingImg(null));
document.getElementById('chatPic').addEventListener('click', () => document.getElementById('chatFile').click());
document.getElementById('chatFile').addEventListener('change', (e) => { takeImage(e.target.files[0]); e.target.value = ''; });
chatInput.addEventListener('paste', (e) => {
  const it = [...(e.clipboardData && e.clipboardData.items || [])].find((x) => x.type.startsWith('image/'));
  if (it) { e.preventDefault(); takeImage(it.getAsFile()); }
});
// 拖进窗口：拖到他身上或聊天框上都行
window.addEventListener('dragenter', (e) => { if ([...(e.dataTransfer && e.dataTransfer.types || [])].includes('Files')) { setIgnore(false); chatBox.classList.add('drag'); } });
window.addEventListener('dragover', (e) => { e.preventDefault(); });
window.addEventListener('dragleave', (e) => { if (!e.relatedTarget) chatBox.classList.remove('drag'); });
window.addEventListener('drop', (e) => {
  e.preventDefault(); chatBox.classList.remove('drag');
  const f = [...(e.dataTransfer && e.dataTransfer.files || [])].find((x) => x.type.startsWith('image/'));
  if (f) takeImage(f);
});

async function sendChat() {
  const callEpoch = window.Call ? Call.callId : null;
  const staleChat = () => window.Call && (Call.active || Call.callId !== callEpoch);
  if (staleChat()) return;
  const text = chatInput.value.trim();
  if ((!text && !pendingImg) || chatBusy) return;
  chatInput.value = '';
  armChatIdle();
  lastActive = Date.now();
  wakeIfDozing(false);

  if (!api) { react(pick(LINES.noApi)); return; }
  chatBusy = true;
  chatBox.classList.add('busy');
  // 等回复时：安静地听着
  reacting = true;
  say('……', 60000, undefined, '', { record: false });
  { const [f, fs] = pick(MOODS.think.faces); playFace(f, { strength: fs }); }

  const img = pendingImg; setPendingImg(null);
  if (img) say('……（在看）', 60000, undefined, '', { record: false });
  let r;
  try { r = img ? await api.chatImage({ text, b64: img.b64, mime: img.mime, ...chatLists() }) : await api.chat({ text, ...chatLists() }); } catch (e) { r = { error: String(e) }; }
  chatBusy = false;
  chatBox.classList.remove('busy');
  if (staleChat()) return;

  if (r && r.reply) {
    // AI 点名了有效的表情代号就直接用，否则按心情挑
    react({ t: r.reply, m: MOODS[r.mood] ? r.mood : 'calm', a: ACTIONS[r.action] ? r.action : 'none',
            f: FACES[r.face] ? r.face : undefined, autoAction: true, intensity: r.intensity ?? undefined }, { raw: true, ja: r.ja, audio: r.audio, words: r.words });
    // 语音出错只提示一次，不打断他说话
    if (r.voiceError && !voiceErrShown) {
      voiceErrShown = true;
      console.warn('voice error', r.voiceError);
      const noticeSeq = speechSeq;
      setTimeout(() => { if (!staleChat() && noticeSeq === speechSeq) say('（' + r.voiceError + '）', 6000, '语音出错'); }, Math.max(3500, r.reply.length * 180));
    }
  } else if (r && r.error === 'noapi') {
    react(pick(LINES.noApi));
  } else {
    console.warn('chat error', r && r.error);
    react(pick(LINES.apiError));
    if (r && r.error) { const noticeSeq = speechSeq; setTimeout(() => { if (!staleChat() && noticeSeq === speechSeq) say('（' + r.error + '）', 6000, '连接出错'); }, 3200); }
  }
  armChatIdle();
}

chatInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); sendChat(); }
  if (e.key === 'Escape') closeChat();
});
document.getElementById('chatSend').addEventListener('click', sendChat);
document.getElementById('chatClose').addEventListener('click', closeChat);
chatBtn.addEventListener('click', openChat);

// 给浏览器里调试用
window.__pet = { get layoutInfo() { return { s: window.__layout.s, modelY: model.y, H: window.innerHeight }; }, get bodyName() { return bodyName; }, holdMouth: (v) => { mouthHold = v; }, playVoice: (b64) => playVoice(b64, speechSeq), get mouth() { return mouth; }, get voicePlaying() { return voicePlaying; }, get faceName() { return faceName; }, openChat, closeChat, anger, get layers() { return { bodyLayer, faceLayer }; }, step: (ms, n = 1) => { for (let i = 0; i < n; i++) { step(ms); app.render(); } }, react, say, remind, playBody, playFace, setIdle, startDoze, greet, setOutfit, get outfit() { return outfit; }, get model() { return model; }, setOutfit, get outfit() { return outfit; }, get lingering() { return lingering; }, proactive, takeImage, nextIdleLine, tryIdleTalk };

init().catch((err) => {
  console.error(err);
  say('模型加载失败：' + err.message, 60000);
});
