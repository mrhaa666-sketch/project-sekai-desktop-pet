// Windows 免打扰与前台窗口检测。截图由独立服务处理，不阻塞这里的状态更新。
const { spawn } = require('child_process');
const path = require('path');
const SCRIPT = String.raw`
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
Add-Type @"
using System; using System.Runtime.InteropServices; using System.Text;
public class MafuyuFS {
  [DllImport("user32.dll")] static extern IntPtr SetThreadDpiAwarenessContext(IntPtr context);
  [DllImport("user32.dll")] static extern bool SetProcessDPIAware();
  [DllImport("dwmapi.dll")] static extern int DwmGetWindowAttribute(IntPtr h, int attribute, out RECT rect, int size);
  public static void Init() {
    try { if (SetThreadDpiAwarenessContext(new IntPtr(-4)) != IntPtr.Zero) return; } catch { }
    try { SetProcessDPIAware(); } catch { }
  }
  [DllImport("shell32.dll")] static extern int SHQueryUserNotificationState(out int s);
  [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] static extern IntPtr GetShellWindow();
  [DllImport("user32.dll")] static extern IntPtr GetDesktopWindow();
  [DllImport("user32.dll")] static extern bool GetWindowRect(IntPtr h, out RECT r);
  [DllImport("user32.dll")] static extern IntPtr MonitorFromWindow(IntPtr h, uint f);
  [DllImport("user32.dll")] static extern bool GetMonitorInfo(IntPtr m, ref MONITORINFO mi);
  [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetClassName(IntPtr h, StringBuilder s, int n);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetWindowText(IntPtr h, StringBuilder s, int n);
  [StructLayout(LayoutKind.Sequential)] public struct RECT { public int L, T, R, B; }
  [StructLayout(LayoutKind.Sequential)] public struct MONITORINFO { public int cbSize; public RECT rcMonitor; public RECT rcWork; public uint dwFlags; }
  public static string Check() {
    Init();
    int q = 0; try { SHQueryUserNotificationState(out q); } catch { }
    IntPtr h = GetForegroundWindow(); int fullscreen = 0; uint pid = 0; string rect = "";
    if (h != IntPtr.Zero && h != GetShellWindow() && h != GetDesktopWindow()) {
      StringBuilder sb = new StringBuilder(256); GetClassName(h, sb, 256); string c = sb.ToString();
      if (c != "WorkerW" && c != "Progman" && c != "Shell_TrayWnd") {
        RECT r; MONITORINFO mi = new MONITORINFO(); mi.cbSize = Marshal.SizeOf(mi);
        if (GetWindowRect(h, out r) && GetMonitorInfo(MonitorFromWindow(h, 2), ref mi)) {
          fullscreen = (r.L <= mi.rcMonitor.L && r.T <= mi.rcMonitor.T && r.R >= mi.rcMonitor.R && r.B >= mi.rcMonitor.B) ? 1 : 0;
          // 可见边界不会包含最大化窗口的透明边框；该接口返回物理像素。
          RECT visible;
          try { if (DwmGetWindowAttribute(h, 9, out visible, Marshal.SizeOf(typeof(RECT))) == 0 && visible.R > visible.L && visible.B > visible.T) r = visible; } catch { }
          rect = r.L + "," + r.T + "," + r.R + "," + r.B;
        }
      }
      GetWindowThreadProcessId(h, out pid);
    }
    string title = "", proc = "";
    if (h != IntPtr.Zero) { StringBuilder t = new StringBuilder(512); GetWindowText(h, t, 512); title = t.ToString().Replace("\t", " ").Replace("\r", " ").Replace("\n", " "); }
    try { if (pid != 0) proc = System.Diagnostics.Process.GetProcessById((int)pid).ProcessName; } catch { }
    return q + " " + fullscreen + " " + pid + "\t" + proc + "\t" + title + "\t" + rect;
  }
}
"@
while ($true) { [Console]::Out.WriteLine([MafuyuFS]::Check()); [Console]::Out.Flush(); Start-Sleep -Seconds 5 }
`;

class Dnd {
  constructor() {
    this.state = { quns: 0, fullscreen: false, pid: 0, at: 0, ok: false, error: '' };
    this.proc = null; this.fails = 0; this.restartTimer = null; this.stopped = false;
    if (process.platform === 'win32') this.start();
  }
  retry(error) {
    this.state.ok = false; this.state.error = String(error || '检测进程退出了').slice(0, 200);
    if (this.stopped || this.restartTimer || ++this.fails > 5) return;
    this.restartTimer = setTimeout(() => { this.restartTimer = null; this.start(); }, Math.min(60000, 15000 * this.fails));
  }
  start() {
    if (this.stopped || this.proc) return;
    try {
      const enc = Buffer.from(SCRIPT, 'utf16le').toString('base64');
      const exe = path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe');
      const p = spawn(exe, ['-NoLogo', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-EncodedCommand', enc], { windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] });
      this.proc = p;
      let buf = '';
      p.stdout.setEncoding('utf8'); p.stderr.setEncoding('utf8');
      p.stdout.on('data', (data) => {
        if (this.proc !== p) return;
        buf += data;
        if (buf.length > 65536) { buf = ''; return; }
        let newline;
        while ((newline = buf.indexOf('\n')) >= 0) {
          const line = buf.slice(0, newline).trim(); buf = buf.slice(newline + 1);
          const [head, proc = '', title = '', rs = ''] = line.split('\t');
          const m = /^(\d+) ([01]) (\d+)$/.exec(head || '');
          if (!m) continue;
          const r = rs.split(',').map(Number);
          const rect = r.length === 4 && r.every(Number.isFinite) && r[2] > r[0] && r[3] > r[1] ? { x: r[0], y: r[1], width: r[2] - r[0], height: r[3] - r[1] } : null;
          this.state = { quns: +m[1], fullscreen: m[2] === '1', pid: +m[3], proc, title, rect, at: Date.now(), ok: true, error: '' };
          this.fails = 0;
          if (+m[3] !== process.pid && (proc || title)) this.lastExternal = { proc, title, rect, at: Date.now() };
        }
      });
      p.stderr.on('data', (data) => { if (this.proc === p) this.state.error = String(data).slice(0, 200); });
      const ended = (error) => {
        if (this.proc !== p) return;
        this.proc = null; this.retry(error);
      };
      p.on('error', (e) => ended(e.message));
      p.on('exit', () => ended('前台检测进程退出了'));
    } catch (e) { this.proc = null; this.retry(e.message); }
  }
  stop() {
    this.stopped = true; clearTimeout(this.restartTimer); this.restartTimer = null;
    const p = this.proc; this.proc = null; this.state.ok = false;
    if (p) try { p.kill(); } catch (e) {}
  }
  busy() {
    const s = this.state;
    if (!s.ok || Date.now() - s.at > 20000 || s.pid && s.pid === process.pid) return false;
    return s.quns === 2 || s.quns === 3 || s.quns === 4 || s.fullscreen;
  }
  foreground() {
    const s = this.state;
    if (!s.ok || Date.now() - s.at > 20000) return null;
    const self = !!s.pid && s.pid === process.pid;
    if (self && this.lastExternal && Date.now() - this.lastExternal.at < 120000) return { ...this.lastExternal, self: false, fromRecent: true };
    return { proc: s.proc || '', title: s.title || '', rect: s.rect || null, self };
  }
  describe() {
    if (process.platform !== 'win32') return '只在 Windows 上检测';
    if (!this.state.ok) return this.state.error ? '检测不到：' + this.state.error : '正在启动检测…';
    return this.busy() ? '现在有程序全屏，瑞希会保持安静' : '现在没有全屏的程序';
  }
}
module.exports = { Dnd };
