# 晓山瑞希桌宠 1.0.2

Windows Electron 桌宠。入口 main.js，界面 src/index.html，模型在 src/model 与 src/model_casual。

main.js 保留原版聊天、语音、记忆、好感、截图、提醒、备份与窗口功能。brain.js 为瑞希人设与聊天协议。src/lines.js 为表情、动作和同人台词。

video-editor.js 负责探测、LLM结构化方案、校验与本地视频导出；editor-window.js 负责窗口与IPC；preload-editor.js 暴露受限接口；src/editor.html 和 src/editor.js 为剪辑界面。bin 内附FFmpeg及许可说明。

使用与验证限制见程序根目录《晓山瑞希桌宠使用说明与检查报告.md》。验证目录附自动测试，需Node.js。模型、音色与密钥不属于同一配置；本包不含私人数据。

UI主题：#DDAACC，浅粉底与深梅色文字。

## 发言上下文规则

实际发言按原有 JSONL 格式保存在本机；待机自言自语单独标为“待机”，点击及其他固定反应标为“被点到/反应”。请求模型时，补充上下文使用本地月日与时分、中文来源及可选标签，每条一行，不再重复附带日语译文。最多读取最近100条、合计约15000字符；超长条目只保留结尾并标注“……”。已在本次聊天历史中的回复、通话继续去重；标签含“出错”的新旧提示均不作为角色发言。聊天历史格式、人设和 memoryTurns 规则不变。
