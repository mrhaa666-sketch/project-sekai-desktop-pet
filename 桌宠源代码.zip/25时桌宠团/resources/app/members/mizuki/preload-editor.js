'use strict';
const {contextBridge,ipcRenderer}=require('electron');
const invoke=(name,data)=>ipcRenderer.invoke('editor-'+name,data);
contextBridge.exposeInMainWorld('editorAPI',{
  state:()=>invoke('state'), import:()=>invoke('import'), generate:prompt=>invoke('generate',{prompt}),
  validate:plan=>invoke('validate',plan), export:plan=>invoke('export',plan), cancel:()=>invoke('cancel'),
  save:plan=>invoke('save',plan), load:()=>invoke('load'), reveal:()=>invoke('reveal'),
  onProgress:fn=>ipcRenderer.on('editor-progress',(_,v)=>fn(v)),
  onHint:fn=>ipcRenderer.on('editor-hint',(_,v)=>fn(v))
});
