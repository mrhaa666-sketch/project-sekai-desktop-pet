// 台词、心情、动作。全部是对你的「私下模式」——不用优等生那一面。
// 私下的她几乎面无表情：表情只做很淡的变化，心情主要靠身体动作看出来；极浅的微笑只会很偶尔出现。
// t = 台词，ja = 配音用的日语（空 = 不配音），m = 心情（决定表情），a = 动作（决定身体动作）。
// {name} 会替换成设置里的称呼（日语里换成「日语称呼」）。
'use strict';

// 表情代号表：代号 → [文件名, 说明]。文件在 model/faces/文件名.motion3.json。
// 文件名保持英文，是为了解压时不会因为中文文件名出乱码；平时只用中文代号。
// 没有眼睛高光的表情、在外人面前用的表情都已经删掉了。想加新表情：把文件放进 model/faces/，再在这里加一行。
window.FACES = {
  '平静': ['face_darknormal_01', '私下的平常脸（默认）'],
  '平静2': ['face_smallmouth_01', '平淡，嘴很小'],
  '普通开口': ['face_normal_01', '平常脸，嘴微张'],
  '说话': ['face_normal_02', '正在说话的样子'],
  '放空': ['face_darkdarkness_01', '脸上有一点阴影，出神'],
  '闭眼': ['face_darkcloseeye_01', '静静地闭着眼'],
  '闭眼2': ['face_closeeye_01', '闭眼，带一点脸红'],
  '淡笑1': ['face_darksmile_02', '真心的淡淡的笑'],
  '淡笑2': ['face_darksmile_03', '真心的淡淡的笑，眼睛弯一点'],
  '淡笑3': ['face_darksmile_06', '放松的浅笑'],
  '眯眼淡笑': ['face_darksmile_04', '眯着眼的淡笑（私下那种）'],
  '害羞笑': ['face_darksmile_05', '脸红地笑'],
  '害羞': ['face_shy_02', '脸红，嘴角有一点笑'],
  '假笑1': ['face_smile_04', '营业式假笑，只在生气时用（眯起眼）'],
  '假笑2': ['face_smile_02', '营业式假笑，只在生气时用（眉毛有点为难）'],
  '假笑3': ['face_smile_03', '营业式假笑，只在生气时用（眯一点眼）'],
  '闭眼笑': ['face_closeeye_07', '闭着眼笑'],
  '脸红笑': ['face_smile_05', '脸红的明朗笑'],
  '苦笑': ['face_smile_08', '半眯着眼，为难地笑'],
  '脸红发愣1': ['face_fever_02', '脸很红，额头发暗，愣住'],
  '脸红发愣2': ['face_fever_04', '脸红，睁大眼睛愣住'],
  '脸红抿笑': ['face_fever_03', '脸红，抿着嘴笑'],
  '脸红闭眼': ['face_fever_05', '脸很红，闭着眼'],
  '脸红窘迫': ['face_fever_07', '脸红，眯着眼，冒汗，很窘'],
  '吃惊1': ['face_darksurprise_01', '吃惊，嘴张成圆形'],
  '吃惊2': ['face_darksurprise_03', '睁大眼睛吃惊'],
  '吓到': ['face_darksurprise_02', '被吓到，脸上有阴影'],
  '惊讶1': ['face_surprise_01', '惊讶，嘴张成小圆'],
  '惊讶2': ['face_surprise_03', '惊讶，嘴微张'],
  '惊讶3': ['face_surprise_04', '惊讶又为难'],
  '惊讶阴影': ['face_surprise_02', '惊讶，脸上有阴影'],
  '震惊': ['face_shock_02', '震惊，脸上有阴影'],
  '为难1': ['face_darktrouble_01', '为难，嘴微张'],
  '为难2': ['face_darktrouble_02', '为难，想说什么'],
  '困扰': ['face_trouble_02', '困扰，嘴微张'],
  '困扰流汗': ['face_trouble_01', '困扰，冒冷汗'],
  '困惑': ['face_baffling_01', '困惑，皱着眉'],
  '无语': ['face_baffling_02', '半眯着眼，无语'],
  '尴尬': ['face_darke_01', '尴尬地咧嘴'],
  '低落1': ['face_darksad_01', '低落，嘴微张'],
  '低落2': ['face_darksad_02', '低落，嘴微张'],
  '低落3': ['face_darksad_03', '低落，想说什么'],
  '低落4': ['face_darksad_04', '低落，带一点脸红'],
  '低落5': ['face_darksad_06', '低落又为难'],
  '难过1': ['face_sad_01', '难过，嘴微张'],
  '难过2': ['face_sad_02', '难过，嘴微张'],
  '难过3': ['face_sad_03', '难过'],
  '难过4': ['face_sad_06', '难过又为难'],
  '难过5': ['face_sad_07', '难过，眼睛看向旁边'],
  '心碎': ['face_darkheartbreak_01', '受伤、失落'],
  '想哭1': ['face_cry_01', '快要哭了'],
  '想哭2': ['face_cry_02', '眼眶湿了'],
  '认真': ['face_serious_01', '认真，皱一点眉'],
  '移开视线': ['face_lookaway_01', '眼睛看向旁边'],
  '低头': ['face_lookdown_01', '眼睛往下看'],
  '不满': ['face_angry_01', '不满，噘嘴'],
  '不快': ['face_disgust_01', '不快，皱眉'],
  '嫌弃': ['face_darkdisgust_01', '半眯眼，嫌弃、闹别扭'],
  '生气冷淡': ['face_darkangry_06', '冷下来的生气'],
  '生气1': ['face_darkangry_01', '生气，噘着嘴'],
  '生气2': ['face_darkangry_04', '生气，皱眉'],
  '生气阴沉1': ['face_darkangry_02', '很生气，脸上有阴影'],
  '生气阴沉2': ['face_darkangry_03', '很生气，脸上有阴影，嘴更平'],
};

// 心情 → 表情 + 动作。
// faces：[表情代号, 强度]，强度 0~1，越小越接近「平静」（私下几乎面无表情，所以大多很低）。
// rare：很偶尔才出现的表情（比如极浅的微笑），chance 是出现概率。
// actions：这个心情常用的身体动作（来自剧情统计）；AI 没选动作时从这里挑。心情主要靠动作表达。
window.MOODS = {
  calm:      { faces: [['平静', 1], ['平静2', 1]], actions: ['none', 'nod', 'tilt'], desc: '平静、平常的样子（默认）' },
  soft:      { faces: [['平静', 1]], rare: { chance: 0.12, faces: [['淡笑1', 0.45], ['淡笑3', 0.4]] },
               actions: ['nod', 'tilt'], desc: '心情不错、放松（脸上几乎看不出来）' },
  warm:      { faces: [['平静', 1]], rare: { chance: 0.1, faces: [['淡笑3', 0.4]] },
               actions: ['warm'], desc: '心里暖和、被打动（她会用「暖和」形容这种感觉）' },
  shy:       { faces: [['害羞', 0.45]], actions: ['shy'], desc: '害羞（只有一点点脸红）' },
  flustered: { faces: [['脸红发愣2', 0.5], ['脸红窘迫', 0.4]], actions: ['shy', 'look_away'], desc: '被说中心事、有点慌' },
  think:     { faces: [['平静', 1], ['移开视线', 0.6]], actions: ['think', 'tilt'], desc: '在想事情、不太确定自己的感受' },
  sad:       { faces: [['低落1', 0.35], ['低落2', 0.35], ['低落3', 0.3]], actions: ['look_down', 'sigh'], desc: '低落、难过' },
  hurt:      { faces: [['心碎', 0.5], ['想哭2', 0.35]], actions: ['look_down', 'think'], desc: '受伤、很难受' },
  troubled:  { faces: [['为难1', 0.35], ['困扰', 0.35]], actions: ['trouble', 'shake'], desc: '困扰、为难' },
  surprised: { faces: [['吃惊1', 0.4], ['惊讶2', 0.4]], actions: ['tilt'], desc: '有点吃惊' },
  sleepy:    { faces: [['闭眼', 1], ['闭眼2', 1]], actions: ['sleep'], desc: '困了、闭眼' },
  sulky:     { faces: [['嫌弃', 0.55], ['不满', 0.4]], actions: ['shake', 'sigh', 'look_away'], desc: '有点不高兴、闹别扭' },
  angry:     { faces: [['生气冷淡', 0.55], ['生气2', 0.45]], actions: ['shake', 'angry', 'sigh'], desc: '生气（冷下来的那种）' },
  mask:      { faces: [['假笑1', 1], ['假笑2', 1], ['假笑3', 1]], actions: ['polite'], desc: '生气时的营业式假笑（偶尔才用；只有这时表情是明显的）' },
};

// 动作 → 身体动作（随机挑一个）
// 全部取自游戏剧情：统计了 25 时主线和活动剧情里，真冬在只有 25 时成员的场景中做过的动作。
// 剧情里她私下没做过的动作（摇晃、双手交握、抱臂、托腮等）都不用。
window.ACTIONS = {
  none:      { bodies: [], desc: '不做动作' },
  nod:       { bodies: ['w-normal16-nod', 'w-normal15-nod', 'w-normal03-nod', 'w-normal08-nod', 'w-normal07-nod'], desc: '轻轻点头' },
  tilt:      { bodies: ['w-normal15-tilthead', 'w-normal03-tilthead', 'w-normal07-tilthead', 'w-normal08-tilthead', 'w-normal16-tilthead'], desc: '歪头（私下最常见的反应）' },
  think:     { bodies: ['w-normal04-tilthead', 'w-normal01-tilthead'], desc: '不太确定、在想' },
  shy:       { bodies: ['w-normal15-shy', 'w-normal03-blushed'], desc: '害羞地缩一下' },
  warm:      { bodies: ['w-normal03-relief', 'w-normal04-relief'], desc: '手按在胸口（心里暖和，或说不清的感觉）' },
  look_down: { bodies: ['w-normal08-sad', 'w-normal07-sad'], desc: '垂下视线（低落）' },
  sigh:      { bodies: ['w-normal07-sigh'], desc: '叹气' },
  trouble:   { bodies: ['w-normal03-trouble', 'w-normal04-trouble'], desc: '为难' },
  shake:     { bodies: ['w-normal03-shakehead', 'w-normal02-shakehead', 'w-normal01-shakehead'], desc: '摇头' },
  look_away: { bodies: ['w-normal15-lookaround'], desc: '移开视线' },
  angry:     { bodies: ['w-normal16-angry'], desc: '生气' },
  polite:    { bodies: ['w-normal01-nod', 'w-adult02-nod', 'w-adult02-tilthead'], desc: '优等生式的端正点头（只配营业假笑用）' },
  sleep:     { bodies: ['w-adult15-sleep'], desc: '打瞌睡' },
};

// AI 直接点名表情代号时的强度（私下几乎面无表情，所以默认很淡）
window.FACE_STRENGTH_DEFAULT = 0.45;
// 脸上的阴影（ParamFaceShadow：暗下去的阴沉效果 / 受惊时的蓝色竖线）默认一律不加；
// 只有 AI 直接点名下面这几个“本来就是阴影效果”的表情时才保留（也会按强度变淡）
window.SHADOW_FACES = new Set(['生气阴沉1', '生气阴沉2', '吓到', '惊讶阴影', '震惊']);
window.FACE_STRENGTH_FULL = new Set(['平静', '平静2', '闭眼', '闭眼2', '假笑1', '假笑2', '假笑3']);

window.LINES = {
  // 换衣服之后（按时间自动换的时候才说；在打瞌睡、聊天、通话时不说）
  // 没接聊天模型时，25 时和纪念日用的固定台词
  nightcord: [{ t: '……一点了。25 时。我去 Nightcord 了……你也别熬太晚。', ja: '……一時。25時。ナイトコードに行ってくる……あなたも、夜更かししすぎないで。', m: 'calm', a: 'nod' }],
  birthdayMafuyu: [{ t: '……今天是我的生日。不太习惯被祝贺。……不过，你在的话，好像也不坏。', ja: '……今日、私の誕生日。祝われるの、慣れてない。……でも、あなたがいるなら、悪くないかも。', m: 'shy', a: 'shy' }],
  birthdayUser: [{ t: '{name}，生日快乐。……我不太会说这种话。但我是认真的。', ja: '{name}、誕生日おめでとう。……こういうの、うまく言えない。でも、本気だよ。', m: 'warm', a: 'warm' }],
  anniversary: [{ t: '……今天，是我们的纪念日。我记得。', ja: '……今日、私たちの記念日。ちゃんと覚えてる。', m: 'warm', a: 'warm' }],
  // 你用合成器弹曲子给她听
  synthListen: [
    { t: '……嗯，在听。', ja: '……うん、聴いてる。', m: 'calm', a: 'nod' },
    { t: '是你写的？……我听听。', ja: 'あなたが書いたの？……聴かせて。', m: 'soft', a: 'tilt' },
    { t: '……钢琴的声音。不讨厌。', ja: '……ピアノの音。嫌いじゃない。', m: 'soft', a: 'warm' },
  ],
  outfitCasual: [
    { t: '……换好了。这样轻松一点。', ja: '……着替えた。こっちのほうが、楽。', m: 'calm', a: 'nod' },
    { t: '放学了。……今天也结束了。', ja: '学校、終わった。……今日も、終わり。', m: 'calm', a: 'none' },
    { t: '换下制服了。……嗯，可以喘口气了。', ja: '制服、脱いだ。……うん、少し息ができる。', m: 'soft', a: 'warm' },
  ],
  outfitUniform: [
    { t: '……该去学校了。', ja: '……学校、行かなきゃ。', m: 'calm', a: 'nod' },
    { t: '换好制服了。……嗯，走吧。', ja: '制服、着た。……うん、行こう。', m: 'calm', a: 'none' },
  ],
  greet: {
    morning: [
      { t: '……早。', ja: '……おはよう。', m: 'calm', a: 'nod' },
      { t: '早上好，{name}。……还有点困。', ja: 'おはよう、{name}。……まだ少し眠い。', m: 'sleepy', a: 'tilt' },
    ],
    day: [
      { t: '嗯，你来了。', ja: 'うん、来たんだ。', m: 'calm', a: 'nod' },
      { t: '{name}。……正好，有点想见你。', ja: '{name}。……ちょうど、少し会いたかった。', m: 'soft', a: 'nod' },
    ],
    evening: [
      { t: '回来了。今天累吗。', ja: 'おかえり。今日、疲れた？', m: 'calm', a: 'tilt' },
      { t: '……等了你一会儿。', ja: '……少し、待ってた。', m: 'shy', a: 'shy' },
    ],
    night: [
      { t: '这个时间……你也睡不着？', ja: 'こんな時間……あなたも眠れないの？', m: 'calm', a: 'tilt' },
      { t: '还没到25时。……不对，你该睡了。', ja: 'まだ25時じゃない。……違う、あなたはもう寝なきゃ。', m: 'troubled', a: 'sigh' },
    ],
  },

  // 点头部
  head: [
    { t: '……摸头？嗯。', ja: '……頭？　うん。', m: 'shy', a: 'shy' },
    { t: '……不讨厌。', ja: '……嫌いじゃない。', m: 'warm', a: 'warm' },
    { t: '……有点暖和。', ja: '……少し、あったかい。', m: 'warm', a: 'warm' },
    { t: '头发会乱的。……算了，随你。', ja: '髪、乱れる。……まあ、いいよ。', m: 'calm', a: 'tilt' },
  ],

  // 点身体
  body: [
    { t: '怎么了。', ja: 'どうしたの。', m: 'calm', a: 'tilt' },
    { t: '嗯，我在听。', ja: 'うん、聞いてる。', m: 'calm', a: 'nod' },
    { t: '{name}，今天怎么样？', ja: '{name}、今日はどうだった？', m: 'calm', a: 'tilt' },
    { t: '在做什么？……我在旁边看着就好。', ja: '何してるの？……私は横で見てるだけでいい。', m: 'calm', a: 'look_away' },
    { t: '和你在一起的时候，不用想该做什么表情。', ja: 'あなたといるときは、どんな顔をすればいいか考えなくていい。', m: 'warm', a: 'nod' },
    { t: '……见到你，这里会暖和一点。为什么，我也说不清。', ja: '……あなたに会うと、ここが少しあったかくなる。どうしてかは、うまく言えない。', m: 'warm', a: 'warm' },
    { t: '有点想你。……明明你就在这里。', ja: '少し、会いたかった。……ここにいるのに。', m: 'shy', a: 'shy' },
    { t: '累了就说。我不觉得麻烦。', ja: '疲れたら言って。面倒だなんて思わないから。', m: 'calm', a: 'nod' },
    { t: '……可以再待一会儿吗。', ja: '……もう少しだけ、いてくれる？', m: 'soft', a: 'tilt' },
    { t: '今天没怎么勉强自己。……嗯，不坏。', ja: '今日はあまり無理しなかった。……うん、悪くない。', m: 'soft', a: 'nod' },
    { t: '{name}，饭吃了吗。……我尝不出什么味道，所以你要好好吃。', ja: '{name}、ご飯食べた？……私は味がよくわからないから、あなたはちゃんと食べて。', m: 'calm', a: 'tilt' },
  ],

  // 连续点很多下（越点越不高兴）
  poke: [
    { t: '……你在玩我吗。', ja: '……私で遊んでる？', m: 'troubled', a: 'trouble' },
    { t: '点太多了。', ja: 'つつきすぎ。', m: 'sulky', a: 'shake' },
  ],
  pokeAngry: [
    { t: '……够了。', ja: '……もういい。', m: 'angry', a: 'sigh' },
    { t: '我说了，停下。', ja: 'やめてって言ったよね。', m: 'angry', a: 'angry' },
  ],
  // 生气时偶尔会露出营业式的假笑
  pokeMask: [
    { t: '嗯，没关系哦。我一点也不介意的。', ja: 'ううん、大丈夫だよ。全然気にしてないから。', m: 'mask', a: 'polite' },
    { t: '{name}真是的～……这样，开心吗？', ja: 'もう、{name}ったら～……それで、楽しい？', m: 'mask', a: 'polite' },
  ],
  // 刚生过气时摸她
  stillSulky: [
    { t: '……哼。', ja: '……ふん。', m: 'sulky', a: 'look_away' },
    { t: '……现在不想。', ja: '……今はいい。', m: 'sulky', a: 'look_away' },
  ],

  // 拖动后放下
  drop: [
    { t: '这里？嗯。', ja: 'ここ？　うん。', m: 'calm', a: 'nod' },
    { t: '……突然被拎起来，吓了一跳。', ja: '……急に持ち上げるから、びっくりした。', m: 'surprised', a: 'shake' },
  ],

  // 一个人待着时偶尔的自言自语
  // 待机时的自言自语：按时段、衣服挑；同一句近期不会重复（见 renderer.js 的 nextIdleLine）
  // when: morning 5–11 / day 11–17 / evening 17–23 / night 23–5；不写就是什么时候都行
  // outfit: uniform 校服 / casual 常服；不写就是都行
  idle: [
    { t: '……', ja: '', m: 'calm', a: 'look_away' },
    { t: '在想新的歌词……还没想好。', ja: '新しい歌詞、考えてる……まだまとまらない。', m: 'think', a: 'think' },
    { t: '你忙的话，我就安静待着。', ja: '忙しいなら、静かにしてる。', m: 'calm', a: 'nod' },
    { t: '……刚才那段旋律，是开心的感觉吗。我不太确定。', ja: '……さっきのメロディ、楽しい感じなのかな。よくわからない。', m: 'think', a: 'tilt' },
    { t: '水族箱……看着看着，好像自己也变透明了。', ja: '水槽……見てると、自分まで透明になっていくみたい。', m: 'think', a: 'look_away' },
    { t: '……这样待着，不讨厌。', ja: '……こうしてるの、嫌いじゃない。', m: 'soft', a: 'warm' },
    { t: '奏说，下一首想要更安静一点的。……我在想怎么写。', ja: '奏が、次はもっと静かな曲がいいって。……どう書こうか考えてる。', m: 'think', a: 'think' },
    { t: '瑞希又发了好多表情包过来。……我只回了一个“嗯”。', ja: '瑞希がまたスタンプをたくさん送ってきた。……「うん」とだけ返した。', m: 'calm', a: 'tilt' },
    { t: '绘名说我的画面构想太抽象了。……是吗。', ja: '絵名に、イメージが抽象的すぎるって言われた。……そうかな。', m: 'think', a: 'tilt' },
    { t: '……刚才在想一件事，又忘了。', ja: '……さっき何か考えてたのに、忘れちゃった。', m: 'think', a: 'look_away' },
    { t: '你那边，现在安静吗。', ja: 'そっちは、今静か？', m: 'calm', a: 'tilt' },
    { t: '……不说话也可以。我在这里。', ja: '……話さなくてもいいよ。私はここにいる。', m: 'soft', a: 'nod' },
    { t: '要是累了，就停一下。……我也会陪着。', ja: '疲れたら、少し止まって。……私も付き合うから。', m: 'soft', a: 'nod' },
    { t: '屏幕看久了，眼睛会酸。', ja: '画面ばかり見てると、目が疲れるよ。', m: 'calm', a: 'tilt' },
    { t: '……有你在旁边的时候，时间过得有点不一样。', ja: '……あなたが近くにいると、時間の流れ方が少し違う。', m: 'soft', a: 'look_away' },
    { t: '弓道的时候，只要看着靶子就好。……那种安静，我还挺喜欢的。', ja: '弓道の時は、的だけ見ていればいい。……あの静けさは、わりと好き。', m: 'calm', a: 'none' },
    { t: '喜欢的东西……我还在找。', ja: '好きなもの……まだ探してる。', m: 'think', a: 'look_down' },
    { t: '……你刚才是不是叹气了。', ja: '……今、ため息ついた？', m: 'think', a: 'tilt' },
    { t: '早上的空气，有点凉。', ja: '朝の空気、少し冷たい。', m: 'calm', a: 'none', when: 'morning' },
    { t: '……还有点困。今天要做的事，慢慢来。', ja: '……まだ少し眠い。今日やること、ゆっくりでいい。', m: 'sleepy', a: 'tilt', when: 'morning' },
    { t: '早饭吃了吗。……我是问认真的。', ja: '朝ごはん、食べた？……ちゃんと聞いてる。', m: 'calm', a: 'tilt', when: 'morning' },
    { t: '午休快结束了。……下午的课，有点不想上。', ja: 'もうすぐ昼休みが終わる。……午後の授業、ちょっと行きたくない。', m: 'calm', a: 'look_away', when: 'day', outfit: 'uniform' },
    { t: '下午的阳光很晃眼。', ja: '午後の日差し、まぶしい。', m: 'calm', a: 'look_away', when: 'day' },
    { t: '……这个时间，人有点容易发呆。', ja: '……この時間、ついぼーっとしちゃう。', m: 'sleepy', a: 'tilt', when: 'day' },
    { t: '放学了。……今天也算撑过来了。', ja: '学校、終わった。……今日もなんとか乗り切った。', m: 'calm', a: 'nod', when: 'evening', outfit: 'casual' },
    { t: '天黑得越来越早了。', ja: '暗くなるのが、どんどん早くなる。', m: 'calm', a: 'look_away', when: 'evening' },
    { t: '晚饭……我还不太饿。你呢。', ja: '晩ごはん……私はまだあまりお腹すいてない。あなたは？', m: 'calm', a: 'tilt', when: 'evening' },
    { t: '作业还剩一点。……写完就去 Nightcord。', ja: '宿題、もう少し残ってる。……終わったらナイトコードに行く。', m: 'calm', a: 'none', when: 'evening' },
    { t: '……已经这么晚了。你还不睡吗。', ja: '……もうこんな時間。まだ寝ないの？', m: 'calm', a: 'tilt', when: 'night' },
    { t: '夜里很安静。……这种时候，比较好写曲子。', ja: '夜は静か。……こういう時のほうが、曲が書きやすい。', m: 'calm', a: 'think', when: 'night' },
    { t: '明天还要早起的话……别熬太久。', ja: '明日も早いなら……あまり無理しないで。', m: 'soft', a: 'nod', when: 'night' },
    { t: '……这身衣服比较轻松。不用想该怎么站。', ja: '……この服のほうが楽。どう立てばいいか考えなくていい。', m: 'calm', a: 'none', outfit: 'casual' },
    { t: '制服的领子，有点紧。', ja: '制服の襟、少しきつい。', m: 'calm', a: 'look_away', outfit: 'uniform' },
  ],

  water: [
    { t: '{name}，喝点水。我看着你喝。', ja: '{name}、水飲んで。ちゃんと見てるから。', m: 'calm', a: 'tilt' },
    { t: '很久没喝水了。……去倒一杯吧。', ja: 'しばらく水、飲んでないよ。……一杯ついできて。', m: 'calm', a: 'tilt' },
  ],

  rest: [
    { t: '看屏幕太久了。站起来走走。', ja: '画面見すぎ。少し立って歩いて。', m: 'calm', a: 'tilt' },
    { t: '休息五分钟吧。我等你。', ja: '五分だけ休もう。待ってるから。', m: 'soft', a: 'nod' },
  ],

  sleep: [
    { t: '很晚了。……{name}，去睡吧。', ja: 'もう遅いよ。……{name}、寝よう。', m: 'troubled', a: 'sigh' },
    { t: '熬夜这件事，我比较有经验。……所以才不想你也这样。', ja: '夜更かしのことなら、私のほうが詳しい。……だから、あなたにはしてほしくない。', m: 'sad', a: 'look_down' },
    { t: '明天再继续吧。晚安。', ja: '続きはまた明日。おやすみ。', m: 'sleepy', a: 'sleep' },
  ],

  doze: [{ t: '……有点困。', ja: '……少し、眠い。', m: 'sleepy', a: 'sleep' }],
  wake: [{ t: '……啊。你回来了。', ja: '……あ。戻ってきたんだ。', m: 'surprised', a: 'tilt' }],

  // 聊天时没接 API
  noApi: [{ t: '……还没接上我的「声音」。右键 → 设置，填好 API 就可以了。', m: 'think', a: 'tilt' }],
  apiError: [{ t: '……刚才没听清。再说一次？', ja: '……今の、聞き取れなかった。もう一回言って？', m: 'troubled', a: 'tilt' }],
};

// 平时站着的姿势和表情
window.IDLE = { b: 'w-normal15-pose', f: '平静' };
// 偶尔的小动作（不说话）
// 也都取自她在剧情里私下做过的动作：轻轻歪头、换一下站姿
window.IDLE_MOVES = ['w-normal15-tilthead', 'w-normal07-tilthead', 'w-normal08-tilthead', 'w-normal16-tilthead', 'w-normal16-pose', 'w-normal08-pose', 'w-normal15-lookaround'];
