'use strict';
// 写词窗口的后台分析线程：耗时的频谱计算放在这里，不卡界面
importScripts('lyrics-analysis.js');
self.onmessage = (e) => {
  const { id, samples, sampleRate } = e.data || {};
  try {
    const r = self.LyricsAnalysis.analyzeAudio(samples, sampleRate, (p, stage) => self.postMessage({ id, progress: p, stage }));
    self.postMessage({ id, result: r });
  } catch (err) {
    self.postMessage({ id, error: String((err && err.message) || err) });
  }
};
