'use strict';
/* 合成器窗口：写简谱 → 用钢琴音色弹出来；可以保存、导出 WAV / MIDI；弹的时候告诉真冬 */
const $ = (id) => document.getElementById(id);
const api = window.synthAPI;
const msg = (t, cls = '') => { $('msg').textContent = t; $('msg').className = cls; };

let mineLoaded = false;   // 现在框里是她写的曲子
let ac = null, src = null, raf = 0, cache = { text: null, buf: null, score: null };
const ctx = () => (ac || (ac = new AudioContext()));

/* ---------- 预览：把每个音包成一个可以高亮的块 ---------- */
let spans = [];
function buildPreview(text, score) {
  const pv = $('preview');
  pv.textContent = '';
  spans = [];
  if (!score || !score.notes.length) return;
  let pos = 0;
  for (const n of score.notes) {
    const [a, b] = n.src;
    if (a > pos) pv.appendChild(document.createTextNode(text.slice(pos, a)));
    const sp = document.createElement('span');
    sp.className = 'n'; sp.textContent = text.slice(a, b);
    pv.appendChild(sp); spans.push(sp);
    pos = b;
  }
  if (pos < text.length) pv.appendChild(document.createTextNode(text.slice(pos)));
}

function check() {
  const text = $('score').value;
  const score = Jianpu.parse(text);
  if (score.error) {
    msg(`第 ${text.slice(0, score.error.pos).split('\n').length} 行：${score.error.msg}`, 'err');
    buildPreview('', null);
    return null;
  }
  if (!score.notes.length) { msg('还没有写音符'); buildPreview('', null); return null; }
  const sec = score.total * 60 / score.bpm;
  msg(`${score.notes.length} 个音 · 1=${score.key} · ♩=${score.bpm} · 大约 ${sec < 60 ? Math.round(sec) + ' 秒' : Math.floor(sec / 60) + ' 分 ' + Math.round(sec % 60) + ' 秒'}`);
  buildPreview(text, score);
  return score;
}
let checkTimer = 0;
$('score').addEventListener('input', () => { mineLoaded = false;  clearTimeout(checkTimer); checkTimer = setTimeout(check, 250); });

// 定位到出错的地方
$('msg').addEventListener('click', () => {
  const s = Jianpu.parse($('score').value);
  if (s.error) { $('score').focus(); $('score').setSelectionRange(s.error.pos, s.error.pos + 1); }
});

async function getBuffer() {
  const text = $('score').value;
  if (cache.text === text && cache.buf) return cache;
  const score = check();
  if (!score) return null;
  msg('合成中…');
  const buf = await Jianpu.render(score);
  cache = { text, buf, score };
  check();
  return cache;
}

/* ---------- 播放 ---------- */
function stop() {
  if (src) { try { src.stop(); } catch (e) {} src = null; }
  cancelAnimationFrame(raf);
  spans.forEach((s) => s.classList.remove('on'));
  $('play').disabled = false; $('stop').disabled = true;
}
$('stop').onclick = stop;
$('play').onclick = async () => {
  stop();
  const c = await getBuffer();
  if (!c) return;
  const a = ctx(); if (a.state === 'suspended') await a.resume();
  src = a.createBufferSource(); src.buffer = c.buf; src.connect(a.destination);
  const t0 = a.currentTime + 0.05;
  src.start(t0);
  src.onended = () => { if (src) stop(); };
  $('play').disabled = true; $('stop').disabled = false;
  if ($('share').checked || mineLoaded) api.played($('title').value.trim(), mineLoaded);
  const spb = 60 / c.score.bpm;
  let cur = -1;
  const tick = () => {
    const beat = (a.currentTime - t0 - 0.05) / spb;
    let k = -1;
    for (let i = 0; i < c.score.notes.length; i++) { const n = c.score.notes[i]; if (beat >= n.t && beat < n.t + n.dur) { k = i; break; } }
    if (k !== cur) {
      if (cur >= 0 && spans[cur]) spans[cur].classList.remove('on');
      if (k >= 0 && spans[k]) { spans[k].classList.add('on'); spans[k].scrollIntoView({ block: 'nearest' }); }
      cur = k;
    }
    raf = requestAnimationFrame(tick);
  };
  tick();
};

/* ---------- 导出 ---------- */
const fname = () => ($('title').value.trim() || '无题').replace(/[\\/:*?"<>|]/g, '_');
$('wav').onclick = async () => {
  const c = await getBuffer(); if (!c) return;
  const r = await api.exportFile({ name: fname() + '.wav', data: Jianpu.toWav(c.buf) });
  if (r && r.path) msg('已导出：' + r.path, 'ok');
};
$('midi').onclick = async () => {
  const score = check(); if (!score) return;
  const r = await api.exportFile({ name: fname() + '.mid', data: Jianpu.toMidi(score) });
  if (r && r.path) msg('已导出：' + r.path, 'ok');
};

/* ---------- 保存的曲子 ---------- */
let saved = {};
async function refreshSaved(select) {
  saved = await api.list();
  const sel = $('saved');
  sel.innerHTML = '<option value="">已保存的曲子…</option>';
  for (const name of Object.keys(saved).sort((a, b) => (saved[b].at || 0) - (saved[a].at || 0))) {
    const o = document.createElement('option'); o.value = name; o.textContent = name; sel.appendChild(o);
  }
  if (select) sel.value = select;
}
$('saved').onchange = () => {
  const name = $('saved').value; if (!name || !saved[name]) return;
  stop();
  $('title').value = name; $('score').value = saved[name].text; mineLoaded = saved[name].by === 'mafuyu'; check();
};
$('save').onclick = async () => {
  const name = $('title').value.trim();
  if (!name) { msg('先给曲子起个名字', 'err'); $('title').focus(); return; }
  await api.save({ title: name, text: $('score').value });
  await refreshSaved(name);
  msg('已保存', 'ok');
};
$('del').onclick = async () => {
  const name = $('saved').value;
  if (!name) { msg('先在右边选一首要删除的曲子', 'err'); return; }
  await api.remove(name);
  await refreshSaved('');
  msg(`已删除《${name}》`, 'ok');
};

/* ---------- 小键盘：两个八度，按当前调写成简谱 ---------- */
const NAMES = ['1', '#1', '2', '#2', '3', '4', '#4', '5', '#5', '6', '#6', '7'];
function tokenFor(midi) {
  const tonic = Jianpu.parse($('score').value).tonic || 60;
  const d = midi - tonic, oct = Math.floor(d / 12), r = ((d % 12) + 12) % 12;
  return NAMES[r] + (oct > 0 ? "'".repeat(oct) : ','.repeat(-oct));
}
const tapCache = new Map();
async function tap(midi, el) {
  el.classList.add('down'); setTimeout(() => el.classList.remove('down'), 180);
  // 先写进光标的位置，再试音
  const ta = $('score'), p = ta.selectionStart, q = ta.selectionEnd, v = ta.value;
  const before = v.slice(0, p), sep = before && !/[\s|[]$/.test(before) ? ' ' : '';
  const tok = sep + tokenFor(midi);
  ta.value = before + tok + v.slice(q);
  ta.setSelectionRange(p + tok.length, p + tok.length);
  check();
  if (!tapCache.has(midi)) tapCache.set(midi, Jianpu.render({ bpm: 60, total: 1, notes: [{ t: 0, dur: 0.6, midi: [midi] }] }));
  const buf = await tapCache.get(midi);
  const a = ctx(); if (a.state === 'suspended') await a.resume();
  const s = a.createBufferSource(); s.buffer = buf; s.connect(a.destination); s.start();
}
(function buildKeyboard() {
  const kb = $('kb'), W = 100 / 15;
  const white = [0, 2, 4, 5, 7, 9, 11], black = { 1: 0, 3: 1, 6: 3, 8: 4, 10: 5 };
  let wi = 0;
  for (let o = 0; o < 2; o++) {
    for (const st of white) {
      const midi = 60 + o * 12 + st, el = document.createElement('div');
      el.className = 'w'; el.style.left = wi * W + '%'; el.style.width = `calc(${W}% - 2px)`;
      el.textContent = st === 0 ? 'C' + (4 + o) : '';
      el.onmousedown = (e) => { e.preventDefault(); tap(midi, el); };
      kb.appendChild(el); wi++;
    }
    for (const st in black) {
      const midi = 60 + o * 12 + +st, el = document.createElement('div');
      el.className = 'b'; el.style.left = `calc(${(o * 7 + black[st] + 1) * W}% - ${W * 0.3}%)`; el.style.width = W * 0.6 + '%';
      el.onmousedown = (e) => { e.preventDefault(); tap(midi, el); };
      kb.appendChild(el);
    }
  }
  const midi = 84, el = document.createElement('div');
  el.className = 'w'; el.style.left = wi * W + '%'; el.style.width = `calc(${W}% - 2px)`; el.textContent = 'C6';
  el.onmousedown = (e) => { e.preventDefault(); tap(midi, el); };
  kb.appendChild(el);
})();

/* ---------- 让她写一段 ---------- */
$('compose').onclick = async () => { stop(); await api.compose(''); };
api.onStatus(({ busy, text, err }) => {
  $('compose').disabled = !!busy;
  msg(text, err ? 'err' : busy ? '' : 'ok');
});
api.onLoad(async ({ title, text, play, mine }) => {
  stop();
  await refreshSaved(title);
  $('title').value = title; $('score').value = text; mineLoaded = !!mine;
  check();
  if (play) $('play').click();
});

/* ---------- 开始 ---------- */
(async () => {
  await refreshSaved('');
  const names = Object.keys(saved);
  if (!names.length) {
    $('title').value = '小星星（示例）';
    $('score').value = '1=C 4/4 ♩=96   // 示例：可以直接点“播放”\n[1,5,1] 1 5 5 | [4,6] 6 5 - | [4,4] 4 3 3 | [5,,2] 2 1 - |\n5 5_ 5_ 4 4 | 3 3 2 - | 5 5 4 4 | 3 3 2 - |\n1 1 5 5 | 6 6 5 - | 4 4 3 3 | 2 2 [1,1] - |';
  }
  check();
})();

/* ---------- 写词：把当前作品直接交给写词窗口（不用先导出文件） ---------- */
function currentPiece() {
  const text = $('score').value, title = $('title').value.trim();
  if (!text.trim()) return { error: '合成器里还没有曲子：先写一段，或者从“已保存的曲子”里选一首，再点“为这首写歌词”。' };
  const p = Jianpu.parse(text);
  if (p.error) return { error: '这首谱子有错误，先改好再写歌词：' + p.error.msg };
  if (!p.notes.some((n) => n.midi.length)) return { error: '这首谱子里还没有音符（只有休止或空白）。' };
  return { kind: 'synth', title, text, mine: mineLoaded };
}
$('toLyrics').onclick = async () => {
  clearTimeout(checkTimer);   // 不让输入检查的提示盖掉这里的提示
  const c = currentPiece();
  if (c.error) { msg(c.error, 'err'); return; }
  const r = await api.toLyrics(c);
  if (r && r.error) msg(r.error, 'err');
  else msg(`已经把${c.title ? '《' + c.title + '》' : '当前这首'}交给写词窗口（编辑框里的内容没有改动）。`, 'ok');
};
api.onGetCurrent && api.onGetCurrent((reqId) => api.currentReply(reqId, currentPiece()));
