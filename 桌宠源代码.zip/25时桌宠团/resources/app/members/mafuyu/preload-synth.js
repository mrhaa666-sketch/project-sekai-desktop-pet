const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('synthAPI', {
  list: () => ipcRenderer.invoke('synth-list'),
  save: (v) => ipcRenderer.invoke('synth-save', v),
  remove: (name) => ipcRenderer.invoke('synth-remove', name),
  exportFile: (v) => ipcRenderer.invoke('synth-export', v),
  played: (title, mine) => ipcRenderer.send('synth-played', title, mine),
  compose: (hint) => ipcRenderer.invoke('synth-compose', hint),
  onStatus: (cb) => ipcRenderer.on('synth-status', (_e, v) => cb(v)),
  onLoad: (cb) => ipcRenderer.on('synth-load', (_e, v) => cb(v)),
  // 写词：把当前作品交给写词窗口；写词窗口来要当前作品时回复
  toLyrics: (v) => ipcRenderer.invoke('synth-to-lyrics', v),
  onGetCurrent: (cb) => ipcRenderer.on('synth-get-current', (_e, reqId) => cb(reqId)),
  currentReply: (reqId, data) => ipcRenderer.send('synth-current-reply', { reqId, data }),
});
