// Windows 预热独立单帧截图服务；兼容采集默认关闭，图片只在内存中处理。
const { app, desktopCapturer, screen, ipcMain } = require('electron');
const fs = require('fs');
const path = require('path');
const winCapture = process.platform === 'win32' ? require('./screen-win') : null;
const DEFAULT_BLOCK = '微信, WeChat, QQ, TIM, 钉钉, 飞书, 支付宝, 银行, 网银, 密码, Password, KeePass, 1Password, Bitwarden, InPrivate, 无痕, Incognito, 隐身';
function blockedBy(fg, list) {
  if (!fg) return null;
  const hay = `${fg.proc} ${fg.title}`.toLowerCase();
  const words = String(list ?? DEFAULT_BLOCK).split(/[,，、\n]+/).map((w) => w.trim()).filter(Boolean);
  return words.find((w) => hay.includes(w.toLowerCase())) || null;
}
function logCapture(info) {
  try {
    const file = path.join(app.getPath('userData'), 'screen-capture.log');
    const line = JSON.stringify({ at: new Date().toISOString(), version: 'screen-integrated-20261025', ...info }) + '\n';
    fs.stat(file, (err, stat) => {
      const append = () => fs.appendFile(file, line, () => {});
      if (!err && stat.size > 1024 * 1024) fs.rename(file, file + '.old', (e) => { if (e) fs.writeFile(file, line, () => {}); else append(); });
      else append();
    });
  } catch (e) {}
}

let preparing = null, serviceReady = false;
function prepare() {
  if (!winCapture) return Promise.resolve(false);
  if (preparing) return preparing;
  const started = Date.now(), token = generation;
  const job = winCapture.prepare().then(() => {
    if (token !== generation) return false;
    if (!serviceReady) logCapture({ event: 'prepare', ok: true, backend: 'win-gdi', startupMs: Date.now() - started });
    serviceReady = true; return true;
  }, (e) => {
    if (token !== generation) return false;
    serviceReady = false;
    logCapture({ event: 'prepare', ok: false, backend: 'win-gdi', error: String(e.message || e).slice(0, 240) });
    return false;
  }).finally(() => { if (preparing === job) preparing = null; });
  preparing = job;
  return job;
}

let reqSeq = 0;
const waiting = new Map();
ipcMain.on('grab-frame-result', (event, result) => {
  if (!result || typeof result !== 'object') return;
  const w = waiting.get(result.id);
  if (!w || event.sender !== w.wc) return;
  if (result.error) w.finish(new Error(String(result.error)));
  else if (typeof result.b64 !== 'string' || !result.b64) w.finish(new Error('截图返回的图片为空'));
  else w.finish(null, result);
});
function grabViaPage(wc, payload) {
  return new Promise((resolve, reject) => {
    const id = ++reqSeq;
    let timer;
    const cancel = () => { try { if (!wc.isDestroyed()) wc.send('grab-frame-cancel', { id }); } catch (e) {} };
    const finish = (error, result) => {
      if (!waiting.has(id)) return;
      waiting.delete(id); clearTimeout(timer); wc.removeListener('destroyed', destroyed);
      error ? reject(error) : resolve(result);
    };
    const destroyed = () => finish(new Error('桌宠页面已关闭'));
    waiting.set(id, { wc, finish, cancel });
    wc.once('destroyed', destroyed);
    timer = setTimeout(() => { cancel(); finish(new Error('取画面超时，已取消本次截图')); }, 7500);
    try { if (wc.isDestroyed()) throw new Error('桌宠页面已关闭'); wc.send('grab-frame', { id, ...payload, timeoutMs: 6000 }); }
    catch (e) { cancel(); finish(e); }
  });
}
let sourceCache = null;
async function screenSource(disp) {
  const displays = screen.getAllDisplays();
  const signature = JSON.stringify(displays.map((d) => [d.id, d.bounds, d.scaleFactor]));
  const cached = sourceCache && sourceCache.signature === signature && sourceCache.ids.get(String(disp.id));
  if (cached) return { id: cached, cached: true };
  const sources = await desktopCapturer.getSources({ types: ['screen'], thumbnailSize: { width: 0, height: 0 }, fetchWindowIcons: false });
  sourceCache = { signature, ids: new Map(sources.map((s) => [String(s.display_id), s.id])) };
  const src = sources.find((s) => String(s.display_id) === String(disp.id)) || (displays.length === 1 && sources.length === 1 ? sources[0] : null);
  if (!src) throw new Error('找不到目标屏幕');
  sourceCache.ids.set(String(disp.id), src.id);
  return { id: src.id, cached: false };
}
function geometry(scope, petWin, fgRect) {
  const windowRect = scope === 'window' && process.platform === 'win32' && fgRect && ['x', 'y', 'width', 'height'].every((key) => Number.isFinite(fgRect[key])) && fgRect.width > 0 && fgRect.height > 0 ? fgRect : null;
  const disp = windowRect ? screen.getDisplayMatching(screen.screenToDipRect(null, windowRect)) : screen.getDisplayMatching(petWin.getBounds());
  const raw = process.platform === 'win32' ? screen.dipToScreenRect(null, disp.bounds) : {
    x: disp.bounds.x, y: disp.bounds.y, width: disp.size.width * disp.scaleFactor, height: disp.size.height * disp.scaleFactor,
  };
  const full = Object.fromEntries(['x', 'y', 'width', 'height'].map((key) => [key, Math.round(raw[key])]));
  let rect = { ...full }, crop = null;
  if (windowRect) {
    const x = Math.max(full.x, Math.round(windowRect.x)), y = Math.max(full.y, Math.round(windowRect.y));
    const right = Math.min(full.x + full.width, Math.round(windowRect.x + windowRect.width));
    const bottom = Math.min(full.y + full.height, Math.round(windowRect.y + windowRect.height));
    if (right - x > 40 && bottom - y > 40) {
      rect = { x, y, width: right - x, height: bottom - y };
      crop = { x: (x - full.x) / full.width, y: (y - full.y) / full.height, w: rect.width / full.width, h: rect.height / full.height };
    }
  }
  return { disp, rect, full, crop, what: crop ? '当前窗口' : '整个屏幕' };
}

let captureBusy = false, generation = 0;
function stop() {
  generation++;
  serviceReady = false; sourceCache = null; preparing = null;
  if (winCapture) winCapture.close();
  for (const w of [...waiting.values()]) { w.cancel(); w.finish(new Error('截图已取消')); }
}
async function capture({ scope = 'screen', petWin, fgRect = null, allowLegacyFallback = false } = {}) {
  if (captureBusy) throw new Error('截图正在进行，请稍后再试');
  captureBusy = true;
  const started = Date.now(), token = generation;
  let nativeError = '', backend = winCapture ? 'win-gdi' : 'electron';
  try {
    if (!petWin || petWin.isDestroyed() || petWin.webContents.isDestroyed()) throw new Error('桌宠页面不可用');
    const g = geometry(scope, petWin, fgRect);
    if (winCapture) {
      try {
        const result = await winCapture.capture({ rect: g.rect, maxSide: 1280 });
        if (token !== generation) throw new Error('截图已取消');
        serviceReady = true;
        const frame = {};
        for (const key of ['width', 'height', 'allocateMs', 'copyMs', 'resizeMs', 'encodeMs', 'totalMs']) if (Number.isFinite(result.timings?.[key])) frame[key] = result.timings[key];
        logCapture({ event: 'capture', ok: true, backend, scope, sourceMs: 0, regionSize: { width: g.rect.width, height: g.rect.height }, workerReadyMs: result.workerReadyMs, reusedWorker: result.reusedWorker, eventLoopLagMs: result.eventLoopLagMs, requestMs: result.requestMs, frame, totalMs: Date.now() - started });
        return { b64: result.b64, mime: 'image/jpeg', what: g.what };
      } catch (e) {
        serviceReady = false;
        if (token !== generation || allowLegacyFallback !== true) throw e;
        // 原生进程先结束，再进入用户主动开启的兼容路径，避免两次采集重叠。
        winCapture.close(); nativeError = String(e.message || e).slice(0, 240);
        logCapture({ event: 'fallback', ok: false, backend: 'win-gdi', error: nativeError });
      }
    }
    backend = 'electron';
    const sourceAt = Date.now(), src = await screenSource(g.disp);
    if (token !== generation) throw new Error('截图已取消');
    const sourceMs = Date.now() - sourceAt;
    const maxCaptureSide = g.crop ? Math.min(1920, 1280 / Math.max(g.crop.w, g.crop.h)) : 1280;
    const scale = Math.min(1, maxCaptureSide / Math.max(g.full.width, g.full.height));
    const captureSize = { width: Math.max(1, Math.round(g.full.width * scale)), height: Math.max(1, Math.round(g.full.height * scale)) };
    const result = await grabViaPage(petWin.webContents, { sourceId: src.id, captureSize, crop: g.crop, maxSide: 1280 });
    if (token !== generation) throw new Error('截图已取消');
    const frame = {};
    for (const key of ['acquireMs', 'firstFrameMs', 'drawMs', 'encodeMs', 'totalMs', 'width', 'height']) if (Number.isFinite(result.timings?.[key])) frame[key] = result.timings[key];
    logCapture({ event: 'capture', ok: true, backend, scope, fallback: !!nativeError, sourceMs, cachedSource: src.cached, frame, totalMs: Date.now() - started });
    return { b64: result.b64, mime: 'image/jpeg', what: g.what };
  } catch (e) {
    sourceCache = null;
    logCapture({ event: 'capture', ok: false, backend, scope, fallback: !!nativeError, error: String(e.message || e).slice(0, 240), totalMs: Date.now() - started });
    throw e;
  } finally { captureBusy = false; }
}
const LOOK_PROMPT = '这是用户电脑屏幕的截图。用简体中文、100 字以内，说清楚用户此刻大概在做什么：开着什么软件或网页、在看或在做的内容是什么（比如在写什么作业、看什么视频、玩什么游戏、听什么歌）。画面角落里那个紫色长发的动漫女孩是桌面宠物本身，不用描述她。不要抄写聊天记录的原话、账号、金额、地址、密码这类隐私，只概括。';
module.exports = { capture, prepare, stop, blockedBy, DEFAULT_BLOCK, LOOK_PROMPT };
