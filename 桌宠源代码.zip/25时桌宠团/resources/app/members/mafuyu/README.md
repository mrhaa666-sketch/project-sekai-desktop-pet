# 真冬桌宠（源码）

需要先装 Node.js（18 以上）。在这个文件夹里打开命令行：

    npm install electron@33
    npx electron .

## 文件
- src/lines.js    台词；表情代号表（FACES）；心情 → 表情代号（MOODS）；动作 → 身体动作（ACTIONS）
- src/model/faces/  67 个表情（文件名保持英文，代号和文件名的对应在 lines.js 的 FACES 里；没有眼睛高光的已删除）
- 表情代号对照.png / .txt  每个代号长什么样、对应的原文件名
- src/renderer.js 动画、点击、拖动、提醒气泡、聊天框
- src/model_casual/  常服模型（和 src/model/ 校服模型的结构一样，动作文件名也一样）
- src/jianpu.js   简谱解析、钢琴音色合成（直接算每个音的泛音）、导出 WAV / MIDI
- src/synth.html / synth.js  合成器窗口
- memory.js       长期记忆和资料库：调用 /embeddings 算向量，本地存 memory.json，余弦相似度检索；切段导入资料
- src/memory.html / memory.js  “她的记忆”窗口
- affection.js    好感值（affection.json，模型给 delta，单次/每日上限）和心情余韵（半衰期回落）
- src/affection.html / affection.js  好感调试窗口
- dnd.js          免打扰：Windows 上用常驻 PowerShell 查询 SHQueryUserNotificationState 和前台窗口是否全屏
- screen.js       看屏幕：desktopCapturer 截图（只在内存里）、“不看”名单、给看图模型的描述要求
- llm.js          聊天请求：OpenAI 兼容 / Claude / Gemini 三种接口，统一成同一种结果；读取模型列表
- brain.js        聊天大脑：拼提示词、记对话，默认人设也在这里；开语音时让它同时给出日语
- asr.js          语音识别：OpenAI 兼容的 /audio/transcriptions（默认硅基流动 SenseVoice），分段识别、过滤无效结果
- src/call.js     语音通话：说话检测、轮流对话、按句配音与字幕、停止/静音/挂断、过期结果丢弃
- src/vad-worklet.js 把麦克风声音切成 20ms 一帧
- voice.js        语音：把日语交给 MiniMax（T2A v2）用你的音色 ID 念出来，结果缓存在本地；心情 → 语气的对照也在这里
- main.js         窗口、托盘菜单、提醒计时、设置
- src/model/      模型

## 自己接 AI
最简单：右键她 → 设置，填 API 地址、密钥、模型名，就能聊天。

想换成别的做法（本地模型、语音、加记忆等），只改 brain.js 里的 chat() 就行。
它收到：{ text: 你说的话, moods: {心情: 说明}, actions: {动作: 说明} }
它要返回：{ reply: "她说的话", mood: "心情", action: "动作", face: "表情代号（可省略）" }
face 填了有效代号就优先用它，否则按 mood 挑。
出错时返回 { error: "原因" }，没配置时返回 { error: "noapi" }。
mood / action / face 不在列表里时，桌宠会自动用 calm / none / 按心情挑。

## 语音（MiniMax）
设置里开启语音，填 MiniMax 密钥和音色 ID。流程：
聊天模型回复 { reply: 中文, ja: 日语, mood, ... } → voice.js 把 ja 交给 MiniMax → 桌宠播放并按音量对口型（参数 ParamMouthOpenY）。
固定台词的日语写在 src/lines.js 每句的 ja 里；每句第一次念时合成，之后读缓存（缓存在用户数据文件夹的 voice-cache 里）。

## 动作的来源
src/lines.js 里 ACTIONS 用到的身体动作，取自游戏剧情数据：统计了 25 时主线（21 集）和 25 时活动剧情（189 集）里，
真冬在只有 25 时成员的场景中实际做过的动作（以歪头、点头、害羞、手按胸口、为难、叹气、低落、摇头为主）。
营业假笑配的是她在外人面前带笑时用的动作（normal01 / adult02 的点头、歪头）。打瞌睡（adult15-sleep）是桌宠专用，剧情里没有。

## 语音通话（第一版：轮流对话）
你说话 → 说话检测（能量 + 自适应环境噪声，停顿超过设定时长算说完，太短的不提交，有单句上限）
→ asr.js 分段识别 → brain.js 以通话格式回复 { segments: [{ ja, zh }], mood, intensity, action, face }
→ 每句 ja 交给 voice.js 合成（下一句在上一句播放时就开始合成）→ 那句真正开始播放时显示对应的 zh 字幕。
- 通话和文字聊天共用同一份对话记录、同样的字段（reply = 中文、ja = 日语）；通话的记录带 via: "call"。
- 每次通话、每一轮都有编号；停止、挂断时取消还没回来的请求，迟到的结果因为编号对不上直接丢弃，也不会记进对话。
- 被打断的回复会在对话记录里标上 interrupted（说到第几句），模型下一轮就知道你没听完。
- 半双工：她说话、识别中、思考中都不收声，避免把她自己的声音当成输入；打断用“停止”按钮或“按住说话”。
- 各环节耗时（不含内容）写在用户数据文件夹的 call-timing.log。
以后再做：开口直接打断（需要可靠的回声消除）、流式识别和流式输出、逐字字幕对齐。

## 根据曲子写歌词（硅基流动）
- `lyrics.js`：主进程，写词窗口与硅基流动接口（/models、/chat/completions 流式、听曲用 audio_url、/audio/transcriptions），超时与取消
- `preload-lyrics.js`、`src/lyrics.html`、`src/lyrics-ui.js`：写词窗口
- `src/lyrics-analysis.js`：曲子分析（音频：频谱/节拍/段落/调性；合成器作品：读取简谱数据），`src/lyrics-worker.js` 在后台线程里跑音频分析
- 合成器入口：`src/synth.js` 的“为这首写歌词…”按钮 → `synth-to-lyrics`
- 离线检查：在本目录执行 `node --test test/*.test.js`（插件系统回归 + 写词分析，不联网）

## 发言上下文规则

实际发言按原有 JSONL 格式保存在本机；待机自言自语单独标为“待机”，点击及其他固定反应标为“被点到/反应”。请求模型时，补充上下文使用本地月日与时分、中文来源及可选标签，每条一行，不再重复附带日语译文。最多读取最近100条、合计约15000字符；超长条目只保留结尾并标注“……”。已在本次聊天历史中的回复、通话继续去重；标签含“出错”的新旧提示均不作为角色发言。聊天历史格式、人设和 memoryTurns 规则不变。
