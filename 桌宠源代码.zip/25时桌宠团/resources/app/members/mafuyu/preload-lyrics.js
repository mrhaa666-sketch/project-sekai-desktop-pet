// 写词窗口：只暴露写词需要的接口（密钥不会传到页面）
const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('lyricsAPI', {
  config: () => ipcRenderer.invoke('lyrics-config'),
  run: (kind, payload) => ipcRenderer.invoke('lyrics-run', { kind, payload }),
  cancel: (id) => ipcRenderer.send('lyrics-cancel', id),
  onProgress: (cb) => ipcRenderer.on('lyrics-progress', (_e, v) => cb(v)),
  onSource: (cb) => ipcRenderer.on('lyrics-source', (_e, v) => cb(v)),
  synthCurrent: () => ipcRenderer.invoke('lyrics-synth-current'),
  copy: (text) => ipcRenderer.invoke('lyrics-copy', text),
  save: (v) => ipcRenderer.invoke('lyrics-save', v),
  openSettings: () => ipcRenderer.send('lyrics-open-settings'),
  done: (title) => ipcRenderer.send('lyrics-done', title),
});
