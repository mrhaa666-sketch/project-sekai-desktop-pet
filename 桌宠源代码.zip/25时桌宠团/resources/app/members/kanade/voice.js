const { cleanKey, keyIssue } = require('./llm');
// 语音：把日语台词交给 MiniMax 语音合成（T2A v2），用你的音色 ID 念出来。
// 同一句话（同音色、同语气）只合成一次，之后从本地缓存读，不再花钱。
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

// 心情 → MiniMax 的语气（emotion）。没写的心情就用 calm。
const MOOD_EMOTION = {
  calm: 'calm', soft: 'calm', warm: 'calm', shy: 'calm', think: 'calm', sleepy: 'calm',
  sad: 'sad', hurt: 'sad', troubled: 'sad',
  surprised: 'surprised', flustered: 'surprised',
  sulky: 'disgusted', angry: 'angry',
  mask: 'calm',             // 兼容旧心情字段，奏用平静回应
};

const ERR = {
  1001: '超时', 1002: '请求太频繁', 1004: '密钥不对或没有权限',
  1039: '请求太频繁', 1042: '文本里无效字符太多', 2013: '参数不对（检查音色 ID 和模型名）',
};

class Voice {
  constructor(cacheDir) {
    this.cacheDir = cacheDir;
    try { fs.mkdirSync(cacheDir, { recursive: true }); } catch (e) {}
  }

  // 返回 { audio: base64 的 mp3 } 或 { error }
  // opts.words：要不要逐字时间点（通话时用来让日语字幕跟着念到的位置亮起来）
  async speak(cfg, text, mood, signal, opts = {}) {
    if (signal && signal.aborted) return { error: 'aborted' };
    if (!cfg.ttsKey || !cfg.ttsVoiceId) return { error: 'novoice' };
    text = String(text || '').trim();
    if (!text) return { error: '没有要念的日语' };
    const model = cfg.ttsModel || 'speech-2.8-hd';
    const emotion = cfg.ttsEmotion === false ? '' : (MOOD_EMOTION[mood] || 'calm');
    const speed = Number(cfg.ttsSpeed) || 1;
    const key = crypto.createHash('sha1').update(JSON.stringify([(cfg.ttsBase || 'https://api.minimaxi.com').replace(/\/+$/, ''), String(cfg.ttsGroupId || ''), cleanKey(cfg.ttsKey), cfg.ttsVoiceId, model, emotion, speed, text])).digest('hex');
    const file = path.join(this.cacheDir, key + '.mp3');
    const wfile = path.join(this.cacheDir, key + '.words.json');
    if (fs.existsSync(file) && (!opts.words || fs.existsSync(wfile))) {
      const out = { audio: fs.readFileSync(file).toString('base64'), cached: true };
      if (opts.words) { try { out.words = JSON.parse(fs.readFileSync(wfile, 'utf8')); } catch (e) {} }
      return out;
    }

    let url = (cfg.ttsBase || 'https://api.minimaxi.com').replace(/\/+$/, '') + '/v1/t2a_v2';
    if (cfg.ttsGroupId) url += '?GroupId=' + encodeURIComponent(cfg.ttsGroupId);
    const voice_setting = { voice_id: cfg.ttsVoiceId, speed, vol: 1, pitch: 0 };
    if (emotion) voice_setting.emotion = emotion;

    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 40000);
    const abort = () => ctrl.abort();
    if (signal) { signal.addEventListener('abort', abort, { once: true }); if (signal.aborted) abort(); }
    let data;
    try {
      { const ki = keyIssue(cfg.ttsKey, 'MiniMax 密钥'); if (ki) return { error: ki }; }
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${cleanKey(cfg.ttsKey)}` },
        body: JSON.stringify({
          model, text, stream: false,
          language_boost: 'Japanese',
          output_format: 'hex',
          voice_setting,
          audio_setting: { sample_rate: 32000, bitrate: 128000, format: 'mp3', channel: 1 },
          ...(opts.words ? { subtitle_enable: true, subtitle_type: 'word' } : {}),
        }),
        signal: ctrl.signal,
      });
      if (!res.ok) return { error: `语音 ${res.status} ${(await res.text().catch(() => '')).slice(0, 100)}` };
      data = await res.json();
    } catch (e) {
      if (signal && signal.aborted) return { error: 'aborted' };
      return { error: e.name === 'AbortError' ? '语音合成等太久了' : '连不上语音服务：' + e.message };
    } finally {
      clearTimeout(timer);
      if (signal) signal.removeEventListener('abort', abort);
    }

    if (signal && signal.aborted) return { error: 'aborted' };
    if (ctrl.signal.aborted) return { error: '语音合成等太久了' };
    const code = data?.base_resp?.status_code;
    if (code) return { error: `语音 ${code} ${ERR[code] || ''} ${data.base_resp.status_msg || ''}`.trim() };
    const hex = data?.data?.audio;
    if (!hex) return { error: '语音回复里没有声音' };
    const buf = Buffer.from(hex, 'hex');
    try { fs.writeFileSync(file, buf); } catch (e) {}
    const out = { audio: buf.toString('base64') };
    if (opts.words) {
      // 逐字时间点在单独的字幕文件里；拿不到就算了（字幕按句显示）
      out.words = await fetchWords(data?.data?.subtitle_file, signal);
      if (signal && signal.aborted) return { error: 'aborted' };
      try { fs.writeFileSync(wfile, JSON.stringify(out.words || [])); } catch (e) {}
    }
    return out;
  }

  clearCache() {
    try { for (const f of fs.readdirSync(this.cacheDir)) fs.unlinkSync(path.join(this.cacheDir, f)); } catch (e) {}
  }
}

// 下载并整理字幕文件：返回 [{ b: 开始字符位置, e: 结束字符位置, t0: 开始毫秒, t1: 结束毫秒 }]
async function fetchWords(url, signal) {
  if (!url || (signal && signal.aborted)) return [];
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 6000);
  const abort = () => ctrl.abort();
    if (signal) { signal.addEventListener('abort', abort, { once: true }); if (signal.aborted) abort(); }
  try {
    const res = await fetch(url, { signal: ctrl.signal });
    if (!res.ok) return [];
    const data = await res.json();
    return ctrl.signal.aborted ? [] : parseWords(data);
  } catch (e) { return []; } finally { clearTimeout(timer); if (signal) signal.removeEventListener('abort', abort); }
}
function parseWords(j) {
  const entries = Array.isArray(j) ? j : Array.isArray(j?.subtitles) ? j.subtitles : Array.isArray(j?.data?.subtitles) ? j.data.subtitles : j && (j.timestamped_words || j.text) ? [j] : [];
  const words = [];
  for (const s of entries) {
    if (Array.isArray(s.timestamped_words) && s.timestamped_words.length) {
      for (const w of s.timestamped_words) {
        if (Number.isFinite(+w.time_begin) && Number.isFinite(+w.word_begin)) words.push({ b: +w.word_begin, e: +(w.word_end ?? w.word_begin + 1), t0: +w.time_begin, t1: +(w.time_end ?? w.time_begin) });
      }
    } else if (Number.isFinite(+s.time_begin) && Number.isFinite(+s.text_begin)) {
      words.push({ b: +s.text_begin, e: +(s.text_end ?? s.text_begin), t0: +s.time_begin, t1: +(s.time_end ?? s.time_begin) });   // 只有整句时间
    }
  }
  return words.sort((a, b) => a.t0 - b.t0);
}

module.exports = { Voice, MOOD_EMOTION, parseWords };
