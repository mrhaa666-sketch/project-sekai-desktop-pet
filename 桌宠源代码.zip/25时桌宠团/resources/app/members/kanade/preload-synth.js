const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('synthAPI', {
  list: () => ipcRenderer.invoke('synth-list'),
  save: (v) => ipcRenderer.invoke('synth-save', v),
  remove: (name) => ipcRenderer.invoke('synth-remove', name),
  exportFile: (v) => ipcRenderer.invoke('synth-export', v),
  played: (title, mine) => ipcRenderer.send('synth-played', title, mine),
  compose: (hint) => ipcRenderer.invoke('synth-compose', hint),
  onStatus: (cb) => ipcRenderer.on('synth-status', (_e, v) => cb(v)),
  onLoad: (cb) => ipcRenderer.on('synth-load', (_e, v) => cb(v)),
});
