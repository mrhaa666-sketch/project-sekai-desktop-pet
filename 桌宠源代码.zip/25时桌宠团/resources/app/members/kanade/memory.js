const { cleanKey, keyIssue } = require('./llm');
// 长期记忆 + 资料库（向量存储）
// 每条记忆/资料存一段文字和它的向量（embedding）。聊天前，用你这句话的向量去找最相关的几条，附在消息末尾告诉她。
// 向量用 OpenAI 兼容的 /embeddings 接口算（默认硅基流动 BAAI/bge-m3）。全部存在本机 userData/memory.json
const fs = require('fs');
const path = require('path');

const toB64 = (f32) => Buffer.from(f32.buffer, f32.byteOffset, f32.byteLength).toString('base64');
const fromB64 = (s) => { const b = Buffer.from(s, 'base64'); return new Float32Array(b.buffer, b.byteOffset, b.byteLength / 4).slice(); };
function normalize(v) {
  let n = 0; for (let i = 0; i < v.length; i++) n += v[i] * v[i];
  n = Math.sqrt(n) || 1;
  const out = new Float32Array(v.length); for (let i = 0; i < v.length; i++) out[i] = v[i] / n;
  return out;
}
function dot(a, b) { let s = 0; const n = Math.min(a.length, b.length); for (let i = 0; i < n; i++) s += a[i] * b[i]; return s; }
const newId = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);

// 把长文切成小段（按段落、句子，每段大约 maxLen 字，相邻两段有一点重叠）
function chunk(text, maxLen = 320, overlap = 40) {
  const paras = String(text).replace(/\r/g, '').split(/\n\s*\n+/).map((p) => p.trim()).filter(Boolean);
  const out = [];
  for (const p of paras) {
    if (p.length <= maxLen) { out.push(p); continue; }
    const sents = p.match(/[^。！？!?\n.]+[。！？!?.]*\n?|\n/g) || [p];
    let cur = '';
    for (const s of sents) {
      if ((cur + s).length > maxLen && cur) { out.push(cur.trim()); cur = cur.slice(-overlap); }
      cur += s;
      while (cur.length > maxLen * 1.5) { out.push(cur.slice(0, maxLen).trim()); cur = cur.slice(maxLen - overlap); }
    }
    if (cur.trim()) out.push(cur.trim());
  }
  // 太短的段落和下一段合并
  const merged = [];
  for (const c of out) {
    if (merged.length && merged[merged.length - 1].length + c.length < maxLen * 0.6) merged[merged.length - 1] += '\n' + c;
    else merged.push(c);
  }
  return merged.filter((c) => c.length >= 4);
}

class Memory {
  constructor(file, getCfg) {
    this.file = file;
    this.epochs = { memory: 0, knowledge: 0 };
    this.getCfg = getCfg;     // 返回当前设置（embedding 地址、密钥、模型）
    this.items = [];          // { id, kind: 'memory'|'knowledge', text, source, at, model, vec(Float32Array) }
    this.load();
  }

  load() {
    try {
      const j = JSON.parse(fs.readFileSync(this.file, 'utf8'));
      this.items = (j.items || []).map((x) => ({ ...x, vec: x.vec ? fromB64(x.vec) : null }));
    } catch (e) { this.items = []; }
  }
  save() {
    try {
      fs.mkdirSync(path.dirname(this.file), { recursive: true });
      const tmp = this.file + '.tmp';
      fs.writeFileSync(tmp, JSON.stringify({ version: 1, items: this.items.map((x) => ({ ...x, vec: x.vec ? toB64(x.vec) : null })) }));
      fs.renameSync(tmp, this.file);
    } catch (e) {}
  }

  cfg() {
    const s = this.getCfg();
    return {
      on: s.memoryEnabled !== false,
      base: String(s.embBase || 'https://api.siliconflow.cn/v1').trim().replace(/\/+$/, ''),
      key: cleanKey(s.embKey || s.asrKey || ''),
      keyLabel: s.embKey ? '长期记忆的 embedding 密钥' : '语音识别 API 密钥（长期记忆借用了它）',    // 没单独填就用语音识别的密钥（默认都是硅基流动）
      model: String(s.embModel || 'BAAI/bge-m3').trim(),
      topK: Math.max(1, Math.min(10, +s.memoryTopK || 5)),
      // 相关度门槛（bge-m3 的经验值：明显相关一般在 0.55 以上，不相关多在 0.45 以下）
      min: Number.isFinite(+s.memoryMinScore) && s.memoryMinScore !== '' && s.memoryMinScore != null ? +s.memoryMinScore : 0.45,
      dup: Number.isFinite(+s.memoryDupScore) && s.memoryDupScore != null ? +s.memoryDupScore : 0.88,   // 超过这个就算同一件事
    };
  }
  epoch(kind) { return this.epochs[kind] || 0; }
  ready() { const c = this.cfg(); return c.on && !!c.key; }

  // 算向量：一次最多 32 段
  async embed(texts, { timeout = 15000 } = {}) {
    const c = this.cfg();
    if (!c.key) throw new Error('还没填 embedding 的 API 密钥');
    const ki = keyIssue(c.key, c.keyLabel);
    if (ki) throw new Error(ki);
    const url = /\/embeddings$/.test(c.base) ? c.base : c.base + '/embeddings';
    const out = [];
    for (let i = 0; i < texts.length; i += 32) {
      const batch = texts.slice(i, i + 32).map((t) => String(t).slice(0, 2000));
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${c.key}` },
        body: JSON.stringify({ model: c.model, input: batch, encoding_format: 'float' }),
        signal: AbortSignal.timeout(timeout),
      });
      if (!res.ok) {
        const body = await res.text().catch(() => '');
        const hint = { 401: 'API 密钥不对', 402: '余额不足', 403: '没有权限', 404: '地址或模型名不对', 429: '请求太频繁' }[res.status] || '';
        throw new Error(`${res.status} ${hint} ${body.slice(0, 100)}`.trim());
      }
      const j = await res.json();
      const data = (j.data || []).slice().sort((a, b) => (a.index ?? 0) - (b.index ?? 0));
      if (data.length !== batch.length) throw new Error('返回的向量数量不对');
      for (const d of data) out.push(normalize(Float32Array.from(d.embedding)));
    }
    return out;
  }

  // 找最相关的几条。kind 不填就两种都找
  search(qvec, { k = 5, kind, min = 0 } = {}) {
    const model = this.cfg().model;
    const scored = [];
    for (const it of this.items) {
      if (!it.vec || it.model !== model || (kind && it.kind !== kind)) continue;
      scored.push({ it, score: dot(qvec, it.vec) });
    }
    scored.sort((a, b) => b.score - a.score);
    return scored.filter((x) => x.score >= min).slice(0, k);
  }

  // 聊天前用：返回要附在消息末尾的文字（找不到或出错就返回空）
  async recall(text, { timeout = 2500 } = {}) {
    if (!this.ready() || !this.items.length || !String(text || '').trim()) return '';
    try {
      const [q] = await this.embed([text], { timeout });
      const c = this.cfg();
      const mem = this.search(q, { k: c.topK, kind: 'memory', min: c.min });
      const kno = this.search(q, { k: 3, kind: 'knowledge', min: c.min + 0.03 });
      const parts = [];
      if (mem.length) {
        const d = (ms) => { const x = new Date(ms); return `${x.getMonth() + 1}月${x.getDate()}日`; };
        parts.push('你记得的事：' + mem.map((m) => `（${d(m.it.at)}）${m.it.text}`).join('；'));
      }
      if (kno.length) parts.push('资料里相关的内容：' + kno.map((m) => `《${m.it.source || '资料'}》${m.it.text.replace(/\s+/g, ' ')}`).join(' '));
      this.lastRecall = { at: Date.now(), mem: mem.map((m) => ({ text: m.it.text, score: +m.score.toFixed(3) })), kno: kno.map((m) => ({ text: m.it.text.slice(0, 60), score: +m.score.toFixed(3) })) };
      return parts.join('\n');
    } catch (e) {
      this.lastError = e.message;
      return '';
    }
  }

  // 记下新的事。和已有记忆很像（同一件事）时就更新那一条，不重复记
  async remember(texts, { source = '聊天', epoch = this.epoch('memory') } = {}) {
    texts = (texts || []).map((t) => String(t || '').trim()).filter((t) => t.length >= 4 && t.length <= 200).slice(0, 5);
    if (!texts.length || !this.ready() || epoch !== this.epoch('memory')) return [];
    const model = this.cfg().model;
    let vecs;
    try { vecs = await this.embed(texts); } catch (e) { this.lastError = e.message; return []; }
    if (epoch !== this.epoch('memory') || model !== this.cfg().model) return [];
    const added = [];
    texts.forEach((t, i) => {
      const [hit] = this.search(vecs[i], { k: 1, kind: 'memory' });
      if (hit && hit.score >= this.cfg().dup) {
        hit.it.text = t; hit.it.vec = vecs[i]; hit.it.at = Date.now();   // 同一件事：用新的说法
        added.push({ ...hit.it, vec: undefined, updated: true });
      } else {
        const it = { id: newId(), kind: 'memory', text: t, source, at: Date.now(), model, vec: vecs[i] };
        this.items.push(it);
        added.push({ ...it, vec: undefined });
      }
    });
    this.save();
    return added;
  }

  // 记忆管理页用的操作
  list(kind) {
    return this.items.filter((x) => !kind || x.kind === kind).map(({ vec, ...x }) => ({ ...x, stale: !vec || x.model !== this.cfg().model }))
      .sort((a, b) => b.at - a.at);
  }
  async addManual(text, kind = 'memory') {
    const epoch = this.epoch(kind), model = this.cfg().model;
    text = String(text || '').trim();
    if (!text) return { error: '内容是空的' };
    const [v] = await this.embed([text]);
    if (epoch !== this.epoch(kind) || model !== this.cfg().model) return { error: '操作已取消，请重试' };
    const it = { id: newId(), kind, text: text.slice(0, 2000), source: kind === 'memory' ? '手动添加' : '手动添加', at: Date.now(), model: this.cfg().model, vec: v };
    this.items.push(it); this.save();
    return { ok: true };
  }
  async edit(id, text) {
    const it = this.items.find((x) => x.id === id);
    if (!it) return { error: '找不到这一条' };
    const epoch = this.epoch(it.kind), model = this.cfg().model;
    text = String(text || '').trim();
    if (!text) return { error: '内容是空的' };
    const [v] = await this.embed([text]);
    if (epoch !== this.epoch(it.kind) || model !== this.cfg().model || !this.items.includes(it)) return { error: '操作已取消，请重试' };
    it.text = text; it.vec = v; it.model = this.cfg().model; it.at = Date.now();
    this.save();
    return { ok: true };
  }
  remove(id) { const it = this.items.find(x => x.id === id); if (it) this.epochs[it.kind] = this.epoch(it.kind) + 1; this.items = this.items.filter((x) => x.id !== id); this.save(); return { ok: true }; }
  removeSource(source) { this.epochs.knowledge++; this.items = this.items.filter((x) => !(x.kind === 'knowledge' && x.source === source)); this.save(); return { ok: true }; }
  clear(kind) {
    for (const k of ['memory', 'knowledge']) if (!kind || k === kind) this.epochs[k]++;
    this.items = kind ? this.items.filter(x => x.kind !== kind) : [];
    this.save(); return { ok: true };
  }

  // 导入资料（txt / md）：切段、算向量
  async importText(source, text, onProgress) {
    const epoch = this.epoch('knowledge');
    const parts = chunk(text);
    if (!parts.length) return { error: '文件里没有文字' };
    if (parts.length > 2000) return { error: `太长了（切出 ${parts.length} 段），请拆成几个文件` };
    // 先把新资料的向量全部算好，放在一边；全部成功后才替换旧资料。中途失败就保留旧资料，什么都不改
    const model = this.cfg().model, fresh = [];
    for (let i = 0; i < parts.length; i += 32) {
      const vecs = await this.embed(parts.slice(i, i + 32));
      if (epoch !== this.epoch('knowledge') || model !== this.cfg().model) return { error: '操作已取消，请重试' };
      vecs.forEach((v, k) => fresh.push({ id: newId(), kind: 'knowledge', text: parts[i + k], source, at: Date.now(), model, vec: v }));
      onProgress && onProgress(Math.min(parts.length, i + 32), parts.length);
    }
    if (epoch !== this.epoch('knowledge') || model !== this.cfg().model) return { error: '操作已取消，请重试' };
    // 同名资料重新导入：一次性替换并保存
    this.items = this.items.filter((x) => !(x.kind === 'knowledge' && x.source === source)).concat(fresh);
    this.save();
    return { ok: true, chunks: parts.length };
  }


  // 换了 embedding 模型后，全部重新算
  async reembed(onProgress) {
    const todo = this.items.slice(), epochs = { ...this.epochs }, model = this.cfg().model;
    for (let i = 0; i < todo.length; i += 32) {
      const vecs = await this.embed(todo.slice(i, i + 32).map((x) => x.text));
      if (model !== this.cfg().model) return { error: '模型已改变，请重试' };
      vecs.forEach((v, k) => { const it = todo[i + k]; if (this.items.includes(it) && epochs[it.kind] === this.epoch(it.kind)) { it.vec = v; it.model = model; } });
      onProgress && onProgress(Math.min(todo.length, i + 32), todo.length);
    }
    this.save();
    return { ok: true, count: todo.length };
  }

  async semanticSearch(text, kind) {
    const [q] = await this.embed([text]);
    return this.search(q, { k: 20, kind }).map(({ it, score }) => ({ id: it.id, score: +score.toFixed(3) }));
  }

  stats() {
    const m = this.cfg().model;
    return {
      memory: this.items.filter((x) => x.kind === 'memory').length,
      knowledge: this.items.filter((x) => x.kind === 'knowledge').length,
      sources: [...new Set(this.items.filter((x) => x.kind === 'knowledge').map((x) => x.source))].length,
      stale: this.items.filter((x) => !x.vec || x.model !== m).length,
    };
  }
}

module.exports = { Memory, chunk };
