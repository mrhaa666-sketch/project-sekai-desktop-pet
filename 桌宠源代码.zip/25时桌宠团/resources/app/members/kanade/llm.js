// 聊天模型的统一请求：OpenAI 兼容格式（DeepSeek、硅基流动、Kimi、通义、智谱、Ollama…）、Claude、Gemini
// 返回统一成 { choices: [{ message: { content, reasoning_content } }] }，后面的解析不用管是哪家

const TYPES = { openai: 'OpenAI 兼容', anthropic: 'Claude', gemini: 'Gemini' };

// 没选接口类型时，按地址猜
function apiType(cfg) {
  if (TYPES[cfg.apiType]) return cfg.apiType;
  const b = cfg.apiBase || '';
  if (/anthropic\.com/i.test(b)) return 'anthropic';
  if (/generativelanguage\.googleapis\.com/i.test(b) && !/\/openai\/?$/i.test(b)) return 'gemini';
  return 'openai';
}

// 本机或局域网的模型（Ollama、LM Studio）一般不要密钥
function isLocal(base) {
  return /^https?:\/\/(localhost|127\.\d+\.\d+\.\d+|0\.0\.0\.0|\[::1\]|192\.168\.\d+\.\d+|10\.\d+\.\d+\.\d+|172\.(1[6-9]|2\d|3[01])\.\d+\.\d+)(:\d+)?(\/|$)/i.test(base || '');
}
// 密钥只能是英文字母、数字和符号。复制时常混进空格、换行、全角空格、看不见的零宽字符：这些自动去掉；
// 混进了中文或全角符号（比如把名字、说明文字粘了进去），请求头会报错，这时给出说得清楚的提示
function cleanKey(k) { return String(k || '').replace(/[\s\u3000\u200B-\u200D\u2060\uFEFF]+/g, ''); }
function keyIssue(k, label = 'API 密钥') {
  const bad = [...cleanKey(k)].find((c) => c.charCodeAt(0) < 0x21 || c.charCodeAt(0) > 0x7e);
  return bad ? `${label}里混进了“${bad}”这样的中文或全角字符，密钥只会是英文字母、数字和符号。请到平台上重新复制密钥，粘贴前先把输入框清空` : null;
}
function hasChatApi(cfg) { return !!(cfg.apiKey || isLocal(cfg.apiBase)); }

// 地址或模型名里有 deepseek 就算（用中转地址时也能认出来）
function isDeepSeek(url, model) { return /deepseek/i.test(url) || /deepseek/i.test(model); }

const trim = (s) => String(s || '').trim().replace(/\/+$/, '');

// Claude 要求 user / assistant 交替出现，而且第一条必须是 user：把连续同角色的合并
function alternate(messages) {
  const out = [];
  for (const m of messages) {
    const last = out[out.length - 1];
    if (last && last.role === m.role && typeof last.content === 'string' && typeof m.content === 'string') last.content += '\n\n' + m.content;
    else out.push({ role: m.role, content: m.content });
  }
  while (out.length && out[0].role !== 'user') out.shift();
  return out;
}

// 消息内容可以是文字，也可以是 [{type:'text', text}, {type:'image', mime, b64}]（看图用），按各家格式转换
function toOpenAI(c) {
  if (typeof c === 'string') return c;
  return c.map((p) => p.type === 'image' ? { type: 'image_url', image_url: { url: `data:${p.mime};base64,${p.b64}` } } : { type: 'text', text: p.text });
}
function toAnthropic(c) {
  if (typeof c === 'string') return c;
  return c.map((p) => p.type === 'image' ? { type: 'image', source: { type: 'base64', media_type: p.mime, data: p.b64 } } : { type: 'text', text: p.text });
}
function toGeminiParts(c) {
  if (typeof c === 'string') return [{ text: c }];
  return c.map((p) => p.type === 'image' ? { inline_data: { mime_type: p.mime, data: p.b64 } } : { text: p.text });
}

function build(cfg, { system, messages, stream, json, maxTokens }) {
  cfg = { ...cfg, apiKey: cleanKey(cfg.apiKey) };
  const type = apiType(cfg);
  const model = String(cfg.model || '').trim();
  const temp = cfg.temperature ?? 1.0;

  if (type === 'anthropic') {
    let base = trim(cfg.apiBase) || 'https://api.anthropic.com';
    const url = /\/messages$/i.test(base) ? base : base.replace(/\/v1$/i, '') + '/v1/messages';
    return {
      type, url,
      headers: { 'Content-Type': 'application/json', 'x-api-key': cfg.apiKey || '', 'anthropic-version': '2023-06-01' },
      body: { model, system, messages: alternate(messages).map((m) => ({ role: m.role, content: toAnthropic(m.content) })), max_tokens: maxTokens, temperature: Math.min(1, temp), ...(stream ? { stream: true } : {}) },
      delta: (j) => (j.type === 'content_block_delta' && j.delta && j.delta.type === 'text_delta' ? { text: j.delta.text } : {}),
      full: (j) => ({ content: (j.content || []).filter((b) => b.type === 'text').map((b) => b.text).join('') }),
    };
  }

  if (type === 'gemini') {
    const base = (trim(cfg.apiBase) || 'https://generativelanguage.googleapis.com').replace(/\/v1(beta)?$/i, '');
    const url = `${base}/v1beta/models/${encodeURIComponent(model)}:${stream ? 'streamGenerateContent?alt=sse' : 'generateContent'}`;
    const parts = (j) => {
      const ps = (j.candidates && j.candidates[0] && j.candidates[0].content && j.candidates[0].content.parts) || [];
      return { text: ps.filter((p) => !p.thought).map((p) => p.text || '').join(''), reasoning: ps.filter((p) => p.thought).map((p) => p.text || '').join('') };
    };
    return {
      type, url,
      headers: { 'Content-Type': 'application/json', 'x-goog-api-key': cfg.apiKey || '' },
      body: {
        systemInstruction: { parts: [{ text: system }] },
        contents: alternate(messages).map((m) => ({ role: m.role === 'assistant' ? 'model' : 'user', parts: toGeminiParts(m.content) })),
        // 新的 Gemini 会先思考，思考也算字数，所以额度给大一些
        generationConfig: { temperature: temp, maxOutputTokens: Math.max(maxTokens, 4096), ...(json ? { responseMimeType: 'application/json' } : {}) },
      },
      delta: parts,
      full: (j) => { const p = parts(j); return { content: p.text, reasoning_content: p.reasoning }; },
    };
  }

  // OpenAI 兼容
  const base = trim(cfg.apiBase) || 'https://api.deepseek.com';
  const url = /\/chat\/completions$/i.test(base) ? base : base + '/chat/completions';
  return {
    type, url,
    headers: { 'Content-Type': 'application/json', ...(cfg.apiKey ? { Authorization: `Bearer ${cfg.apiKey}` } : {}) },
    body: {
      model,
      messages: [{ role: 'system', content: system }, ...messages.map((m) => ({ role: m.role, content: toOpenAI(m.content) }))],
      ...(json ? { response_format: { type: 'json_object' } } : {}),
      temperature: temp,
      max_tokens: maxTokens,
      ...(stream ? { stream: true } : {}),
      // DeepSeek 的新模型默认会先「深度思考」：思考会占掉字数额度，回复变慢甚至是空的。聊天用不上，关掉
      ...(isDeepSeek(url, model) ? { thinking: { type: 'disabled' } } : {}),
    },
    delta: (j) => {
      const d = (j.choices && j.choices[0] && j.choices[0].delta) || {};
      return { text: d.content || '', reasoning: d.reasoning_content || d.reasoning || '' };
    },
    full: (j) => {
      const m = (j.choices && j.choices[0] && j.choices[0].message) || {};
      return { content: m.content || '', reasoning_content: m.reasoning_content || m.reasoning || '' };
    },
  };
}

const HINTS = {
  400: '请求不被接受（模型名可能不对）', 401: 'API 密钥不对', 402: '账户余额不足', 403: '没有权限（密钥或地区不支持）',
  404: '地址或模型名不对', 429: '请求太频繁或额度用完了', 500: '服务器出错了', 503: '服务器暂时不可用', 529: '服务器太忙了',
};

// 发请求。onText(累计文字) 只在流式时调用。出错时返回 { error }
async function request(cfg, { system, messages, stream, json = true, maxTokens = 1200, signal, onText }) {
  if (!String(cfg.model || '').trim()) return { error: '还没填模型名' };
  const ki = keyIssue(cfg.apiKey, cfg.keyLabel || '聊天模型的 API 密钥');
  if (ki) return { error: ki };
  let req = build(cfg, { system, messages, stream, json, maxTokens });
  let res = await fetch(req.url, { method: 'POST', headers: req.headers, body: JSON.stringify(req.body), signal });
  // 有的平台不认 JSON 模式：去掉再试一次（提示词里本来就要求了 JSON 格式）
  if (json && (res.status === 400 || res.status === 422)) {
    const body = await res.text().catch(() => '');
    if (/response_format|json|mime/i.test(body)) {
      req = build(cfg, { system, messages, stream, json: false, maxTokens });
      res = await fetch(req.url, { method: 'POST', headers: req.headers, body: JSON.stringify(req.body), signal });
    } else return { error: `${res.status} ${HINTS[400]} ${body.slice(0, 160)}`.trim() };
  }
  if (!res.ok) {
    const body = await res.text().catch(() => '');
    return { error: `${res.status} ${HINTS[res.status] || ''} ${body.slice(0, 160)}`.trim() };
  }
  if (!stream) {
    const j = await res.json();
    return { data: { choices: [{ message: req.full(j) }] } };
  }
  return { data: await readStream(res, req.delta, onText) };
}

// 读流式回复（SSE），每收到一段就把累计的内容交给 onText
async function readStream(res, delta, onText) {
  const reader = res.body.getReader();
  const dec = new TextDecoder();
  let buf = '', acc = '', reasoning = '';
  const line = (l) => {
    l = l.trim();
    if (!l.startsWith('data:')) return;
    const payload = l.slice(5).trim();
    if (!payload || payload === '[DONE]') return;
    try {
      const d = delta(JSON.parse(payload));
      if (d.reasoning) reasoning += d.reasoning;
      if (d.text) { acc += d.text; onText && onText(acc); }
    } catch (e) {}
  };
  for (;;) {
    const { value, done } = await reader.read();
    if (done) break;
    buf += dec.decode(value, { stream: true });
    let nl;
    while ((nl = buf.indexOf('\n')) >= 0) { line(buf.slice(0, nl)); buf = buf.slice(nl + 1); }
  }
  if (buf) line(buf);
  return { choices: [{ message: { content: acc, reasoning_content: reasoning } }] };
}

module.exports = { cleanKey, keyIssue, request, apiType, hasChatApi, isLocal, isDeepSeek, TYPES };

// 读取平台上能用的模型名，填模型名时用
async function listModels(cfg) {
  const ki = keyIssue(cfg.apiKey, cfg.keyLabel || '聊天模型的 API 密钥');
  if (ki) return { error: ki };
  cfg = { ...cfg, apiKey: cleanKey(cfg.apiKey) };
  const type = apiType(cfg);
  let url, headers = {};
  if (type === 'anthropic') {
    url = (trim(cfg.apiBase) || 'https://api.anthropic.com').replace(/\/v1(\/messages)?$/i, '') + '/v1/models?limit=100';
    headers = { 'x-api-key': cfg.apiKey || '', 'anthropic-version': '2023-06-01' };
  } else if (type === 'gemini') {
    url = (trim(cfg.apiBase) || 'https://generativelanguage.googleapis.com').replace(/\/v1(beta)?$/i, '') + '/v1beta/models?pageSize=200';
    headers = { 'x-goog-api-key': cfg.apiKey || '' };
  } else {
    url = (trim(cfg.apiBase) || 'https://api.deepseek.com').replace(/\/chat\/completions$/i, '') + '/models';
    if (cfg.apiKey) headers = { Authorization: `Bearer ${cfg.apiKey}` };
  }
  try {
    const res = await fetch(url, { headers, signal: AbortSignal.timeout(15000) });
    if (!res.ok) return { error: `${res.status} ${HINTS[res.status] || ''}`.trim() };
    const j = await res.json();
    let ids;
    if (type === 'gemini') ids = (j.models || []).filter((m) => !m.supportedGenerationMethods || m.supportedGenerationMethods.includes('generateContent')).map((m) => String(m.name || '').replace(/^models\//, ''));
    else ids = (j.data || j.models || []).map((m) => m.id || m.name || '');
    ids = [...new Set(ids.filter(Boolean))].sort();
    return { models: ids };
  } catch (e) {
    return { error: e.name === 'TimeoutError' ? '等太久没有回应' : '连不上：' + e.message };
  }
}
module.exports.listModels = listModels;

// 看图：让视觉模型把图片客观地描述出来（之后作为文字交给她），这样聊天模型不支持图片也没关系
async function describeImage(vcfg, { b64, mime, hint = '', system: sys = '' }) {
  const system = sys || '你是一个看图助手。用简体中文客观、具体地描述这张图片：画面里有什么、人物的样子和动作、文字（原样抄下来）、氛围和颜色。如果是截图，说明是什么软件或网页、在显示什么。如果是动漫或游戏角色、能认出来就说出名字。不要评价，不要寒暄，200 字以内。';
  const content = [{ type: 'image', mime, b64 }, { type: 'text', text: hint ? `发图的人还说了：「${hint}」。请描述这张图片。` : '请描述这张图片。' }];
  const r = await request(vcfg, { system, messages: [{ role: 'user', content }], json: false, maxTokens: 700, signal: AbortSignal.timeout(60000) });
  if (r.error) return r;
  const text = (r.data.choices[0].message.content || '').trim();
  return text ? { text } : { error: '看图模型没有回答' };
}
module.exports.describeImage = describeImage;
