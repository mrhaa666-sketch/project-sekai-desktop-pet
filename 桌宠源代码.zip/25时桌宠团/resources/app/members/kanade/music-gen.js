'use strict';
/* 生成纯音乐 / 纯伴奏（主进程）：窗口、作曲请求、保存
 *
 * 两种后端（设置 → 生成纯音乐 里选）：
 *  1. local（默认）：本地多轨合成。聊天模型（设置里的聊天 API，或单独指定的写谱模型）按要求写出 JSON 多轨乐谱，
 *     src/music-score.js 检查修正，src/music-synth.js 在生成窗口的后台线程（Web Worker）里用合成音源演奏、混音，导出 WAV。
 *     这是“多轨合成音乐”，不是专业的 AI 音频生成模型。
 *  2. minimax：MiniMax 官方音乐生成接口 POST {平台}/v1/music_generation，is_instrumental: true（官方文档：
 *     https://platform.minimax.io/docs/api-reference/music-generation）。用“语音”设置里的 MiniMax 密钥和平台，付费；
 *     官方接口没有时长和速度参数，纯伴奏只能写进描述里。
 * 密钥只在主进程使用，不发给页面，不写日志。只有用户在窗口里点“生成”才会请求。
 */
const path = require('path');
const fs = require('fs');
const { BrowserWindow, ipcMain, dialog, app } = require('electron');
const llm = require('./llm');
const MusicScore = require('./src/music-score.js');

const LIMITS = { minSec: 30, maxSec: 300, minBpm: 50, maxBpm: 180, maxPrompt: 800 };
const MINIMAX_MODELS = ['music-3.0', 'music-2.6'];
const MINIMAX_ERRORS = { 1002: '请求太频繁（1002），稍后再试', 1004: 'MiniMax 鉴权失败（1004），请检查“语音”设置里的 MiniMax API 密钥', 1008: 'MiniMax 账户余额不足（1008）', 1026: '描述里有被判定为敏感的内容（1026），请修改要求', 2013: '参数不被接受（2013），可能是模型名或描述长度不对', 2049: 'MiniMax API 密钥无效（2049）' };

class GenError extends Error { constructor(m, extra = {}) { super(m); Object.assign(this, extra); } }

function cleanReq(p = {}) {
  const mode = p.mode === 'accompaniment' ? 'accompaniment' : p.mode === 'music' ? 'music' : null;
  if (!mode) throw new GenError('请先选择“纯音乐”或“纯伴奏”');
  const prompt = String(p.prompt || '').trim().slice(0, LIMITS.maxPrompt);
  if (prompt.length < 2) throw new GenError('请先写下想要的曲子（主题、情绪、风格、乐器等）');
  const seconds = Math.round(Number(p.seconds));
  if (!(seconds >= LIMITS.minSec && seconds <= LIMITS.maxSec)) throw new GenError(`时长要在 ${LIMITS.minSec}–${LIMITS.maxSec} 秒之间`);
  let bpm = p.bpm == null || p.bpm === '' ? 0 : Math.round(Number(p.bpm));
  if (bpm && !(bpm >= LIMITS.minBpm && bpm <= LIMITS.maxBpm)) throw new GenError(`速度要在 ${LIMITS.minBpm}–${LIMITS.maxBpm} BPM 之间，或者选“自动”`);
  const beats = [3, 4].includes(+p.beats) ? +p.beats : 0;
  return { mode, prompt, seconds, bpm: bpm || 0, beats };
}

function chatCfg(s) {
  return { apiType: s.apiType || '', apiBase: s.apiBase, apiKey: s.apiKey, model: String(s.musicModel || s.model || '').trim(), temperature: 0.9, keyLabel: '聊天模型的 API 密钥' };
}

/* ---------- 后端 1：聊天模型写多轨乐谱 ---------- */
async function composeScore(s, req, { signal, onProgress }) {
  const cfg = chatCfg(s);
  if (!llm.hasChatApi(cfg)) throw new GenError('还没有设置聊天模型的 API（右键 → 设置 → 聊天模型）。本地多轨合成需要它来写乐谱。', { noConfig: true });
  if (!cfg.model) throw new GenError('还没有填写模型名（设置 → 聊天模型，或 生成纯音乐 → 写谱模型）', { noConfig: true });
  const pr = MusicScore.buildPrompt(req);
  let messages = [{ role: 'user', content: pr.user }];
  let last = null;
  for (let attempt = 1; attempt <= 2; attempt++) {
    onProgress({ stage: attempt === 1 ? 'compose' : 'revise', chars: 0 });
    let t = 0;
    const r = await llm.request(cfg, {
      system: pr.system, messages, stream: true, json: true, maxTokens: 7000, signal,
      onText: (acc) => { const now = Date.now(); if (now - t > 150) { t = now; onProgress({ stage: attempt === 1 ? 'compose' : 'revise', chars: acc.length }); } },
    }).catch((e) => { if (signal.aborted) throw signal.reason instanceof Error ? signal.reason : new GenError('已取消', { canceled: true }); return { error: '连接失败：' + (e.cause && e.cause.code || e.message) }; });
    if (signal.aborted) throw signal.reason instanceof Error ? signal.reason : new GenError('已取消', { canceled: true });
    if (r.error) throw new GenError('写谱模型出错：' + r.error);
    const text = r.data.choices[0].message.content || '';
    onProgress({ stage: 'check' });
    let raw;
    try { raw = MusicScore.extractJSON(text); }
    catch (e) { last = { errors: [e.message] }; messages = [...messages, { role: 'assistant', content: text.slice(0, 6000) }, { role: 'user', content: `${e.message}。请只输出一个完整的 JSON 对象。` }]; continue; }
    const n = MusicScore.normalize(raw, req);
    if (!n.errors.length) return { score: n.score, notes: n.notes, attempts: attempt };
    last = n;
    messages = [...messages, { role: 'assistant', content: JSON.stringify(raw).slice(0, 6000) }, { role: 'user', content: `这份乐谱有问题，请修改后重新输出完整 JSON：\n- ${n.errors.join('\n- ')}` }];
  }
  throw new GenError('模型两次都没有写出可用的乐谱：' + ((last && last.errors) || []).join('；'), { invalid: true });
}

/* ---------- 后端 2：MiniMax 音乐生成 ---------- */
function minimaxPrompt(req) {
  const acc = req.mode === 'accompaniment';
  const parts = [
    req.prompt,
    acc ? '纯伴奏（instrumental backing track）：以和声、节奏和配器为主，不要突出的主旋律，留出给旋律的空间。' : '纯音乐（instrumental）：有完整清晰的器乐主旋律。',
    '不要人声、歌词、哼唱或说话（no vocals, no lyrics, no humming, no speech）。',
    `有前奏、发展段落和完整的结尾，长度约 ${req.seconds} 秒${req.bpm ? `，速度约 ${req.bpm} BPM` : ''}${req.beats ? `，${req.beats}/4 拍` : ''}。`,
  ];
  return parts.join('\n').slice(0, 2000);
}
async function minimaxGenerate(s, req, { signal, onProgress }) {
  const key = llm.cleanKey(s.ttsKey);
  if (!key) throw new GenError('还没有填写 MiniMax API 密钥（右键 → 设置 → 语音）。MiniMax 后端用的是语音设置里的密钥和平台。', { noConfig: true });
  { const ki = llm.keyIssue(key, 'MiniMax API 密钥'); if (ki) throw new GenError(ki, { noConfig: true }); }
  const base = String(s.ttsBase || 'https://api.minimaxi.com').trim().replace(/\/+$/, '');
  const model = MINIMAX_MODELS.includes(s.musicMinimaxModel) ? s.musicMinimaxModel : MINIMAX_MODELS[0];
  onProgress({ stage: 'remote', model });
  let res;
  try {
    res = await fetch(base + '/v1/music_generation', {
      method: 'POST', signal,
      headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + key },
      body: JSON.stringify({ model, prompt: minimaxPrompt(req), is_instrumental: true, output_format: 'hex', audio_setting: { sample_rate: 44100, bitrate: 256000, format: 'mp3' } }),
    });
  } catch (e) {
    if (signal.aborted) throw signal.reason instanceof Error ? signal.reason : new GenError('已取消', { canceled: true });
    throw new GenError('连不上 MiniMax：' + (e.cause && e.cause.code || e.message));
  }
  const text = await res.text().catch(() => '');
  if (!res.ok) throw new GenError(`MiniMax 返回 ${res.status}：${text.slice(0, 160)}`);
  let j; try { j = JSON.parse(text); } catch (e) { throw new GenError('MiniMax 返回的内容不是 JSON', { invalid: true }); }
  const code = j && j.base_resp ? j.base_resp.status_code : -1;
  if (code !== 0) throw new GenError(MINIMAX_ERRORS[code] || `MiniMax 出错（${code}）：${String(j && j.base_resp && j.base_resp.status_msg || '').slice(0, 120)}`, { status: code });
  const hex = j.data && j.data.audio;
  if (!hex || typeof hex !== 'string' || !/^[0-9a-fA-F]+$/.test(hex.slice(0, 2000)) || hex.length < 2000) throw new GenError('MiniMax 没有返回音频数据（可能还在生成中或返回格式变了）', { invalid: true });
  const buf = Buffer.from(hex, 'hex');
  const isMp3 = (buf[0] === 0x49 && buf[1] === 0x44 && buf[2] === 0x33) || (buf[0] === 0xff && (buf[1] & 0xe0) === 0xe0);
  if (!isMp3) throw new GenError('MiniMax 返回的数据不是 MP3 音频', { invalid: true });
  const info = j.extra_info || {};
  return { bytes: buf, ext: 'mp3', model, info: { durationMs: Number(info.music_duration) || 0, sampleRate: info.music_sample_rate || 0, size: buf.length } };
}

/* ---------- 窗口和 IPC ---------- */
module.exports = function setupMusic({ getSettings, icon, appDir, sayLine }) {
  let win = null;
  const jobs = new Map();
  const send = (ch, v) => { if (win && !win.isDestroyed()) win.webContents.send(ch, v); };
  const fromWin = (e) => win && !win.isDestroyed() && e.sender === win.webContents;

  function open() {
    if (win && !win.isDestroyed()) { win.focus(); return win; }
    win = new BrowserWindow({
      width: 1000, height: 760, minWidth: 800, minHeight: 600, title: '奏桌宠 · 生成纯音乐 / 伴奏',
      icon, autoHideMenuBar: true, backgroundColor: '#f6f4f0',
      webPreferences: { preload: path.join(appDir, 'preload-music.js'), contextIsolation: true },
    });
    win.loadFile(path.join(appDir, 'src', 'music.html'));
    win.on('closed', () => { for (const j of jobs.values()) j.abort(new GenError('窗口关闭，已取消', { canceled: true })); jobs.clear(); win = null; });
    return win;
  }

  ipcMain.handle('music-config', () => {
    const s = getSettings(), cfg = chatCfg(s);
    return {
      backend: s.musicBackend === 'minimax' ? 'minimax' : 'local',
      chatReady: llm.hasChatApi(cfg) && !!cfg.model, chatModel: cfg.model, usesMusicModel: !!String(s.musicModel || '').trim(),
      minimaxReady: !!llm.cleanKey(s.ttsKey), minimaxModel: MINIMAX_MODELS.includes(s.musicMinimaxModel) ? s.musicMinimaxModel : MINIMAX_MODELS[0],
      minimaxBase: String(s.ttsBase || 'https://api.minimaxi.com'), timeoutSec: timeoutMs(s) / 1000, limits: LIMITS,
      instruments: MusicScore.INSTRUMENTS,
    };
  });
  let timeoutOverride = 0;   // 只给测试脚本用
  const timeoutMs = (s) => timeoutOverride || Math.max(60, Math.min(900, Number(s.musicTimeout) || 300)) * 1000;

  async function run(p, onProgress) {
    const id = String(p.id || Date.now());
    const s = getSettings();
    const ctl = new AbortController();
    const job = { abort: (why) => ctl.abort(why) };
    jobs.set(id, job);
    const t0 = Date.now();
    const tick = setInterval(() => onProgress({ id, stage: 'tick', elapsed: Math.round((Date.now() - t0) / 1000) }), 1000);
    const to = setTimeout(() => ctl.abort(new GenError(`超过 ${timeoutMs(s) / 1000} 秒没有完成，已停止（可以在设置里把超时调长）`, { timeout: true })), timeoutMs(s));
    try {
      const req = cleanReq(p);
      const prog = (x) => onProgress({ id, ...x, elapsed: Math.round((Date.now() - t0) / 1000) });
      if (s.musicBackend === 'minimax') {
        const r = await minimaxGenerate(s, req, { signal: ctl.signal, onProgress: prog });
        return { ok: true, backend: 'minimax', bytes: r.bytes, ext: r.ext, model: r.model, info: r.info, req };
      }
      const r = await composeScore(s, req, { signal: ctl.signal, onProgress: prog });
      return { ok: true, backend: 'local', score: r.score, notes: r.notes, attempts: r.attempts, model: chatCfg(s).model, req };
    } catch (e) {
      const ge = e instanceof GenError ? e : new GenError(ctl.signal.aborted ? '已取消' : String(e && e.message || e), { canceled: ctl.signal.aborted });
      return { error: ge.message, canceled: !!ge.canceled, timeout: !!ge.timeout, noConfig: !!ge.noConfig, invalid: !!ge.invalid };
    } finally { clearInterval(tick); clearTimeout(to); jobs.delete(id); }
  }

  ipcMain.handle('music-generate', (e, p = {}) => (fromWin(e) ? run(p, (x) => send('music-progress', x)) : { error: '只能在生成窗口里使用' }));
  ipcMain.on('music-cancel', (e, id) => { if (!fromWin(e)) return; const j = jobs.get(String(id)); if (j) j.abort(new GenError('已取消', { canceled: true })); });
  ipcMain.handle('music-save', async (e, { name, bytes, ext } = {}) => {
    if (!fromWin(e)) return { error: 'denied' };
    if (!bytes || !bytes.byteLength) return { error: '没有可以保存的音频' };
    const safe = (String(name || '奏的曲子').replace(/[\\/:*?"<>|\r\n]/g, '_').trim() || '奏的曲子').slice(0, 60);
    const x = ext === 'mp3' ? 'mp3' : 'wav';
    let dir; try { dir = app.getPath('music'); } catch (err) { dir = app.getPath('home'); }
    const r = await dialog.showSaveDialog(win, { title: '保存音频', defaultPath: path.join(dir, `${safe}.${x}`), filters: [{ name: x === 'mp3' ? 'MP3 音频' : 'WAV 音频', extensions: [x] }] });
    if (r.canceled || !r.filePath) return { canceled: true };
    try { fs.writeFileSync(r.filePath, Buffer.from(bytes)); }
    catch (err) { return { error: '保存失败：' + (err.code === 'EACCES' || err.code === 'EPERM' ? '没有写入权限，换个文件夹试试' : err.code === 'ENOSPC' ? '磁盘空间不够' : err.code === 'ENOENT' ? '保存位置的文件夹不存在' : err.message) }; }
    return { ok: true, path: r.filePath };
  });
  ipcMain.on('music-done', (e, { title } = {}) => {
    if (!fromWin(e)) return;
    sayLine(`……做好了${title ? '，《' + String(title).slice(0, 20) + '》' : ''}。没有歌词的曲子，你听听看。`, '……できた。歌のない曲。聴いてみて。', 'calm', 'nod');
  });
  return { open, _test: { run, cleanReq, minimaxPrompt, cancel: (id) => { const j = jobs.get(String(id)); if (j) j.abort(new GenError('已取消', { canceled: true })); }, setTimeoutMs: (ms) => { timeoutOverride = ms; } } };
};
module.exports.cleanReq = cleanReq;
module.exports.minimaxPrompt = minimaxPrompt;
module.exports.LIMITS = LIMITS;
module.exports.MINIMAX_MODELS = MINIMAX_MODELS;
