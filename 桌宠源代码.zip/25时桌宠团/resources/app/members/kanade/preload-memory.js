const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('memAPI', {
  list: (kind) => ipcRenderer.invoke('mem-list', kind),
  add: (v) => ipcRenderer.invoke('mem-add', v),
  edit: (v) => ipcRenderer.invoke('mem-edit', v),
  remove: (id) => ipcRenderer.invoke('mem-remove', id),
  removeSource: (s) => ipcRenderer.invoke('mem-remove-source', s),
  clear: (kind) => ipcRenderer.invoke('mem-clear', kind),
  search: (v) => ipcRenderer.invoke('mem-search', v),
  reembed: () => ipcRenderer.invoke('mem-reembed'),
  importFiles: () => ipcRenderer.invoke('mem-import'),
  onProgress: (cb) => ipcRenderer.on('mem-progress', (_e, v) => cb(v)),
  onChanged: (cb) => ipcRenderer.on('mem-changed', (_e, v) => cb(v)),
});
