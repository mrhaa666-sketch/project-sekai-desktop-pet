const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('affAPI', {
  info: () => ipcRenderer.invoke('aff-info'),
  set: (v) => ipcRenderer.invoke('aff-set', v),
  clearMood: () => ipcRenderer.invoke('aff-clear-mood'),
  saveCfg: (v) => ipcRenderer.invoke('aff-cfg', v),
  openFile: () => ipcRenderer.send('open-aff-file'),
  onChanged: (cb) => ipcRenderer.on('aff-changed', () => cb()),
});
