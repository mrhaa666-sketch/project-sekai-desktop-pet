// 生成纯音乐 / 伴奏窗口：只暴露这个窗口需要的接口（密钥不会传到页面）
const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('musicAPI', {
  config: () => ipcRenderer.invoke('music-config'),
  generate: (p) => ipcRenderer.invoke('music-generate', p),
  cancel: (id) => ipcRenderer.send('music-cancel', id),
  onProgress: (cb) => ipcRenderer.on('music-progress', (_e, v) => cb(v)),
  save: (v) => ipcRenderer.invoke('music-save', v),
  done: (v) => ipcRenderer.send('music-done', v),
  openSettings: () => ipcRenderer.send('music-open-settings'),
});
