'use strict';
/* 简谱解析 + 钢琴音色合成
   写法：
     1–7 音，0 休止，- 把前一个音延长一拍
     后面加 ' 高八度（可以叠加 1''），加 , 低八度（5,,）
     前面加 # 升半音，b 降半音
     后面加 _ 时值减半（1_ 半拍，1__ 四分之一拍），加 . 附点（×1.5）
     [135] 和弦（几个音同时按下），后面同样可以加 _ . -
     | 小节线（只是看着方便，不影响播放）
     开头写 1=C、1=bE、1=F#、4/4、♩=90（也可以写 速度=90 或 bpm=90）
     // 后面是注释
*/
(function (root) {
  const KEYS = { C: 0, D: 2, E: 4, F: 5, G: 7, A: 9, B: 11 };
  const DEG = [0, 0, 2, 4, 5, 7, 9, 11];   // 1–7 在大调里离主音几个半音

  // 全角符号、中文标点换成半角
  function normalize(s) {
    return s.replace(/[’‘＇′`´]/g, "'").replace(/[，、]/g, ',').replace(/[｜]/g, '|')
      .replace(/[—－–]/g, '-').replace(/[＿]/g, '_').replace(/[＃♯]/g, '#').replace(/[♭]/g, 'b')
      .replace(/[．·•]/g, '.').replace(/[［【]/g, '[').replace(/[］】]/g, ']').replace(/＝/g, '=')
      .replace(/[０-９]/g, (c) => String.fromCharCode(c.charCodeAt(0) - 0xfee0));
  }

  // 返回 { notes: [{t, dur, midi:[...], src:[start,end]}], bpm, key, beats, error }
  // t 和 dur 的单位是拍；src 是这个音在原文里的位置（播放时高亮用）
  function parse(text) {
    const raw = normalize(String(text || ''));
    let bpm = 90, tonic = 60, keyName = 'C', beats = 4;
    const notes = [];
    let t = 0, last = null;
    const bars = [];                // 每个小节线 | 出现时已经过了几拍（检查每小节拍数用）
    const err = (msg, pos) => ({ notes, bpm, key: keyName, tonic, beats, bars, error: { msg, pos } });

    // 先处理每行的注释和头部信息（换成空格，保持位置不变，方便高亮）
    let body = raw.replace(/\/\/[^\n]*/g, (m) => ' '.repeat(m.length));
    body = body.replace(/1\s*=\s*([#b]?)([A-Ga-g])([#b]?)/g, (m, a1, k, a2) => {
      const acc = (a1 || a2) === '#' ? 1 : (a1 || a2) === 'b' ? -1 : 0;
      tonic = 60 + KEYS[k.toUpperCase()] + acc;
      if (tonic > 66) tonic -= 12;                 // 主音放在中央 C 附近
      keyName = (acc === 1 ? '#' : acc === -1 ? 'b' : '') + k.toUpperCase();
      return ' '.repeat(m.length);
    });
    body = body.replace(/(?:♩|bpm|BPM|速度|拍速)\s*[=:：]?\s*(\d{2,3})/g, (m, n) => { bpm = Math.max(30, Math.min(240, +n)); return ' '.repeat(m.length); });
    body = body.replace(/(\d)\s*\/\s*(\d)/g, (m, a, b) => { beats = +a || 4; return ' '.repeat(m.length); });

    let i = 0;
    const n = body.length;
    while (i < n) {
      const c = body[i];
      if (c === '|') { if (!bars.length || bars[bars.length - 1] !== t) bars.push(t); i++; continue; }
      if (/\s/.test(c)) { i++; continue; }
      if (c === '-') {                           // 延长前一个音
        if (!last) return err('“-” 前面没有音可以延长', i);
        last.dur += 1; t += 1; i++; continue;
      }
      const start = i;
      let pitches = [];
      const readOne = () => {
        let acc = 0;
        while (body[i] === '#' || body[i] === 'b') { acc += body[i] === '#' ? 1 : -1; i++; }
        const d = body[i];
        if (!/[0-7]/.test(d)) return null;
        i++;
        let oct = 0;
        while (body[i] === "'" || body[i] === ',') { oct += body[i] === "'" ? 1 : -1; i++; }
        return d === '0' ? 'rest' : tonic + DEG[+d] + acc + oct * 12;
      };
      if (c === '[') {
        i++;
        while (i < n && body[i] !== ']') {
          if (/\s/.test(body[i])) { i++; continue; }
          const p = readOne();
          if (p === null) return err(`和弦里有看不懂的字符“${body[i] || '（结尾）'}”`, i);
          if (p !== 'rest') pitches.push(p);
        }
        if (body[i] !== ']') return err('和弦的 [ 没有配对的 ]', start);
        i++;
      } else {
        const p = readOne();
        if (p === null) return err(`看不懂“${c}”。音只能写 0–7，可以带 # b ' , _ . -`, start);
        if (p !== 'rest') pitches.push(p);
      }
      let dur = 1;
      while (body[i] === '_' || body[i] === '.') { dur *= body[i] === '_' ? 0.5 : 1.5; i++; }
      const note = { t, dur, midi: pitches, src: [start, i] };
      for (const m of pitches) if (m < 21 || m > 108) return err('这个音太高或太低了，钢琴弹不出来', start);
      notes.push(note);
      last = note; t += dur;
    }
    return { notes, bpm, key: keyName, tonic, beats, bars, total: t, error: null };
  }

  const freq = (m) => 440 * Math.pow(2, (m - 69) / 12);

  // 把整首曲子合成成一段声音（AudioBuffer）
  // 钢琴音色：每个音直接算出来——多个泛音、高泛音衰减更快、轻微的弦不协和、两根弦稍微走音的拍音、
  // 击弦噪声、按力度变亮；最后用 OfflineAudioContext 加混响和压缩
  function synthNote(L, R, sr, f, t0, held, vel, pan) {
    const B = 0.00035;                                      // 弦的不协和程度
    const decay = Math.max(0.6, Math.min(4.5, 3.2 * Math.pow(261.6 / f, 0.55)));   // 越低的音延音越长
    const release = 0.18 + 0.12 * Math.min(1, 261.6 / f);
    const i0 = Math.floor(t0 * sr), iEnd = Math.floor((t0 + held) * sr);
    const iStop = Math.min(L.length, Math.floor((t0 + held + release * 2.5) * sr));
    const gl = Math.cos((pan + 1) * Math.PI / 4), gr = Math.sin((pan + 1) * Math.PI / 4);
    const bright = 0.55 + 0.6 * vel;
    const N = f > 1500 ? 4 : f > 700 ? 6 : 9;
    const atk = Math.floor(0.004 * sr);
    const relK = Math.exp(-1 / (release / 3 * sr));
    for (let k = 1; k <= N; k++) {
      const fk = f * k * Math.sqrt(1 + B * k * k);
      if (fk > sr * 0.45) break;
      let amp = vel * 0.22 * Math.pow(k, -1.25 / bright) * (k === 2 ? 1.15 : 1);
      const tau = decay / (1 + 0.45 * (k - 1));
      const dk = Math.exp(-1 / (tau * sr));
      const strings = k <= 3 ? [-0.8, 0.8] : [0];           // 低泛音用两根稍微走音的弦，有自然的拍音
      for (const cents of strings) {
        const w = 2 * Math.PI * fk * Math.pow(2, cents / 1200) / sr;
        // 用旋转递推代替 Math.sin，快很多
        const c = Math.cos(w), sn = Math.sin(w);
        let x = 0, y = 1, env = amp / strings.length;
        const ph = Math.random() * Math.PI * 2; x = Math.sin(ph); y = Math.cos(ph);
        for (let i = i0, j = 0; i < iStop; i++, j++) {
          const nx = x * c + y * sn; y = y * c - x * sn; x = nx;
          const a = j < atk ? j / atk : 1;
          const v = x * env * a;
          L[i] += v * gl; R[i] += v * gr;
          env *= i < iEnd ? dk : dk * relK;
          if (env < 1e-5) break;
        }
      }
    }
    // 击弦噪声（很短、偏高频）
    const nLen = Math.floor(0.025 * sr);
    let lp = 0;
    for (let j = 0; j < nLen && i0 + j < L.length; j++) {
      const r = Math.random() * 2 - 1;
      lp += (r - lp) * 0.5;
      const v = (r - lp) * 0.035 * vel * Math.pow(1 - j / nLen, 2);
      L[i0 + j] += v * gl; R[i0 + j] += v * gr;
    }
  }

  async function render(score, { sampleRate = 44100, volume = 2.0 } = {}) {
    const spb = 60 / score.bpm;
    const len = Math.max(0.5, score.total * spb + 2.4);
    const n = Math.ceil(len * sampleRate);
    const L = new Float32Array(n), R = new Float32Array(n);
    for (const note of score.notes) {
      const t0 = note.t * spb + 0.05;
      const held = Math.max(0.12, note.dur * spb);
      const vel = note.midi.length > 1 ? Math.min(0.75, 0.95 / Math.sqrt(note.midi.length)) : 0.75;
      for (const m of note.midi) {
        const pan = Math.max(-0.6, Math.min(0.6, (m - 64) / 40));   // 低音偏左、高音偏右，像坐在钢琴前
        synthNote(L, R, sampleRate, freq(m), t0, held, vel, pan);
      }
    }
    // 混响和压缩
    const ctx = new OfflineAudioContext(2, n, sampleRate);
    const dryBuf = ctx.createBuffer(2, n, sampleRate);
    dryBuf.copyToChannel(L, 0); dryBuf.copyToChannel(R, 1);
    const srcN = ctx.createBufferSource(); srcN.buffer = dryBuf;
    const master = ctx.createGain(); master.gain.value = volume;
    const comp = ctx.createDynamicsCompressor();
    comp.threshold.value = -14; comp.ratio.value = 3; comp.attack.value = 0.003; comp.release.value = 0.25;
    master.connect(comp); comp.connect(ctx.destination);
    const rev = ctx.createConvolver();
    const irLen = Math.floor(sampleRate * 1.8), ir = ctx.createBuffer(2, irLen, sampleRate);
    for (let ch = 0; ch < 2; ch++) {
      const d = ir.getChannelData(ch);
      let seed = 1234 + ch * 777;
      for (let k = 0; k < irLen; k++) {
        seed = (seed * 16807) % 2147483647;
        d[k] = ((seed / 2147483647) * 2 - 1) * Math.pow(1 - k / irLen, 3.2);
      }
    }
    rev.buffer = ir;
    const wet = ctx.createGain(); wet.gain.value = 0.16;
    srcN.connect(master);
    srcN.connect(rev); rev.connect(wet); wet.connect(master);
    srcN.start(0);
    return ctx.startRendering();
  }

  // AudioBuffer → WAV 文件（16 位）
  function toWav(buf) {
    const ch = buf.numberOfChannels, sr = buf.sampleRate, n = buf.length;
    const out = new DataView(new ArrayBuffer(44 + n * ch * 2));
    const w = (o, s) => { for (let k = 0; k < s.length; k++) out.setUint8(o + k, s.charCodeAt(k)); };
    w(0, 'RIFF'); out.setUint32(4, 36 + n * ch * 2, true); w(8, 'WAVE'); w(12, 'fmt ');
    out.setUint32(16, 16, true); out.setUint16(20, 1, true); out.setUint16(22, ch, true); out.setUint32(24, sr, true);
    out.setUint32(28, sr * ch * 2, true); out.setUint16(32, ch * 2, true); out.setUint16(34, 16, true); w(36, 'data'); out.setUint32(40, n * ch * 2, true);
    const data = []; for (let c = 0; c < ch; c++) data.push(buf.getChannelData(c));
    let o = 44;
    for (let k = 0; k < n; k++) for (let c = 0; c < ch; c++) { const v = Math.max(-1, Math.min(1, data[c][k])); out.setInt16(o, v < 0 ? v * 0x8000 : v * 0x7fff, true); o += 2; }
    return new Uint8Array(out.buffer);
  }

  // 简谱 → MIDI 文件（之后“她自己写旋律”导出用）
  function toMidi(score) {
    const tpq = 480, ev = [];
    for (const nt of score.notes) for (const m of nt.midi) {
      ev.push({ t: Math.round(nt.t * tpq), on: 1, m });
      ev.push({ t: Math.round((nt.t + nt.dur) * tpq), on: 0, m });
    }
    ev.sort((a, b) => a.t - b.t || a.on - b.on);
    const bytes = [];
    const vlq = (v) => { const s = [v & 0x7f]; while ((v >>= 7)) s.unshift((v & 0x7f) | 0x80); bytes.push(...s); };
    const us = Math.round(60000000 / score.bpm);
    vlq(0); bytes.push(0xff, 0x51, 0x03, (us >> 16) & 255, (us >> 8) & 255, us & 255);
    vlq(0); bytes.push(0xc0, 0);                       // 音色：大钢琴
    let prev = 0;
    for (const e of ev) { vlq(e.t - prev); prev = e.t; bytes.push(e.on ? 0x90 : 0x80, e.m, e.on ? 80 : 0); }
    vlq(0); bytes.push(0xff, 0x2f, 0x00);
    const head = [0x4d, 0x54, 0x68, 0x64, 0, 0, 0, 6, 0, 0, 0, 1, (tpq >> 8) & 255, tpq & 255];
    const L = bytes.length;
    return new Uint8Array([...head, 0x4d, 0x54, 0x72, 0x6b, (L >>> 24) & 255, (L >> 16) & 255, (L >> 8) & 255, L & 255, ...bytes]);
  }

  // 检查每小节的拍数是不是对的：返回不对的小节 [{bar: 第几小节, got: 实际拍数}]
  function checkBars(score) {
    const bad = [];
    const ends = score.bars.slice();
    if (!ends.length || ends[ends.length - 1] < score.total) ends.push(score.total);
    let prev = 0;
    ends.forEach((e, k) => {
      const got = Math.round((e - prev) * 1000) / 1000;
      const last = k === ends.length - 1;
      if (got > 0 && Math.abs(got - score.beats) > 1e-6 && !(last && got < score.beats)) bad.push({ bar: k + 1, got });
      prev = e;
    });
    return bad;
  }

  root.Jianpu = { parse, checkBars, render, toWav, toMidi, freq, normalize };
})(typeof window !== 'undefined' ? window : globalThis);
