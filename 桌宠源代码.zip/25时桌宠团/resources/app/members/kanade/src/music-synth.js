'use strict';
/* 本地多轨合成器（纯 JavaScript 数字信号处理，可以在 Web Worker 或 Node 里运行）
 *
 * 把 MusicScore.arrange() 展开的音符事件，用合成音源逐个演奏到立体声总线上：
 *   振荡器（带限锯齿 / 方波、正弦、加法合成）、状态变量滤波器、包络、颤音、拨弦（Karplus–Strong）、噪声鼓。
 * 混音：每个声部有自己的音量、声像和混响发送量 → Freeverb 式混响 → 压缩 → 淡出 / 收尾 → 峰值归一到 -1 dBFS。
 * 所有乐器都是合成出来的，没有采样、没有人声。随机数用固定种子，同一份乐谱每次渲染结果一样。 */
(function (root) {
  const TWO_PI = Math.PI * 2;
  const freq = (m) => 440 * Math.pow(2, (m - 69) / 12);
  const MIX = {
    lead: { gain: 0.5, pan: 0.0, rev: 0.22 },
    chords: { gain: 0.36, pan: -0.22, rev: 0.2 },
    pad: { gain: 0.22, pan: 0.0, rev: 0.34 },
    arp: { gain: 0.25, pan: 0.32, rev: 0.28 },
    bass: { gain: 0.44, pan: 0.0, rev: 0.03 },
    drums: { gain: 0.55, pan: 0.0, rev: 0.08 },
  };
  const DRUM_PAN = { hat: 0.28, openhat: 0.28, shaker: -0.32, ride: 0.35, crash: -0.25, tom: -0.18, kick: 0, snare: 0.04, clap: 0, rim: 0.05 };

  function rng(seed) { let s = seed >>> 0 || 1; return () => { s ^= s << 13; s >>>= 0; s ^= s >> 17; s ^= s << 5; s >>>= 0; return s / 4294967296 * 2 - 1; }; }
  const polyblep = (t, dt) => { if (t < dt) { t /= dt; return t + t - t * t - 1; } if (t > 1 - dt) { t = (t - 1) / dt; return t * t + t + t + 1; } return 0; };

  // 状态变量滤波器（TPT 结构，稳定），mode: 0 低通 1 带通 2 高通
  function SVF(sr) {
    let ic1 = 0, ic2 = 0, g = 0, k = 1, a1 = 0, a2 = 0, a3 = 0;
    return {
      set(fc, q) { g = Math.tan(Math.PI * Math.min(fc, sr * 0.45) / sr); k = 1 / Math.max(0.3, q); a1 = 1 / (1 + g * (g + k)); a2 = g * a1; a3 = g * a2; },
      run(x, mode) {
        const v3 = x - ic2, v1 = a1 * ic1 + a2 * v3, v2 = ic2 + a2 * ic1 + a3 * v3;
        ic1 = 2 * v1 - ic1; ic2 = 2 * v2 - ic2;
        return mode === 0 ? v2 : mode === 1 ? v1 : x - k * v1 - v2;
      },
    };
  }

  /**
   * renderSong(score, arrangement, opts) → { left, right, sampleRate, duration, stats }
   * opts: { sampleRate, onProgress(p, stage) }
   */
  function renderSong(sc, arr, opts = {}) {
    const sr = opts.sampleRate || 44100;
    const onProgress = opts.onProgress || (() => {});
    const tm = root.MusicScore.timeMap(sc, arr);
    const musicEnd = tm(arr.totalBeats);
    const TAIL = 3.2;
    const N = Math.ceil((musicEnd + TAIL) * sr);
    const L = new Float32Array(N), R = new Float32Array(N), SEND = new Float32Array(N);
    const rand = rng(0x6b616e61);
    const acc = sc.mode === 'accompaniment';
    const ksCache = new Map();

    // 把一个单声道音符写进总线：声像 + 混响发送
    function mixIn(buf, start, len, gain, pan, send) {
      const gl = Math.cos((pan + 1) * Math.PI / 4) * gain, gr = Math.sin((pan + 1) * Math.PI / 4) * gain, gs = gain * send;
      const end = Math.min(N, start + len);
      for (let i = Math.max(0, start), j = i - start; i < end; i++, j++) { const v = buf[j]; L[i] += v * gl; R[i] += v * gr; SEND[i] += v * gs; }
    }
    let scratch = new Float32Array(sr * 4);
    const need = (n) => { if (scratch.length < n) scratch = new Float32Array(n); scratch.fill(0, 0, n); return scratch; };

    // ADSR 包络（逐个采样）：a 线性起音，d 指数衰减到 sus，音符结束后 rel 指数释放
    function envelope(i, held, a, d, sus, rel) {
      const t = i / sr;
      let v;
      if (t < a) v = t / a;
      else v = sus + (1 - sus) * Math.exp(-(t - a) / d);
      if (t > held) v *= Math.exp(-(t - held) / (rel / 4));
      return v;
    }
    const lenOf = (held, rel) => Math.ceil((held + rel * 1.7) * sr);

    /* ---------- 乐器 ---------- */
    function additive(buf, n, f, held, parts, v, opt = {}) {
      // parts: [倍频, 振幅, 衰减秒]
      for (const [r, amp, dec] of parts) {
        const fr = f * r * (opt.inharm ? Math.sqrt(1 + opt.inharm * r * r) : 1);
        if (fr > sr * 0.45) continue;
        const w = TWO_PI * fr / sr, c = Math.cos(w), s = Math.sin(w);
        let x = 0, y = 1;
        const kd = Math.exp(-1 / (dec * sr)), kr = Math.exp(-1 / ((opt.rel || 0.25) / 4 * sr));
        let e = amp * v;
        const att = Math.max(1, Math.floor((opt.a || 0.003) * sr)), heldN = Math.floor(held * sr);
        for (let i = 0; i < n; i++) {
          const nx = x * c + y * s; y = y * c - x * s; x = nx;
          buf[i] += x * e * (i < att ? i / att : 1);
          e *= i < heldN ? kd : kd * kr;
          if (e < 1e-5) break;
        }
      }
    }
    function vaVoice(buf, n, f, held, v, o) {
      // 虚拟模拟：若干个带限锯齿/方波 + 低通滤波 + 包络 + 颤音
      const flt = SVF(sr);
      const oscs = o.oscs.map(([type, det, amp, mul]) => ({ type, dt: f * (mul || 1) * Math.pow(2, det / 1200) / sr, ph: Math.abs(rand()), amp }));
      let lfo = 0; const lfoDt = (o.vibRate || 5.2) / sr;
      for (let i = 0; i < n; i++) {
        if ((i & 31) === 0) {
          const t = i / sr;
          const fc = o.cut1 + (o.cut0 - o.cut1) * Math.exp(-t / o.cutT);
          flt.set(fc, o.q || 0.7);
        }
        const vib = o.vib ? 1 + (o.vib / 1731) * Math.sin(TWO_PI * lfo) * Math.min(1, Math.max(0, i / sr - (o.vibDelay || 0.25)) * 3) : 1;
        lfo += lfoDt;
        let s = 0;
        for (const q of oscs) {
          const dt = q.dt * vib;
          let val;
          if (q.type === 0) val = 2 * q.ph - 1 - polyblep(q.ph, dt);                       // 锯齿
          else if (q.type === 1) { val = (q.ph < 0.5 ? 1 : -1) + polyblep(q.ph, dt) - polyblep((q.ph + 0.5) % 1, dt); }   // 方波
          else if (q.type === 2) val = 1 - 4 * Math.abs(q.ph - 0.5);                         // 三角
          else val = Math.sin(TWO_PI * q.ph);                                                // 正弦
          s += val * q.amp;
          q.ph += dt; if (q.ph >= 1) q.ph -= 1;
        }
        buf[i] += flt.run(s, 0) * v * envelope(i, held, o.a, o.d, o.sus, o.rel);
      }
    }
    function karplus(buf, n, m, held, v, bright, damp) {
      const key = m + ':' + bright + ':' + damp;
      let src = ksCache.get(key);
      if (!src) {
        const len = Math.ceil(3.2 * sr); src = new Float32Array(len);
        const P = Math.max(2, Math.round(sr / freq(m))), line = new Float32Array(P);
        let lp = 0; for (let i = 0; i < P; i++) { lp += (rand() - lp) * bright; line[i] = lp; }
        let idx = 0, prev = 0, peak = 0;
        for (let i = 0; i < len; i++) { const cur = line[idx]; const o = damp * 0.5 * (cur + prev); prev = cur; line[idx] = o; src[i] = o; idx = (idx + 1) % P; if (i < 3000) peak = Math.max(peak, Math.abs(o)); }
        if (peak > 0) for (let i = 0; i < len; i++) src[i] /= peak;
        ksCache.set(key, src);
      }
      const heldN = Math.floor(held * sr), kr = Math.exp(-1 / (0.05 * sr));
      let g = 0.55 * v;
      for (let i = 0; i < n && i < src.length; i++) { buf[i] += src[i] * g; if (i > heldN) g *= kr; }
    }

    const INST = {
      piano: (b, n, f, h, v) => additive(b, n, f, h, [[1, 0.5, 1.6], [2, 0.3 * (0.6 + v), 1.1], [3, 0.16 * (0.5 + v), 0.8], [4, 0.09 * v, 0.6], [5, 0.05 * v, 0.45], [6, 0.03 * v, 0.35]].map(([r, a, d]) => [r, a, d * Math.pow(261 / f, 0.5) + 0.15]), v, { inharm: 0.0003, rel: 0.3, a: 0.004 }),
      epiano: (b, n, f, h, v) => {
        const wc = TWO_PI * f / sr; let pc = 0, pm = 0;
        for (let i = 0; i < n; i++) {
          const t = i / sr, idx = (0.3 + 2.2 * v * Math.exp(-t / 0.25));
          b[i] += Math.sin(pc + idx * Math.sin(pm)) * 0.42 * v * envelope(i, h, 0.003, 1.2, 0.25, 0.45);
          pc += wc; pm += wc; if (pc > 1e4) { pc -= TWO_PI * 1000; pm -= TWO_PI * 1000; }
        }
      },
      strings: (b, n, f, h, v) => vaVoice(b, n, f, h, v * 0.2, { oscs: [[0, -7, 1], [0, 0, 1], [0, 7, 1]], cut0: 2800, cut1: 2400, cutT: 1, a: 0.26, d: 0.5, sus: 0.85, rel: 0.6, vib: 5, vibRate: 5.3 }),
      cello: (b, n, f, h, v) => vaVoice(b, n, f, h, v * 0.24, { oscs: [[0, -5, 1], [0, 5, 1]], cut0: 1700, cut1: 1400, cutT: 1, a: 0.18, d: 0.5, sus: 0.85, rel: 0.5, vib: 6, vibRate: 5 }),
      pad: (b, n, f, h, v) => vaVoice(b, n, f, h, v * 0.17, { oscs: [[0, -11, 1], [0, 11, 1], [2, 0, 1, 0.5]], cut0: 1300, cut1: 1100, cutT: 2, a: 0.7, d: 1, sus: 1, rel: 1.4 }),
      organ: (b, n, f, h, v) => additive(b, n, f, h, [[1, 0.32, 99], [2, 0.24, 99], [3, 0.18, 99], [4, 0.14, 99], [6, 0.09, 99], [8, 0.07, 99]], v * envOrgan(h), { rel: 0.08, a: 0.012 }),
      flute: (b, n, f, h, v) => {
        vaVoice(b, n, f, h, v * 0.33, { oscs: [[3, 0, 1], [3, 0, 0.08, 2]], cut0: 6000, cut1: 6000, cutT: 1, a: 0.06, d: 0.3, sus: 0.9, rel: 0.15, vib: 9, vibRate: 5, vibDelay: 0.3 });
        const flt = SVF(sr); flt.set(f * 1.5, 2);
        for (let i = 0; i < n; i++) b[i] += flt.run(rand(), 1) * 0.05 * v * (i < 0.06 * sr ? 1 : 0.3) * envelope(i, h, 0.02, 0.1, 0.5, 0.12);
      },
      synthlead: (b, n, f, h, v) => vaVoice(b, n, f, h, v * 0.15, { oscs: [[0, -5, 1], [1, 5, 0.7]], cut0: 5200, cut1: 2400, cutT: 0.3, q: 1.4, a: 0.01, d: 0.3, sus: 0.8, rel: 0.16, vib: 8, vibRate: 5.5 }),
      brass: (b, n, f, h, v) => vaVoice(b, n, f, h, v * 0.2, { oscs: [[0, -4, 1], [0, 4, 1]], cut0: 500, cut1: 1500 + 1200 * v, cutT: 0.08, q: 1, a: 0.06, d: 0.4, sus: 0.8, rel: 0.2 }),
      pluck: (b, n, f, h, v, m) => karplus(b, n, m, h, v, 0.55, 0.996),
      harp: (b, n, f, h, v, m) => karplus(b, n, m, Math.max(h, 1.5), v * 0.9, 0.8, 0.998),
      uprightbass: (b, n, f, h, v, m) => karplus(b, n, m, h, v * 1.25, 0.25, 0.997),
      bell: (b, n, f, h, v) => additive(b, n, f, h, [[1, 0.3, 2.4], [2.76, 0.15, 1.1], [5.4, 0.08, 0.5], [8.93, 0.04, 0.25]], v, { rel: 2, a: 0.002 }),
      musicbox: (b, n, f, h, v) => additive(b, n, f, h, [[1, 0.3, 1.4], [3.01, 0.12, 0.5], [5.8, 0.05, 0.2]], v, { rel: 1.2, a: 0.002 }),
      marimba: (b, n, f, h, v) => additive(b, n, f, h, [[1, 0.45, 0.55], [3.98, 0.12, 0.07], [9.2, 0.03, 0.02]], v, { rel: 0.5, a: 0.002 }),
      fingerbass: (b, n, f, h, v) => vaVoice(b, n, f, h, v * 0.55, { oscs: [[2, 0, 1], [0, 0, 0.3]], cut0: 1100, cut1: 450, cutT: 0.2, a: 0.005, d: 0.7, sus: 0.45, rel: 0.08 }),
      synthbass: (b, n, f, h, v) => vaVoice(b, n, f, h, v * 0.32, { oscs: [[0, 0, 1], [1, 0, 0.8, 0.5]], cut0: 2200, cut1: 380, cutT: 0.12, q: 4, a: 0.003, d: 0.4, sus: 0.6, rel: 0.07 }),
    };
    function envOrgan() { return 1; }
    const REL = { piano: 0.3, epiano: 0.45, strings: 0.6, cello: 0.5, pad: 1.4, organ: 0.08, flute: 0.15, synthlead: 0.16, brass: 0.2, pluck: 0.05, harp: 0.05, uprightbass: 0.05, bell: 2.5, musicbox: 1.5, marimba: 0.6, fingerbass: 0.08, synthbass: 0.07 };
    const RING = { piano: 1.2, pluck: 1.6, harp: 2.4, uprightbass: 1.5, bell: 2.5, musicbox: 1.4, marimba: 0.6 };   // 自然衰减的乐器，按下后会响一会儿

    /* ---------- 鼓（噪声和扫频正弦合成） ---------- */
    const kitCfg = { acoustic: { k: 1, lp: 12000, len: 1 }, electronic: { k: 1.15, lp: 14000, len: 1.35 }, lofi: { k: 0.9, lp: 4800, len: 0.9 }, brush: { k: 0.7, lp: 7000, len: 1.1 } }[sc.kit] || { k: 1, lp: 12000, len: 1 };
    function drum(b, name, v) {
      const lp = SVF(sr); lp.set(kitCfg.lp, 0.7);
      const bp = SVF(sr), hp = SVF(sr);
      let n = 0;
      if (name === 'kick') {
        n = Math.floor(0.55 * kitCfg.len * sr); let ph = 0;
        const f0 = sc.kit === 'electronic' ? 130 : 160, f1 = sc.kit === 'electronic' ? 40 : 48;
        for (let i = 0; i < n; i++) { const t = i / sr; const f = f1 + (f0 - f1) * Math.exp(-t / (0.035 * kitCfg.len)); ph += TWO_PI * f / sr; b[i] += Math.sin(ph) * Math.exp(-t / (0.12 * kitCfg.len)) * 0.95 * kitCfg.k * v + (i < 200 ? rand() * 0.15 * v * (1 - i / 200) : 0); }
      } else if (name === 'snare' || name === 'rim') {
        n = Math.floor(0.35 * sr); bp.set(name === 'rim' ? 3500 : 1900, 0.6); let ph = 0;
        const brush = sc.kit === 'brush';
        for (let i = 0; i < n; i++) { const t = i / sr; const env = brush ? Math.min(1, t / 0.02) * Math.exp(-t / 0.09) : Math.exp(-t / 0.055); b[i] += lp.run(bp.run(rand(), 1), 0) * (brush ? 0.5 : 0.8) * env * v; if (!brush) { ph += TWO_PI * 190 / sr; b[i] += Math.sin(ph) * 0.3 * Math.exp(-t / 0.025) * v; } }
      } else if (name === 'clap') {
        n = Math.floor(0.3 * sr); bp.set(1300, 0.8);
        for (let i = 0; i < n; i++) { const t = i / sr; const burst = t < 0.03 ? Math.exp(-((t * 1000) % 11) / 2.5) : Math.exp(-(t - 0.03) / 0.05); b[i] += bp.run(rand(), 1) * 0.9 * burst * v; }
      } else if (name === 'hat' || name === 'openhat' || name === 'shaker') {
        const dec = name === 'openhat' ? 0.12 : name === 'shaker' ? 0.025 : 0.016;
        n = Math.floor(dec * 7 * sr); hp.set(name === 'shaker' ? 6000 : 7500, 0.7);
        for (let i = 0; i < n; i++) { const t = i / sr; const a = name === 'shaker' ? Math.min(1, t / 0.012) : 1; b[i] += lp.run(hp.run(rand(), 2), 0) * (name === 'shaker' ? 0.32 : 0.5) * a * Math.exp(-t / dec) * v; }
      } else if (name === 'tom') {
        n = Math.floor(0.4 * sr); let ph = 0;
        for (let i = 0; i < n; i++) { const t = i / sr; ph += TWO_PI * (85 + 65 * Math.exp(-t / 0.08)) / sr; b[i] += Math.sin(ph) * 0.55 * Math.exp(-t / 0.09) * v; }
      } else if (name === 'crash' || name === 'ride') {
        const dec = name === 'ride' ? 0.18 : 0.55;
        n = Math.floor(dec * 5 * sr); (name === 'ride' ? bp : hp).set(name === 'ride' ? 7500 : 4500, 0.5); lp.set(Math.min(kitCfg.lp, 11000), 0.7);
        for (let i = 0; i < n; i++) { const t = i / sr; const x = name === 'ride' ? bp.run(rand(), 1) : hp.run(rand(), 2); b[i] += lp.run(x, 0) * (name === 'ride' ? 0.25 : 0.4) * Math.exp(-t / dec) * v; }
      }
      return n;
    }

    /* ---------- 逐个音符演奏 ---------- */
    const evs = arr.events;
    const step = Math.max(1, Math.floor(evs.length / 50));
    for (let k = 0; k < evs.length; k++) {
      const e = evs[k];
      const t0 = tm(e.t);
      const start = Math.floor(t0 * sr);
      if (start >= N) continue;
      const mix = MIX[e.tr] || MIX.chords;
      let trGain = mix.gain * (acc && e.tr === 'arp' ? 0.85 : 1) * (acc && e.tr === 'pad' ? 1.2 : 1);
      if (e.tr === 'drums') {
        const b = need(Math.ceil(3 * sr));
        const n = drum(b, e.p, e.v);
        mixIn(b, start, n, trGain, DRUM_PAN[e.p] || 0, mix.rev * (e.p === 'snare' || e.p === 'clap' ? 1.6 : 1));
      } else {
        const held = Math.max(0.05, tm(e.t + e.d) - t0);
        const ins = INST[e.ins] ? e.ins : 'piano';
        const rel = REL[ins] || 0.3;
        const n = Math.min(N - start, Math.max(lenOf(held, rel), Math.ceil((RING[ins] || 0) * sr)));
        const b = need(n);
        INST[ins](b, n, freq(e.p), held, e.v, e.p);
        // 铺底的音按音高左右轻轻散开，听起来更宽
        const pan = e.tr === 'pad' ? ((e.p % 5) - 2) * 0.18 : mix.pan;
        mixIn(b, start, n, trGain, pan, mix.rev);
      }
      if (k % step === 0) onProgress(0.05 + 0.75 * k / evs.length, `合成各声部（${k}/${evs.length} 个音）`);
    }

    /* ---------- 混响（Freeverb 结构：8 个梳状 + 4 个全通，左右略有差异） ---------- */
    onProgress(0.8, '加混响');
    const scale = sr / 44100;
    const combT = [1116, 1188, 1277, 1356, 1422, 1491, 1557, 1617], apT = [556, 441, 341, 225];
    const room = 0.84, damp = 0.3, wet = 0.32;
    for (const [out, spread] of [[L, 0], [R, 23]]) {
      const combs = combT.map((t) => ({ buf: new Float32Array(Math.round((t + spread) * scale)), i: 0, lp: 0 }));
      const aps = apT.map((t) => ({ buf: new Float32Array(Math.round((t + spread) * scale)), i: 0 }));
      for (let i = 0; i < N; i++) {
        const x = SEND[i] * 0.015;
        let s = 0;
        for (const c of combs) { const y = c.buf[c.i]; c.lp = y * (1 - damp) + c.lp * damp; c.buf[c.i] = x + c.lp * room; c.i = (c.i + 1) % c.buf.length; s += y; }
        for (const a of aps) { const y = a.buf[a.i]; a.buf[a.i] = s + y * 0.5; a.i = (a.i + 1) % a.buf.length; s = y - s; }
        out[i] += s * wet;
      }
      onProgress(spread ? 0.9 : 0.85, '加混响');
    }

    /* ---------- 母带：压缩、结尾淡出、峰值归一 ---------- */
    onProgress(0.92, '母带处理');
    const thr = Math.pow(10, -16 / 20), ratio = 2.5;
    const atk = Math.exp(-1 / (0.01 * sr)), relc = Math.exp(-1 / (0.2 * sr));
    let envF = 0;
    // 高频架式提升（约 3kHz 以上 +2.5dB）和 30Hz 以下的超低频切除，让声音更清楚
    const kLp = 1 - Math.exp(-TWO_PI * 3000 / sr), kHp = 1 - Math.exp(-TWO_PI * 30 / sr);
    let lpL = 0, lpR = 0, dcL = 0, dcR = 0;
    const fadeFrom = sc.ending === 'fade' ? tm(Math.max(0, arr.endBeat - sc.beats * 4)) : musicEnd + TAIL - 1.4;
    const fadeTo = sc.ending === 'fade' ? musicEnd + 0.5 : musicEnd + TAIL - 0.02;
    for (let i = 0; i < N; i++) {
      lpL += (L[i] - lpL) * kLp; lpR += (R[i] - lpR) * kLp;
      L[i] += 0.33 * (L[i] - lpL); R[i] += 0.33 * (R[i] - lpR);
      dcL += (L[i] - dcL) * kHp; dcR += (R[i] - dcR) * kHp;
      L[i] -= dcL; R[i] -= dcR;
      const a = Math.max(Math.abs(L[i]), Math.abs(R[i]));
      envF = a > envF ? atk * envF + (1 - atk) * a : relc * envF + (1 - relc) * a;
      let g = envF > thr ? Math.pow(envF / thr, 1 / ratio - 1) : 1;
      const t = i / sr;
      if (t > fadeFrom) g *= Math.max(0, 1 - (t - fadeFrom) / (fadeTo - fadeFrom));
      L[i] *= g; R[i] *= g;
    }
    let peak = 0, sq = 0;
    for (let i = 0; i < N; i++) { const a = Math.abs(L[i]), b = Math.abs(R[i]); if (a > peak) peak = a; if (b > peak) peak = b; sq += L[i] * L[i] + R[i] * R[i]; }
    if (!(peak > 1e-4)) throw new Error('渲染结果是静音：乐谱里没有可演奏的音符');
    const norm = 0.891 / peak;
    for (let i = 0; i < N; i++) { L[i] *= norm; R[i] *= norm; }
    const rms = Math.sqrt(sq / (2 * N)) * norm;
    // 每段的响度，用来检查有没有起伏
    const sections = arr.sections.map((s) => {
      const a = Math.floor(tm(s.start) * sr), b = Math.min(N, Math.floor(tm(s.start + s.bars * sc.beats) * sr));
      let q = 0; for (let i = a; i < b; i += 16) q += L[i] * L[i] + R[i] * R[i];
      return { name: s.name, start: tm(s.start), end: tm(s.start + s.bars * sc.beats), energy: s.energy, rmsDb: Math.round(10 * Math.log10(q / Math.max(1, (b - a) / 16) / 2 + 1e-12) * 10) / 10 };
    });
    onProgress(1, '完成');
    return { left: L, right: R, sampleRate: sr, duration: N / sr, stats: { peakDb: -1, rmsDb: Math.round(20 * Math.log10(rms + 1e-9) * 10) / 10, musicEnd, sections, notes: evs.length, tracks: arr.tracks } };
  }

  root.MusicSynth = { renderSong, MIX };
  if (typeof module !== 'undefined' && module.exports) module.exports = root.MusicSynth;
})(typeof self !== 'undefined' ? self : typeof globalThis !== 'undefined' ? globalThis : this);
