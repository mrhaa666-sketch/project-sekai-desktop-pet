'use strict';
// 后台线程：编配展开 → 合成各声部 → 混音 → 编码 WAV。耗时的计算都在这里，不卡界面也不卡桌宠。
importScripts('music-score.js', 'music-synth.js');
self.onmessage = (e) => {
  const { id, score } = e.data || {};
  try {
    const arr = self.MusicScore.arrange(score);
    self.postMessage({ id, progress: 0.03, stage: '编配展开' });
    const out = self.MusicSynth.renderSong(score, arr, { onProgress: (p, stage) => self.postMessage({ id, progress: p * 0.96, stage }) });
    self.postMessage({ id, progress: 0.97, stage: '编码 WAV' });
    const wav = self.MusicScore.encodeWav(out.left, out.right, out.sampleRate);
    // 画波形用：每段取峰值
    const P = 1600, step = Math.floor(out.left.length / P), peaks = new Float32Array(P);
    for (let i = 0; i < P; i++) { let m = 0; for (let j = i * step, k = 0; k < step; j += 8, k += 8) { const a = Math.abs(out.left[j]) + Math.abs(out.right[j]); if (a > m) m = a; } peaks[i] = m / 2; }
    self.postMessage({ id, done: true, wav, peaks, stats: out.stats, duration: out.duration, desc: self.MusicScore.describe(score, arr) }, [wav, peaks.buffer]);
  } catch (err) {
    self.postMessage({ id, error: String((err && err.message) || err) });
  }
};
