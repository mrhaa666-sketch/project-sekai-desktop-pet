'use strict';
/* 生成纯音乐 / 伴奏窗口 */
const api = window.musicAPI;
const $ = (id) => document.getElementById(id);
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const mmss = (s) => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`;
const setMsg = (id, t, cls = '') => { const e = $(id); e.textContent = t; e.className = 'msg' + (cls ? ' ' + cls : ''); };

let cfg = null, job = null, worker = null;
let current = null;   // { bytes, ext, title, duration, peaks, sections }
let blobUrl = null, raf = 0;

/* ---------- 设置状态 ---------- */
async function loadConfig() {
  cfg = await api.config();
  const pill = $('cfgPill'), note = $('backendNote');
  if (cfg.backend === 'minimax') {
    pill.textContent = cfg.minimaxReady ? `MiniMax 音乐生成 · ${cfg.minimaxModel}` : 'MiniMax 密钥未设置'; pill.className = 'pill ' + (cfg.minimaxReady ? 'ok' : 'bad');
    note.className = 'notice warn';
    note.innerHTML = `<b>后端：MiniMax 官方音乐生成接口（${esc(cfg.minimaxModel)}，付费）</b>。由 MiniMax 的音乐模型直接生成音频（无人声模式），输出 MP3。` +
      '官方接口没有时长和速度参数：这两项只会写进描述里，实际长度以返回为准；纯伴奏也只能通过描述要求。每次点“生成”都会产生 MiniMax 费用；按官方说明，2026 年 8 月 20 日起新用户不能再开通付费音乐接口。';
    $('seconds').title = 'MiniMax 接口不能指定时长，只作为参考';
  } else {
    pill.textContent = cfg.chatReady ? `本地多轨合成 · 写谱模型 ${cfg.chatModel}` : '聊天模型未设置'; pill.className = 'pill ' + (cfg.chatReady ? 'ok' : 'bad');
    note.className = 'notice';
    note.innerHTML = '<b>后端：本地多轨合成</b>。聊天模型按你的要求写出多轨乐谱（主旋律、和声、曲式、配器、律动），桌宠内置的合成音源在后台演奏、混音，导出 WAV。' +
      '这是<b>多轨合成音乐</b>，音色是合成器音色，不是专业 AI 音频模型或真人录音的音质。只会把文字要求发给聊天模型，不上传任何音频。';
  }
  refresh();
}
$('openSettings').onclick = () => api.openSettings();
window.addEventListener('focus', () => { if (!job) loadConfig(); });

function refresh() {
  const busy = !!job;
  $('gen').disabled = busy; $('cancel').disabled = !busy;
  for (const el of document.querySelectorAll('#prompt, #seconds, #bpm, #beats, input[name=mode]')) el.disabled = busy;
  $('genHint').textContent = busy ? '' : cfg && ((cfg.backend === 'local' && !cfg.chatReady) || (cfg.backend === 'minimax' && !cfg.minimaxReady)) ? '先在设置里填好 API' : '';
}
$('seconds').oninput = () => { $('secVal').textContent = mmss(+$('seconds').value); };

/* ---------- 阶段进度 ---------- */
const STAGES = {
  local: [['compose', '写谱（聊天模型写多轨乐谱）'], ['check', '检查和修正乐谱'], ['arrange', '编配展开'], ['synth', '合成各声部'], ['master', '混响与母带处理'], ['encode', '编码 WAV']],
  minimax: [['remote', '请求 MiniMax 生成音频'], ['decode', '解码音频']],
};
let stageKeys = [];
function initStages(kind) {
  stageKeys = STAGES[kind].map((s) => s[0]);
  $('stages').innerHTML = STAGES[kind].map(([k, t]) => `<li data-k="${k}">${t}<span class="d"></span></li>`).join('');
  $('stages').hidden = false; $('barWrap').hidden = false; $('bar').style.width = '0';
}
function stage(k, detail = '', frac) {
  const i = stageKeys.indexOf(k);
  [...$('stages').children].forEach((li, j) => { li.className = j < i ? 'done' : j === i ? 'on' : ''; if (j === i) li.querySelector('.d').textContent = detail; });
  if (frac != null) $('bar').style.width = Math.round(frac * 100) + '%';
}
function stagesDone() { [...$('stages').children].forEach((li) => { li.className = 'done'; }); $('bar').style.width = '100%'; }

/* ---------- 生成 ---------- */
function readForm() {
  const mode = (document.querySelector('input[name=mode]:checked') || {}).value;
  const prompt = $('prompt').value.trim();
  const bpm = $('bpm').value.trim();
  if (!prompt) return { error: '先写下想要的曲子：主题、情绪、风格、乐器都可以。' };
  if (!mode) return { error: '请选择“纯音乐”或“纯伴奏”。' };
  if (bpm && !(+bpm >= 50 && +bpm <= 180)) return { error: '速度要在 50–180 BPM 之间，不填就是自动。' };
  return { mode, prompt, seconds: +$('seconds').value, bpm: bpm ? +bpm : 0, beats: $('beats').value ? +$('beats').value : 0 };
}
api.onProgress((p) => {
  if (!job || p.id !== job.id) return;
  if (p.stage === 'tick') { const li = $('stages').querySelector('li.on .d'); if (li && job.kind === 'minimax') li.textContent = `已等待 ${p.elapsed} 秒`; if (li && job.kind === 'local' && job.phase === 'compose' && !job.chars) li.textContent = `等待模型… ${p.elapsed} 秒`; return; }
  if (p.stage === 'compose' || p.stage === 'revise') { job.phase = 'compose'; job.chars = p.chars; stage('compose', (p.stage === 'revise' ? '修正第 2 次 · ' : '') + (p.chars ? `已收到 ${p.chars} 字` : `等待模型… ${p.elapsed || 0} 秒`), 0.05 + Math.min(0.3, (p.chars || 0) / 12000)); }
  if (p.stage === 'check') { job.phase = 'check'; stage('check', '', 0.36); }
  if (p.stage === 'remote') stage('remote', '', 0.1);
});

$('gen').onclick = async () => {
  if (job) return;
  await loadConfig();
  if (job) return; // 配置读取期间可能再次点击，不能重复提交生成请求。
  const f = readForm();
  if (f.error) { setMsg('msg', f.error, 'err'); return; }
  setMsg('msg', '');
  job = { id: 'm' + Date.now(), kind: cfg.backend, phase: 'compose', chars: 0 };
  const my = job;
  refresh();
  initStages(cfg.backend);
  stage(cfg.backend === 'minimax' ? 'remote' : 'compose', '准备中…', 0.02);
  try {
    const r = await api.generate({ id: my.id, ...f });
    if (job !== my) return;
    if (!r || r.error) throw Object.assign(new Error(r ? r.error : '没有响应'), { canceled: r && r.canceled });
    if (r.backend === 'minimax') await finishMinimax(r, my);
    else await finishLocal(r, my);
  } catch (e) {
    if (job === my) {
      setMsg('msg', e.canceled ? '已取消。可以修改要求后重新生成。' : e.message, e.canceled ? '' : 'err');
      const on = $('stages').querySelector('li.on'); if (on) on.className = e.canceled ? '' : 'fail';
    }
  } finally {
    if (job === my) { job = null; if (worker) { worker.terminate(); worker = null; } refresh(); }
  }
};
$('cancel').onclick = () => {
  if (!job) return;
  const my = job;
  api.cancel(my.id);
  if (worker) { worker.terminate(); worker = null; }
  job = null;
  setMsg('msg', '已取消。可以修改要求后重新生成。');
  [...$('stages').children].forEach((li) => { if (li.className === 'on') li.className = ''; });
  refresh();
};

function renderInWorker(score, my) {
  return new Promise((resolve, reject) => {
    worker = new Worker('music-worker.js');
    worker.onmessage = (e) => {
      const d = e.data;
      if (job !== my) return;
      if (d.error) { reject(new Error('渲染失败：' + d.error)); return; }
      if (d.done) { resolve(d); return; }
      const p = d.progress;
      const k = p < 0.05 ? 'arrange' : p < 0.78 ? 'synth' : p < 0.95 ? 'master' : 'encode';
      stage(k, k === 'synth' ? d.stage.replace(/^合成各声部/, '').replace(/[（）]/g, '') : '', 0.4 + p * 0.6);
    };
    worker.onerror = (e) => reject(new Error('渲染线程出错：' + (e.message || '未知错误')));
    worker.postMessage({ id: my.id, score });
  });
}

async function finishLocal(r, my) {
  stage('arrange', '', 0.4);
  const d = await renderInWorker(r.score, my);
  if (job !== my) return;
  worker.terminate(); worker = null;
  stagesDone();
  const desc = d.desc;
  showResult({
    bytes: new Uint8Array(d.wav), ext: 'wav', title: desc.title, duration: d.duration, peaks: d.peaks, sections: d.stats.sections,
    chips: [['类型', r.req.mode === 'accompaniment' ? '纯伴奏' : '纯音乐'], ['时长', mmss(d.duration)], ['调性', desc.key], ['速度', desc.bpm + ' BPM'], ['拍子', desc.beats + '/4'], ['小节', desc.bars], ['响度', d.stats.rmsDb + ' dBFS RMS']],
    meta: `本地多轨合成 · 写谱模型 ${r.model}`,
    method: `<b>多轨合成音乐</b>：${esc(r.model)} 按要求写出乐谱，本地合成音源演奏并混音（峰值 -1 dBFS，WAV 44.1kHz 立体声）。<br>曲式：${esc(desc.form)}<br>配器：${esc(desc.instruments.join('，'))}<br>声部：${esc(desc.tracks.map((t) => ({ lead: '主旋律', chords: '和声', pad: '铺底', bass: '低音', arp: '琶音', drums: '鼓' }[t])).join('、'))}${r.req.mode === 'accompaniment' ? '（纯伴奏：没有主旋律声部）' : ''}`,
    notes: r.notes,
  });
  setMsg('msg', `完成：${mmss(d.duration)}${r.attempts > 1 ? '（模型第一次的乐谱有问题，已让它修正一次）' : ''}。`, 'ok');
  api.done({ title: desc.title });
}

async function finishMinimax(r, my) {
  stage('decode', '', 0.9);
  const bytes = new Uint8Array(r.bytes);
  let buf;
  try { buf = await new OfflineAudioContext(2, 1, 44100).decodeAudioData(bytes.slice().buffer); }
  catch (e) { throw new Error('MiniMax 返回的音频解码失败（数据可能不完整）'); }
  if (job !== my) return;
  const P = 1600, ch = buf.getChannelData(0), step = Math.max(1, Math.floor(ch.length / P)), peaks = new Float32Array(P);
  for (let i = 0; i < P; i++) { let m = 0; for (let j = i * step; j < Math.min(ch.length, (i + 1) * step); j += 8) m = Math.max(m, Math.abs(ch[j])); peaks[i] = m; }
  stagesDone();
  const title = ($('prompt').value.trim().slice(0, 16) || 'MiniMax 生成') + (r.req.mode === 'accompaniment' ? '（伴奏）' : '');
  showResult({
    bytes, ext: 'mp3', title, duration: buf.duration, peaks, sections: [],
    chips: [['类型', r.req.mode === 'accompaniment' ? '纯伴奏（描述要求）' : '纯音乐'], ['时长', mmss(buf.duration)], ['模型', r.model], ['格式', 'MP3']],
    meta: `MiniMax 音乐生成 · ${r.model}`,
    method: `由 MiniMax 官方音乐模型 <b>${esc(r.model)}</b> 生成（is_instrumental，无人声模式）。时长、速度是写进描述里的参考，实际长度 ${mmss(buf.duration)}${r.req.seconds && Math.abs(buf.duration - r.req.seconds) > 20 ? `，和设置的 ${mmss(r.req.seconds)} 不同（接口不支持指定时长）` : ''}。`,
    notes: [],
  });
  setMsg('msg', `完成：${mmss(buf.duration)}。`, 'ok');
  api.done({ title });
}

/* ---------- 结果、试听、保存 ---------- */
function showResult(res) {
  stopAudio();
  current = res;
  if (blobUrl) URL.revokeObjectURL(blobUrl);
  blobUrl = URL.createObjectURL(new Blob([res.bytes], { type: res.ext === 'mp3' ? 'audio/mpeg' : 'audio/wav' }));
  $('audio').src = blobUrl;
  $('empty').hidden = true; $('result').hidden = false;
  $('title').textContent = res.title;
  $('resultMeta').textContent = res.meta;
  $('chips').innerHTML = res.chips.map(([k, v]) => `<span class="chip">${k} <b>${esc(v)}</b></span>`).join('');
  $('method').innerHTML = res.method;
  $('notesBox').hidden = !res.notes.length;
  $('notes').innerHTML = res.notes.map((n) => `<li>${esc(n)}</li>`).join('');
  setMsg('saveMsg', '');
  drawWave(0);
  $('time').textContent = `0:00 / ${mmss(res.duration)}`;
}
function drawWave(pos) {
  const c = $('wave'), g = c.getContext('2d'), W = c.width, H = c.height;
  g.clearRect(0, 0, W, H);
  if (!current) return;
  const T = current.duration;
  g.font = '20px "Microsoft YaHei UI", sans-serif'; g.textBaseline = 'top';
  current.sections.forEach((s, i) => {
    const x0 = s.start / T * W, x1 = s.end / T * W;
    g.fillStyle = i % 2 ? '#e9eef1' : '#f6f0ef'; g.fillRect(x0, 0, x1 - x0, H);
    g.fillStyle = '#6b7c88'; g.fillText(s.name, x0 + 5, 5);
  });
  const P = current.peaks.length, mx = Math.max(...current.peaks, 1e-6);
  for (let i = 0; i < P; i++) {
    const x = i / P * W, h = current.peaks[i] / mx * (H - 40) / 2;
    g.fillStyle = i / P < pos / T ? '#934657' : '#9aabb7';
    g.fillRect(x, H / 2 + 12 - h, Math.max(1, W / P), h * 2);
  }
  if (pos > 0) { g.fillStyle = '#7a3545'; g.fillRect(pos / T * W - 1, 0, 2, H); }
}
function tickPlay() {
  const a = $('audio');
  drawWave(a.currentTime);
  $('time').textContent = `${mmss(a.currentTime)} / ${mmss(current ? current.duration : 0)}`;
  if (!a.paused) raf = requestAnimationFrame(tickPlay);
}
function stopAudio() { const a = $('audio'); a.pause(); try { a.currentTime = 0; } catch (e) {} cancelAnimationFrame(raf); if (current) { drawWave(0); $('time').textContent = `0:00 / ${mmss(current.duration)}`; } $('play').textContent = '▶ 试听'; }
$('play').onclick = async () => {
  const a = $('audio');
  if (!a.paused) { a.pause(); $('play').textContent = '▶ 试听'; return; }
  try { await a.play(); $('play').textContent = '❚❚ 暂停'; tickPlay(); } catch (e) { setMsg('saveMsg', '播放失败：' + e.message, 'err'); }
};
$('stop').onclick = stopAudio;
$('audio').addEventListener('ended', () => { $('play').textContent = '▶ 试听'; cancelAnimationFrame(raf); drawWave(current ? current.duration : 0); });
$('wave').addEventListener('click', (e) => { if (!current) return; const r = $('wave').getBoundingClientRect(); const a = $('audio'); a.currentTime = (e.clientX - r.left) / r.width * current.duration; drawWave(a.currentTime); $('time').textContent = `${mmss(a.currentTime)} / ${mmss(current.duration)}`; });
$('save').onclick = async () => {
  if (!current) return;
  $('save').disabled = true;
  try {
    const r = await api.save({ name: current.title, bytes: current.bytes, ext: current.ext });
    if (r && r.ok) setMsg('saveMsg', '已保存：' + r.path, 'ok');
    else if (r && r.error) setMsg('saveMsg', r.error, 'err');
  } finally { $('save').disabled = false; }
};

$('secVal').textContent = mmss(+$('seconds').value);
loadConfig();
