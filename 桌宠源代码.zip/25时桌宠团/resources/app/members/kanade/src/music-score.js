'use strict';
/* 纯音乐 / 纯伴奏：乐谱格式、检查修正、编配展开、WAV 编码（纯计算，浏览器和 Node 都能用）
 *
 * 流程：聊天模型按 buildPrompt() 的要求写出 JSON 乐谱（调性、速度、配器、每段的和弦进行 / 旋律 / 律动、曲式）
 *       → normalize() 检查并修正（模式、时长、结尾、音域、拍数对齐）
 *       → arrange() 把乐谱展开成每个乐器的音符事件（和弦排位、低音线、琶音、鼓点、结尾）
 *       → 渲染器（music-render.js）用本地合成音源演奏、混音、导出。
 * 旋律、和声、曲式、配器和律动选择都来自模型按要求写的乐谱；这里只做检查和演奏方式的展开。
 */
(function (root) {
  const PCS = { C: 0, D: 2, E: 4, F: 5, G: 7, A: 9, B: 11 };
  const NAMES = ['C', 'C#', 'D', 'Eb', 'E', 'F', 'F#', 'G', 'Ab', 'A', 'Bb', 'B'];
  const MODES = { major: [0, 2, 4, 5, 7, 9, 11], minor: [0, 2, 3, 5, 7, 8, 10], dorian: [0, 2, 3, 5, 7, 9, 10], mixolydian: [0, 2, 4, 5, 7, 9, 10], lydian: [0, 2, 4, 6, 7, 9, 11], phrygian: [0, 1, 3, 5, 7, 8, 10] };
  const MODE_ZH = { major: '大调', minor: '小调', dorian: '多利亚', mixolydian: '混合利底亚', lydian: '利底亚', phrygian: '弗里几亚' };

  // 本地音源里有的乐器（都是乐器，没有人声 / 合唱 / 哼唱）
  const INSTRUMENTS = {
    piano: '钢琴', epiano: '电钢琴', strings: '弦乐', pad: '合成铺底', organ: '风琴', pluck: '拨弦（吉他感）', harp: '竖琴',
    bell: '钟琴', marimba: '马林巴', musicbox: '八音盒', flute: '长笛', synthlead: '合成主音', brass: '铜管', cello: '大提琴',
    fingerbass: '指弹贝斯', synthbass: '合成贝斯', uprightbass: '低音提琴',
  };
  const LEAD_OK = ['piano', 'epiano', 'flute', 'synthlead', 'bell', 'marimba', 'musicbox', 'strings', 'brass', 'cello', 'pluck', 'harp', 'organ'];
  const BASS_OK = ['fingerbass', 'synthbass', 'uprightbass', 'cello', 'piano'];
  const KITS = { acoustic: '原声鼓', electronic: '电子鼓', lofi: '低保真鼓', brush: '刷子鼓', none: '无鼓' };
  const DRUM_STYLES = ['none', 'light', 'groove', 'four_on_floor', 'halftime', 'shuffle', 'waltz', 'build', 'breakbeat'];
  const BASS_STYLES = ['none', 'root', 'octave', 'walking', 'pedal', 'syncopated', 'arpeggio'];
  const CHORD_STYLES = ['none', 'sustain', 'block', 'stabs', 'broken', 'strum'];
  const ARP_STYLES = ['none', 'up', 'down', 'updown', 'alberti'];
  const VOICE_WORDS = /人声|演唱|唱歌|歌声|歌词|合唱|哼唱|哼鸣|说话|旁白|念白|rap|说唱|vocal|voice|choir|sing|lyric|hum/i;

  const clamp = (x, a, b) => Math.max(a, Math.min(b, x));
  const num = (x, d) => (Number.isFinite(+x) ? +x : d);
  const round = (x, q = 0.25) => Math.round(x / q) * q;

  /* ---------- 解析：调、和弦、音符 ---------- */
  function parseKey(k, m) {
    const s = String(k || 'C').trim().replace('♯', '#').replace('♭', 'b');
    const mm = /^([A-Ga-g])([#b]?)\s*(major|minor|maj|min|m|dorian|mixolydian|lydian|phrygian|大调|小调)?/i.exec(s);
    if (!mm) return null;
    let mode = String(m || mm[3] || 'major').toLowerCase();
    mode = { maj: 'major', min: 'minor', m: 'minor', 大调: 'major', 小调: 'minor' }[mode] || mode;
    if (!MODES[mode]) mode = 'major';
    const tonic = (PCS[mm[1].toUpperCase()] + (mm[2] === '#' ? 1 : mm[2] === 'b' ? -1 : 0) + 12) % 12;
    return { tonic, mode, text: `${NAMES[tonic]} ${MODE_ZH[mode]}` };
  }
  const QUALITY = {
    '': [0, 4, 7], M: [0, 4, 7], maj: [0, 4, 7], m: [0, 3, 7], min: [0, 3, 7], '-': [0, 3, 7], dim: [0, 3, 6], aug: [0, 4, 8], '+': [0, 4, 8],
    sus2: [0, 2, 7], sus4: [0, 5, 7], sus: [0, 5, 7], 5: [0, 7], 6: [0, 4, 7, 9], m6: [0, 3, 7, 9], 7: [0, 4, 7, 10], maj7: [0, 4, 7, 11], M7: [0, 4, 7, 11],
    m7: [0, 3, 7, 10], min7: [0, 3, 7, 10], mmaj7: [0, 3, 7, 11], m7b5: [0, 3, 6, 10], dim7: [0, 3, 6, 9], add9: [0, 4, 7, 14], madd9: [0, 3, 7, 14],
    9: [0, 4, 7, 10, 14], maj9: [0, 4, 7, 11, 14], m9: [0, 3, 7, 10, 14], 11: [0, 4, 7, 10, 17], m11: [0, 3, 7, 10, 17], 13: [0, 4, 7, 10, 21], '7sus4': [0, 5, 7, 10],
  };
  function parseChord(sym) {
    const s = String(sym || '').trim().replace(/♯/g, '#').replace(/♭/g, 'b').replace(/Δ/g, 'maj7').replace(/ø/g, 'm7b5').replace(/°/g, 'dim');
    if (!s) return null;
    if (/^(N\.?C\.?|-|x|休止)$/i.test(s)) return { rest: true, sym: s };
    const m = /^([A-G])([#b]?)([^/]*)(?:\/([A-G])([#b]?))?$/.exec(s);
    if (!m) return null;
    const q = m[3];
    if (!(q in QUALITY)) return null;
    const root = (PCS[m[1]] + (m[2] === '#' ? 1 : m[2] === 'b' ? -1 : 0) + 12) % 12;
    const bass = m[4] ? (PCS[m[4]] + (m[5] === '#' ? 1 : m[5] === 'b' ? -1 : 0) + 12) % 12 : root;
    return { root, bass, ivs: QUALITY[q], sym: s };
  }
  function parseNote(tok) {
    const m = /^([A-Ga-g])([#b]?)(-?\d)$/.exec(String(tok).replace('♯', '#').replace('♭', 'b'));
    if (!m) return null;
    return 12 * (+m[3] + 1) + PCS[m[1].toUpperCase()] + (m[2] === '#' ? 1 : m[2] === 'b' ? -1 : 0);
  }
  // "D5/1 F5/0.5 r/1" → [{p:midi|null, d:拍}]
  function parseLine(str, kind = '旋律') {
    const out = [], bad = [];
    const toks = Array.isArray(str) ? str : String(str || '').trim().split(/[\s,|]+/).filter(Boolean);
    for (const tk of toks) {
      const [a, b] = String(tk).split(/[/:*]/);   // 也接受 A4:1、A4*1 这类写法
      const d = round(num(b, 1));
      if (!(d > 0) || d > 16) { bad.push(tk); continue; }
      if (/^(r|rest|0|-)$/i.test(a)) { out.push({ p: null, d }); continue; }
      const p = parseNote(a);
      if (p == null) { bad.push(tk); continue; }
      out.push({ p, d });
    }
    return { notes: out, bad };
  }

  /* ---------- 给模型的提示词 ---------- */
  function targetBars(seconds, bpm, beats) { return Math.max(8, Math.round(seconds * bpm / 60 / beats)); }

  function buildPrompt(req) {
    const acc = req.mode === 'accompaniment';
    const bpm = req.bpm || null;
    const beats = req.beats || 4;
    const bars = targetBars(req.seconds, bpm || 96, beats);
    const sys = [
      '你是作曲和编曲家。根据用户的中文要求，写一首完整的器乐作品的乐谱，只输出一个 JSON 对象，不要任何解释。',
      '这首曲子会由本地的合成音源演奏，只有乐器，没有任何人声：不要写歌词、演唱、说话、哼唱、合唱。',
      acc
        ? '模式：纯伴奏。只写和声、节奏和配器（和弦、铺底、琶音、低音、鼓），不要写主旋律：JSON 里不要 lead 乐器，各段不要 melody 字段。琶音要在中音区、作为背景织体，不要变成突出的旋律。'
        : '模式：纯音乐。要有完整、好记的主旋律（melody），由 lead 乐器演奏；主旋律要有动机、发展和对比，副歌/高潮段更明亮，结尾回到主音。',
      '',
      'JSON 格式：',
      '{',
      '  "title": "中文曲名",',
      `  "bpm": ${bpm || '60–170 之间的整数'},`,
      `  "key": "D", "mode": "minor",          // mode 可选 ${Object.keys(MODES).join(' / ')}`,
      `  "beats": ${beats},                      // 每小节拍数，3 或 4`,
      `  "instruments": { ${acc ? '' : '"lead": "flute", '}"chords": "piano", "pad": "strings", "bass": "fingerbass", "arp": "pluck", "kit": "acoustic" },`,
      `     // 可用乐器：${Object.keys(INSTRUMENTS).join(' / ')}；kit 可选 ${Object.keys(KITS).join(' / ')}；不需要的声部可以省略`,
      '  "sections": {',
      '    "intro": { "bars": 4, "chords": "Dm | Bb | F | C", "energy": 0.3, "drums": "none", "bass": "pedal", "chordStyle": "sustain", "arp": "none"' + (acc ? ' },' : ', "melody": "r/4 | A4/2 D5/2 | …" },'),
      '    "A": { … }, "B": { … }, "bridge": { … }, "outro": { … }',
      '  },',
      '  "form": ["intro", "A", "B", "A", "bridge", "B", "outro"],   // 演奏顺序，段落可以重复',
      '  "ending": "ritardando"   // ritardando 渐慢收尾 / fade 淡出 / final_hit 齐奏收束',
      '}',
      '',
      '规则：',
      '- chords：用 | 分隔小节，小节数等于 bars；一小节里可以写两个和弦（空格隔开，平分）。和弦写法如 C Dm7 G7 Fmaj7 Bb/D Esus4 Am6 Bdim。',
      acc ? '' : '- melody：写成“音名八度/拍数”，例如 "A4/1 C5/0.5 D5/0.5 r/2"，r 是休止，可以用 | 标出小节；每段 melody 的总拍数 = bars × beats。音域在 G3–C6 之间。',
      `- drums 可选：${DRUM_STYLES.join(' / ')}；bass 可选：${BASS_STYLES.join(' / ')}；chordStyle 可选：${CHORD_STYLES.join(' / ')}；arp 可选：${ARP_STYLES.join(' / ')}。`,
      '- 也可以自己写鼓：在段落里加 "drumPattern": { "kick": "x...x...x...x...", "snare": "....x.......x...", "hat": "x.x.x.x.x.x.x.x." }，每小节 16 格（3 拍子 12 格），x 重击、o 轻击、. 不打。',
      '- energy 0–1 表示这段的力度和密度。要有起伏：前奏轻、主体逐步展开、高潮最强、结尾收住。',
      `- 曲式要有发展：至少 3 种不同的段落，并且有前奏和结尾段（outro）。整首按 form 展开后共约 ${bars} 小节（${req.seconds} 秒${bpm ? `，速度固定 ${bpm} BPM` : ''}）。`,
      '- 最后一段的最后一个和弦用主和弦，让曲子完整结束。',
    ].filter((l) => l !== '').join('\n');
    const user = [
      `用户的要求：${String(req.prompt || '').slice(0, 800)}`,
      `时长：约 ${req.seconds} 秒。${bpm ? `速度：${bpm} BPM（必须使用）。` : '速度：按要求自己选。'}${req.beats ? `拍子：${req.beats}/4。` : ''}`,
      acc ? '这是纯伴奏：只要和声、节奏、配器，不要主旋律。' : '这是纯音乐：需要完整的主旋律。',
      '只输出 JSON。',
    ].join('\n');
    return { system: sys, user, targetBars: bars };
  }

  /* ---------- 检查和修正 ---------- */
  function extractJSON(text) {
    let t = String(text || '').trim();
    const fence = /```(?:json)?\s*([\s\S]*?)```/i.exec(t);
    if (fence) t = fence[1].trim();
    const a = t.indexOf('{'), b = t.lastIndexOf('}');
    if (a < 0 || b <= a) throw new Error('模型没有返回 JSON 乐谱');
    try { return JSON.parse(t.slice(a, b + 1)); }
    catch (e) { throw new Error('模型返回的乐谱不是有效的 JSON：' + e.message.slice(0, 80)); }
  }

  /**
   * 检查并修正乐谱。返回 { score, notes:[修正说明], errors:[需要模型重写的问题] }
   * req：{ mode, seconds, bpm(用户指定，可空), beats }
   */
  function normalize(raw, req) {
    const notes = [], errors = [];
    if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return { score: null, notes, errors: ['乐谱不是 JSON 对象'] };
    const acc = req.mode === 'accompaniment';
    const sc = {};
    sc.title = String(raw.title || '').replace(/[\r\n]/g, ' ').trim().slice(0, 40) || (acc ? '无题伴奏' : '无题');
    const userBpm = req.bpm ? clamp(Math.round(req.bpm), 50, 180) : 0;
    sc.bpm = userBpm || clamp(Math.round(num(raw.bpm, 96)), 50, 180);
    if (userBpm && raw.bpm && Math.round(raw.bpm) !== userBpm) notes.push(`速度按你的设置用 ${userBpm} BPM（模型写的是 ${raw.bpm}）`);
    sc.beats = req.beats || ([3, 4].includes(+raw.beats) ? +raw.beats : 4);
    const key = parseKey(raw.key, raw.mode);
    if (!key) { notes.push(`看不懂调性“${raw.key}”，改用 C 大调`); }
    sc.key = key || parseKey('C', 'major');

    // 配器
    const ins = raw.instruments && typeof raw.instruments === 'object' ? raw.instruments : {};
    const pick = (v, ok, def) => { const s = String(v || '').toLowerCase().replace(/[\s_-]/g, ''); return ok.includes(s) ? s : def; };
    sc.instruments = {};
    for (const role of ['lead', 'chords', 'pad', 'bass', 'arp']) {
      if (!ins[role]) continue;
      const okList = role === 'bass' ? BASS_OK : role === 'lead' ? LEAD_OK : Object.keys(INSTRUMENTS);
      const v = pick(ins[role], okList, null);
      if (v) sc.instruments[role] = v;
      else if (VOICE_WORDS.test(String(ins[role]))) notes.push(`去掉了“${ins[role]}”：这首不能有人声`);
      else { sc.instruments[role] = { lead: 'piano', chords: 'piano', pad: 'pad', bass: 'fingerbass', arp: 'pluck' }[role]; notes.push(`没有“${ins[role]}”这个乐器，${role} 声部改用 ${INSTRUMENTS[sc.instruments[role]]}`); }
    }
    sc.kit = pick(ins.kit || ins.drums, Object.keys(KITS), 'acoustic');
    if (acc && sc.instruments.lead) { delete sc.instruments.lead; notes.push('纯伴奏模式：去掉了主旋律声部（lead）'); }
    if (!sc.instruments.chords && !sc.instruments.pad) { sc.instruments.chords = 'piano'; notes.push('没有和声乐器，补了钢琴'); }
    if (!sc.instruments.bass) { sc.instruments.bass = 'fingerbass'; notes.push('没有低音乐器，补了指弹贝斯'); }
    if (!acc && !sc.instruments.lead) sc.instruments.lead = 'piano';

    // 段落
    const secIn = raw.sections && typeof raw.sections === 'object' ? raw.sections : {};
    const entries = Array.isArray(secIn) ? secIn.map((s, i) => [String((s && s.name) || 'S' + (i + 1)), s]) : Object.entries(secIn);
    sc.sections = {};
    const bpb = sc.beats;
    let melodyCount = 0, accWarned = false;
    for (const [name0, s] of entries.slice(0, 16)) {
      if (!s || typeof s !== 'object') continue;
      const name = String(name0).slice(0, 20);
      const bars = clamp(Math.round(num(s.bars, 8)), 1, 32);
      const sec = { name, bars, energy: clamp(num(s.energy, 0.5), 0, 1) };
      // 和弦：每小节一个或几个
      const barStrs = String(Array.isArray(s.chords) ? s.chords.map((b) => (Array.isArray(b) ? b.join(' ') : b)).join(' | ') : s.chords || '').split('|').map((x) => x.trim()).filter(Boolean);
      const badChords = [];
      let chordBars = barStrs.map((b) => b.split(/\s+/).map((c) => { const p = parseChord(c); if (!p) badChords.push(c); return p; }).filter(Boolean));
      chordBars = chordBars.filter((b) => b.length);
      if (badChords.length) notes.push(`段落 ${name}：看不懂的和弦 ${badChords.slice(0, 4).join(' ')}，已跳过`);
      if (!chordBars.length) { errors.push(`段落 ${name} 没有可用的和弦`); continue; }
      if (chordBars.length !== bars) {
        const fixed = [];
        for (let i = 0; i < bars; i++) fixed.push(chordBars[i % chordBars.length]);
        if (chordBars.length < bars) notes.push(`段落 ${name}：和弦只写了 ${chordBars.length} 小节，按顺序循环补满 ${bars} 小节`);
        else notes.push(`段落 ${name}：和弦写了 ${chordBars.length} 小节，只用前 ${bars} 小节`);
        chordBars = fixed;
      }
      sec.chords = chordBars;
      sec.drums = DRUM_STYLES.includes(s.drums) ? s.drums : (sec.energy < 0.25 ? 'none' : 'groove');
      sec.bass = BASS_STYLES.includes(s.bass) ? s.bass : 'root';
      sec.chordStyle = CHORD_STYLES.includes(s.chordStyle) ? s.chordStyle : 'sustain';
      sec.arp = ARP_STYLES.includes(s.arp) ? s.arp : 'none';
      if (s.drumPattern && typeof s.drumPattern === 'object') {
        const steps = bpb * 4, dp = {};
        for (const k of ['kick', 'snare', 'hat', 'openhat', 'clap', 'ride', 'shaker', 'tom']) {
          const v = String(s.drumPattern[k] || '').replace(/\s/g, '');
          if (/^[xXoO.\-]+$/.test(v)) dp[k] = (v.repeat(Math.ceil(steps / v.length))).slice(0, steps);
        }
        if (Object.keys(dp).length) sec.drumPattern = dp;
      }
      if (s.melody && acc && !accWarned) { notes.push('纯伴奏模式：去掉了各段的主旋律'); accWarned = true; }
      if (s.melody && !acc) {
        const { notes: mel, bad } = parseLine(s.melody);
        if (bad.length) notes.push(`段落 ${name}：旋律里有看不懂的音 ${bad.slice(0, 4).join(' ')}，已跳过`);
        const total = bars * bpb;
        let sum = 0; const fit = [];
        for (const n of mel) { if (sum >= total) break; const d = Math.min(n.d, total - sum); fit.push({ p: n.p == null ? null : clamp(n.p, 55, 86), d }); sum += d; }
        if (sum < total) fit.push({ p: null, d: total - sum });
        const diff = mel.reduce((t, n) => t + n.d, 0) - total;
        if (Math.abs(diff) >= bpb) notes.push(`段落 ${name}：旋律${diff > 0 ? '比段落长，截掉了' : '比段落短，补了休止'} ${Math.abs(diff)} 拍`);
        if (fit.some((n) => n.p != null)) { sec.melody = fit; melodyCount++; }
      }
      sc.sections[name] = sec;
    }
    const names = Object.keys(sc.sections);
    if (names.length < 3) errors.push(`只有 ${names.length} 种段落，至少需要 3 种（前奏、主体、结尾），曲子才有发展`);
    if (!acc && melodyCount === 0) errors.push('纯音乐模式需要主旋律，但所有段落都没有可用的 melody');

    // 曲式
    const byLower = {}; for (const n of names) byLower[n.toLowerCase().replace(/\s+/g, '')] = n;
    const resolve = (n) => sc.sections[n] ? n : byLower[String(n).toLowerCase().replace(/\s+/g, '')];
    let form = (Array.isArray(raw.form) ? raw.form : []).map(String).map(resolve).filter(Boolean);
    const missing = (Array.isArray(raw.form) ? raw.form : []).map(String).filter((n) => !resolve(n));
    if (missing.length) notes.push(`曲式里的 ${[...new Set(missing)].slice(0, 4).join('、')} 没有定义，已跳过`);
    if (form.length < 3) { if (names.length >= 3) { form = names.slice(); notes.push('曲式不完整，按段落定义的顺序演奏'); } }
    if (form.length && names.length >= 3) {
      const isEnd = (n) => /outro|ending|coda|尾|结/i.test(n);
      if (!form.some(isEnd) && !isEnd(form[form.length - 1])) notes.push('没有单独的结尾段：最后一段后面会加一小节主和弦收束');
    }
    sc.ending = ['ritardando', 'fade', 'final_hit'].includes(raw.ending) ? raw.ending : 'ritardando';

    // 时长：和目标差太多时，重复或删掉中间的段落（不动第一次出现的段落、前奏和结尾）
    const target = targetBars(req.seconds, sc.bpm, sc.beats);
    const barsOf = (f) => f.reduce((t, n) => t + sc.sections[n].bars, 0);
    if (form.length >= 3) {
      const before = barsOf(form);
      let guard = 0;
      const mid = () => form.slice(1, -1);
      while (barsOf(form) < target * 0.85 && guard++ < 24) {
        // 再来一遍主体：找中间最常出现的两个段落按原顺序重复
        const m = mid(); if (!m.length) break;
        const counts = {}; m.forEach((n) => { counts[n] = (counts[n] || 0) + 1; });
        const main = Object.keys(counts).sort((a, b) => counts[b] - counts[a] || sc.sections[b].energy - sc.sections[a].energy)[0];
        const i = form.lastIndexOf(main);
        const insert = form.slice(Math.max(1, i - 1), i + 1);
        form.splice(form.length - 1, 0, ...insert);
      }
      while (barsOf(form) > target * 1.2 && guard++ < 48) {
        // 从后往前删掉重复出现的中间段落
        let removed = false;
        for (let i = form.length - 2; i >= 1; i--) {
          if (form.indexOf(form[i]) !== i) { form.splice(i, 1); removed = true; break; }
        }
        if (!removed) break;
      }
      const after = barsOf(form);
      if (after !== before) notes.push(`为了接近 ${req.seconds} 秒，曲式从 ${before} 小节调整为 ${after} 小节：${form.join(' → ')}`);
      if (after < target * 0.6) errors.push(`曲子太短：只有 ${after} 小节，目标约 ${target} 小节（${req.seconds} 秒）`);
      if (after > target * 1.6) errors.push(`曲子太长：有 ${after} 小节，目标约 ${target} 小节`);
    }
    sc.form = form;

    // 结尾：最后一个和弦不是主和弦就补一小节
    if (form.length) {
      const last = sc.sections[form[form.length - 1]];
      const lastBar = last.chords[last.chords.length - 1];
      const lc = lastBar[lastBar.length - 1];
      sc.addTonicBar = !(lc && !lc.rest && lc.root === sc.key.tonic);
      if (sc.addTonicBar) notes.push('最后一个和弦不是主和弦：结尾补了一小节主和弦');
    }
    sc.mode = acc ? 'accompaniment' : 'music';
    sc.targetBars = target;
    return { score: errors.length ? null : sc, partial: sc, notes, errors };
  }

  /* ---------- 编配展开：乐谱 → 音符事件 ---------- */
  function chordPitches(ch, center) {
    // 在 center 附近排一个紧凑的和弦（转位让声部移动最小）
    const pcs = ch.ivs.map((iv) => (ch.root + iv) % 12);
    const uniq = [...new Set(pcs)];
    const out = [];
    for (const pc of uniq) { let m = pc + 12 * Math.floor(center / 12); while (m < center - 6) m += 12; while (m > center + 6) m -= 12; out.push(m); }
    return out.sort((a, b) => a - b);
  }
  const VEL = (base, energy) => clamp(base * (0.55 + 0.6 * energy), 0.05, 1);

  function arrange(sc) {
    const ev = [];   // { tr, ins, t(拍), d(拍), p(midi), v }
    const bpb = sc.beats;
    let t = 0, center = 60;
    const push = (tr, ins, tt, d, p, v) => { if (d > 0 && p >= 24 && p <= 100) ev.push({ tr, ins, t: tt, d, p, v }); };
    const drum = (k, tt, v) => ev.push({ tr: 'drums', ins: sc.kit, t: tt, d: 0.25, p: k, v });
    const sections = [];
    const formLen = sc.form.length;
    sc.form.forEach((name, fi) => {
      const s = sc.sections[name];
      const start = t;
      const e = s.energy;
      const nextName = sc.form[fi + 1];
      const lastOfSong = fi === formLen - 1;
      sections.push({ name, start, bars: s.bars, energy: e });
      // 旋律
      if (s.melody && sc.instruments.lead) {
        let mt = t;
        s.melody.forEach((n, i) => {
          if (n.p != null) {
            const isLastNote = lastOfSong && i === s.melody.length - 1;
            push('lead', sc.instruments.lead, mt, n.d * (isLastNote ? 1 : 0.95), n.p, VEL(0.8, Math.max(0.45, e)));
          }
          mt += n.d;
        });
      }
      for (let b = 0; b < s.bars; b++) {
        const bt = t + b * bpb;
        const chs = s.chords[b];
        const seg = bpb / chs.length;
        chs.forEach((ch, ci) => {
          if (ch.rest) return;
          const ct = bt + ci * seg;
          const voicing = chordPitches(ch, center);
          center = Math.round((center * 2 + (voicing[0] + voicing[voicing.length - 1]) / 2) / 3);
          center = clamp(center, 55, 66);
          // 和声乐器
          if (sc.instruments.chords && s.chordStyle !== 'none') {
            const ins = sc.instruments.chords, v = VEL(0.55, e);
            if (s.chordStyle === 'sustain') voicing.forEach((p) => push('chords', ins, ct, seg * 0.98, p, v));
            else if (s.chordStyle === 'block') for (let k = 0; k < seg; k++) voicing.forEach((p) => push('chords', ins, ct + k, 0.9, p, v * (k === 0 ? 1 : 0.8)));
            else if (s.chordStyle === 'stabs') for (let k = 0.5; k < seg; k += 1) voicing.forEach((p) => push('chords', ins, ct + k, 0.35, p, v * 0.9));
            else if (s.chordStyle === 'broken') { const pat = [voicing[0] - 12, voicing[voicing.length - 1], voicing[1] || voicing[0], voicing[voicing.length - 1]]; for (let k = 0; k < seg * 2; k++) push('chords', ins, ct + k * 0.5, 0.5, pat[k % 4], v * (k % 2 ? 0.8 : 1)); }
            else if (s.chordStyle === 'strum') for (let k = 0; k < seg; k += (e > 0.6 ? 0.5 : 1)) voicing.concat([voicing[0] + 12]).forEach((p, i) => push('chords', ins, ct + k + i * 0.03, 0.9, p, v * (Number.isInteger(k) ? 1 : 0.7)));
          }
          // 铺底
          if (sc.instruments.pad && e >= 0.15) voicing.concat([voicing[0] + 12]).forEach((p) => push('pad', sc.instruments.pad, ct, seg, p, VEL(0.45, e)));
          // 琶音
          if (sc.instruments.arp && s.arp !== 'none') {
            const acc = sc.mode === 'accompaniment';
            const base = chordPitches(ch, acc ? 57 : 67);
            const tones = base.concat(base.map((p) => p + 12));
            let seq = s.arp === 'down' ? tones.slice().reverse() : s.arp === 'updown' ? tones.concat(tones.slice(1, -1).reverse()) : s.arp === 'alberti' ? [base[0], base[2] || base[1], base[1], base[2] || base[1]] : tones;
            const step = e >= 0.55 ? 0.25 : 0.5;
            for (let k = 0, i = 0; k < seg - 1e-6; k += step, i++) push('arp', sc.instruments.arp, ct + k, step * 0.9, seq[i % seq.length], VEL(acc ? 0.38 : 0.45, e) * (i % 2 ? 0.85 : 1));
          }
          // 低音
          if (sc.instruments.bass && s.bass !== 'none') {
            const ins = sc.instruments.bass, v = VEL(0.75, e);
            let r = 36 + ((ch.bass - 36) % 12 + 12) % 12; if (r > 47) r -= 12;
            const fifth = r + 7, oct = r + 12;
            if (s.bass === 'root' || s.bass === 'pedal') { const pedal = s.bass === 'pedal' ? 36 + ((sc.key.tonic - 36) % 12 + 12) % 12 : r; for (let k = 0; k < seg; k += (s.bass === 'pedal' ? seg : (e > 0.5 ? 1 : 2))) push('bass', ins, ct + k, Math.min(seg - k, s.bass === 'pedal' ? seg : (e > 0.5 ? 1 : 2)) * 0.95, pedal, v); }
            else if (s.bass === 'octave') for (let k = 0; k < seg; k += 0.5) push('bass', ins, ct + k, 0.45, (k * 2) % 2 ? oct : r, v * ((k * 2) % 2 ? 0.8 : 1));
            else if (s.bass === 'walking') { const w = [r, r + (ch.ivs[1] || 4), fifth, r + 9 > oct ? oct : r + 9]; for (let k = 0; k < seg; k++) push('bass', ins, ct + k, 0.9, w[k % 4], v); }
            else if (s.bass === 'syncopated') [[0, 1.5], [1.5, 1], [2.5, 0.5], [3, 1]].forEach(([o, d]) => { if (o < seg) push('bass', ins, ct + o, Math.min(d, seg - o) * 0.9, o === 2.5 ? oct : r, v * (o ? 0.85 : 1)); });
            else if (s.bass === 'arpeggio') { const a = [r, r + (ch.ivs[1] || 4), fifth, oct]; for (let k = 0; k < seg; k += 0.5) push('bass', ins, ct + k, 0.45, a[(k * 2) % 4], v * 0.9); }
          }
        });
        // 鼓
        if (sc.kit !== 'none') drumBar(s, bt, b, fi, nextName, lastOfSong, drum, bpb);
      }
      t += s.bars * bpb;
    });
    // 结尾：主和弦长音（+ 低音、铺底），final_hit 时加镲
    const endT = t;
    const tonicCh = { root: sc.key.tonic, bass: sc.key.tonic, ivs: ['minor', 'dorian', 'phrygian'].includes(sc.key.mode) ? [0, 3, 7] : [0, 4, 7] };
    const holdBars = sc.addTonicBar ? 2 : 1;
    const hold = holdBars * bpb;
    const lastSec = sc.sections[sc.form[sc.form.length - 1]];
    const ve = Math.max(0.35, lastSec.energy);
    const voicing = chordPitches(tonicCh, 60);
    if (sc.addTonicBar || sc.ending !== 'fade') {
      if (sc.instruments.chords) voicing.concat([voicing[0] - 12]).forEach((p) => push('chords', sc.instruments.chords, endT, hold, p, VEL(0.6, ve)));
      if (sc.instruments.pad) voicing.concat([voicing[0] + 12]).forEach((p) => push('pad', sc.instruments.pad, endT, hold, p, VEL(0.45, ve)));
      if (sc.instruments.bass) push('bass', sc.instruments.bass, endT, hold, 36 + ((sc.key.tonic - 36) % 12 + 12) % 12, VEL(0.75, ve));
      if (sc.instruments.lead && sc.mode !== 'accompaniment') push('lead', sc.instruments.lead, endT, hold, 72 + ((sc.key.tonic - 72) % 12 + 12) % 12, VEL(0.7, ve));
      if (sc.kit !== 'none' && (sc.ending === 'final_hit' || ve > 0.5)) { drum('crash', endT, 0.8); drum('kick', endT, 0.9); }
    }
    const totalBeats = endT + hold;
    ev.sort((a, b) => a.t - b.t);
    return { events: ev, sections, totalBeats, endBeat: endT, tracks: [...new Set(ev.map((e) => e.tr))] };
  }

  const STYLE_PATTERNS = {
    light: { kick: 'x.......x.......', hat: '..x...x...x...x.', snare: '................', shaker: 'o.o.o.o.o.o.o.o.' },
    groove: { kick: 'x.....x.x.......', snare: '....x.......x...', hat: 'x.x.x.x.x.x.x.x.' },
    four_on_floor: { kick: 'x...x...x...x...', clap: '....x.......x...', hat: '..x...x...x...x.', openhat: '..o...o...o...o.' },
    halftime: { kick: 'x.......x.x.....', snare: '........x.......', hat: 'x.x.x.x.x.x.x.x.' },
    shuffle: { kick: 'x.....x.x.......', snare: '....x.......x...', hat: 'x..x.xx..x.xx..x' },
    waltz: { kick: 'x...........', snare: '....x...x...', hat: 'x.x.x.x.x.x.' },
    build: { kick: 'x...x...x...x...', snare: '....x...x.x.xxxx', hat: 'x.x.x.x.x.x.x.x.' },
    breakbeat: { kick: 'x.x.......x.....', snare: '....x..x.x..x...', hat: 'x.x.x.x.x.x.x.x.' },
  };
  function drumBar(s, bt, b, fi, nextName, last, drum, bpb) {
    const steps = bpb * 4;
    let pat = s.drumPattern;
    if (!pat) {
      if (s.drums === 'none') return;
      pat = STYLE_PATTERNS[s.drums] || STYLE_PATTERNS.groove;
      if (bpb === 3 && s.drums !== 'waltz') pat = STYLE_PATTERNS.waltz;
    }
    const e = s.energy;
    const isLastBar = b === s.bars - 1;
    const fill = isLastBar && !last && nextName && nextName !== s.name && e >= 0.4;
    for (const [k, str] of Object.entries(pat)) {
      for (let i = 0; i < steps; i++) {
        const c = str[i % str.length];
        if (c === '.' || c === '-' || !c) continue;
        if (fill && i >= steps - 4 && (k === 'snare' || k === 'hat')) continue;
        drum(k, bt + i / 4, (c === 'x' || c === 'X' ? 0.9 : 0.5) * (0.55 + 0.5 * e));
      }
    }
    if (b === 0 && e >= 0.6) drum('crash', bt, 0.7);
    if (fill) for (let i = steps - 4; i < steps; i++) drum(i % 2 ? 'snare' : 'tom', bt + i / 4, 0.55 + 0.1 * (i - steps + 4));
  }

  /* ---------- 拍 → 秒（结尾渐慢） ---------- */
  function timeMap(sc, arr) {
    const spb = 60 / sc.bpm;
    const ritStart = sc.ending === 'ritardando' ? Math.max(0, arr.endBeat - sc.beats * 2) : Infinity;
    // 渐慢区间里速度从 100% 线性降到 70%
    const ritLen = arr.totalBeats - ritStart;
    return (beat) => {
      if (beat <= ritStart) return beat * spb;
      const x = Math.min(beat, arr.totalBeats) - ritStart;
      // ∫ 1/(1 - 0.3·u/L) du
      const L = ritLen, k = 0.3 / L;
      const extra = -Math.log(1 - k * x) / k;
      return ritStart * spb + extra * spb + Math.max(0, beat - arr.totalBeats) * spb / 0.7;
    };
  }

  /* ---------- WAV 编码（16 位立体声） ---------- */
  function encodeWav(left, right, sr) {
    const n = left.length, buf = new ArrayBuffer(44 + n * 4), v = new DataView(buf);
    const w = (o, s) => { for (let i = 0; i < s.length; i++) v.setUint8(o + i, s.charCodeAt(i)); };
    w(0, 'RIFF'); v.setUint32(4, 36 + n * 4, true); w(8, 'WAVE'); w(12, 'fmt '); v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, 2, true);
    v.setUint32(24, sr, true); v.setUint32(28, sr * 4, true); v.setUint16(32, 4, true); v.setUint16(34, 16, true); w(36, 'data'); v.setUint32(40, n * 4, true);
    let o = 44;
    for (let i = 0; i < n; i++) {
      const l = Math.max(-1, Math.min(1, left[i])), r = Math.max(-1, Math.min(1, right[i]));
      v.setInt16(o, l < 0 ? l * 32768 : l * 32767, true); v.setInt16(o + 2, r < 0 ? r * 32768 : r * 32767, true); o += 4;
    }
    return buf;
  }

  function describe(sc, arr) {
    const ins = Object.entries(sc.instruments).map(([r, i]) => `${{ lead: '主旋律', chords: '和声', pad: '铺底', bass: '低音', arp: '琶音' }[r]}：${INSTRUMENTS[i]}`);
    if (sc.kit !== 'none') ins.push(`鼓：${KITS[sc.kit]}`);
    return { title: sc.title, key: sc.key.text, bpm: sc.bpm, beats: sc.beats, form: sc.form.join(' → '), instruments: ins, sections: Object.keys(sc.sections).length, bars: arr ? Math.round(arr.totalBeats / sc.beats) : 0, tracks: arr ? arr.tracks : [] };
  }

  const API = { INSTRUMENTS, KITS, MODES, parseChord, parseNote, parseLine, parseKey, buildPrompt, extractJSON, normalize, arrange, timeMap, encodeWav, describe, targetBars, VOICE_WORDS };
  root.MusicScore = API;
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
})(typeof self !== 'undefined' ? self : typeof globalThis !== 'undefined' ? globalThis : this);
