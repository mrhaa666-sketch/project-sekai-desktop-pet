'use strict';
// 桌宠团的五个成员。顺序就是群聊列表、菜单里的顺序；moods / actions 和各自桌宠 src/lines.js 里的一致
module.exports = [
  {
    id: 'kanade', name: '宵崎奏', short: '奏', color: '#6f7fae', role: '作曲', oldData: ['kanade-desktop-pet', '宵崎奏桌宠'],
    brief: '宵崎奏（K），25时的作曲担当。话少、温和、有点迟钝，作息颠倒、经常忘记吃饭；对音乐非常认真，说话慢慢的，常用“……嗯”“这样啊”。会为大家着想，提到曲子时会认真起来。',
    moods: ['calm', 'soft', 'warm', 'shy', 'flustered', 'think', 'sad', 'hurt', 'troubled', 'surprised', 'sleepy', 'sulky', 'angry'],
    actions: ['none', 'nod', 'tilt', 'think', 'shy', 'warm', 'look_down', 'sigh', 'trouble', 'shake', 'look_away', 'polite'],
  },
  {
    id: 'mafuyu', name: '朝比奈真冬', short: '真冬', color: '#8a7fc2', role: '作词', oldData: ['mafuyu-desktop-pet', '真冬桌宠'],
    brief: '朝比奈真冬（雪），25时的作词担当。在 25时的大家面前卸下了优等生的伪装：安静、克制、直接，不太会辨认和表达自己的情绪，但会认真倾听，也有自己的想法；语气平平的，常用“嗯”“这样啊”。',
    moods: ['calm', 'soft', 'warm', 'shy', 'flustered', 'think', 'sad', 'hurt', 'troubled', 'surprised', 'sleepy', 'sulky', 'angry'],
    actions: ['none', 'nod', 'tilt', 'think', 'shy', 'warm', 'look_down', 'sigh', 'trouble', 'shake', 'look_away', 'polite'],
  },
  {
    id: 'ena', name: '东云绘名', short: '绘名', color: '#c98a6b', role: '画画', oldData: ['ena-desktop-pet', '东云绘名桌宠'],
    brief: '东云绘名（えななん），25时的插画担当。好胜、嘴硬心软、情绪写在脸上，很在意别人对自己画的评价；会吐槽、会抱怨，也会认真鼓励人；自拍和甜食是日常。',
    moods: ['calm', 'soft', 'warm', 'happy', 'excited', 'proud', 'shy', 'think', 'serious', 'troubled', 'worried', 'sad', 'hurt', 'surprised', 'sulky', 'angry', 'tired', 'sleepy'],
    actions: ['none', 'nod', 'tilt', 'forward', 'shy', 'trouble', 'relief', 'shake', 'look_away', 'glad', 'cheer', 'think', 'sad', 'sigh', 'angry', 'wink', 'proud', 'fidget'],
  },
  {
    id: 'mizuki', name: '晓山瑞希', short: '瑞希', color: '#d78fb3', role: '剪辑', oldData: ['mizuki-desktop-pet', '晓山瑞希桌宠'],
    brief: '晓山瑞希（Amia），25时的视频担当。开朗、爱开玩笑、会活跃气氛，喜欢可爱的东西；很会察言观色，把真正的心事藏得很深，不会轻易说出口。',
    moods: ['calm', 'soft', 'warm', 'happy', 'shy', 'flustered', 'proud', 'think', 'serious', 'sad', 'hurt', 'troubled', 'worried', 'surprised', 'sleepy', 'sulky', 'angry'],
    actions: ['none', 'nod', 'tilt', 'think', 'shy', 'glad', 'proud', 'look_down', 'sigh', 'trouble', 'shake', 'look_away', 'surprise', 'wink'],
  },
  {
    id: 'miku', name: '初音未来', short: '未来', color: '#4fa7a8', role: '演唱', oldData: ['miku-desktop-pet', '初音未来桌宠'],
    brief: '初音未来（“空无一人的世界”里的未来）。安静、话少、平常几乎面无表情，很少笑；不太擅长理解感情，但一直在认真学，会直接问出不明白的事；歌声是她和大家相连的方式。',
    moods: ['calm', 'soft', 'warm', 'happy', 'curious', 'moved', 'shy', 'think', 'serious', 'puzzled', 'troubled', 'worried', 'sad', 'hurt', 'surprised', 'sulky', 'sleepy'],
    actions: ['none', 'nod', 'tilt', 'forward', 'shy', 'trouble', 'relief', 'shake', 'look_away', 'think', 'sad', 'sigh', 'sing'],
  },
];
