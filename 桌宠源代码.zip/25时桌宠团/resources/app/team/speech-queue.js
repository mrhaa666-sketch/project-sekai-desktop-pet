'use strict';
// Only the actual player releases a turn; synthesis may still run in parallel.
function createSpeechQueue() {
  let active = null;
  const waiting = [];
  function advance() {
    if (!active && waiting.length) { active = waiting.shift(); active.resolve(true); }
  }
  return {
    acquire(owner, token) {
      if ((active && active.owner === owner && active.token === token) || waiting.some(x => x.owner === owner && x.token === token)) return Promise.resolve(false);
      return new Promise(resolve => { waiting.push({ owner, token, resolve }); advance(); });
    },
    release(owner, token) {
      for (let i = waiting.length - 1; i >= 0; i--) if (waiting[i].owner === owner && waiting[i].token === token) waiting.splice(i, 1)[0].resolve(false);
      if (active && active.owner === owner && active.token === token) active = null;
      advance();
    },
    drop(owner) {
      for (let i = waiting.length - 1; i >= 0; i--) if (waiting[i].owner === owner) waiting.splice(i, 1)[0].resolve(false);
      if (active && active.owner === owner) active = null;
      advance();
    },
    cancelWaiting() { for (const item of waiting.splice(0)) item.resolve(false); },
    clear() { for (const item of waiting.splice(0)) item.resolve(false); active = null; },
  };
}
module.exports = { createSpeechQueue };
