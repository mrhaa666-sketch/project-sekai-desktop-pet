'use strict';
/* 瑞希的 MV 导出：几张画面 + 成曲 + 歌词字幕 → MP4（1280×720，30fps，H.264 + AAC）
 * 一次 ffmpeg 完成：每张画面做缓慢推拉 / 平移（zoompan），镜头之间叠化或硬切（xfade），
 * 叠上歌词字幕图片（页面里用系统字体画好的透明 PNG），开头淡入、结尾淡出，配上成曲。 */
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

const W = 1280, H = 720, FPS = 30;
const MOTIONS = ['zoom_in', 'zoom_out', 'pan_left', 'pan_right', 'still'];

function ffmpegPath(mizukiDir) {
  const local = path.join(mizukiDir, 'bin', 'ffmpeg' + (process.platform === 'win32' ? '.exe' : ''));
  return fs.existsSync(local) ? local : 'ffmpeg';
}

/* ---------- 方案检查：镜头首尾相接、覆盖整首歌 ---------- */
function validatePlan(raw, { duration, scenes }) {
  if (!raw || typeof raw !== 'object') throw new Error('剪辑方案不是 JSON 对象');
  if (!(duration > 0)) throw new Error('时长不对');
  if (!(scenes > 0)) throw new Error('没有画面');
  let shots = (Array.isArray(raw.shots) ? raw.shots : []).map((s) => ({
    scene: Math.max(0, Math.min(scenes - 1, Math.round(+s.scene) || 0)),
    start: +s.start, end: +s.end,
    motion: MOTIONS.includes(s.motion) ? s.motion : 'zoom_in',
    transition: s.transition === 'cut' ? 'cut' : 'fade',
  })).filter((s) => Number.isFinite(s.start) && Number.isFinite(s.end) && s.end > s.start).sort((a, b) => a.start - b.start);
  if (!shots.length) throw new Error('剪辑方案里没有镜头');
  // 首尾相接：每个镜头从上一个结束的地方开始，最后一个到整首歌结束
  const out = [];
  let t = 0;
  for (const s of shots) {
    if (t >= duration - 0.5) break;
    const end = Math.min(duration, Math.max(s.end, t + 1.5));
    out.push({ ...s, start: t, end });
    t = end;
  }
  if (t < duration) {
    if (duration - t < 2 && out.length) out[out.length - 1].end = duration;
    else out.push({ scene: (out.length ? out[out.length - 1].scene + 1 : 0) % scenes, start: t, end: duration, motion: 'zoom_out', transition: 'fade' });
  }
  // 太短的镜头并进前一个；镜头太长就拆开（不超过 14 秒）
  const merged = [];
  for (const s of out) {
    if (merged.length && s.end - s.start < 1.5) { merged[merged.length - 1].end = s.end; continue; }
    merged.push(s);
  }
  const final = [];
  for (const s of merged) {
    const n = Math.ceil((s.end - s.start) / 14);
    for (let i = 0; i < n; i++) {
      const a = s.start + (s.end - s.start) * i / n, b = s.start + (s.end - s.start) * (i + 1) / n;
      final.push({ ...s, start: +a.toFixed(3), end: +b.toFixed(3), motion: i % 2 ? (s.motion === 'zoom_in' ? 'zoom_out' : 'zoom_in') : s.motion, transition: i ? 'fade' : s.transition });
    }
  }
  if (final.length > 60) throw new Error('镜头太多了（最多 60 个）');
  final[0].transition = 'fade';
  const sub = raw.subtitle && typeof raw.subtitle === 'object' ? raw.subtitle : {};
  return {
    title: String(raw.title || '').trim().slice(0, 40) || '25时的MV',
    shots: final,
    subtitle: { position: sub.position === 'center' ? 'center' : 'bottom', size: ['small', 'medium', 'large'].includes(sub.size) ? sub.size : 'medium' },
    titleCard: raw.titleCard !== false,
  };
}

// 没有聊天模型、或模型给的方案不能用：按段落平均分配画面
function localPlan({ duration, scenes, sections, title }) {
  const cuts = [0];
  for (const s of sections || []) if (s.start > cuts[cuts.length - 1] + 3 && s.start < duration - 3) cuts.push(s.start);
  cuts.push(duration);
  const shots = [];
  const motions = ['zoom_in', 'pan_left', 'zoom_out', 'pan_right'];
  for (let i = 0; i < cuts.length - 1; i++) {
    const a = cuts[i], b = cuts[i + 1], n = Math.max(1, Math.round((b - a) / 9));
    for (let j = 0; j < n; j++) shots.push({ scene: shots.length % scenes, start: a + (b - a) * j / n, end: a + (b - a) * (j + 1) / n, motion: motions[shots.length % 4], transition: 'fade' });
  }
  return validatePlan({ title, shots, subtitle: { position: 'bottom', size: 'medium' }, titleCard: true }, { duration, scenes });
}

/* ---------- ffmpeg ---------- */
function run(exe, args, { signal, onProgress, duration }) {
  return new Promise((resolve, reject) => {
    if (signal && signal.aborted) return reject(new Error('已取消'));
    const child = spawn(exe, args, { windowsHide: true, shell: false, stdio: ['ignore', 'pipe', 'pipe'] });
    let err = '', buf = '';
    const kill = () => { try { child.kill(); } catch (e) {} };
    if (signal) signal.addEventListener('abort', kill, { once: true });
    child.stdout.on('data', (b) => {
      buf += b.toString();
      let i;
      while ((i = buf.indexOf('\n')) >= 0) {
        const line = buf.slice(0, i).trim(); buf = buf.slice(i + 1);
        const m = /^out_time_us=(\d+)$/.exec(line);
        if (m && onProgress) onProgress(Math.max(0, Math.min(1, +m[1] / 1e6 / duration)));
      }
    });
    child.stderr.on('data', (b) => { err = (err + b.toString()).slice(-4000); });
    child.on('error', (e) => reject(new Error(e.code === 'ENOENT' ? '找不到视频处理工具 ffmpeg（应在瑞希的 bin 文件夹里），请重新解压完整程序' : e.message)));
    child.on('close', (code) => {
      if (signal) signal.removeEventListener('abort', kill);
      if (signal && signal.aborted) reject(new Error('已取消'));
      else if (code !== 0) reject(new Error('导出失败：' + err.slice(-1500)));
      else resolve();
    });
  });
}

// 一个镜头的推拉 / 平移表达式（输入先放大到 2 倍，减轻 zoompan 的抖动）
function motionFilter(motion, frames) {
  const N = Math.max(1, frames - 1);
  const p = `(on/${N})`;
  const center = { x: 'iw/2-(iw/zoom/2)', y: 'ih/2-(ih/zoom/2)' };
  switch (motion) {
    case 'zoom_in': return { z: `1+0.12*${p}`, ...center };
    case 'zoom_out': return { z: `1.12-0.12*${p}`, ...center };
    case 'pan_left': return { z: '1.12', x: `(iw-iw/zoom)*(1-${p})`, y: 'ih/2-(ih/zoom/2)' };
    case 'pan_right': return { z: '1.12', x: `(iw-iw/zoom)*${p}`, y: 'ih/2-(ih/zoom/2)' };
    default: return { z: `1.04+0.02*${p}`, ...center };
  }
}

async function render({ plan, images, audio, subs, out, duration, ffmpeg, signal, onProgress = () => {} }) {
  if (!images.length) throw new Error('没有画面');
  for (const f of [...images, audio]) if (!fs.existsSync(f)) throw new Error('找不到素材：' + path.basename(f));
  const shots = plan.shots;
  const args = ['-hide_banner', '-loglevel', 'error', '-nostdin', '-y'];
  const fc = [];
  // 每个镜头一个输入（同一张图可以用多次）；镜头长度 = 自己的时长 + 下一个镜头的叠化时长
  const T = shots.map((s, i) => (i === 0 ? 0 : s.transition === 'cut' ? 0.04 : Math.min(0.8, (shots[i - 1].end - shots[i - 1].start) / 3, (s.end - s.start) / 3)));
  shots.forEach((s, i) => {
    const len = (s.end - s.start) + (i + 1 < shots.length ? T[i + 1] : 0);
    const frames = Math.max(2, Math.round(len * FPS));
    args.push('-loop', '1', '-framerate', String(FPS), '-t', len.toFixed(3), '-i', images[s.scene % images.length]);
    const m = motionFilter(s.motion, frames);
    fc.push(`[${i}:v]scale=${W * 2}:${H * 2}:force_original_aspect_ratio=increase,crop=${W * 2}:${H * 2},setsar=1,zoompan=z='${m.z}':x='${m.x}':y='${m.y}':d=1:s=${W}x${H}:fps=${FPS},format=yuv420p,trim=duration=${len.toFixed(3)},setpts=PTS-STARTPTS[v${i}]`);
  });
  let cur = 'v0', acc = shots[0].end - shots[0].start;
  for (let i = 1; i < shots.length; i++) {
    const nx = `x${i}`;
    fc.push(`[${cur}][v${i}]xfade=transition=fade:duration=${T[i].toFixed(3)}:offset=${acc.toFixed(3)}[${nx}]`);
    cur = nx; acc += shots[i].end - shots[i].start;
  }
  // 字幕（每行一张透明 PNG，按时间显示）
  let idx = shots.length;
  for (const s of subs) {
    args.push('-i', s.file);
    const nx = `s${idx}`;
    fc.push(`[${cur}][${idx}:v]overlay=0:0:enable='between(t,${Math.max(0, s.t0).toFixed(2)},${Math.max(s.t0 + 0.3, s.t1).toFixed(2)})'[${nx}]`);
    cur = nx; idx++;
  }
  const fadeOut = Math.min(2, duration / 4);
  fc.push(`[${cur}]fade=t=in:st=0:d=0.8,fade=t=out:st=${(duration - fadeOut).toFixed(2)}:d=${fadeOut.toFixed(2)},format=yuv420p[vout]`);
  args.push('-i', audio);
  const aIdx = idx;
  fc.push(`[${aIdx}:a]aresample=48000,afade=t=out:st=${(duration - fadeOut).toFixed(2)}:d=${fadeOut.toFixed(2)}[aout]`);
  const staged = out.replace(/\.mp4$/i, '') + '.导出中.mp4';
  args.push('-filter_complex', fc.join(';'), '-map', '[vout]', '-map', '[aout]', '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '20', '-pix_fmt', 'yuv420p',
    '-c:a', 'aac', '-b:a', '192k', '-ar', '48000', '-ac', '2', '-t', duration.toFixed(3), '-movflags', '+faststart', '-progress', 'pipe:1', '-nostats', staged);
  onProgress(0.01, '瑞希开始剪了');
  try {
    await run(ffmpeg, args, { signal, duration, onProgress: (f) => onProgress(f, `正在合成画面和声音 ${Math.round(f * 100)}%`) });
    fs.renameSync(staged, out);
  } finally { try { fs.rmSync(staged, { force: true }); } catch (e) {} }
  onProgress(1, '导出完成');
  return { path: out, duration };
}

module.exports = { ffmpegPath, validatePlan, localPlan, render, motionFilter, W, H };
