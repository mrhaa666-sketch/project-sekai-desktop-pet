'use strict';
/* 让五个桌宠在同一个程序里各管各的：
 * 每个成员的主进程代码 require('electron') 时拿到的是这里做的“替身”：
 *  - ipcMain：按发消息的窗口属于谁，把消息交给那个成员自己的处理函数（五个成员的通道名都一样，不会互相抢）
 *  - BrowserWindow：记下每个窗口属于哪个成员
 *  - app：数据目录指向成员自己的文件夹；单实例锁、退出、托盘这些由桌宠团统一管
 *  - Tray：成员不再各自放托盘图标，菜单交给桌宠团的托盘
 *  - Menu.buildFromTemplate：在成员的右键菜单最上面加上桌宠团的几项 */
const electron = require('electron');
const Module = require('module');
const path = require('path');

const owners = new Map();          // webContents.id → 成员 id
const handles = new Map();         // 通道 → Map(成员 id → fn)
const listeners = new Map();       // 通道 → Map(成员 id → Set(fn))
const members = [];                // { id, dir, shim }

function ownerOf(sender) {
  if (!sender) return null;
  let id = owners.get(sender.id);
  if (id) return id;
  // 子窗口（window.open 出来的）算到打开它的窗口头上
  try { const host = sender.hostWebContents || (sender.opener && sender.opener()); if (host) id = owners.get(host.id); } catch (e) {}
  return id || null;
}
function pick(map, sender) {
  if (!map || !map.size) return null;
  const id = ownerOf(sender);
  if (id && map.has(id)) return map.get(id);
  return null;
}

function realHandle(ch) {
  if (handles.has(ch)) return;
  handles.set(ch, new Map());
  electron.ipcMain.handle(ch, (e, ...a) => {
    const fn = pick(handles.get(ch), e.sender);
    if (!fn) throw new Error(`没有处理 ${ch} 的成员`);
    return fn(e, ...a);
  });
}
function realOn(ch) {
  if (listeners.has(ch)) return;
  listeners.set(ch, new Map());
  electron.ipcMain.on(ch, (e, ...a) => {
    const set = pick(listeners.get(ch), e.sender);
    if (set) for (const fn of [...set]) { try { fn(e, ...a); } catch (err) { console.error(`[${ch}]`, err); } }
  });
}

function makeShim(id, dir, host) {
  const ipcMain = {
    handle(ch, fn) { realHandle(ch); handles.get(ch).set(id, fn); },
    handleOnce(ch, fn) { realHandle(ch); handles.get(ch).set(id, (...a) => { handles.get(ch).delete(id); return fn(...a); }); },
    removeHandler(ch) { const m = handles.get(ch); if (m) m.delete(id); },
    on(ch, fn) { realOn(ch); const m = listeners.get(ch); if (!m.has(id)) m.set(id, new Set()); m.get(id).add(fn); return ipcMain; },
    addListener(ch, fn) { return ipcMain.on(ch, fn); },
    once(ch, fn) { const w = (...a) => { ipcMain.removeListener(ch, w); fn(...a); }; w.orig = fn; return ipcMain.on(ch, w); },
    removeListener(ch, fn) { const set = listeners.get(ch) && listeners.get(ch).get(id); if (set) { set.delete(fn); for (const f of set) if (f.orig === fn) set.delete(f); } return ipcMain; },
    off(ch, fn) { return ipcMain.removeListener(ch, fn); },
    removeAllListeners(ch) { if (ch) { const m = listeners.get(ch); if (m) m.delete(id); } else for (const m of listeners.values()) m.delete(id); return ipcMain; },
    listenerCount(ch) { const set = listeners.get(ch) && listeners.get(ch).get(id); return set ? set.size : 0; },
  };

  class BrowserWindow extends electron.BrowserWindow {
    constructor(opts) {
      super(opts);
      const wcId = this.webContents.id;
      owners.set(wcId, id);
      this.webContents.on('did-create-window', (child) => { try { owners.set(child.webContents.id, id); } catch (e) {} });
      this.once('closed', () => owners.delete(wcId));
    }
    static getAllWindows() { return electron.BrowserWindow.getAllWindows().filter((w) => !w.isDestroyed() && owners.get(w.webContents.id) === id); }
    static fromWebContents(wc) { return electron.BrowserWindow.fromWebContents(wc); }
    static fromId(n) { return electron.BrowserWindow.fromId(n); }
    static getFocusedWindow() { return electron.BrowserWindow.getFocusedWindow(); }
  }

  const userData = path.join(host.userData, 'members', id);
  const app = new Proxy(electron.app, {
    get(target, k) {
      switch (k) {
        case 'getPath': return (name) => (name === 'userData' ? userData : target.getPath(name));
        case 'setPath': return () => {};
        case 'setName': return () => {};
        case 'getName': return () => id;
        case 'requestSingleInstanceLock': return () => true;
        case 'hasSingleInstanceLock': return () => true;
        case 'setAppUserModelId': return () => {};
        case 'quit': return () => host.quitAll();
        case 'exit': return (code) => host.quitAll(code);
        case 'relaunch': return (o) => target.relaunch(o);
        case 'on': case 'addListener': return (ev, fn) => { if (['window-all-closed', 'second-instance', 'activate'].includes(ev)) return app; target.on(ev, fn); return app; };
        case 'once': return (ev, fn) => { if (['window-all-closed', 'second-instance', 'activate'].includes(ev)) return app; target.once(ev, fn); return app; };
        default: { const v = Reflect.get(target, k); return typeof v === 'function' ? v.bind(target) : v; }
      }
    },
  });

  class Tray {
    constructor() { this.menu = null; this.tip = ''; host.trays.set(id, this); }
    setContextMenu(m) { this.menu = m; host.trayChanged(id); }
    setToolTip(t) { this.tip = t; }
    setImage() {} setTitle() {} on() { return this; } once() { return this; } removeListener() { return this; }
    popUpContextMenu() {} destroy() { host.trays.delete(id); } isDestroyed() { return false; }
  }

  const Menu = new Proxy(electron.Menu, {
    get(target, k) {
      if (k === 'buildFromTemplate') {
        return (tpl) => {
          const isMain = Array.isArray(tpl) && tpl.some((it) => it && it.label === '退出');
          if (isMain) tpl = [...host.menuItems(id), { type: 'separator' }, ...tpl.map((it) => (it && it.label === '退出' ? { ...it, label: '退出桌宠团（五个人一起）' } : it))];
          return target.buildFromTemplate(tpl);
        };
      }
      const v = Reflect.get(target, k);
      return typeof v === 'function' ? v.bind(target) : v;
    },
  });

  const overrides = { ipcMain, BrowserWindow, app, Tray, Menu };
  return new Proxy({}, {
    get(_t, k) { if (k in overrides) return overrides[k]; return electron[k]; },
    has(_t, k) { return k in overrides || k in electron; },
  });
}

function install(host) {
  const origLoad = Module._load;
  Module._load = function (request, parent, isMain) {
    if (request === 'electron' && parent && parent.filename) {
      const f = parent.filename;
      const m = members.find((x) => f.startsWith(x.dir + path.sep));
      if (m) return m.shim;
    }
    return origLoad.apply(this, arguments);
  };
  return {
    add(id, dir) { const m = { id, dir: path.resolve(dir), shim: makeShim(id, path.resolve(dir), host) }; members.push(m); return m; },
    ownerOf,
  };
}

module.exports = { install, ownerOf };
