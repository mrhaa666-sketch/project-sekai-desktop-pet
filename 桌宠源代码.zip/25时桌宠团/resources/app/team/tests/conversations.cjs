const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('fs'),os=require('os'),path=require('path');
const members=require('../members'),create=require('../group');
function setup(){
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'team-conversations-'));fs.writeFileSync(path.join(dir,'group-log.json'),JSON.stringify([{who:'user',to:'miku',text:'未来私聊问题',kind:'direct'},{who:'miku',to:'user',text:'未来私聊回答',kind:'direct'},{who:'user',to:'kanade',text:'奏的问题',kind:'group'},{who:'kanade',to:'user',text:'奏的回答',kind:'group'}]));
 const team=Object.fromEntries(members.map(m=>[m.id,{settings:()=>({model:'fixture'}),voiceOn:()=>false,say:()=>{},note:()=>{}}]));let prompt='';
 const llm={hasChatApi:()=>true,request:async(c,p)=>{prompt=p.messages[0].content;return {data:{choices:[{message:{content:JSON.stringify({lines:[{who:'kanade',reply:'新回复',mood:'calm'}]})}}]}};}};
 const group=create({team,members,online:()=>true,shared:{get:()=>({})},state:{interject:'off'},llm,getGroupWin:()=>null,userData:dir});return {group,prompt:()=>prompt};
}
test('旧版日志在角色会话之间隔离，不丢失原记录',()=>{const {group}=setup();assert.deepEqual(group.log('kanade').map(e=>e.text),['奏的问题','奏的回答']);assert.deepEqual(group.log('miku').map(e=>e.text),['未来私聊问题','未来私聊回答']);assert.deepEqual(group.log('all'),[]);});
test('清空奏的记录不会删除未来记录',()=>{const {group}=setup();group.clear('kanade');assert.equal(group.log('miku').length,2);assert.equal(group.log('kanade').length,0);});
test('指定成员的模型上下文与新增回复归到本人会话',async()=>{const f=setup();try{await f.group.userSay('新问题','kanade');assert(!f.prompt().includes('未来私聊'));assert(f.prompt().includes('奏的回答'));assert(f.group.log('kanade').some(e=>e.text==='新回复'));assert(!f.group.log('miku').some(e=>e.text==='新回复'));}finally{f.group.stop();}});
test('旧私聊后的其他成员插话仍归到那次私聊',()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'team-legacy-'));fs.writeFileSync(path.join(dir,'group-log.json'),JSON.stringify([{who:'user',to:'miku',text:'未来问题',kind:'direct'},{who:'miku',to:'user',text:'未来回答',kind:'direct'},{who:'ena',to:'miku',text:'绘名接话',kind:'group'}]));
 const g=create({team:{},members,online:()=>false,shared:{},state:{},llm:{},getGroupWin:()=>null,userData:dir});assert.equal(g.log('miku').length,3);assert.equal(g.log('all').length,0);
});
test('单独聊天返回时，不会打断另一名成员正在播放的声音',async()=>{
 let stops=0;const g=create({team:{},members,online:()=>false,shared:{},state:{interject:'off'},llm:{},getGroupWin:()=>null,userData:fs.mkdtempSync(path.join(os.tmpdir(),'team-direct-')),stopSpeech:()=>stops++});await g.afterDirect('miku','你好',{reply:'嗯'});assert.equal(stops,0);
});
test('指定真冬但模型只给奏的回答时，不能冒充真冬交付',async()=>{const f=setup();try{const r=await f.group.userSay('只问真冬','mafuyu');assert(r.error);assert(!f.group.log('mafuyu').some(e=>e.who==='kanade'));}finally{f.group.stop();}});
