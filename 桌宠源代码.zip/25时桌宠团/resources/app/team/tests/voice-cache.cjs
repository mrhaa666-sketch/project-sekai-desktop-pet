const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('fs'),os=require('os'),path=require('path'),http=require('http');
async function provider(t,label){
 const server=http.createServer((req,res)=>{req.resume();req.on('end',()=>{const text=label+'|'+req.headers.authorization+'|'+new URL(req.url,'http://fixture').searchParams.get('GroupId');res.setHeader('Content-Type','application/json');res.end(JSON.stringify({base_resp:{status_code:0},data:{audio:Buffer.from(text).toString('hex')}}));});});
 await new Promise(r=>server.listen(0,'127.0.0.1',r));t.after(()=>{server.closeAllConnections();server.close();});return 'http://127.0.0.1:'+server.address().port;
}
for(const member of ['kanade','mafuyu','ena','mizuki','miku'])test(member+'：缓存不跨平台、账户或GroupId复用音色',async t=>{
 const {Voice}=require('../../members/'+member+'/voice');const dir=fs.mkdtempSync(path.join(os.tmpdir(),'voice-cache-check-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
 const a=await provider(t,'A'),b=await provider(t,'B');const voice=new Voice(dir);
 const cfg={ttsBase:a,ttsKey:'local-account-A',ttsVoiceId:'same-voice-id',ttsModel:'fixture'};
 const say=c=>voice.speak(c,'同じ文','calm');const text=v=>Buffer.from(v.audio,'base64').toString();
 assert.equal(text(await say(cfg)),'A|Bearer local-account-A|null');
 assert.equal(text(await say({...cfg,ttsBase:b})),'B|Bearer local-account-A|null');
 assert.equal(text(await say({...cfg,ttsKey:'local-account-B'})),'A|Bearer local-account-B|null');
 assert.equal(text(await say({...cfg,ttsGroupId:'another-group'})),'A|Bearer local-account-A|another-group');
 const cached=await say(cfg);assert.equal(cached.cached,true);assert.equal(text(cached),'A|Bearer local-account-A|null');
});
