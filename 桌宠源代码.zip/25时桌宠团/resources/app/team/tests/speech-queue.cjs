const {test}=require('node:test'),assert=require('node:assert/strict');
const {createSpeechQueue}=require('../speech-queue');
const tick=()=>new Promise(r=>setImmediate(r));
test('下一角色只有在前一段实际释放后才能播放',async()=>{
 const q=createSpeechQueue();assert.equal(await q.acquire(1,'a'),true);
 let next=false;const p=q.acquire(2,'b').then(v=>next=v);await tick();assert.equal(next,false);
 q.release(1,'wrong');await tick();assert.equal(next,false);
 q.release(1,'a');await p;assert.equal(next,true);q.release(2,'b');
});
test('取消等待者不会影响正在说话的成员',async()=>{
 const q=createSpeechQueue();await q.acquire(1,'a');const p=q.acquire(2,'b');q.release(2,'b');assert.equal(await p,false);
 let got=false;const p3=q.acquire(3,'c').then(v=>got=v);await tick();assert.equal(got,false);q.release(1,'a');await p3;assert.equal(got,true);
});
test('窗口关闭会释放本人并让下一人继续，不会残留等待',async()=>{
 const q=createSpeechQueue();await q.acquire(1,'a');const own=q.acquire(1,'a2'),other=q.acquire(2,'b');q.drop(1);assert.equal(await own,false);assert.equal(await other,true);
});
test('全局停止取消所有等待请求，旧释放不影响新播放',async()=>{
 const q=createSpeechQueue();await q.acquire(1,'a');const p=q.acquire(2,'b');q.clear();assert.equal(await p,false);assert.equal(await q.acquire(3,'c'),true);
 q.release(1,'a');let got=false;const d=q.acquire(4,'d').then(v=>got=v);await tick();assert.equal(got,false);q.release(3,'c');await d;assert.equal(got,true);
});
test('广播停止时取消等待者，但要等当前播放器确认结束才放行新发言',async()=>{
 const q=createSpeechQueue();await q.acquire(1,'a');const canceled=q.acquire(2,'b');q.cancelWaiting();assert.equal(await canceled,false);
 let got=false;const next=q.acquire(3,'c').then(v=>got=v);await tick();assert.equal(got,false);q.release(1,'a');await next;assert.equal(got,true);
});
