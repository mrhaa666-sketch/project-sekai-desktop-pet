const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('fs');const path=require('path');const os=require('os');
const app=path.resolve(__dirname,'../..');
const members=require(path.join(app,'team/members'));
const createGroup=require(path.join(app,'team/group'));
const createShared=require(path.join(app,'team/shared'));
function fixture(){
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'nightcord-regression-'));
 const requests=[],spoken=[];
 const team=Object.fromEntries(members.map(m=>[m.id,{settings:()=>({model:'fixture',name:'测试'}),voiceOn:()=>false,say:v=>spoken.push(v.t),note:()=>{}}]));
 const llm={hasChatApi:()=>true,request:(_c,p)=>new Promise(resolve=>requests.push({resolve,signal:p.signal}))};
 const group=createGroup({team,members,online:()=>true,shared:{get:()=>({})},state:{interject:'often'},llm,getGroupWin:()=>null,userData:dir});
 const resolve=(i,text)=>requests[i].resolve({data:{choices:[{message:{content:JSON.stringify({lines:[{who:'mafuyu',reply:text,ja:'',mood:'calm',action:'none'}]})}}]}});
 return {group,requests,spoken,resolve};
}
const tick=()=>new Promise(r=>setImmediate(r));
test('停止群聊后，尚未返回的模型回复不能重新开口',async()=>{
 const f=fixture();try{const pending=f.group.userSay('你好','all');f.group.stop();f.resolve(0,'已过期');await pending;await tick();assert.deepEqual(f.spoken,[]);assert.equal(f.requests[0].signal.aborted,true);}finally{f.group.stop();}
});
test('较早的群聊请求晚返回时不能打断较新的回复',async()=>{
 const f=fixture();try{const older=f.group.userSay('旧问题','all');const newer=f.group.userSay('新问题','all');f.resolve(1,'新的回复');await newer;await tick();f.resolve(0,'旧的回复');await older;await tick();assert.deepEqual(f.spoken,['新的回复']);}finally{f.group.stop();}
});
test('停止等待中的MV交接对话后，不会重新说话',async()=>{
 const f=fixture();try{const pending=f.group.workChat('真实进度',['mafuyu']);f.group.stop();f.resolve(0,'交接');await pending;assert.deepEqual(f.spoken,[]);}finally{f.group.stop();}
});
test('首次迁移遇到null成员设置时，其余成员设置仍能加载',()=>{
 const writes=[];
 const s=createShared({userData:'fixture',members:[{id:'a'},{id:'b'}],readJSON:(p,d)=>p.endsWith('shared.json')?null:p.includes('a'+path.sep)?null:{name:'保留的名字'},writeJSON:(p,v)=>writes.push(JSON.parse(JSON.stringify(v)))});
 assert.equal(s.get().name,'保留的名字');assert.equal(writes[0].name,'保留的名字');
});
test('shared.json误存为数组后，保存的设置仍能持久化',()=>{
 let disk=[];const readJSON=(p,d)=>p.endsWith('shared.json')?disk:{};
 const options={userData:'fixture',members:[],readJSON,writeJSON:(p,v)=>{disk=JSON.parse(JSON.stringify(v));}};
 const s=createShared(options);s.saveFromPanel({name:'不会丢失'},{});
 assert.equal(createShared(options).get().name,'不会丢失');
});
test('未停止的群聊会正常说出回复，并记录发言',async()=>{
 const f=fixture();try{const pending=f.group.userSay('你好','all');f.resolve(0,'嗯，听到了。');const r=await pending;await tick();assert.equal(r.ok,true);assert.deepEqual(f.spoken,['嗯，听到了。']);assert.equal(f.group.log().at(-1).text,'嗯，听到了。');}finally{f.group.stop();}
});
test('正常共用设置保存后会同步，页面不泄露密钥',()=>{
 let disk={apiKey:'only-local-fixture',name:'原名称'};const synced=[];
 const s=createShared({userData:'fixture',members:[{id:'a',name:'测试'}],readJSON:()=>disk,writeJSON:(p,v)=>{disk=JSON.parse(JSON.stringify(v));}});
 s.saveFromPanel({name:'新名称',apiKey:''},{a:{applyShared:v=>synced.push(v),settings:()=>({})}});
 assert.equal(synced[0].name,'新名称');assert.equal(disk.apiKey,'only-local-fixture');
 const pub=s.publicView({});assert.equal(pub.apiKey,'');assert.equal(pub.apiKeySet,true);
});
