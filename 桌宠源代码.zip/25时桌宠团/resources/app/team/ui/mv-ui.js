'use strict';
/* 一起做 MV（页面）：把五个人的工作串起来
 *  1 奏：作曲（纯伴奏）→ 本机合成 WAV，并在本机分析曲子（段落、速度、调性、小节）
 *  2 真冬：按曲子填词
 *  3 绘名：按曲子和歌词设计分镜，一幕一幕画出来
 *  4 未来：在伴奏上编唱的调子，用复刻音色逐行合成，本机调音高、对齐小节，和伴奏混成成曲
 *  5 瑞希：排剪辑方案，画字幕，导出 MP4
 * 两种模式：每一步停下来确认（继续 / 重做 / 自己改），或者一键自动做完（出错才停）。 */
const api = window.mvAPI;
const $ = (id) => document.getElementById(id);
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const mmss = (s) => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`;
const pad = (n) => String(n).padStart(2, '0');
let roster = [], cfg = null;
const mem = (id) => roster.find((m) => m.id === id) || { short: id, name: id, color: '#888' };

const STEPS = [
  { key: 'compose', who: 'kanade', title: '作曲', desc: '写一首纯伴奏，在本机合成出来，再分析段落和节拍' },
  { key: 'lyrics', who: 'mafuyu', title: '填词', desc: '听曲子的结构和情绪，按段落填词' },
  { key: 'paint', who: 'ena', title: '画画', desc: '按曲子和歌词设计分镜，一幕一幕画出来' },
  { key: 'sing', who: 'miku', title: '演唱', desc: '在伴奏上编唱的调子，用复刻音色唱出来，和伴奏混成成曲' },
  { key: 'edit', who: 'mizuki', title: '剪辑', desc: '排镜头、配字幕，导出 MP4' },
];
let S = null;            // 这一次做 MV 的全部内容
let running = false, stopFlag = false, curJob = null, decide = null, paintWait = false;

/* ---------- 顶部状态 ---------- */
async function loadConfig() {
  cfg = await api.config();
  const p = [];
  p.push([cfg.chatReady ? 'ok' : 'bad', cfg.chatReady ? `聊天模型 ${cfg.chatModel}` : '聊天模型未设置']);
  p.push(['ok', cfg.musicBackend === 'minimax' ? '奏：MiniMax 音乐生成' : '奏：本地多轨合成']);
  p.push([cfg.lyricsBy ? 'ok' : 'bad', cfg.lyricsBy ? `真冬：${cfg.lyricsBy}` : '真冬：没有可用的写词模型']);
  p.push([cfg.paintReady ? 'ok' : 'warn', cfg.paintReady ? `绘名：${cfg.paintModel}` : '绘名：没有画画密钥（会用本地抽象画面代替）']);
  p.push([cfg.voiceReady ? 'ok' : 'warn', cfg.voiceReady ? '未来：复刻音色已设置' : '未来：没有复刻音色（会做成纯伴奏 MV）']);
  $('pills').innerHTML = p.map(([c, t]) => `<span class="pill ${c}">${esc(t)}</span>`).join('');
}
$('toGroup').onclick = () => api.openGroup();
$('folder').onclick = () => api.openFolder();
$('seconds').oninput = () => { $('secVal').textContent = mmss(+$('seconds').value); };

/* ---------- 步骤卡片 ---------- */
function avatar(id, size = 34) {
  const m = mem(id);
  return m.src ? `<span class="av" style="width:${size}px;height:${size}px"><img src="${m.src}" alt=""></span>` : `<span class="av" style="width:${size}px;height:${size}px;background:${m.color}">${esc((m.short || '?').slice(0, 1))}</span>`;
}
function renderSteps() {
  $('flow').innerHTML = talkCard('kickoff') + STEPS.map((s, i) => `<div class="step" id="st_${s.key}">
    <div class="sh">${avatar(s.who)}<div class="t"><b>${i + 1}. ${esc(mem(s.who).short)} · ${s.title}</b><div class="sub">${s.desc}</div></div><span class="st" id="ss_${s.key}">等待</span></div>
    <div class="bar"><i id="sb_${s.key}"></i></div>
    <div class="note" id="sn_${s.key}"></div>
    <div class="res" id="sr_${s.key}"></div>
    <div class="acts" id="sa_${s.key}"></div></div>${talkCard(s.key)}`).join('');
}
function setStep(key, cls, text, frac) {
  const el = $('st_' + key); if (!el) return;
  el.className = 'step ' + (cls || '');
  if (text != null) $('ss_' + key).textContent = text;
  if (frac != null) $('sb_' + key).style.width = Math.round(frac * 100) + '%';
}
const note = (key, t, cls = '') => { const n = $('sn_' + key); n.textContent = t || ''; n.className = 'note ' + cls; };
const acts = (key, list) => {
  const box = $('sa_' + key); box.innerHTML = '';
  for (const [label, fn, primary] of list) { const b = document.createElement('button'); b.textContent = label; if (primary) b.className = 'primary'; b.onclick = fn; box.appendChild(b); }
};

/* ---------- 角色之间的对话：开工碰头、每一步之间的交接、一起看成片 ----------
 * 对话插在流程里：说完（或者你点“跳过这段对话”）才进入下一步；
 * 对话的内容会交给下一步的人参考（比如真冬听奏说了哪里是副歌，写词时会照顾到）。 */
const ALL = ['kanade', 'mafuyu', 'ena', 'mizuki', 'miku'];
const TALKS = {
  kickoff: { title: '开工前碰个头', ids: ALL, max: 5, before: 'compose',
    instruction: '奏先说打算写一首什么样的曲子（速度快慢、情绪、主要乐器）；其他人各自最多补一句自己负责的部分想怎么做；最后奏收住，说先去写曲子。' },
  compose: { title: '奏 → 真冬：交接伴奏', ids: ['kanade', 'mafuyu', 'mizuki'], max: 4,
    instruction: '奏把伴奏交给真冬：说清楚这首曲子的情绪、哪一段是副歌；真冬说她打算怎么写这首词，或者问一个具体的问题由奏回答；瑞希可以插一句。' },
  lyrics: { title: '真冬 → 绘名：交接歌词', ids: ['mafuyu', 'ena', 'kanade'], max: 4,
    instruction: '真冬把歌词交给绘名，简单说这首词想表达的东西；绘名说她打算画什么样的画面（色调、场景、主角），可以引用一两句歌词；奏可以插一句。' },
  paint: { title: '绘名 → 未来：交接画面', ids: ['ena', 'miku', 'mafuyu'], max: 4,
    instruction: '绘名给大家看画好的几幕画面；未来说她打算怎么唱（哪里轻、哪里放开）；真冬可以补一句歌词里最想被唱清楚的地方。' },
  sing: { title: '未来 → 瑞希：交接成曲', ids: ['miku', 'mizuki', 'ena'], max: 4,
    instruction: '未来把唱好的成曲交给瑞希；瑞希说她打算怎么剪（镜头节奏、副歌怎么切、字幕放哪）；绘名可以提一句希望哪一幕停留久一点。' },
  edit: { title: '一起看成片', ids: ALL, max: 5,
    instruction: 'MV 做好了，大家一起看了一遍成片。每个人说一句真实的感想（可以有一点小小的不满意或下次想改的地方），最后自然地收住。' },
};
let talkWait = null;          // 正在进行的对话：{ id, key }
function talkCard(key) {
  const t = TALKS[key];
  return `<div class="talkc" id="tk_${key}"><div class="th"><span class="ti">💬 ${esc(t.title)}</span><span class="ts" id="ts_${key}">等待</span><button class="ghost tskip" id="tx_${key}" hidden>跳过这段对话</button></div><div class="tl" id="tl_${key}"></div></div>`;
}
function talkLine(key, l) {
  const box = $('tl_' + key); if (!box) return;
  const to = l.to && l.to !== 'user' && l.to !== 'all' ? ` → ${esc(mem(l.to).short)}` : '';
  box.insertAdjacentHTML('beforeend', `<div class="tline">${avatar(l.who, 26)}<div><div class="tw"><b style="color:${mem(l.who).color}">${esc(mem(l.who).short)}</b>${to}</div><div class="tt">${esc(l.text)}</div></div></div>`);
  const card = $('tk_' + key); if (card) card.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
}
api.onTalk((v) => { if (talkWait && v && v.talkId === talkWait.id) talkLine(talkWait.key, v); });
async function talk(key, context) {
  if (!S.talkOn || stopFlag || !$('tk_' + key)) return;
  const t = TALKS[key];
  const id = newId();
  talkWait = { id, key };
  $('tl_' + key).innerHTML = '';
  $('tk_' + key).className = 'talkc on'; $('ts_' + key).textContent = '大家在说…';
  const skip = $('tx_' + key); skip.hidden = false;
  skip.onclick = () => { api.skipChat(); $('ts_' + key).textContent = '跳过了'; };
  let r = null;
  try { r = await api.chat({ talkId: id, context, ids: t.ids, instruction: t.instruction, max: t.max }); } catch (e) { r = { error: e.message }; }
  skip.hidden = true;
  if (talkWait && talkWait.id === id) talkWait = null;
  const lines = (r && r.lines) || [];
  if (r && r.error) { $('ts_' + key).textContent = '没说成：' + r.error; $('tk_' + key).className = 'talkc'; return; }
  if ($('ts_' + key).textContent !== '跳过了') $('ts_' + key).textContent = lines.length ? '说完了' : '没有人说话';
  $('tk_' + key).className = 'talkc done';
  S.talk[key] = lines.map((l) => `${mem(l.who).short}：${l.text}`).join('\n');
}
const heard = (key, label) => (S.talk[key] ? `\n${label}：\n${S.talk[key]}` : '');
function sys(text) { $('talk').insertAdjacentHTML('beforeend', `<div class="l sub">· ${esc(text)}</div>`); $('talk').scrollTop = $('talk').scrollHeight; }

/* ---------- 工具 ---------- */
let jobSeq = 0;
const newId = () => 'mv' + Date.now() + '-' + (++jobSeq);
async function call(fn, p) {
  const id = newId(); curJob = id;
  try { const r = await fn({ id, ...p }); if (stopFlag) throw Object.assign(new Error('已停止'), { stopped: true }); return r; }
  finally { if (curJob === id) curJob = null; }
}
const must = (r, what) => { if (!r || r.error) throw Object.assign(new Error((what ? what + '：' : '') + (r ? r.error : '没有响应')), { noConfig: r && r.noConfig, canceled: r && r.canceled }); return r; };
const blobUrl = (bytes, type) => URL.createObjectURL(new Blob([bytes], { type }));
function b64ToBytes(b64) { const bin = atob(b64), u = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); return u; }
async function decodeAudio(bytes, sr = 44100) { return new OfflineAudioContext(2, 1, sr).decodeAudioData(bytes.slice().buffer); }
async function monoOf(buf, sr) {
  const oc = new OfflineAudioContext(1, Math.ceil(buf.duration * sr), sr);
  const src = oc.createBufferSource(); src.buffer = buf; src.connect(oc.destination); src.start();
  return (await oc.startRendering()).getChannelData(0).slice();
}
function wavStereo(buf) {
  const n = buf.length, ch = Math.min(2, buf.numberOfChannels), sr = buf.sampleRate;
  const L = buf.getChannelData(0), R = ch > 1 ? buf.getChannelData(1) : L;
  const out = new ArrayBuffer(44 + n * 4), v = new DataView(out);
  const w = (o, s) => { for (let i = 0; i < s.length; i++) v.setUint8(o + i, s.charCodeAt(i)); };
  w(0, 'RIFF'); v.setUint32(4, 36 + n * 4, true); w(8, 'WAVEfmt '); v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, 2, true);
  v.setUint32(24, sr, true); v.setUint32(28, sr * 4, true); v.setUint16(32, 4, true); v.setUint16(34, 16, true); w(36, 'data'); v.setUint32(40, n * 4, true);
  for (let i = 0, o = 44; i < n; i++, o += 4) { v.setInt16(o, Math.max(-1, Math.min(1, L[i])) * 32767, true); v.setInt16(o + 2, Math.max(-1, Math.min(1, R[i])) * 32767, true); }
  return new Uint8Array(out);
}
function worker(file, msg, transfer, onProgress) {
  return new Promise((resolve, reject) => {
    const w = new Worker(file);
    const stopCheck = setInterval(() => { if (stopFlag) { w.terminate(); clearInterval(stopCheck); reject(Object.assign(new Error('已停止'), { stopped: true })); } }, 300);
    w.onmessage = (e) => {
      const d = e.data || {};
      if (d.error) { clearInterval(stopCheck); w.terminate(); reject(new Error(d.error)); return; }
      if (d.done || d.result) { clearInterval(stopCheck); w.terminate(); resolve(d.done ? d : d.result); return; }
      if (d.progress != null && onProgress) onProgress(d.progress, d.stage || '');
    };
    w.onerror = (e) => { clearInterval(stopCheck); w.terminate(); reject(new Error('后台线程出错：' + (e.message || '未知错误'))); };
    w.postMessage(msg, transfer || []);
  });
}
api.onProgress((p) => {
  if (!running || !p) return;
  const k = p.step;
  if (k === 'compose' && (p.stage === 'compose' || p.stage === 'revise')) note('compose', `奏在写谱…${p.chars ? `（已经写了 ${p.chars} 字）` : ''}`);
  if (k === 'compose' && p.stage === 'remote') note('compose', '在等 MiniMax 生成…');
  if (k === 'lyrics' && p.stage === 'stream') note('lyrics', `真冬在写…${p.chars ? `（${p.chars} 字）` : ''}`);
  if (k === 'lyrics' && p.stage === 'fallback') note('lyrics', `硅基流动没有写成（${p.note}），改用聊天模型写。`, 'warn');
  if (k === 'paint' && p.stage) note('paint', `第 ${(+p.index || 0) + 1} 幕：${{ prompt: '整理画面描述', prompted: '描述写好了', draw: '在画', download: '取回画好的图' }[p.stage] || '…'}`);
  if (k === 'sing' && p.stage === 'compose') note('sing', `未来在听曲子、编唱的调子…${p.chars ? `（${p.chars} 字）` : ''}`);
  if (k === 'edit' && p.fraction != null) { setStep('edit', 'run', '在剪', 0.3 + p.fraction * 0.7); note('edit', p.text || ''); }
});

/* ---------- 1. 奏：作曲 ---------- */
async function stepCompose() {
  const k = 'compose';
  setStep(k, 'run', '在作曲', 0.05); note(k, '奏在想这首曲子…');
  let bytes, ext = 'wav', title = S.title, desc = null;
  if (S.ownTrack) {
    bytes = S.ownTrack.bytes; ext = (S.ownTrack.name.split('.').pop() || 'wav').toLowerCase(); title = S.ownTrack.name.replace(/\.[^.]+$/, '');
  } else {
    const prompt = [S.theme, S.musicStyle && '曲风、乐器：' + S.musicStyle, S.talk.kickoff && '开工时大家说的（参考）：' + S.talk.kickoff.slice(0, 300), '这是 MV 的伴奏，之后会有人声唱旋律：留出人声的空间，段落清楚（前奏、主歌、副歌、尾声），节拍稳定清楚。'].filter(Boolean).join('\n');
    const r = must(await call(api.compose, { prompt, seconds: S.seconds }), '作曲');
    if (r.backend === 'minimax') { bytes = new Uint8Array(r.bytes); ext = 'mp3'; }
    else {
      setStep(k, 'run', '在合成', 0.4); note(k, '乐谱写好了，正在本机合成各个声部…');
      const d = await worker('w/kanade/music-worker.js', { id: newId(), score: r.score }, [], (p, st) => { setStep(k, 'run', '在合成', 0.4 + p * 0.45); note(k, st); });
      bytes = new Uint8Array(d.wav); desc = d.desc; title = desc.title || title;
    }
  }
  setStep(k, 'run', '在分析', 0.88); note(k, '在本机分析段落、节拍和调性…');
  const buf = await decodeAudio(bytes);
  if (buf.duration < 20) throw new Error('曲子太短了（至少 20 秒）');
  if (buf.duration > 300) throw new Error('曲子太长了（最多 5 分钟）');
  const m22 = await monoOf(buf, 22050), m22b = m22.slice();
  const [la, sa] = await Promise.all([
    worker('w/mafuyu/lyrics-worker.js', { id: newId(), samples: m22, sampleRate: 22050 }, [m22.buffer]),
    worker('w/miku/sing-worker.js', { id: newId(), type: 'analyze', samples: m22b, sampleRate: 22050 }, [m22b.buffer]),
  ]);
  const name = `01-伴奏.${ext}`;
  must(await api.save({ name, bytes }), '保存伴奏');
  S.inst = { bytes, ext, name, buf, duration: buf.duration, title, desc };
  S.ana = { lyric: la, sing: sa };
  if (!S.title || S.title === '25时的MV') S.title = title;
  const chips = desc ? `${desc.key} · ${desc.bpm} BPM · ${desc.beats}/4 · ${mmss(buf.duration)} · ${desc.form}` : `${sa.key.text} · ${sa.tempo.reliable ? sa.tempo.bpm + ' BPM' : '节拍不明显'} · ${mmss(buf.duration)}`;
  $('sr_' + k).innerHTML = `<div class="sub">《${esc(title)}》 · ${esc(chips)} · 分析出 ${sa.sections.length} 个段落、${sa.bars.length} 个小节</div><audio controls src="${blobUrl(bytes, ext === 'mp3' ? 'audio/mpeg' : 'audio/wav')}"></audio>`;
  setStep(k, 'done', '完成', 1); note(k, S.ownTrack ? '用的是你选的曲子。' : desc ? '本地多轨合成（合成器音色，不是真人演奏）。' : 'MiniMax 生成。');
  S.facts.compose = `奏写好了伴奏《${title}》：${chips}。\n段落（本机分析）：${sa.sections.map((x) => `${x.label} ${mmss(x.start)}–${mmss(x.end)}`).join('，')}。\n接下来真冬要按这首曲子填词。`;
}

/* ---------- 2. 真冬：填词 ---------- */
function parseLyrics(text) {
  const raw = String(text || '').replace(/\r/g, '').split('\n').map((l) => l.trim());
  let title = '';
  const lines = [];
  for (const l of raw) {
    const t = /^标题[:：]\s*(.+)$/.exec(l);
    if (t) { title = t[1].replace(/[《》]/g, '').trim(); continue; }
    if (!l || /^[【\[].*[】\]]$/.test(l) || /^[（(].*[)）]$/.test(l)) continue;
    lines.push(l.replace(/[（(][^)）]*[)）]/g, '').trim());
  }
  return { title, lines: lines.filter(Boolean).slice(0, 20) };
}
async function stepLyrics() {
  const k = 'lyrics';
  setStep(k, 'run', '在填词', 0.1); note(k, '真冬在看曲子的结构…');
  let text;
  if (S.ownLyrics) text = S.ownLyrics;
  else {
    const brief = window.LyricsAnalysis.promptBrief(S.ana.lyric);
    const r = must(await call(api.lyrics, { brief, theme: S.theme, style: S.musicStyle, language: S.language, maxLines: S.seconds <= 90 ? 12 : 16, extra: S.talk.compose ? '奏交接时说的（参考）：' + S.talk.compose.slice(0, 180) : '' }), '填词');
    text = r.text; S.lyricsBy = r.by;
  }
  const p = parseLyrics(text);
  if (!p.lines.length) throw new Error('歌词里没有能唱的行');
  S.lyrics = { text: text.trim(), ...p };
  if (p.title) S.title = p.title;
  must(await api.save({ name: '02-歌词.txt', text: S.lyrics.text }), '保存歌词');
  $('sr_' + k).innerHTML = `<div class="sub">《${esc(S.title)}》 · ${p.lines.length} 行要唱${S.lyricsBy ? ' · ' + esc(S.lyricsBy) : ''}。可以直接在下面改，改完点“继续”就按改过的来。</div><textarea id="lyricsEdit">${esc(S.lyrics.text)}</textarea>`;
  setStep(k, 'done', '完成', 1); note(k, '');
  S.facts.lyrics = () => `真冬写好了歌词《${S.title}》，一共 ${S.lyrics.lines.length} 行：\n${S.lyrics.lines.slice(0, 10).join('\n')}\n接下来绘名要按曲子和歌词画画面。`;
}
// 在确认这一步时，用户可能改过歌词
function takeEditedLyrics() {
  const el = $('lyricsEdit');
  if (!el || !S.lyrics || el.value.trim() === S.lyrics.text) return false;
  const p = parseLyrics(el.value);
  if (!p.lines.length) return false;
  S.lyrics = { text: el.value.trim(), ...p };
  if (p.title) S.title = p.title;
  api.save({ name: '02-歌词.txt', text: S.lyrics.text });
  sys('用你改过的歌词继续。');
  return true;
}

/* ---------- 3. 绘名：画画 ---------- */
function localArt(i, n) {
  // 没有画画密钥时的替代：用五个人的代表色画抽象的光斑背景（明确告诉用户这是替代品）
  const c = document.createElement('canvas'); c.width = 1920; c.height = 1080;
  const g = c.getContext('2d');
  const cols = ['#6f7fae', '#8a7fc2', '#c98a6b', '#d78fb3', '#4fa7a8'];
  const a = cols[i % 5], b = cols[(i + 2) % 5];
  const bg = g.createLinearGradient(0, 0, 1920, 1080); bg.addColorStop(0, '#15131d'); bg.addColorStop(0.55, a + '88'); bg.addColorStop(1, '#0d0c13');
  g.fillStyle = bg; g.fillRect(0, 0, 1920, 1080);
  let seed = (i + 1) * 9301;
  const rnd = () => { seed = (seed * 9301 + 49297) % 233280; return seed / 233280; };
  for (let k = 0; k < 26; k++) {
    const x = rnd() * 1920, y = rnd() * 1080, r = 40 + rnd() * 260;
    const rg = g.createRadialGradient(x, y, 0, x, y, r); rg.addColorStop(0, (k % 2 ? a : b) + '66'); rg.addColorStop(1, '#00000000');
    g.fillStyle = rg; g.beginPath(); g.arc(x, y, r, 0, Math.PI * 2); g.fill();
  }
  g.globalAlpha = 0.25; g.strokeStyle = '#ffffff'; g.lineWidth = 2;
  for (let k = 0; k < 6; k++) { g.beginPath(); const y = 200 + rnd() * 700; g.moveTo(0, y); g.bezierCurveTo(600, y - 200 * rnd(), 1300, y + 200 * rnd(), 1920, y - 100); g.stroke(); }
  g.globalAlpha = 1;
  return c.toDataURL('image/png').split(',')[1];
}
async function paintOne(i) {
  const sc = S.scenes[i];
  let b64, type = 'png', by = '';
  if (S.localArt) { b64 = localArt(i, S.scenes.length); by = '本地抽象画面'; }
  else {
    const r = must(await call(api.paint, { idea: sc.idea, bible: S.bible, style: S.artStyle, index: i }), `第 ${i + 1} 幕`);
    b64 = r.b64; type = r.type || 'png'; by = r.model;
  }
  const name = `03-画面-${pad(i + 1)}.${type === 'jpg' ? 'jpg' : type}`;
  must(await api.save({ name, b64 }), '保存画面');
  sc.file = name; sc.src = `data:image/${type === 'jpg' ? 'jpeg' : type};base64,${b64}`; sc.by = by;
}
function renderImgs() {
  $('sr_paint').innerHTML = `<div class="sub">${S.bible ? '统一设定：' + esc(S.bible) : ''}</div><div class="imgs">${S.scenes.map((s, i) => `<figure>${s.src ? `<img src="${s.src}" alt="">` : '<img alt="">'}<figcaption><span>${i + 1}. ${esc(s.title)}${s.section ? ' · ' + esc(s.section) : ''}</span>${running && !paintWait ? '' : `<a data-redo="${i}">重画</a>`}</figcaption></figure>`).join('')}</div>`;
}
$('flow').addEventListener('click', async (e) => {
  const a = e.target.closest('[data-redo]'); if (!a || (running && !paintWait)) return;
  const i = +a.dataset.redo;
  a.textContent = '在画…';
  try { await paintOne(i); renderImgs(); note('paint', `第 ${i + 1} 幕重画好了。`); }
  catch (err) { note('paint', err.message, 'err'); renderImgs(); }
});
async function stepPaint() {
  const k = 'paint';
  setStep(k, 'run', '在构思', 0.05);
  if (S.ownImages) {
    S.scenes = S.ownImages.map((f, i) => ({ title: f.name.replace(/\.[^.]+$/, '').slice(0, 12), section: '', idea: '', own: f }));
    for (let i = 0; i < S.scenes.length; i++) {
      const f = S.scenes[i].own, ext = (f.name.split('.').pop() || 'png').toLowerCase().replace('jpeg', 'jpg');
      const name = `03-画面-${pad(i + 1)}.${ext}`;
      must(await api.save({ name, bytes: f.bytes }), '保存画面');
      S.scenes[i].file = name; S.scenes[i].src = blobUrl(f.bytes, ext === 'jpg' ? 'image/jpeg' : 'image/' + ext);
    }
    S.bible = '';
    renderImgs(); setStep(k, 'done', '完成', 1); note(k, '用的是你选的图片。');
    return;
  }
  S.localArt = !cfg.paintReady;
  note(k, '绘名在设计分镜…');
  const brief = S.ana.sing.brief || window.LyricsAnalysis.promptBrief(S.ana.lyric);
  const sb = must(await call(api.storyboard, { title: S.title, theme: S.theme + heard('lyrics', '真冬交接歌词时大家说的'), style: S.artStyle, brief, lyrics: S.lyrics ? S.lyrics.text : '', count: S.count }), '分镜');
  S.bible = sb.bible; S.scenes = sb.scenes;
  renderImgs();
  for (let i = 0; i < S.scenes.length; i++) {
    if (stopFlag) throw Object.assign(new Error('已停止'), { stopped: true });
    setStep(k, 'run', `在画 ${i + 1}/${S.scenes.length}`, 0.1 + 0.9 * i / S.scenes.length);
    if (S.scenes[i].file) continue;
    await paintOne(i);
    renderImgs();
  }
  setStep(k, 'done', '完成', 1);
  note(k, S.localArt ? '没有画画用的密钥，这些是本地生成的抽象画面（可以在团队设置里填上密钥再“重做这一步”，或者自己选图片）。' : '');
  S.facts.paint = `绘名画好了 ${S.scenes.length} 幕画面${S.localArt ? '（没有画画密钥，用的是本地生成的抽象画面，不是真正的插画）' : ''}：\n${S.bible ? '统一设定：' + S.bible + '\n' : ''}${S.scenes.map((x, i) => `${i + 1}. ${x.title}${x.section ? '（' + x.section + '）' : ''}：${x.idea}`).join('\n')}\n接下来未来要在伴奏上唱这首歌。`;
}

/* ---------- 4. 未来：演唱 ---------- */
async function stepSing() {
  const k = 'sing';
  if (!cfg.voiceReady) { S.vocal = null; setStep(k, 'skip', '跳过', 0); note(k, '未来还没有复刻音色（团队设置 → 每个人的复刻音色 ID），这次做成纯伴奏 MV，歌词按段落显示。', 'warn'); return; }
  if (!S.lyrics) { S.vocal = null; setStep(k, 'skip', '跳过', 0); note(k, '没有歌词，不唱。', 'warn'); return; }
  const a = S.ana.sing;
  setStep(k, 'run', '在编调子', 0.05); note(k, '未来在听曲子、编唱的调子…');
  const r = must(await call(api.singPrepare, { lyrics: S.lyrics.lines.join('\n'), music: { brief: a.brief + heard('paint', '交接时大家说的（只参考情绪，不改歌词）'), bpm: a.tempo.bpm, minor: a.key.mode === '小调', bars: a.bars.length, beatsPerBar: a.meter.beatsPerBar } }), '编调子');
  const plan = r.plan;
  const lines = [];
  for (let i = 0; i < plan.lines.length; i++) {
    const l = plan.lines[i];
    setStep(k, 'run', `在唱 ${i + 1}/${plan.lines.length}`, 0.15 + 0.6 * i / plan.lines.length); note(k, `用复刻音色唱：${l.text}`);
    const v = must(await call(api.singVoice, { units: l.units }), `第 ${i + 1} 行`);
    const buf = await new OfflineAudioContext(1, 1, 32000).decodeAudioData(b64ToBytes(v.b64).buffer);
    const bar = a.bars[Math.min(a.bars.length - 1, l.bar || 0)];
    lines.push({ samples: buf.getChannelData(0).slice(), sr: 32000, notes: l.notes, start: bar.t + (l.beat || 0) * 60 / plan.bpm });
  }
  setStep(k, 'run', '在调音高', 0.8); note(k, '在本机切分、调音高、对齐到小节…');
  const res = await worker('w/miku/sing-worker.js', { id: newId(), lines, bpm: plan.bpm, keyPc: a.tonicPc, keyShift: 0, backing: null }, lines.map((l) => l.samples.buffer), (p) => setStep(k, 'run', '在调音高', 0.8 + p * 0.12));
  setStep(k, 'run', '在混音', 0.94); note(k, '和伴奏混在一起…');
  const vocalBuf = await decodeAudio(new Uint8Array(res.wav));
  const inst = S.inst.buf, dur = Math.max(inst.duration, vocalBuf.duration);
  const oc = new OfflineAudioContext(2, Math.ceil(dur * 44100), 44100);
  const comp = oc.createDynamicsCompressor(); comp.threshold.value = -10; comp.ratio.value = 4; comp.connect(oc.destination);
  const s1 = oc.createBufferSource(); s1.buffer = inst; const g1 = oc.createGain(); g1.gain.value = 0.78; s1.connect(g1).connect(comp); s1.start();
  const s2 = oc.createBufferSource(); s2.buffer = vocalBuf; const g2 = oc.createGain(); g2.gain.value = 1.0; s2.connect(g2).connect(comp); s2.start();
  const mixed = await oc.startRendering();
  const bytes = wavStereo(mixed);
  must(await api.save({ name: '04-人声.wav', bytes: new Uint8Array(res.wav) }), '保存人声');
  must(await api.save({ name: '04-成曲.wav', bytes }), '保存成曲');
  S.vocal = { name: '04-成曲.wav', bytes, duration: mixed.duration, lines: res.lines.map((t, i) => ({ t0: t.t0, t1: t.t1, text: plan.lines[i].text, mood: plan.lines[i].mood })), env: res.env, envRate: res.envRate, warn: res.warn || [] };
  $('sr_' + k).innerHTML = `<div class="sub">《${esc(S.title)}》成曲 ${mmss(mixed.duration)} · ${plan.lines.length} 行 · 编调子：${esc(r.by)}</div><audio controls src="${blobUrl(bytes, 'audio/wav')}"></audio>`;
  setStep(k, 'done', '完成', 1);
  note(k, (r.fixes && r.fixes.length ? '自动修正：' + r.fixes.join('；') + '\n' : '') + (S.vocal.warn.length ? '提醒：' + S.vocal.warn.join('；') : ''), S.vocal.warn.length ? 'warn' : '');
  acts(k, [['让未来在桌面上唱一遍', () => api.singToPet({ bytes, env: S.vocal.env, envRate: S.vocal.envRate, title: S.title, lines: S.vocal.lines })]]);
  S.facts.sing = `未来唱好了《${S.title}》，成曲 ${mmss(mixed.duration)}，${S.vocal.lines.length} 行，从 ${mmss(S.vocal.lines[0].t0)} 开始唱，最后一句在 ${mmss(S.vocal.lines[S.vocal.lines.length - 1].t1)} 唱完。\n接下来瑞希要把画面、歌和字幕剪成 MV。`;
}

/* ---------- 5. 瑞希：剪辑 ---------- */
function subtitlePNG(text, { size, position, title = false }) {
  const c = document.createElement('canvas'); c.width = 1280; c.height = 720;
  const g = c.getContext('2d');
  const px = title ? 64 : { small: 30, medium: 38, large: 46 }[size] || 38;
  g.font = `${title ? 700 : 600} ${px}px "Microsoft YaHei UI","Microsoft YaHei","PingFang SC","Noto Sans CJK SC",sans-serif`;
  g.textAlign = 'center'; g.textBaseline = 'middle';
  // 太长就分两行
  let lines = [text];
  if (g.measureText(text).width > 1100) { const h = Math.ceil(text.length / 2); lines = [text.slice(0, h), text.slice(h)]; }
  const y0 = title ? 330 : position === 'center' ? 360 : 640 - (lines.length - 1) * px * 1.25;
  lines.forEach((t, i) => {
    const y = y0 + i * px * 1.25;
    g.lineJoin = 'round'; g.lineWidth = Math.max(5, px / 6); g.strokeStyle = 'rgba(15,12,25,0.85)'; g.strokeText(t, 640, y);
    g.shadowColor = 'rgba(0,0,0,0.5)'; g.shadowBlur = 8; g.fillStyle = '#ffffff'; g.fillText(t, 640, y); g.shadowBlur = 0;
  });
  if (title) { g.font = `400 26px "Microsoft YaHei UI",sans-serif`; g.fillStyle = 'rgba(255,255,255,0.85)'; g.fillText('25時、Nightcordで。', 640, 410); }
  return c.toDataURL('image/png').split(',')[1];
}
async function stepEdit() {
  const k = 'edit';
  setStep(k, 'run', '在排镜头', 0.05); note(k, '瑞希在排剪辑方案…');
  const audio = S.vocal ? S.vocal : { name: S.inst.name, duration: S.inst.duration };
  const duration = audio.duration;
  const sections = S.ana.sing.sections.map((s) => ({ label: s.label, start: s.start, end: s.end }));
  // 没有人声时，歌词按段落大致铺开（只显示，不对口型）
  let lines = S.vocal ? S.vocal.lines : [];
  if (!S.vocal && S.lyrics) {
    const vocalSecs = sections.filter((s) => !/前奏|尾奏|间奏|器乐/.test(s.label));
    const span = vocalSecs.length ? vocalSecs : [{ start: duration * 0.1, end: duration * 0.9 }];
    const total = span.reduce((t, s) => t + (s.end - s.start), 0), per = total / S.lyrics.lines.length;
    let si = 0, t = span[0].start;
    lines = S.lyrics.lines.map((text) => { while (si < span.length - 1 && t + per > span[si].end + 0.01) { si++; t = Math.max(t, span[si].start); } const l = { t0: t, t1: t + per - 0.3, text }; t += per; return l; });
  }
  const r = must(await call(api.editPlan, { talk: S.talk.sing || '', title: S.title, duration, scenes: S.scenes.map((s) => ({ title: s.title, section: s.section })), sections, lines }), '剪辑方案');
  const plan = r.plan;
  if (r.note) sys(`瑞希的方案没排成（${r.note}），先按段落平均分配画面。`);
  setStep(k, 'run', '在画字幕', 0.15);
  const subs = [];
  if (plan.titleCard) {
    const name = '05-片头.png';
    must(await api.save({ name, b64: subtitlePNG(S.title, { title: true }) }));
    subs.push({ name, t0: 0.4, t1: Math.min(4, duration / 6) });
  }
  for (let i = 0; i < lines.length; i++) {
    const l = lines[i], name = `05-字幕-${pad(i + 1)}.png`;
    must(await api.save({ name, b64: subtitlePNG(l.text, plan.subtitle) }));
    subs.push({ name, t0: Math.max(0, l.t0 - 0.15), t1: l.t1 + 0.35 });
  }
  setStep(k, 'run', '在剪', 0.3); note(k, `${plan.shots.length} 个镜头，开始导出…`);
  const out = must(await call(api.exportVideo, { plan, duration, images: S.scenes.map((s) => s.file), audio: audio.name, subs }), '导出');
  S.video = out;
  $('sr_' + k).innerHTML = `<div class="sub">《${esc(plan.title)}》 · ${mmss(duration)} · ${plan.shots.length} 个镜头 · 剪辑方案：${esc(r.by === 'local' ? '按段落平均分配' : r.by)}</div><video controls src="${out.url}"></video>`;
  setStep(k, 'done', '完成', 1); note(k, '导出完成：' + out.path);
  acts(k, [['在文件夹里显示', () => api.reveal({ name: out.name }), true], ['打开素材文件夹', () => api.openFolder()]]);
  S.facts.edit = `瑞希把 MV 剪好了：《${plan.title}》，${mmss(duration)}，${plan.shots.length} 个镜头${plan.titleCard ? '，开头有片头' : ''}${lines.length ? '，配了歌词字幕' : ''}${S.vocal ? '，有未来的歌声' : '，没有人声（纯伴奏）'}${S.localArt ? '；画面是本地生成的抽象画面' : ''}。大家一起看了一遍成片。`;
}

/* ---------- 流程控制 ---------- */
const RUN = { compose: stepCompose, lyrics: stepLyrics, paint: stepPaint, sing: stepSing, edit: stepEdit };
const OWN = {
  compose: ['用我自己的曲子', async () => { const r = await api.pick({ kind: 'audio' }); if (r && r.files) { S.ownTrack = r.files[0]; return true; } return false; }],
  paint: ['用我自己的图片', async () => { const r = await api.pick({ kind: 'images' }); if (r && r.files) { S.ownImages = r.files; return true; } return false; }],
};
// 等你决定：继续 / 重做 / 用自己的；出错时：重试 / 跳过 / 停止
function waitFor(key, list) {
  return new Promise((resolve) => {
    decide = resolve;
    acts(key, list.map(([label, val, primary]) => [label, async () => {
      if (typeof val === 'function') { if (!(await val())) return; resolve('redo'); }
      else resolve(val);
      decide = null; acts(key, []);
    }, primary]));
  });
}
const factsOf = (key) => { const f = S.facts[key]; return typeof f === 'function' ? f() : f || ''; };
async function runFlow() {
  const mode = (document.querySelector('input[name=mode]:checked') || {}).value || 'step';
  await talk('kickoff', `${'想做的歌'}：${S.theme}\n曲风、乐器：${S.musicStyle || '没有特别要求'}\n长度：约 ${mmss(S.seconds)}；歌词语言：${{ zh: '中文', ja: '日语', 'zh-ja': '中文为主，副歌夹一点日语' }[S.language]}；画风：${S.artStyle || '没有特别要求'}；画面 ${S.count} 幕。\n还什么都没开始做。`);
  for (let i = 0; i < STEPS.length; i++) {
    const key = STEPS[i].key;
    for (;;) {
      if (stopFlag) return;
      acts(key, []);
      try {
        await RUN[key]();
      } catch (e) {
        if (stopFlag || e.stopped) { setStep(key, 'fail', '已停止'); return; }
        setStep(key, 'fail', '出错了'); note(key, e.message + (e.noConfig ? '\n（可以在群聊窗口的“团队设置”里填好再重试）' : ''), 'err');
        const opts = [['重试', 'redo', true]];
        if (OWN[key]) opts.push([OWN[key][0], OWN[key][1]]);
        if (key === 'paint') opts.push(['用本地抽象画面代替', async () => { S.localArtForce = true; return true; }]);
        if (key === 'lyrics' || key === 'sing') opts.push(['跳过这一步', 'skip']);
        opts.push(['停止', 'stop']);
        const d = await waitFor(key, opts);
        if (d === 'stop') { stopFlag = true; return; }
        if (d === 'skip') { setStep(key, 'skip', '跳过'); if (key === 'lyrics') S.lyrics = null; if (key === 'sing') S.vocal = null; break; }
        continue;
      }
      if (mode === 'step' && i < STEPS.length - 1) {
        const opts = [['继续', 'next', true], ['重做这一步', 'redo']];
        if (OWN[key]) opts.push([OWN[key][0], OWN[key][1]]);
        if (key === 'paint') { paintWait = true; renderImgs(); }
        const d = await waitFor(key, opts);
        paintWait = false;
        if (d === 'redo') { if (key === 'paint') S.scenes = []; continue; }
        if (key === 'lyrics') takeEditedLyrics();
      }
      // 这一步做好了（逐步模式下是你点了“继续”之后）：做完的人和接手的人交接几句
      if (!stopFlag && S.facts[key]) await talk(key, factsOf(key));
      break;
    }
  }
}
$('start').onclick = async () => {
  if (running) return;
  await loadConfig();
  const theme = $('theme').value.trim();
  if (theme.length < 2) { $('formMsg').textContent = '先写一句想做什么样的歌。'; $('formMsg').className = 'note warn'; return; }
  if (!cfg.chatReady) { $('formMsg').textContent = '还没有设置聊天模型：群聊窗口 → 团队设置。作曲、分镜、剪辑方案都要用到它。'; $('formMsg').className = 'note err'; return; }
  $('formMsg').textContent = '';
  S = { talkOn: $('talkOn').checked, facts: {}, talk: {}, title: '', theme, musicStyle: $('musicStyle').value.trim(), seconds: +$('seconds').value, language: $('language').value, artStyle: $('artStyle').value.trim(), count: +$('count').value, scenes: [] };
  const pj = must(await api.newProject({ title: theme.slice(0, 12) }));
  $('folder').disabled = false;
  renderSteps(); $('talk').innerHTML = '';
  sys(`素材会存在：${pj.dir}`);
  running = true; stopFlag = false;
  for (const el of document.querySelectorAll('#form input,#form select,#form textarea,#start')) el.disabled = true;
  $('stopAll').disabled = false;
  try { await runFlow(); if (!stopFlag) sys('全部做完了。'); }
  catch (e) { sys('出错了：' + e.message); }
  finally {
    running = false; decide = null;
    for (const el of document.querySelectorAll('#form input,#form select,#form textarea,#start')) el.disabled = false;
    $('stopAll').disabled = true;
    if (S.scenes && S.scenes.length) renderImgs();
  }
};
// “用本地抽象画面代替”：只影响这一次的画画
const _stepPaint = stepPaint;
RUN.paint = async () => { if (S.localArtForce) { cfg = { ...cfg, paintReady: false }; } return _stepPaint(); };
$('stopAll').onclick = () => {
  stopFlag = true;
  api.skipChat();
  if (curJob) api.cancel(curJob);
  if (decide) { decide('stop'); decide = null; }
  sys('已停止。做好的素材都还在文件夹里。');
};

/* ---------- 启动 ---------- */
api.onRoster((r) => { roster = r; });
(async () => {
  roster = await api.roster();
  renderSteps();
  await loadConfig();
})();
window.__mv = { get S() { return S; }, parseLyrics, subtitlePNG, localArt, runFlow, STEPS };
