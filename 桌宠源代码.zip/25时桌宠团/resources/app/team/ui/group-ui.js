'use strict';
/* Nightcord 群聊窗口 */
const api = window.groupAPI;
const $ = (id) => document.getElementById(id);
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
let roster = [], target = 'all', sel = null, sending = false;
const mem = (id) => roster.find((m) => m.id === id);
const avatarHTML = (m, size = 36) => {
  if (!m) return `<span class="av" style="width:${size}px;height:${size}px">你</span>`;
  return m.src ? `<span class="av" style="width:${size}px;height:${size}px"><img src="${m.src}" alt=""></span>` : `<span class="av" style="width:${size}px;height:${size}px;background:${m.color}">${esc(m.short.slice(0, 1))}</span>`;
};

/* ---------- 成员列表 ---------- */
function renderRoster() {
  const box = $('roster');
  const all = `<div class="mem all ${target === 'all' ? 'sel' : ''}" data-id="all"><span class="av">25</span><div class="info"><div class="nm">大家</div><div class="rl">对在线的所有人说</div></div></div>`;
  box.innerHTML = all + roster.map((m) => `
    <div class="mem ${m.online ? 'on' : 'off'} ${target === m.id ? 'sel' : ''}" data-id="${m.id}">
      ${avatarHTML(m)}<span class="dot"></span>
      <div class="info"><div class="nm" style="color:${m.color}">${esc(m.name)}</div><div class="rl">${m.loaded ? (m.online ? '在桌面上' : '下线了') : '没有加载成功'}${m.avatarMode ? ' · 头像模式' : ''}${m.voice ? '' : ' · 没有声音'}</div>
        <div class="ctl">
          <label><span class="switch"><input type="checkbox" data-act="online" ${m.online ? 'checked' : ''}><span></span></span>在桌面</label>
          <label><span class="switch"><input type="checkbox" data-act="avatar" ${m.avatarMode ? 'checked' : ''}><span></span></span>头像模式</label>
          <a data-act="pick">换头像</a>${m.custom ? '<a data-act="reset">用回默认</a>' : ''}<a data-act="settings">设置</a>
        </div></div>
    </div>`).join('');
  renderTargets();
}
$('roster').addEventListener('click', async (e) => {
  const row = e.target.closest('.mem'); if (!row) return;
  const id = row.dataset.id;
  const act = e.target.dataset && e.target.dataset.act;
  if (act === 'online') { roster = await api.setOnline(id, e.target.checked); renderRoster(); return; }
  if (act === 'avatar') { roster = await api.setAvatarMode(id, e.target.checked); renderRoster(); return; }
  if (act === 'pick') { const r = await api.pickAvatar(id); if (r && r.error) showErr(r.error); return; }
  if (act === 'reset') { await api.resetAvatar(id); return; }
  if (act === 'settings') { api.openMemberSettings(id); return; }
  if (e.target.closest('.ctl')) return;
  setTarget(id);
});
function setTarget(id) {
  if (id !== 'all' && !mem(id)) id = 'all';
  target = id;
  $('title').textContent = id === 'all' ? '对 大家 说' : `只对 ${mem(id).name} 说（其他人也许会插话）`;
  $('input').placeholder = id === 'all' ? '对大家说点什么…（Enter 发送，Shift+Enter 换行）' : `对${mem(id).short}说…（Enter 发送，Shift+Enter 换行）`;
  renderRoster();
  $('input').focus();
  return loadLog();
}
function renderTargets() {
  $('targets').innerHTML = `<span class="chip ${target === 'all' ? 'sel' : ''}" data-id="all">大家</span>` +
    roster.map((m) => `<span class="chip ${target === m.id ? 'sel' : ''} ${m.online ? '' : 'off'}" data-id="${m.id}" title="${m.online ? '' : '她现在下线了'}">${esc(m.short)}</span>`).join('');
}
$('targets').addEventListener('click', (e) => { const c = e.target.closest('.chip'); if (c) setTarget(c.dataset.id); });

/* ---------- 聊天记录 ---------- */
let lastDay = '', logRequest = 0, logLoading = false, pendingLogEvents = [];
function addLine(e, scroll = true) {
  const empty = $('emptyLog'); if (empty) empty.remove();
  const d = new Date(e.at || Date.now());
  const day = `${d.getMonth() + 1}月${d.getDate()}日`;
  const box = $('log');
  if (day !== lastDay) { lastDay = day; box.insertAdjacentHTML('beforeend', `<div class="day">${day}</div>`); }
  const me = e.who === 'user';
  const m = me ? null : mem(e.who);
  const hm = `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
  const to = !e.to || e.to === 'user' ? '' : e.to === 'all' ? ' → 大家' : ` → ${(mem(e.to) || {}).short || ''}`;
  const tag = e.kind === 'direct' ? '<span class="tag">在桌宠那里单独说的</span>' : e.kind === 'mv' ? '<span class="tag">做 MV</span>' : '';
  const name = me ? '你' : `<b style="color:${m ? m.color : '#fff'}">${esc(m ? m.name : e.who)}</b>`;
  box.insertAdjacentHTML('beforeend', `<div class="line ${me ? 'me' : ''}">${me ? '' : avatarHTML(m)}<div class="body"><div class="who">${name}${esc(to)} · ${hm}${tag}</div><div class="txt">${esc(e.text)}</div></div></div>`);
  if (scroll) box.scrollTop = box.scrollHeight;
}
async function loadLog() {
  const mine = ++logRequest, selected = target;
  logLoading = true; pendingLogEvents = [];
  const list = await api.log(selected);
  if (mine !== logRequest || selected !== target) return;
  const key = e => JSON.stringify([e.at, e.who, e.to, e.text, e.kind, e.thread]);
  const seen = new Set(list.map(key));
  for (const e of pendingLogEvents) if (e.thread === selected && !seen.has(key(e))) { list.push(e); seen.add(key(e)); }
  logLoading = false; pendingLogEvents = [];
  $('log').innerHTML = ''; lastDay = '';
  for (const e of list) addLine(e, false);
  $('log').scrollTop = $('log').scrollHeight;
  if (!list.length) $('log').innerHTML = '<div class="day" id="emptyLog">' + (selected === 'all' ? '这里是大家的群聊。' : '这里还没有与' + esc(mem(selected).short) + '的记录。') + '</div>';
}
api.onLine((e) => { if (logLoading) pendingLogEvents.push(e); if (e.thread === target) addLine(e); });
api.onTyping((t) => {
  if (!t || !t.who) { $('typing').textContent = ''; return; }
  if (t.who === '*') { $('typing').textContent = '大家在想怎么回…'; return; }
  const m = mem(t.who); $('typing').textContent = m ? `${m.short} 正在说…` : '';
});
function showErr(t) { $('err').textContent = t || ''; if (t) setTimeout(() => { if ($('err').textContent === t) $('err').textContent = ''; }, 8000); }
api.onError(showErr);

async function send() {
  const text = $('input').value.trim();
  if (!text || sending) return;
  if (target !== 'all' && mem(target) && !mem(target).online) { showErr(`${mem(target).short}现在下线了，先在左边让她上线吧。`); return; }
  sending = true; $('send').disabled = true; showErr('');
  $('input').value = '';
  try {
    const r = await api.say(text, target);
    if (r && r.error) showErr(r.error);
  } finally { sending = false; $('send').disabled = false; $('input').focus(); }
}
$('send').onclick = send;
$('input').addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); send(); } });
$('stop').onclick = () => api.stop();
$('clear').onclick = async () => { await api.clear(target); loadLog(); };
$('openMV').onclick = () => api.openMV();

/* ---------- 团队设置 ---------- */
const FIELDS = ['name', 'jaName', 'apiBase', 'model', 'ttsModel', 'ttsBase', 'ttsGroupId', 'lyricsModel', 'paintModel', 'visionBase', 'visionModel', 'musicBackend', 'interject', 'maxLines'];
const SECRETS = ['apiKey', 'ttsKey', 'sfKey', 'paintKey', 'visionKey'];
let sv = null;
async function openSettings() {
  sv = await api.settingsGet();
  if (!sv || sv.error) return;
  for (const k of FIELDS) { const el = $('s_' + k); if (el) el.value = sv[k] ?? ''; }
  $('s_maxLines').value = String(sv.maxLines || 5);
  $('s_ttsEnabled').checked = !!sv.ttsEnabled;
  for (const k of SECRETS) { $('s_' + k).value = ''; $('s_' + k).placeholder = sv[k + 'Set'] ? '已填写（不改就留空）' : '还没有填'; $('h_' + k).textContent = ''; }
  $('voices').innerHTML = sv.voices.map((v) => `${avatarHTML(mem(v.id), 26)}<input data-voice="${v.id}" value="${esc(v.voiceId)}" placeholder="${esc(v.name)}的复刻音色 ID"><span class="sub">${esc(v.name)}</span>`).join('');
  $('memberLinks').innerHTML = sv.members.map((m) => `<button data-open="${m.id}">${esc(m.name)}的设置…</button>`).join('');
  $('smsg').textContent = ''; $('smsg').className = 'msg';
  $('settings').classList.add('show');
}
$('openSettings').onclick = openSettings;
$('scancel').onclick = () => $('settings').classList.remove('show');
$('memberLinks').addEventListener('click', (e) => { const b = e.target.closest('[data-open]'); if (b) api.openMemberSettings(b.dataset.open); });
$('sameKey').onclick = () => {
  const k = $('s_sfKey').value.trim();
  if (!k) { $('smsg').textContent = '先在“写词用的 API 密钥”里填上密钥。'; $('smsg').className = 'msg warn'; return; }
  $('s_paintKey').value = k; $('s_visionKey').value = k;
  $('smsg').textContent = '已经填到画画和看图里了，点“保存”生效。'; $('smsg').className = 'msg ok';
};
$('ssave').onclick = async () => {
  const v = {};
  for (const k of FIELDS) { const el = $('s_' + k); if (el) v[k] = el.value; }
  v.ttsEnabled = $('s_ttsEnabled').checked;
  for (const k of SECRETS) v[k] = $('s_' + k).value;
  v.voices = [...document.querySelectorAll('[data-voice]')].map((el) => ({ id: el.dataset.voice, voiceId: el.value }));
  const r = await api.settingsSave(v);
  if (r && r.ok) { $('smsg').textContent = '保存好了，五个人都用上了。'; $('smsg').className = 'msg ok'; for (const k of SECRETS) $('s_' + k).value = ''; setTimeout(openSettings, 600); }
  else { $('smsg').textContent = (r && r.error) || '没保存成功'; $('smsg').className = 'msg err'; }
};

/* ---------- 启动 ---------- */
api.onRoster((r) => { roster = r; renderRoster(); });
api.onFocus((f) => { if (f && f.target) setTarget(f.target); if (f && f.tab === 'settings') openSettings(); });
(async () => {
  roster = await api.roster();
  renderRoster(); await setTarget('all');
})();
