'use strict';
/* 一起做 MV（主进程部分）
 * 流程：奏作曲（纯伴奏）→ 真冬按曲子填词 → 绘名按曲子和歌词画几幕画面 → 未来用复刻音色在伴奏上唱 → 瑞希排剪辑方案并导出 MP4
 * 页面（ui/mv-ui.js）负责串起这些步骤、在后台线程里合成和分析音频；这里负责调用各成员原来的功能、保存素材、调用 ffmpeg。
 * 所有素材都存在 “视频/25时MV/<作品名-时间>/” 里，可以随时打开看、自己替换。 */
const path = require('path');
const fs = require('fs');
const { ipcMain, app, shell, dialog } = require('electron');
const exporter = require('./mv-export');

class MvError extends Error { constructor(m, extra = {}) { super(m); Object.assign(this, extra); } }

module.exports = function createMV({ team, members, online, shared, state, llm, group, getWin, userData, appDir }) {
  const send = (ch, v) => { const w = getWin(); if (w && !w.isDestroyed()) w.webContents.send(ch, v); };
  const fromWin = (e) => { const w = getWin(); return w && !w.isDestroyed() && e.sender === w.webContents; };
  const jobs = new Map();
  let project = null;           // { dir, title }
  const memberDir = (id) => path.join(appDir, 'members', id);
  const feature = (id) => (team[id] ? team[id].feature() : null);
  const sOf = (id) => (team[id] ? team[id].settings() : {});
  const chatCfg = (s) => ({ apiType: s.apiType || '', apiBase: s.apiBase, apiKey: s.apiKey, model: String(s.model || '').trim(), temperature: 0.85, keyLabel: '聊天模型的 API 密钥' });

  // 每个步骤一个任务：可以取消
  async function job(id, fn) {
    const ctl = new AbortController();
    jobs.set(String(id), ctl);
    try { return await fn(ctl.signal); }
    catch (e) { return { error: ctl.signal.aborted ? '已取消' : String(e && e.message || e), canceled: ctl.signal.aborted, noConfig: !!(e && e.noConfig) }; }
    finally { jobs.delete(String(id)); }
  }
  const handle = (ch, fn) => ipcMain.handle(ch, async (e, p = {}) => {
    if (!fromWin(e)) return { error: '只能在 MV 窗口里使用' };
    try { return await fn(p || {}, e); } catch (err) { return { error: String(err && err.message || err) }; }
  });

  async function chatJSON(s, system, user, signal, maxTokens = 2500) {
    const cfg = chatCfg(s);
    if (!llm.hasChatApi(cfg) || !cfg.model) throw new MvError('还没有设置聊天模型（群聊窗口 → 团队设置）', { noConfig: true });
    const r = await llm.request(cfg, { system, messages: [{ role: 'user', content: user }], stream: false, json: true, maxTokens, signal });
    if (r.error) throw new MvError('聊天模型出错：' + r.error);
    const t = String(r.data.choices[0].message.content || ''), a = t.indexOf('{'), b = t.lastIndexOf('}');
    if (a < 0 || b <= a) throw new MvError('模型没有按格式回答');
    try { return JSON.parse(t.slice(a, b + 1)); } catch (e) { throw new MvError('模型回答的格式不对'); }
  }

  /* ---------- 准备情况 ---------- */
  handle('mv-config', () => {
    const k = sOf('kanade'), ena = sOf('ena'), miku = sOf('miku'), mf = sOf('mafuyu');
    const chatReady = llm.hasChatApi(chatCfg(k)) && !!chatCfg(k).model;
    const paintKey = llm.cleanKey(ena.paintKey || ena.visionKey || ena.embKey || ena.asrKey);
    return {
      chatReady, chatModel: chatCfg(k).model,
      musicBackend: k.musicBackend === 'minimax' ? 'minimax' : 'local',
      lyricsBy: llm.cleanKey(mf.sfKey) && String(mf.lyricsModel || '').trim() ? `硅基流动 · ${mf.lyricsModel}` : chatReady ? `聊天模型 · ${chatCfg(k).model}` : '',
      paintReady: !!paintKey, paintModel: String(ena.paintModel || 'Kwai-Kolors/Kolors'),
      voiceReady: !!(llm.cleanKey(miku.ttsKey) && String(miku.ttsVoiceId || '').trim()),
      ffmpeg: exporter.ffmpegPath(memberDir('mizuki')),
      online: members.map((m) => ({ id: m.id, online: online(m.id) })),
      project: project ? project.dir : '',
    };
  });

  /* ---------- 作品文件夹 ---------- */
  handle('mv-new-project', (p) => {
    const safe = (String(p.title || '').replace(/[\\/:*?"<>|\r\n]/g, '_').trim() || '25时的MV').slice(0, 30);
    const d = new Date(), stamp = `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}-${String(d.getHours()).padStart(2, '0')}${String(d.getMinutes()).padStart(2, '0')}${String(d.getSeconds()).padStart(2, '0')}`;
    let base; try { base = app.getPath('videos'); } catch (e) { base = app.getPath('documents'); }
    const dir = path.join(base, '25时MV', `${safe}-${stamp}`);
    fs.mkdirSync(dir, { recursive: true });
    project = { dir, title: safe };
    return { ok: true, dir };
  });
  const inProject = (name) => {
    if (!project) throw new MvError('还没有开始做 MV');
    const n = String(name || '').replace(/[\\/:*?"<>|\r\n]/g, '_').slice(0, 80);
    if (!n || n.startsWith('.')) throw new MvError('文件名不对');
    return path.join(project.dir, n);
  };
  handle('mv-save', (p) => {
    try {
      const f = inProject(p.name);
      if (p.text != null) fs.writeFileSync(f, String(p.text), 'utf8');
      else if (p.bytes) fs.writeFileSync(f, Buffer.from(p.bytes));
      else if (p.b64) fs.writeFileSync(f, Buffer.from(String(p.b64), 'base64'));
      else return { error: '没有内容' };
      return { ok: true, path: f };
    } catch (e) { return { error: '保存失败：' + e.message }; }
  });
  handle('mv-read', (p) => { try { return { ok: true, bytes: fs.readFileSync(inProject(p.name)) }; } catch (e) { return { error: e.message }; } });
  handle('mv-open-folder', () => { if (project) shell.openPath(project.dir); return { ok: !!project }; });
  // 自己换素材：选图片 / 选一首曲子
  handle('mv-pick', async (p) => {
    const w = getWin();
    const img = p.kind === 'images';
    const r = await dialog.showOpenDialog(w, { title: img ? '选几张图片当 MV 画面' : '选一首曲子（纯伴奏最好）', properties: img ? ['openFile', 'multiSelections'] : ['openFile'],
      filters: img ? [{ name: '图片', extensions: ['png', 'jpg', 'jpeg', 'webp'] }] : [{ name: '音频', extensions: ['wav', 'mp3', 'm4a', 'flac', 'ogg', 'aac'] }] });
    if (r.canceled || !r.filePaths.length) return { canceled: true };
    const files = r.filePaths.slice(0, 16).map((f) => {
      const st = fs.statSync(f);
      if (st.size > 60 * 1024 * 1024) throw new MvError('文件太大了');
      return { name: path.basename(f), bytes: fs.readFileSync(f) };
    });
    return { ok: true, files };
  });

  /* ---------- 1. 奏：作曲（纯伴奏） ---------- */
  handle('mv-compose', (p) => job(p.id, async () => {
    const music = feature('kanade');
    if (!music) throw new MvError('奏没有加载成功');
    const r = await music._test.run({ id: p.id, mode: 'accompaniment', prompt: String(p.prompt || '').slice(0, 800), seconds: Math.max(30, Math.min(240, +p.seconds || 90)), bpm: 0, beats: 0 }, (x) => send('mv-progress', { step: 'compose', ...x }));
    if (r.error) throw new MvError(r.error, { noConfig: r.noConfig });
    return r.backend === 'minimax' ? { ok: true, backend: 'minimax', bytes: r.bytes, ext: r.ext, model: r.model } : { ok: true, backend: 'local', score: r.score, model: r.model };
  }));

  /* ---------- 2. 真冬：填词 ---------- */
  handle('mv-lyrics', (p) => job(p.id, async (signal) => {
    const mf = sOf('mafuyu');
    const lyricsMod = require(path.join(memberDir('mafuyu'), 'lyrics.js'));
    const input = { kind: 'audio', brief: String(p.brief || '').slice(0, 12000), listened: '', theme: String(p.theme || '').slice(0, 200), style: String(p.style || '').slice(0, 120), language: ['zh', 'ja', 'zh-ja'].includes(p.language) ? p.language : 'zh', mafuyu: true,
      extra: `这是给 MV 用的歌：总共不超过 ${Math.max(8, Math.min(20, +p.maxLines || 16))} 行要唱的歌词（器乐段不算），每行不超过 14 个字，便于演唱。${String(p.extra || '').slice(0, 200)}` };
    if (!input.brief) throw new MvError('曲子还没有分析');
    const feat = feature('mafuyu');
    if (feat && llm.cleanKey(mf.sfKey) && String(mf.lyricsModel || '').trim()) {
      const r = await feat._test.run('generate', { id: p.id, ...input }, (x) => send('mv-progress', { step: 'lyrics', stage: x.stage, chars: x.chars }), undefined, signal);
      if (r.ok) return { ok: true, text: r.text, by: '硅基流动 · ' + r.model };
      if (r.canceled) throw new MvError('已取消');
      // 硅基流动失败：改用聊天模型
      send('mv-progress', { step: 'lyrics', stage: 'fallback', note: r.error });
    }
    const msgs = lyricsMod.buildMessages(input);
    const cfg = chatCfg(sOf('kanade'));
    if (!llm.hasChatApi(cfg) || !cfg.model) throw new MvError('填词需要硅基流动的写词模型或聊天模型（团队设置里填一个就行）', { noConfig: true });
    const r = await llm.request({ ...cfg, temperature: 0.85 }, { system: msgs[0].content, messages: [msgs[1]], stream: false, json: false, maxTokens: 2500, signal });
    if (r.error) throw new MvError('聊天模型出错：' + r.error);
    const text = String(r.data.choices[0].message.content || '').trim();
    if (!text) throw new MvError('模型没有写出歌词');
    return { ok: true, text, by: '聊天模型 · ' + cfg.model };
  }));

  /* ---------- 3. 绘名：分镜 + 画画 ---------- */
  handle('mv-storyboard', (p) => job(p.id, async (signal) => {
    const n = Math.max(3, Math.min(8, +p.count || 5));
    const sys = `你是东云绘名（25时的插画担当），要为一支 MV 设计分镜。只输出一个 JSON 对象：
{"bible":"整支 MV 统一的视觉设定：主角的外形和服装、画风、主色调、光线（80 字以内）","scenes":[{"title":"这一幕的名字（8 字以内）","section":"对应的段落名","idea":"这一幕画什么：场景、构图、镜头、光线、情绪（60 字以内）"}]}
要求：scenes 正好 ${n} 个，按 MV 的时间顺序，和歌词、曲子的段落对应（前奏、主歌、副歌、尾声……），副歌的画面最有冲击力；画面里不要出现文字；不要画真实存在的人物或有版权的角色，主角是原创的人物或者只画场景。`;
    const user = `作品名：${String(p.title || '').slice(0, 30)}\n主题：${String(p.theme || '').slice(0, 700)}\n画风偏好：${String(p.style || '').slice(0, 80) || '日系插画，干净的线条，细腻的光影'}\n\n曲子（本机分析）：\n${String(p.brief || '').slice(0, 3000)}\n\n歌词：\n${String(p.lyrics || '').slice(0, 2000)}`;
    const raw = await chatJSON(sOf('ena'), sys, user, signal, 1600);
    const bible = String(raw.bible || '').trim().slice(0, 200);
    const scenes = (Array.isArray(raw.scenes) ? raw.scenes : []).slice(0, n).map((s, i) => ({ title: String(s && s.title || `第${i + 1}幕`).slice(0, 16), section: String(s && s.section || '').slice(0, 12), idea: String(s && s.idea || '').trim().slice(0, 160) })).filter((s) => s.idea);
    if (!scenes.length) throw new MvError('分镜没有写出来');
    return { ok: true, bible, scenes };
  }));
  handle('mv-paint', (p) => job(p.id, async () => {
    const paint = feature('ena');
    if (!paint) throw new MvError('绘名没有加载成功');
    const idea = `${String(p.bible || '').slice(0, 220)}\n这一幕：${String(p.idea || '').slice(0, 300)}\n这是一支 MV 的横版画面，16:9，电影感构图，画面里不要出现任何文字。`.slice(0, 780);
    const r = await paint._test.run({ id: p.id, mode: 'text', idea, aspect: 'wide', style: String(p.style || '').slice(0, 60), refine: true }, (x) => send('mv-progress', { step: 'paint', index: p.index, stage: x.stage }));
    if (r.error) throw new MvError(r.error, { noConfig: r.noConfig });
    return { ok: true, b64: r.b64, type: r.type, title: r.title, prompt: r.prompt, model: r.model };
  }));

  /* ---------- 4. 未来：编调子 + 逐行合成 ---------- */
  handle('mv-sing-prepare', (p) => job(p.id, async () => {
    const sing = feature('miku');
    if (!sing) throw new MvError('未来没有加载成功');
    const r = await sing._test.prepare({ id: p.id, lyrics: String(p.lyrics || '').slice(0, 1200), music: p.music }, (x) => send('mv-progress', { step: 'sing', ...x }));
    if (r.error) throw new MvError(r.error, { noConfig: r.noConfig });
    return r;
  }));
  handle('mv-sing-voice', (p) => job(p.id, async (signal) => {
    const singMod = require(path.join(memberDir('miku'), 'sing.js'));
    const units = Array.isArray(p.units) ? p.units.map(String).filter(Boolean).slice(0, 24) : [];
    if (!units.length) throw new MvError('这一行没有要唱的音');
    const r = await singMod.speakUnits(sOf('miku'), units, { signal, cacheDir: path.join(userData, 'members', 'miku', 'sing-cache') });
    return { ok: true, b64: r.b64 };
  }));

  /* ---------- 5. 瑞希：剪辑方案 + 导出 ---------- */
  handle('mv-edit-plan', (p) => job(p.id, async (signal) => {
    const duration = +p.duration || 0;
    if (!(duration > 5)) throw new MvError('成曲的时长不对');
    const scenes = (Array.isArray(p.scenes) ? p.scenes : []).slice(0, 16);
    const sections = (Array.isArray(p.sections) ? p.sections : []).slice(0, 24).map((s) => ({ label: String(s.label || ''), start: +s.start || 0, end: +s.end || 0 }));
    const lines = (Array.isArray(p.lines) ? p.lines : []).slice(0, 40).map((l) => ({ t0: +l.t0 || 0, t1: +l.t1 || 0, text: String(l.text || '').slice(0, 40) }));
    let plan = null, by = 'local', note = '';
    try {
      const sys = `你是晓山瑞希（25时的视频担当），要把几张画面剪成一支 MV。只输出一个 JSON 对象：
{"title":"作品名","shots":[{"scene":画面编号,"start":开始秒,"end":结束秒,"motion":"zoom_in|zoom_out|pan_left|pan_right|still","transition":"fade|cut"}],"subtitle":{"position":"bottom|center","size":"small|medium|large"},"titleCard":true或false}
要求：shots 按时间顺序首尾相接，从 0 开始到 ${duration.toFixed(1)} 秒结束；每个镜头 2.5–12 秒；镜头切换尽量落在段落或歌词行的边界上；副歌的镜头可以短一些、运动强一些；同一张画面可以用多次，但不要连续两次；transition 是这个镜头开始时怎么进来（fade 叠化，cut 硬切）。titleCard 为 true 时开头 3 秒显示作品名。talk 是大家交接时说的话（比如未来希望哪里安静、瑞希自己说的剪辑想法），尽量照顾到。`;
      const user = JSON.stringify({ talk: String(p.talk || '').slice(0, 800), title: String(p.title || ''), duration, scenes: scenes.map((s, i) => ({ scene: i, title: s.title, section: s.section })), sections, lyrics: lines });
      const raw = await chatJSON(sOf('mizuki'), sys, user, signal, 2500);
      plan = exporter.validatePlan(raw, { duration, scenes: scenes.length });
      by = chatCfg(sOf('mizuki')).model;
    } catch (e) {
      if (signal.aborted) throw e;
      note = e.message;
      plan = exporter.localPlan({ duration, scenes: scenes.length, sections, title: p.title });
    }
    return { ok: true, plan, by, note };
  }));
  handle('mv-export', (p) => job(p.id, async (signal) => {
    if (!project) throw new MvError('还没有开始做 MV');
    const plan = exporter.validatePlan(p.plan, { duration: +p.duration, scenes: (p.images || []).length });
    const images = (p.images || []).map((n) => inProject(n));
    const audio = inProject(p.audio);
    const subs = (Array.isArray(p.subs) ? p.subs : []).slice(0, 60).map((s) => ({ file: inProject(s.name), t0: +s.t0, t1: +s.t1 }));
    const out = inProject((String(plan.title || project.title).replace(/[\\/:*?"<>|\r\n]/g, '_').slice(0, 40) || 'MV') + '.mp4');
    const r = await exporter.render({ plan, images, audio, subs, out, duration: +p.duration, ffmpeg: exporter.ffmpegPath(memberDir('mizuki')), signal, onProgress: (f, text) => send('mv-progress', { step: 'edit', fraction: f, text }) });
    return { ok: true, path: r.path, name: path.basename(r.path), url: require('url').pathToFileURL(r.path).href, duration: r.duration };
  }));
  handle('mv-reveal', (p) => { try { shell.showItemInFolder(inProject(p.name)); return { ok: true }; } catch (e) { return { error: e.message }; } });

  /* ---------- 大家的交流 ---------- */
  handle('mv-chat', async (p) => {
    const ids = Array.isArray(p.ids) ? p.ids.filter((x) => members.some((m) => m.id === x)) : null;
    const talkId = String(p.talkId || '');
    chatSkip = false;
    const r = await group.workChat(String(p.context || '').slice(0, 2500), ids, {
      instruction: String(p.instruction || '').slice(0, 600), max: +p.max || 4,
      onLine: (l) => send('mv-talk', { talkId, who: l.who, to: l.to, text: l.reply }),
      shouldSkip: () => chatSkip,
    });
    if (r.error) return { error: r.error };
    return { ok: true, lines: r.lines.map((l) => ({ who: l.who, to: l.to, text: l.reply })) };
  });
  let chatSkip = false;   // 还在等模型写对话时就点了“跳过”：写好了也不说
  ipcMain.on('mv-chat-skip', (e) => { if (fromWin(e)) { chatSkip = true; group.stop(); } });
  ipcMain.on('mv-cancel', (e, id) => {
    if (!fromWin(e)) return;
    const c = jobs.get(String(id)); if (c) c.abort();
    // 成员自己的任务也一起取消（作曲、画画、编调子各有自己的任务表）
    for (const mid of ['kanade', 'ena', 'miku']) { try { const f = feature(mid); if (f && f._test && f._test.cancel) f._test.cancel(String(id)); } catch (err) {} }
  });
  // 让未来在桌面上唱（MV 窗口里试听成曲时）
  handle('mv-sing-to-pet', (p) => {
    const t = team.miku; const w = t && t.win();
    if (!w) return { error: '未来不在桌面上' };
    w.webContents.send('sing-play', { b64: Buffer.from(p.bytes).toString('base64'), env: Array.isArray(p.env) ? p.env.slice(0, 60000) : [], envRate: +p.envRate || 50, lines: (p.lines || []).slice(0, 40), title: String(p.title || '').slice(0, 30) });
    return { ok: true };
  });

  return {
    windowClosed: () => { for (const c of jobs.values()) c.abort(); jobs.clear(); },
    _test: { project: () => project, setProject: (p) => { project = p; } },
  };
};
