// 页面脚本：运行在桌宠窗口里，变量 pet 由插件宿主提供。
// 在人物左下角放一个小按钮（clickable: true 才能点到，且不会被当成拖动人物）。
const chip = document.createElement('button');
chip.textContent = '✦';
chip.title = '小工具箱（插件示例）';
chip.style.cssText = 'position:absolute;left:10px;bottom:14px;width:26px;height:26px;border-radius:50%;border:1.5px solid rgba(255,255,255,.9);' +
  'background:rgba(79,71,45,.55);color:#fff;font-size:13px;line-height:1;cursor:pointer;opacity:.55;transition:opacity .2s;padding:0';
chip.onmouseenter = () => { chip.style.opacity = '1'; };
chip.onmouseleave = () => { chip.style.opacity = '.55'; };
chip.onclick = () => pet.send({ type: 'clicked' });
pet.mount(chip, { clickable: true });

// 聊天框或通话面板打开时先藏起来，免得挡住
const panelOpen = () => !!document.querySelector('#chat.show, #call.show');
const timer = setInterval(() => { chip.style.display = panelOpen() ? 'none' : ''; }, 300);

pet.onMessage((m) => { if (m && m.type === 'hello') chip.title = `小工具箱（已陪你聊了 ${m.count} 句）`; });
pet.onUnload(() => clearInterval(timer));   // mount 的元素会自动移除；自己开的定时器要在这里清掉
