# 咲希桌宠（源码）

需要先装 Node.js（18 以上）。在这个文件夹里打开命令行：

    npm install electron@33
    npx electron .

## 文件
- src/lines.js    台词；表情代号表（FACES）；心情 → 表情代号（MOODS）；动作 → 身体动作（ACTIONS）；站姿表（MOTION_STANCE）
- src/model/        校服模型（02saki_normal_3.0_f_t07）
- src/model_unit/   队服模型（Leo/need，02saki_unit_3.0_f_t05）
- src/model_casual/ 常服模型（02saki_cloth001_3.0_f_t09）
  三套的结构一样：faces/ 是 77 个表情（用了 76 个）（文件名保持英文，代号和文件名的对应在 lines.js 的 FACES 里），motions/ 是身体动作
- 表情代号对照.png / .txt  每个代号长什么样、对应的原文件名
- src/renderer.js 动画、点击、拖动、提醒气泡、聊天框；动作的站姿衔接也在这里
- src/motion.js   读取 .motion3.json、按时间求值；两个动作之间平滑过渡
- src/jianpu.js   简谱 / 音名解析、和弦伴奏、电子琴音色合成（波形表 + 包络 + 合唱 + 混响）、五线谱排版数据（toStaff）、导出 WAV / MIDI / MusicXML
- src/staff.js    把五线谱画成 SVG（谱号、休止符、升降号用 src/fonts/NotoMusic.woff2，SIL OFL 授权）
- src/synth.html / synth.js  电子琴窗口（简谱、五线谱、键盘）
- memory.js       长期记忆和资料库：调用 /embeddings 算向量，本地存 memory.json，余弦相似度检索；切段导入资料
- src/memory.html / memory.js  “她的记忆”窗口
- affection.js    好感值（affection.json，模型给 delta，单次/每日上限）和心情余韵（半衰期回落）
- src/affection.html / affection.js  好感调试窗口
- dnd.js          免打扰：Windows 上用常驻 PowerShell 查询 SHQueryUserNotificationState 和前台窗口是否全屏
- screen.js       看屏幕：截图（只在内存里）、“不看”名单、给看图模型的描述要求
- llm.js          聊天请求：OpenAI 兼容 / Claude / Gemini 三种接口，统一成同一种结果；读取模型列表
- brain.js        聊天大脑：拼提示词、记对话，默认人设也在这里；开语音时让它同时给出日语；写曲子的要求也在这里
- asr.js          语音识别：OpenAI 兼容的 /audio/transcriptions（默认硅基流动 SenseVoice），分段识别、过滤无效结果
- src/call.js     语音通话：说话检测、轮流对话、按句配音与字幕、停止/静音/挂断、过期结果丢弃
- src/vad-worklet.js 把麦克风声音切成 20ms 一帧
- voice.js        语音：把日语交给 MiniMax（T2A v2）用你的音色 ID 念出来，结果缓存在本地；心情 → 语气的对照也在这里
- main.js         窗口、托盘菜单、提醒计时、按时间换衣服、设置
## 衣服和时间
main.js 的 outfitByTime()：周一到周五 8:00–18:00 校服，周日 8:00–15:00 队服，其余时间常服。
三套衣服共用同一个显示范围（renderer.js 的 REGIONS），换衣服时头和肩膀停在同一个位置。

## 自己接 AI
最简单：右键她 → 设置，填 API 地址、密钥、模型名，就能聊天。

想换成别的做法（本地模型、语音、加记忆等），只改 brain.js 里的 chat() 就行。
它收到：{ text: 你说的话, moods: {心情: 说明}, actions: {动作: 说明} }
它要返回：{ reply: "她说的话", mood: "心情", action: "动作", face: "表情代号（可省略）" }
face 填了有效代号就优先用它，否则按 mood 挑。
出错时返回 { error: "原因" }，没配置时返回 { error: "noapi" }。
mood / action / face 不在列表里时，桌宠会自动用 calm / none / 按心情挑。

## 语音（MiniMax）
设置里开启语音，填 MiniMax 密钥和音色 ID。流程：
聊天模型回复 { reply: 中文, ja: 日语, mood, ... } → voice.js 把 ja 交给 MiniMax → 桌宠播放并按音量对口型（参数 ParamMouthOpenY）。
固定台词的日语写在 src/lines.js 每句的 ja 里；每句第一次念时合成，之后读缓存（缓存在用户数据文件夹的 voice-cache 里）。

## 动作和衔接
src/lines.js 的 ACTIONS 里，同一个动作准备了好几种站姿下的版本（手放在胸前、双手垂下、双手交握、抱臂……）。
- 每个身体动作开始、结束时更接近哪种站姿，是按手臂、手、腿的参数和官方的 28 个 pose 动作比较算出来的，写在 MOTION_STANCE 里；
  站姿的名字就是那个站姿的待机动作（比如 w-normal-pose01），HOME_STANCE 是平时的站姿。
- 挑动作时，和她现在站姿一样的版本优先；动作做完就停在它结束时的站姿上，不会突然跳回固定的姿势。
  结束在不常待的姿势（还捧着脸之类）时，会用 1 秒多慢慢放回平时的站姿；起始站姿不同的动作淡入 0.8–0.9 秒。
- 待机小动作（IDLE_MOVES）按站姿挑，里面有几个“换站姿”的动作（比如从双手垂下换到手按胸口），让她偶尔自然地换个姿势。
- 整个人的位移（ParamPositionX / ParamPositionY）每帧固定为 0：动作里自带的上下颠动、左右平移都去掉，她只在原地动。
- 挥手、举起双手（会伸出窗口）、身体大幅前倾的动作都没用。

## 语音通话（第一版：轮流对话）
你说话 → 说话检测（能量 + 自适应环境噪声，停顿超过设定时长算说完，太短的不提交，有单句上限）
→ asr.js 分段识别 → brain.js 以通话格式回复 { segments: [{ ja, zh }], mood, intensity, action, face }
→ 每句 ja 交给 voice.js 合成（下一句在上一句播放时就开始合成）→ 那句真正开始播放时显示对应的 zh 字幕。
- 通话和文字聊天共用同一份对话记录、同样的字段（reply = 中文、ja = 日语）；通话的记录带 via: "call"。
- 每次通话、每一轮都有编号；停止、挂断时取消还没回来的请求，迟到的结果因为编号对不上直接丢弃，也不会记进对话。
- 被打断的回复会在对话记录里标上 interrupted（说到第几句），模型下一轮就知道你没听完。
- 半双工：她说话、识别中、思考中都不收声，避免把她自己的声音当成输入；打断用“停止”按钮或“按住说话”。
- 各环节耗时（不含内容）写在用户数据文件夹的 call-timing.log。
以后再做：开口直接打断（需要可靠的回声消除）、流式识别和流式输出、逐字字幕对齐。

## 电子琴（src/jianpu.js、src/staff.js）
- 简谱：1–7、0、-、' ,、# b、_ .、[ ]、|；开头写 1=、拍号、♩=、音色=电子琴/电钢琴/风琴/合成器、伴奏=流行/分解/柱式/长音
- 音名：C4、F#4、Bb3（科学音高记法，C4 = 中央 C），和简谱可以混着写；每个音会记下五线谱上的写法（字母 + 升降），简谱按调号推出来
- 「和弦：| D | A | Bm | G |」：左手低音（E2–E3）+ 右手和弦（放在旋律下面，挑和上一个和弦最接近的转位）
- 声音：每种音色是几层带限波形表（按音高去掉超过奈奎斯特的谐波）+ ADSR 包络、延迟颤音 / 颤动；
  整首再加立体声合唱（风琴除外）、卷积混响、压缩，最后限幅到 0.95
- 五线谱：toStaff() 按拍号切小节，时值拆成能写出来的音符（跨拍、跨小节用连音线），按调号和小节内的升降决定临时记号；
  staff.js 画成 SVG，同一拍里的八分 / 十六分音符连符杠；有低于 F3 的音时用大谱表（中央 C 以下放低音谱表）
- toMusicXML()：MusicXML 3.1（含调号、拍号、速度、和弦名），MuseScore 等可以打开
- 她写曲子：brain.js 的 COMPOSE_RULE（旋律简谱 + 和弦行 + 音色 + 伴奏），main.js 的 checkScore 检查每小节拍数和和弦

## 根据曲子写歌词（硅基流动）
- `lyrics.js`：主进程，写词窗口与硅基流动接口（/models、/chat/completions 流式、听曲用 audio_url、/audio/transcriptions），超时与取消
- `preload-lyrics.js`、`src/lyrics.html`、`src/lyrics-ui.js`：写词窗口
- `src/lyrics-analysis.js`：曲子分析（音频：频谱/节拍/段落/调性；合成器作品：读取简谱数据），`src/lyrics-worker.js` 在后台线程里跑音频分析
- 合成器入口：`src/synth.js` 的“为这首写歌词…”按钮 → `synth-to-lyrics`
- 离线检查：在本目录执行 `node --test test/*.test.js`（插件系统回归 + 写词分析，不联网）

## 发言上下文规则

实际发言按原有 JSONL 格式保存在本机；待机自言自语单独标为“待机”，点击及其他固定反应标为“被点到/反应”。请求模型时，补充上下文使用本地月日与时分、中文来源及可选标签，每条一行，不再重复附带日语译文。最多读取最近100条、合计约15000字符；超长条目只保留结尾并标注“……”。已在本次聊天历史中的回复、通话继续去重；标签含“出错”的新旧提示均不作为角色发言。聊天历史格式、人设和 memoryTurns 规则不变。
