'use strict';
/* 写词（主进程）：硅基流动 SiliconFlow 接口 + 写词窗口
 *
 * 用到的官方接口（https://api-docs.siliconflow.cn）：
 *   GET  {base}/models?sub_type=chat           读取可用的对话模型
 *   POST {base}/chat/completions               写歌词（stream: true，逐字返回，用来显示真实进度）
 *                                             听曲（content 里放 audio_url；官方文档只标注 Qwen3-Omni 系列支持音频输入）
 *   POST {base}/audio/transcriptions           识别原有歌词（FunAudioLLM/SenseVoiceSmall 或 TeleAI/TeleSpeechASR，≤50MB、≤1小时）
 *
 * 密钥只在主进程里使用，不发给页面，也不写进日志。只有用户在写词窗口里点了按钮才会发请求。
 */
const path = require('path');
const fs = require('fs');
const { BrowserWindow, ipcMain, dialog, clipboard } = require('electron');

const DEFAULT_BASE = 'https://api.siliconflow.cn/v1';
const ASR_MODELS = ['FunAudioLLM/SenseVoiceSmall', 'TeleAI/TeleSpeechASR'];
const LIMITS = { asrBytes: 50 * 1024 * 1024, listenBytes: 8 * 1024 * 1024 };

function cleanKey(k) { return String(k || '').replace(/[\s　​-‍⁠﻿]+/g, ''); }
function config(s) {
  let base = String(s.sfBase || DEFAULT_BASE).trim().replace(/\/+$/, '');
  base = base.replace(/\/(chat\/completions|models|audio\/transcriptions)$/, '');
  return {
    base, key: cleanKey(s.sfKey),
    model: String(s.lyricsModel || '').trim(),
    audioModel: String(s.lyricsAudioModel || '').trim(),
    asrModel: String(s.lyricsAsrModel || '').trim() || ASR_MODELS[0],
    timeoutMs: Math.max(20, Math.min(900, Number(s.lyricsTimeout) || 180)) * 1000,
  };
}
const looksAudioCapable = (m) => /omni/i.test(m);

/* ---------- 错误提示 ---------- */
function friendly(status, body, what) {
  let msg = '';
  try { const j = JSON.parse(body); msg = (j && (j.message || (j.error && (j.error.message || j.error)) || j.data)) || ''; } catch (e) { msg = String(body || '').slice(0, 200); }
  msg = String(msg).slice(0, 300);
  if (status === 401) return '密钥无效或已过期（401）。请在 设置 → 写词（硅基流动）里重新填写 API 密钥。';
  if (status === 403) return `没有权限使用这个模型（403）：可能需要实名认证、账户余额不足，或该模型对你的账号不可用。${msg ? '平台说明：' + msg : ''}`;
  if (status === 404) return `找不到接口或模型（404）。请检查接口地址，以及模型名是否写对。${msg ? '平台说明：' + msg : ''}`;
  if (status === 413) return '上传的音频太大（413）。';
  if (status === 429) return '请求太频繁或超出额度（429），请稍后再试。';
  if (status === 503 || status === 504) return `模型服务繁忙或超时（${status}），请稍后再试。`;
  if (status === 400 && what === 'audio') return `模型拒绝了音频输入（400）。这个模型很可能不支持直接听音频；官方文档中只有 Qwen3-Omni 系列标注支持音频输入。${msg ? '平台说明：' + msg : ''}`;
  return `请求失败（${status}）${msg ? '：' + msg : ''}`;
}
class ApiError extends Error { constructor(m, extra = {}) { super(m); Object.assign(this, extra); } }

/* ---------- 请求：可取消、带超时 ---------- */
function jobSignal(job, timeoutMs) {
  const ctl = new AbortController();
  job.abort = (why) => ctl.abort(why);
  const t = setTimeout(() => ctl.abort(new ApiError(`超过 ${Math.round(timeoutMs / 1000)} 秒没有完成，已停止（可以在设置里把超时调长）`, { timeout: true })), timeoutMs);
  return { signal: ctl.signal, done: () => clearTimeout(t) };
}
async function call(cfg, job, pathname, { method = 'POST', json, form, what, stream } = {}) {
  if (!cfg.key) throw new ApiError('还没有填写硅基流动的 API 密钥（右键 → 设置 → 写词（硅基流动））', { noKey: true });
  const { signal, done } = jobSignal(job, cfg.timeoutMs);
  try {
    const headers = { Authorization: 'Bearer ' + cfg.key };
    let body;
    if (json) { headers['Content-Type'] = 'application/json'; body = JSON.stringify(json); }
    if (form) body = form;
    let res;
    try { res = await fetch(cfg.base + pathname, { method, headers, body, signal }); }
    catch (e) { throw signal.aborted ? (signal.reason instanceof Error ? signal.reason : new ApiError('已取消', { canceled: true })) : new ApiError('连不上硅基流动：' + (e.cause && e.cause.code || e.message)); }
    if (!res.ok) throw new ApiError(friendly(res.status, await res.text().catch(() => ''), what), { status: res.status });
    if (stream) return await stream(res, signal);
    return await res.json();
  } catch (e) {
    if (signal.aborted && !(e instanceof ApiError)) throw signal.reason instanceof Error ? signal.reason : new ApiError('已取消', { canceled: true });
    throw e;
  } finally { done(); }
}

// SSE：一行一行读 data: {...}
async function readStream(res, signal, onDelta) {
  const dec = new TextDecoder();
  let buf = '', text = '', reasoning = 0, finish = '';
  for await (const chunk of res.body) {
    if (signal.aborted) break;
    buf += dec.decode(chunk, { stream: true });
    let i;
    while ((i = buf.indexOf('\n')) >= 0) {
      const line = buf.slice(0, i).trim(); buf = buf.slice(i + 1);
      if (!line.startsWith('data:')) continue;
      const data = line.slice(5).trim();
      if (data === '[DONE]') continue;
      let j; try { j = JSON.parse(data); } catch (e) { continue; }
      if (j.error) throw new ApiError('模型返回错误：' + String(j.error.message || j.error).slice(0, 300));
      const ch = j.choices && j.choices[0];
      if (!ch) continue;
      const d = ch.delta || {};
      if (d.reasoning_content) reasoning += d.reasoning_content.length;
      if (d.content) text += d.content;
      if (ch.finish_reason) finish = ch.finish_reason;
      onDelta({ text, reasoning });
    }
  }
  if (signal.aborted) throw signal.reason instanceof Error ? signal.reason : new ApiError('已取消', { canceled: true });
  return { text, finish };
}

/* ---------- 具体功能 ---------- */
async function listModels(cfg, job) {
  const r = await call(cfg, job, '/models?sub_type=chat', { method: 'GET' });
  const ids = (r && Array.isArray(r.data) ? r.data : []).map((m) => String(m.id)).filter(Boolean).sort();
  return { chat: ids, audioCandidates: ids.filter(looksAudioCapable) };
}

// 1 秒静音 WAV（16k 单声道），用来检测模型是否接受音频输入
function silentWav(sec = 1, sr = 16000) {
  const n = sr * sec, b = Buffer.alloc(44 + n * 2);
  b.write('RIFF', 0); b.writeUInt32LE(36 + n * 2, 4); b.write('WAVEfmt ', 8); b.writeUInt32LE(16, 16); b.writeUInt16LE(1, 20); b.writeUInt16LE(1, 22);
  b.writeUInt32LE(sr, 24); b.writeUInt32LE(sr * 2, 28); b.writeUInt16LE(2, 32); b.writeUInt16LE(16, 34); b.write('data', 36); b.writeUInt32LE(n * 2, 40);
  return b;
}
async function probeAudio(cfg, job, model) {
  if (!model) throw new ApiError('还没有填写“听曲模型”');
  const r = await call(cfg, job, '/chat/completions', { what: 'audio', json: {
    model, max_tokens: 16, temperature: 0,
    messages: [{ role: 'user', content: [{ type: 'audio_url', audio_url: { url: 'data:audio/wav;base64,' + silentWav().toString('base64') } }, { type: 'text', text: '这段音频里有声音吗？只回答“有”或“没有”。' }] }],
  } });
  const ans = r && r.choices && r.choices[0] && r.choices[0].message ? String(r.choices[0].message.content || '').trim() : '';
  return { ok: true, model, answer: ans.slice(0, 40) };
}

async function listen(cfg, job, wavB64, brief) {
  if (!cfg.audioModel) throw new ApiError('还没有填写“听曲模型”（设置 → 写词（硅基流动））');
  const bytes = Math.floor(wavB64.length * 3 / 4);
  if (bytes > LIMITS.listenBytes) throw new ApiError('要上传的音频片段太大');
  const r = await call(cfg, job, '/chat/completions', { what: 'audio', json: {
    model: cfg.audioModel, temperature: 0.3, max_tokens: 700,
    messages: [{ role: 'user', content: [
      { type: 'audio_url', audio_url: { url: 'data:audio/wav;base64,' + wavB64 } },
      { type: 'text', text: `这是一首歌的几个片段（中间用短暂静音隔开）：${brief}\n请用中文简短描述你实际听到的：风格/曲风、主要乐器、情绪和氛围、能量变化、有没有人声（男声/女声）。不要写或猜测歌词内容，听不出来的就说听不出来。150 字以内。` },
    ] }],
  } });
  const t = r && r.choices && r.choices[0] && r.choices[0].message ? String(r.choices[0].message.content || '').trim() : '';
  if (!t) throw new ApiError('听曲模型没有返回描述');
  return { text: t.slice(0, 800) };
}

const LANGS = { zh: '简体中文', ja: '日语（按假名音拍计数）', en: '英语（按音节计数）', 'zh-ja': '中文为主，副歌可以夹少量日语' };
function buildMessages(input) {
  const lang = LANGS[input.language] || LANGS.zh;
  const sys = [
    '你是一位专业的作词人，为给定的曲子写全新的原创歌词。',
    '要求：歌词必须是原创的，不得复制或改写任何已发表歌曲的歌词；不要编造曲子没有提供的信息。',
    '严格按照给出的段落顺序和每段的行数、每行字数来写，让歌词贴合节奏：长音落在适合拖长的字（开口音、韵脚）上，副歌更有记忆点，同类段落押韵方式统一。',
    '输出格式：第一行写“标题：……”，之后每个段落先写一行【段落名】（用给出的段落名），下面每行一句歌词。器乐段写【段落名】后跟一行“（器乐）”。不要写解释、不要写和弦、不要写注释。',
  ].join('\n');
  const parts = [];
  parts.push(`歌词语言：${lang}。`);
  if (input.theme) parts.push(`主题：${input.theme}`);
  if (input.style) parts.push(`风格：${input.style}`);
  if (input.ichika) parts.push('参考天马咲希（Leo/need 的键盘手）的笔触：明亮、坦率、闪闪发光，用身边具体的小事和画面写对朋友、对重要的人的心意，有一点青涩但真诚，不要空洞地喊口号。');
  if (input.extra) parts.push(`补充要求：${input.extra}`);
  parts.push('\n=== 曲子分析 ===\n' + input.brief);
  if (input.listened) parts.push('\n=== 支持音频的模型听曲后的描述（参考氛围，不是歌词） ===\n' + input.listened);
  if (input.kind === 'score') parts.push('\n这是旋律谱：每个乐句写成一行，字数（日语按音拍、英语按音节）尽量等于该乐句的音符数，一字对一音；时值长的音放在句尾或关键词上。');
  else parts.push('\n每段的行数和每行字数是根据节拍和节奏密度估出来的建议，可以上下浮动 1–2 字，但段落顺序和行数请照着写。');
  return [{ role: 'system', content: sys }, { role: 'user', content: parts.join('\n') }];
}
async function generate(cfg, job, input, onDelta) {
  if (!cfg.model) throw new ApiError('还没有选择“写词模型”（设置 → 写词（硅基流动） → 读取模型列表）', { noModel: true });
  return call(cfg, job, '/chat/completions', {
    json: { model: cfg.model, messages: buildMessages(input), stream: true, temperature: 0.85, max_tokens: 2500 },
    stream: (res, signal) => readStream(res, signal, onDelta),
  });
}

async function transcribe(cfg, job, bytes, name) {
  if (!ASR_MODELS.includes(cfg.asrModel)) throw new ApiError(`识别模型只能用官方文档列出的：${ASR_MODELS.join('、')}`);
  if (bytes.byteLength > LIMITS.asrBytes) throw new ApiError('识别原有歌词：文件超过 50MB（硅基流动的上限）');
  const form = new FormData();
  form.append('model', cfg.asrModel);
  form.append('file', new Blob([bytes]), String(name || 'song.mp3').replace(/[\r\n"]/g, '_'));
  const r = await call(cfg, job, '/audio/transcriptions', { form });
  return { text: String((r && r.text) || '').trim() };
}

/* ---------- 窗口和 IPC ---------- */
module.exports = function setupLyrics({ getSettings, icon, appDir, sayLine, openSettings, getSynthWin }) {
  let win = null, pendingSource = null;
  const jobs = new Map();
  const send = (ch, v) => { if (win && !win.isDestroyed()) win.webContents.send(ch, v); };

  function open(source) {
    if (source) pendingSource = source;
    if (win && !win.isDestroyed()) {
      win.focus();
      if (source) send('lyrics-source', source);
      return win;
    }
    win = new BrowserWindow({
      width: 1040, height: 760, minWidth: 820, minHeight: 600, title: '咲希桌宠 · 根据曲子写歌词',
      icon, autoHideMenuBar: true, backgroundColor: '#fbf8ef',
      webPreferences: { preload: path.join(appDir, 'preload-lyrics.js'), contextIsolation: true },
    });
    win.loadFile(path.join(appDir, 'src', 'lyrics.html'));
    win.webContents.on('did-finish-load', () => { if (pendingSource) send('lyrics-source', pendingSource); });
    win.on('closed', () => { for (const j of jobs.values()) j.abort && j.abort(new ApiError('窗口关闭，已取消', { canceled: true })); jobs.clear(); win = null; });
    return win;
  }
  const fromWin = (e) => win && !win.isDestroyed() && e.sender === win.webContents;

  ipcMain.handle('lyrics-config', (e) => {
    const c = config(getSettings());
    return { hasKey: !!c.key, base: c.base, model: c.model, audioModel: c.audioModel, audioLikely: looksAudioCapable(c.audioModel), asrModel: c.asrModel, timeoutSec: c.timeoutMs / 1000, limits: LIMITS, asrModels: ASR_MODELS };
  });

  // 统一的任务入口：kind = generate | listen | asr | models | probe
  async function run(kind, p, onProgress, cfgOverride) {
    const cfg = { ...config(getSettings()), ...(cfgOverride || {}) };
    const id = String(p.id || Date.now());
    const job = { id };
    jobs.set(id, job);
    const t0 = Date.now();
    const tick = setInterval(() => onProgress({ id, stage: 'wait', elapsed: Math.round((Date.now() - t0) / 1000) }), 1000);
    try {
      if (kind === 'models') return { ok: true, ...(await listModels(cfg, job)) };
      if (kind === 'probe') return await probeAudio(cfg, job, String(p.model || cfg.audioModel));
      if (kind === 'listen') { onProgress({ id, stage: 'upload', bytes: Math.floor(String(p.wav || '').length * 3 / 4) }); return { ok: true, ...(await listen(cfg, job, String(p.wav || ''), String(p.brief || '').slice(0, 300))) }; }
      if (kind === 'asr') { onProgress({ id, stage: 'upload', bytes: p.bytes ? p.bytes.byteLength : 0 }); return { ok: true, ...(await transcribe(cfg, job, Buffer.from(p.bytes || []), p.name)) }; }
      if (kind === 'generate') {
        const input = {
          kind: p.kind === 'score' ? 'score' : 'audio', brief: String(p.brief || '').slice(0, 12000), listened: String(p.listened || '').slice(0, 1200),
          theme: String(p.theme || '').slice(0, 200), style: String(p.style || '').slice(0, 120), language: String(p.language || 'zh'), extra: String(p.extra || '').slice(0, 300), ichika: !!p.ichika,
        };
        if (!input.brief) throw new ApiError('还没有分析曲子');
        let last = 0;
        const r = await generate(cfg, job, input, ({ text, reasoning }) => {
          const now = Date.now();
          if (now - last > 120) { last = now; onProgress({ id, stage: 'stream', chars: text.length, reasoning, text, elapsed: Math.round((now - t0) / 1000) }); }
        });
        if (!r.text.trim()) throw new ApiError('模型没有返回歌词内容（可能只输出了思考过程或被截断），请换一个模型或重试');
        return { ok: true, text: r.text, finish: r.finish, model: cfg.model, seconds: Math.round((Date.now() - t0) / 1000) };
      }
      throw new ApiError('未知操作');
    } catch (e) {
      return { error: e.message || String(e), canceled: !!e.canceled, timeout: !!e.timeout, noKey: !!e.noKey, noModel: !!e.noModel, status: e.status || 0 };
    } finally { clearInterval(tick); jobs.delete(id); }
  }

  ipcMain.handle('lyrics-run', (e, { kind, payload } = {}) => {
    if (!fromWin(e)) return { error: '只能在写词窗口里使用' };
    return run(String(kind), payload || {}, (pr) => send('lyrics-progress', pr));
  });
  ipcMain.on('lyrics-cancel', (e, id) => {
    if (!fromWin(e)) return;
    const j = jobs.get(String(id));
    if (j && j.abort) j.abort(new ApiError('已取消', { canceled: true }));
  });
  // 设置窗口：读取模型列表、检测音频能力（用设置页里还没保存的值）
  ipcMain.handle('sf-models', (_e, v = {}) => run('models', {}, () => {}, { base: config({ sfBase: v.sfBase }).base, key: cleanKey(v.sfKey), timeoutMs: 30000 }));
  ipcMain.handle('sf-probe', (_e, v = {}) => run('probe', { model: v.model }, () => {}, { base: config({ sfBase: v.sfBase }).base, key: cleanKey(v.sfKey), timeoutMs: 60000 }));

  ipcMain.handle('lyrics-copy', (e, text) => { if (!fromWin(e)) return false; clipboard.writeText(String(text || '')); return true; });
  ipcMain.handle('lyrics-save', async (e, { name, text } = {}) => {
    if (!fromWin(e)) return { error: 'denied' };
    const safe = (String(name || '歌词').replace(/[\\/:*?"<>|\r\n]/g, '_').trim() || '歌词').slice(0, 60);
    const r = await dialog.showSaveDialog(win, { title: '保存歌词', defaultPath: safe + '.txt', filters: [{ name: '文本文件', extensions: ['txt'] }] });
    if (r.canceled || !r.filePath) return { canceled: true };
    fs.writeFileSync(r.filePath, '﻿' + String(text || '').replace(/\r?\n/g, '\r\n'), 'utf8');
    return { ok: true, path: r.filePath };
  });
  ipcMain.on('lyrics-open-settings', (e) => { if (fromWin(e)) openSettings(); });
  ipcMain.on('lyrics-done', (e, title) => {
    if (!fromWin(e)) return;
    sayLine(`歌词写好了${title ? '，《' + String(title).slice(0, 20) + '》' : ''}。……你看看，有不对的地方我再改。`, '歌詞、書けたよ。……見てみて。気になるところがあったら、直すからね。', 'smile', 'nod');
  });
  // 写词窗口里点“读取合成器当前作品”：向合成器窗口要当前的曲名和谱子
  ipcMain.handle('lyrics-synth-current', async (e) => {
    if (!fromWin(e)) return { error: 'denied' };
    const sw = getSynthWin();
    if (!sw || sw.isDestroyed()) return { error: '合成器没有打开。请先在右键菜单里打开合成器，写好或选好一首曲子。' };
    const reqId = 'r' + Date.now();
    return new Promise((resolve) => {
      const t = setTimeout(() => { ipcMain.removeListener('synth-current-reply', on); resolve({ error: '合成器没有回应' }); }, 4000);
      const on = (ev, v) => { if (ev.sender !== sw.webContents || !v || v.reqId !== reqId) return; clearTimeout(t); ipcMain.removeListener('synth-current-reply', on); resolve(v.data || { error: '合成器里没有作品' }); };
      ipcMain.on('synth-current-reply', on);
      sw.webContents.send('synth-get-current', reqId);
    });
  });

  return { open, _test: { config, buildMessages, friendly, run, readStream } };
};
module.exports.config = config;
module.exports.buildMessages = buildMessages;
module.exports.friendly = friendly;
module.exports.ASR_MODELS = ASR_MODELS;
