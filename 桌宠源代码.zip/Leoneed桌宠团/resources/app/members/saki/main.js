// 咲希桌宠主进程：透明置顶窗口、拖动、托盘菜单、提醒
const { app, BrowserWindow, ipcMain, screen, Menu, Tray, nativeImage, powerMonitor, session, shell, dialog } = require('electron');
const path = require('path');
const TEAM = global.__team || null, TEAM_ID = TEAM ? TEAM.loadingId : null;   // 桌宠团：当前加载的是哪个成员
const fs = require('fs');
const { Brain, DEFAULT_PERSONA } = require('./brain');
const llm = require('./llm');
const { Memory } = require('./memory');
const { Affection, BANDS } = require('./affection');
const { Dnd } = require('./dnd');
const { WindowRecovery, fitPosition } = require('./window-recovery');
const { SpeechContext } = require('./speech-context');
const screenLook = require('./screen');
require('./src/jianpu.js');               // 简谱解析（检查她写的谱子）
const Jianpu = globalThis.Jianpu;
const { Voice } = require('./voice');
const { PluginManager } = require('./plugins');   // 插件系统（plugins.js）
let plugins = null;
const { transcribe } = require('./asr');

if (!app.requestSingleInstanceLock()) { app.quit(); }

const SETTINGS_FILE = path.join(app.getPath('userData'), 'settings.json');
const DEFAULTS = {
  name: '',             // 她怎么称呼你（空 = 叫“你”；在设置里填）
  view: 'full',          // full 全身 / half 半身
  size: 'medium',        // small / medium / large
  water: 45,             // 喝水提醒间隔（分钟），0 = 关闭
  rest: 60,              // 休息提醒间隔（分钟），0 = 关闭
  sleepRemind: true,     // 23:30 以后提醒睡觉
  alwaysOnTop: true,
  autoStart: false,
  x: null, y: null,
  outfitMode: 'auto',
  customReminders: [],
  // 长期记忆（向量存储）：OpenAI 兼容的 /embeddings，默认硅基流动 BAAI/bge-m3
  memoryEnabled: true,
  embBase: 'https://api.siliconflow.cn/v1',
  embKey: '',            // 空 = 用语音识别的密钥
  embModel: 'BAAI/bge-m3',
  memoryTopK: 5,         // 每次最多想起几条
  // 好感（隐性变量，存在 affection.json，由聊天模型判断增减）和心情余韵
  affectionEnabled: true,
  affectionMaxStep: 3,   // 一次最多变多少
  affectionDayCap: 10,   // 一天最多累计变多少
  moodHalfLife: 20,      // 心情余韵的半衰期（分钟）
  // 主动说话
  idleTalk: 'normal',       // 待机时自言自语（固定台词）：off 关闭 / rare 很少 / normal 偶尔 / often 常常
  proactiveEnabled: true,
  proactiveRate: 'normal',  // rare 每小时约 0.5 次 / normal 约 1 次 / often 约 2 次（再按好感调整）
  dndFullscreen: true,      // 有程序全屏（游戏、视频、演示）时不主动说话
  quietNight: true,         // 1:30–7:00 不主动闲聊（凌晨一点那一句除外）
  nightcord: true,          // 凌晨一点你还在电脑前时，她说一句（设置项沿用 nightcord 这个名字）
  userBirthday: '',         // 你的生日 MM-DD
  anniversary: '',          // 纪念日 YYYY-MM-DD（你们在一起 / 认识的日子）
  // 看图（OpenAI 兼容 / Claude / Gemini 的视觉模型；默认硅基流动，模型留空会自动挑一个 Qwen VL）
  visionType: '',
  visionBase: 'https://api.siliconflow.cn/v1',
  visionKey: '',            // 空 = 用 embedding / 语音识别的密钥
  visionModel: '',
  // 看屏幕（默认关闭）：她主动开口时偶尔先看一眼你的屏幕；截图只在内存里，描述完就丢掉
  screenLook: false,
  screenLookFallback: false, // 原生失败时尝试兼容方式，默认关闭
  screenLookRate: 'sometimes',   // rarely 大约 5 次里 1 次 / sometimes 3 次里 1 次 / often 2 次里 1 次
  screenLookScope: 'screen',     // screen 整个屏幕 / window 只看当前窗口
  screenLookBlock: screenLook.DEFAULT_BLOCK,
  // 每天自动备份一次（不含密钥），保留 7 份
  autoBackup: true,   // 聊天里让她设的提醒：[{ id, at(毫秒时间戳), say, ja }]    // 衣服：auto 按时间（周一到周五 8:00–18:00 校服，周日 8:00–15:00 队服，其余常服）/ uniform 一直校服 / unit 一直队服 / casual 一直常服
  // 聊天（OpenAI 兼容 / Claude / Gemini，默认 DeepSeek）
  apiType: '',          // 空 = 按地址自动判断；openai / anthropic / gemini
  apiBase: 'https://api.deepseek.com',
  apiKey: '',
  model: 'deepseek-flash',
  persona: '',           // 空 = 用默认人设
  memoryTurns: 12,       // 记住最近几轮对话
  // 语音（MiniMax 语音合成，念日语）
  ttsEnabled: false,
  ttsBase: 'https://api.minimaxi.com',   // 国内平台；国际平台是 https://api.minimax.io
  ttsKey: '',
  ttsGroupId: '',        // 可选，部分账号需要
  ttsVoiceId: '',        // 你在 MiniMax 上做好的音色 ID
  ttsModel: 'speech-2.8-hd',
  ttsSpeed: 1,
  ttsEmotion: true,      // 语气跟着心情变
  jaName: '',            // 日语里怎么叫你（空 = 用中文称呼）
  showJa: true,          // 气泡里同时显示日语
  voiceFixed: true,      // 固定台词（摸头、提醒等）也配音
  volume: 0.9,
  muted: false,
  // 语音通话：语音识别（OpenAI 兼容的 /audio/transcriptions，默认硅基流动 SenseVoice）
  asrBase: 'https://api.siliconflow.cn',
  asrKey: '',
  asrModel: 'FunAudioLLM/SenseVoiceSmall',
  asrLang: '',           // 空 = 自动识别；也可以填 zh / ja
  vadSilenceMs: 900,     // 静音多久算说完一句
  vadMaxSec: 15,         // 一句最长录多久
  vadLevel: 'normal',    // 说话检测灵敏度：low / normal / high
  callShowJa: true,      // 通话字幕下面显示日语原文
  callStream: true,      // 边生成边说（流式）
  bargeIn: false,        // 她说话时你一开口就打断她（需要耳机或回声消除好的环境）
  callKaraoke: true,     // 日语字幕跟着念到的位置亮起来（需要配音服务给出逐字时间点）
  // 写词：硅基流动（SiliconFlow）。密钥、模型都由用户自己填写
  sfBase: 'https://api.siliconflow.cn/v1',
  sfKey: '',
  lyricsModel: '',          // 写词用的对话模型（设置里点“读取模型列表”选）
  lyricsAudioModel: '',     // 可选：能直接听音频的模型（官方文档只标注 Qwen3-Omni 系列支持音频输入）
  lyricsAsrModel: 'FunAudioLLM/SenseVoiceSmall',   // 识别原有歌词用
  lyricsTimeout: 180,       // 每次请求最多等多少秒
};
// 设置文件里的值不对（手改坏了、旧版本、损坏的备份）就退回默认值，不让程序启动失败
const ENUMS = {
  view: ['full', 'half'], size: ['small', 'medium', 'large'], outfitMode: ['auto', 'uniform', 'unit', 'casual'],
  proactiveRate: ['rare', 'normal', 'often'], idleTalk: ['off', 'rare', 'normal', 'often'], screenLookRate: ['rarely', 'sometimes', 'often'], screenLookScope: ['screen', 'window'], vadLevel: ['low', 'normal', 'high'], asrLang: ['', 'zh', 'ja', 'en'],
  apiType: ['', 'openai', 'anthropic', 'gemini'], visionType: ['', 'openai', 'anthropic', 'gemini'],
};
function sanitizeSettings(o) {
  const out = { ...DEFAULTS };
  if (!o || typeof o !== 'object' || Array.isArray(o)) return out;
  for (const [k, v] of Object.entries(o)) {
    if (!(k in DEFAULTS)) { out[k] = v; continue; }            // 不认识的键原样留着（以后的版本可能用到）
    const d = DEFAULTS[k];
    if (ENUMS[k]) { if (ENUMS[k].includes(v)) out[k] = v; continue; }
    if (d === null) { if (v === null || Number.isFinite(v)) out[k] = v; continue; }   // 窗口位置
    if (typeof d === 'number') { if (Number.isFinite(v)) out[k] = v; continue; }
    if (typeof d === 'boolean') { if (typeof v === 'boolean') out[k] = v; continue; }
    if (typeof d === 'string') { if (typeof v === 'string') out[k] = v; continue; }
    if (Array.isArray(d)) { if (Array.isArray(v)) out[k] = v; continue; }
  }
  if (Array.isArray(out.customReminders)) out.customReminders = out.customReminders.filter((x) => x && Number.isFinite(x.at) && typeof x.say === 'string');
  return out;
}
let settings = { ...DEFAULTS };
try { settings = sanitizeSettings(JSON.parse(fs.readFileSync(SETTINGS_FILE, 'utf8'))); } catch (e) {}
if (TEAM) Object.assign(settings, TEAM.sharedFor(TEAM_ID, settings));   // 桌宠团：密钥和模型用大家共用的那一份
function save() {
  if (TEAM) TEAM.onSave(TEAM_ID, settings);   // 桌宠团：共用的设置有改动就同步给其他成员
  try { fs.mkdirSync(path.dirname(SETTINGS_FILE), { recursive: true }); fs.writeFileSync(SETTINGS_FILE, JSON.stringify(settings, null, 2)); } catch (e) {}
}

const SIZES = {
  full: { small: [210, 440], medium: [260, 540], large: [320, 660] },
  half: { small: [240, 350], medium: [300, 440], large: [370, 540] },
};
const winSize0 = () => (SIZES[settings.view] || SIZES.full)[settings.size] || SIZES.full.medium;
// 桌宠团：头像模式时窗口只要放得下头像和气泡
const winSize = () => (settings.avatarMode ? [260, (typeof HEADROOM === 'number' ? HEADROOM : 0) + 92 + 180] : winSize0());

let win, tray, setWin, synthWin;
let windowRecovery = null;
let speechContext = null;
let isQuitting = false;
let petReady = false, petWantsVisible = true;
app.on('before-quit', () => { isQuitting = true; });

function hasPetWindow() { return !!win && !win.isDestroyed(); }
function petIsShown() { return hasPetWindow() && (petReady ? win.isVisible() : petWantsVisible); }
function refreshTrayMenu() {
  if (!isQuitting && tray && !tray.isDestroyed()) tray.setContextMenu(buildMenu());
}
function hidePetWindow() {
  petWantsVisible = false;
  drag = null;
  if (hasPetWindow()) win.hide();
  refreshTrayMenu();
}
function showPetWindow() {
  if (isQuitting) return null;
  if (!hasPetWindow()) createWindow();
  if (!hasPetWindow()) return null;
  petWantsVisible = true;
  repairPetPosition();
  if (win.isMinimized()) win.restore();
  if (petReady) win.showInactive();
  refreshTrayMenu();
  return win;
}


/* ---------- 时间和衣服 ---------- */
const OUTFIT_NAME = { uniform: '校服', unit: '队服', casual: '常服' };
const WEEK = ['日', '一', '二', '三', '四', '五', '六'];
// 按时间穿什么：周一到周五 8:00–18:00 校服；周日 8:00–15:00 队服（和 Leo/need 的大家练习）；其余时间常服
function outfitByTime(d = new Date()) {
  const wd = d.getDay(), h = d.getHours();
  if (wd >= 1 && wd <= 5 && h >= 8 && h < 18) return 'uniform';
  if (wd === 0 && h >= 8 && h < 15) return 'unit';
  return 'casual';
}
function currentOutfit() {
  return OUTFIT_NAME[settings.outfitMode] ? settings.outfitMode : outfitByTime();
}
let outfitNow = currentOutfit();
const pad2 = (n) => String(n).padStart(2, '0');
function partOfDay(h) {
  return h < 5 ? '凌晨' : h < 8 ? '早上' : h < 11 ? '上午' : h < 13 ? '中午' : h < 17 ? '下午' : h < 19 ? '傍晚' : h < 23 ? '晚上' : '深夜';
}
// 每条消息末尾附上的“此刻”：时间、星期、她穿着什么（只加在末尾，前面的人设和历史不变，缓存不受影响）
function envLine() {
  const d = new Date(), wd = d.getDay();
  const day = wd === 0 || wd === 6 ? '，休息日' : '';
  return `此刻：${d.getFullYear()}年${d.getMonth() + 1}月${d.getDate()}日 星期${WEEK[wd]}${day} ${pad2(d.getHours())}:${pad2(d.getMinutes())}（${partOfDay(d.getHours())}）；你穿着${OUTFIT_NAME[outfitNow]}`;
}
// 衣服该换了：通知桌宠换模型，并记一笔，下一次对话时告诉她
function checkOutfit(manual = false) {
  const o = currentOutfit();
  if (o === outfitNow) return;
  const prev = outfitNow;
  outfitNow = o;
  const d = new Date(), t = `${pad2(d.getHours())}:${pad2(d.getMinutes())}`;
  const why = manual ? `${settings.name || '对方'}让你换的`
    : o === 'uniform' ? '要去学校了'
    : o === 'unit' ? '星期天，要和 Leo/need 的大家一起练习'
    : prev === 'uniform' ? '放学了' : prev === 'unit' ? '练习结束了' : '换上了平时的衣服';
  if (brain) brain.note(`${t} 你把${OUTFIT_NAME[prev]}换成了${OUTFIT_NAME[o]}（${why}）`);
  if (win) win.webContents.send('outfit', { outfit: o, manual });
}
setInterval(() => checkOutfit(false), 30000);
let brain, voice, memory, affection;
// 发给桌宠页面的设置里不带密钥和人设
const voiceOn = () => !!(settings.ttsEnabled && settings.ttsKey && settings.ttsVoiceId);
const publicSettings = () => {
  const { apiKey, persona, ttsKey, asrKey, embKey, visionKey, sfKey, ...rest } = settings;
  return { ...rest, teamMode: !!TEAM, hasApi: llm.hasChatApi(settings), outfit: outfitNow, hasVoice: voiceOn(), hasAsr: !!asrKey, winH: winSize()[1] };
};

// 窗口位置：字幕始终使用预留透明空间；显隐不再移动或缩放原生窗口。
const BUBBLE_HEADROOM = 400;
let base = { x: 0, y: 0 };
function windowBounds() {
  const [w, h] = winSize();
  const d = screen.getDisplayMatching({ x: base.x, y: base.y, width: w, height: h }).workArea;
  const e = Math.max(0, Math.min(BUBBLE_HEADROOM, base.y - d.y));
  return { x: Math.round(base.x), y: Math.round(base.y - e), width: w, height: h + e };
}
function placeWindow() {
  if (!win) return;
  const bounds = windowBounds(), old = win.getBounds();
  if (['x', 'y', 'width', 'height'].some(k => bounds[k] !== old[k])) win.setBounds(bounds);
  if (win.webContents) win.webContents.send('extra', bounds.height - winSize()[1]);
}

// 游戏切换分辨率/显示器后，校正人物本身的位置；正常位置不会移动。
function repairPetPosition() {
  if (!win || win.isDestroyed()) return;
  const fixed = fitPosition(base, winSize(), screen.getAllDisplays(), screen.getPrimaryDisplay());
  if (fixed.x !== base.x || fixed.y !== base.y) {
    base = fixed; settings.x = fixed.x; settings.y = fixed.y; save();
  }
  placeWindow();
}
function recoverPetDisplay() {
  if (isQuitting) return;
  if (!hasPetWindow()) showPetWindow();
  else if (windowRecovery) windowRecovery.reload('托盘恢复显示', true);
  refreshTrayMenu();
}
// 只接受当前桌宠页面实际显示/开始播放的发言。
ipcMain.on('pet-spoken', (e, entry) => {
  if (!win || win.isDestroyed() || e.sender !== win.webContents || !speechContext) return;
  speechContext.record(entry);
});
ipcMain.on('render-health', (e, state) => {
  if (win && e.sender === win.webContents && windowRecovery) windowRecovery.renderState(state);
});
app.on('child-process-gone', (_e, details) => { if (windowRecovery) windowRecovery.gpuGone(details); });

function createWindow() {
  if (isQuitting || hasPetWindow()) return;
  petReady = false; petWantsVisible = true;
  const [w, h] = winSize();
  const wa = screen.getPrimaryDisplay().workArea;
  let x = settings.x, y = settings.y;
  // 第一次启动放在屏幕右下角；保存的位置跑到屏幕外就重新放
  const onScreen = x !== null && screen.getAllDisplays().some((d) => {
    const b = d.workArea; return x + w / 2 > b.x && x + w / 2 < b.x + b.width && y + h / 2 > b.y && y + h / 2 < b.y + b.height;
  });
  if (!onScreen) { x = wa.x + wa.width - w - 40; y = wa.y + wa.height - h; }
  base = { x, y };

  win = new BrowserWindow({
    ...windowBounds(),
    transparent: true, frame: false, resizable: false, hasShadow: false,
    backgroundColor: '#00000000', skipTaskbar: true, maximizable: false, fullscreenable: false,
    alwaysOnTop: settings.alwaysOnTop, show: false, title: '咲希',
    icon: path.join(__dirname, 'icon.png'),
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, backgroundThrottling: false, autoplayPolicy: 'no-user-gesture-required' },
  });
  win.setIgnoreMouseEvents(true, { forward: true });
  win.loadFile(path.join(__dirname, 'src', 'index.html'));
  // 页面退出、WebGL/GPU 异常和显示模式变化统一恢复，避免多个事件反复重载。
  const recoveryLog = (why) => { try { fs.appendFileSync(path.join(app.getPath('userData'), 'window-recovery.log'), new Date().toISOString() + ' ' + why + '\n'); } catch (e) {} };
  windowRecovery = new WindowRecovery({
    win, screen, settings: () => settings, repairPosition: repairPetPosition,
    cancelDrag: () => { drag = null; }, log: recoveryLog,
  });
  const petWin = win;
  // 普通关闭（包括 Alt+F4）只隐藏；托盘退出和系统结束会话允许销毁。
  petWin.on('session-end', () => { isQuitting = true; });
  petWin.on('close', (e) => {
    if (isQuitting) return;
    e.preventDefault();
    if (windowRecovery) windowRecovery.record('关闭请求转为隐藏');
    hidePetWindow();
  });
  for (const event of ['show', 'hide', 'minimize', 'restore']) petWin.on(event, () => {
    if (win !== petWin) return;
    if (event === 'show') petWantsVisible = true;
    if (event === 'hide') petWantsVisible = false;
    refreshTrayMenu();
  });
  petWin.once('ready-to-show', () => {
    if (win !== petWin || petWin.isDestroyed() || isQuitting) return;
    petReady = true;
    if (petWantsVisible) petWin.showInactive();
    refreshTrayMenu();
  });

  // 每个窗口只保留一个鼠标定时器；销毁时清理，避免重建后叠加。
  const cursorTimer = setInterval(() => {
    if (petWin.isDestroyed() || !petWin.isVisible() || petWin.webContents.isCrashed() || petWin.webContents.isLoading()) return;
    const c = screen.getCursorScreenPoint();
    const b = petWin.getBounds();
    try { petWin.webContents.send('cursor', { x: c.x - b.x, y: c.y - b.y }); } catch (e) {}
  }, 33);
  petWin.on('closed', () => {
    clearInterval(cursorTimer);
    if (win !== petWin) return;
    win = null; windowRecovery = null; petReady = false; petWantsVisible = false; drag = null;
    refreshTrayMenu();
  });
  // 首次启动由 startPlugins 连接；仅重建窗口时复用现有插件管理器。
  if (plugins) plugins.attachWindow(petWin);
  refreshTrayMenu();
}

/* ---------- 拖动 ---------- */
let drag = null;
ipcMain.on('drag-start', () => {
  if (!win) return;
  const c = screen.getCursorScreenPoint();
  drag = { cx: c.x, cy: c.y, bx: base.x, by: base.y };
});
ipcMain.on('drag-move', () => {
  if (!win || !drag) return;
  const c = screen.getCursorScreenPoint();
  base = { x: drag.bx + c.x - drag.cx, y: drag.by + c.y - drag.cy };
  placeWindow();
});
ipcMain.on('drag-end', () => {
  drag = null;
  if (!win) return;
  repairPetPosition();
  settings.x = Math.round(base.x); settings.y = Math.round(base.y);
  save();
});
// 气泡需要更多空间时，窗口往上长；气泡收起后缩回
// 保留旧页面的消息接口；字幕不再改变窗口边界。
ipcMain.on('bubble-space', () => {});
ipcMain.on('set-ignore', (_e, v) => { if (win) win.setIgnoreMouseEvents(v, { forward: true }); });
ipcMain.handle('get-settings', () => publicSettings());
// 聊天：模型回中文台词 + 日语；开了语音就再交给 MiniMax 念日语
let lastLists = null;   // 桌宠最近一次发来的心情、动作、表情列表（主进程自己发起对话时用）
async function handleChat(payload, context = {}) {
  const historyEpoch = brain.historyEpoch, memoryEpoch = context.memoryEpoch ?? (memory ? memory.epoch('memory') : 0);
  if (payload.moods) lastLists = { moods: payload.moods, actions: payload.actions, faces: payload.faces };
  const on = voiceOn();
  let text = payload.text;
  if (payload.proactive) {
    // 她主动开口：告诉她为什么、这不是对方说的话；她觉得不用说也可以不说
    const name = settings.name || '你';
    text = `（系统：${String(payload.text).replace(/\{name\}/g, name)}。这不是${name}说的话。你可以主动对ta说一句，简短自然，像私下随口一说；不要总是问ta在做什么。如果觉得现在不说话更好，reply 写空字符串。）`;
  } else lastUserChat = Date.now();
  // 插件：可以改写你发的话，或者直接代替模型回答（e.cancel）
  if (plugins && !payload.proactive) {
    const pe = await plugins.filterChat(text, { image: !!context.image });
    if (pe.cancel) {
      const pr = { reply: String(pe.reply || '……').slice(0, 500), ja: String(pe.ja || ''), mood: String(pe.mood || 'calm'), action: String(pe.action || 'none'), plugin: true };
      plugins.emit('chat:reply', { input: text, reply: pr.reply, ja: pr.ja, mood: pr.mood, proactive: false, plugin: true });
      return pr;
    }
    text = pe.text;
  }
  const recall = memory ? await memory.recall(payload.proactive ? payload.text : text) : '';
  if (historyEpoch !== brain.historyEpoch) return { error: 'aborted' };
  const r = await brain.chat(settings, { ...payload, text, recall, withJa: on });
  if (historyEpoch !== brain.historyEpoch) return { error: 'aborted' };
  if (payload.proactive && r && r.reply) { pro.lastAt = Date.now(); pro.count++; saveProactive(); }
  if (r && r.remember && r.remember.length) memory.remember(r.remember, { epoch: memoryEpoch }).then((a) => a.length && notifyMemory(a));
  if (on && r && r.reply && !settings.muted) {
    if (r.ja) {
      const v = await voice.speak(settings, r.ja, r.mood);
      if (v.audio) r.audio = v.audio; else r.voiceError = v.error;
    } else r.voiceError = r.voiceError || '这次回复没有日语';
  }
  if (historyEpoch !== brain.historyEpoch) return { error: 'aborted' };
  afterReply(r, '聊天');
  if (r && r.do && r.do.length) runActions(r.do, { delay: Math.min(4000, 1200 + (r.reply || '').length * 120), allowLook: !payload.proactive });
  if (plugins) plugins.emit('chat:reply', { input: payload.proactive ? '' : text, reply: (r && r.reply) || '', ja: (r && r.ja) || '', mood: (r && r.mood) || '', error: (r && r.error) || '', proactive: !!payload.proactive });
  return r;
}
ipcMain.handle('chat', async (_e, payload) => {
  const r = await handleChat(payload);
  // 桌宠团：单独和她说话时，其他成员可能会插一两句
  if (TEAM && payload && !payload.proactive && r && r.reply && !r.error) TEAM.afterDirect(TEAM_ID, String(payload.text || ''), r);
  return r;
});

/* ---------- 看图：先让视觉模型描述图片，再把描述当成文字交给她 ---------- */
function visionCfg() {
  const base = String(settings.visionBase || DEFAULTS.visionBase).trim();
  const keyLabel = settings.visionKey ? '看图 API 密钥' : settings.embKey ? '长期记忆的 embedding 密钥（看图借用了它）' : '语音识别 API 密钥（看图借用了它）';
  return { apiType: settings.visionType || '', apiBase: base, apiKey: String(settings.visionKey || settings.embKey || settings.asrKey || '').trim(), keyLabel, model: String(settings.visionModel || '').trim(), temperature: 0.3 };
}
// 没填看图模型：从平台的模型列表里挑一个 Qwen VL 的 Instruct 模型（大的优先）
async function pickVisionModel(v) {
  const r = await llm.listModels(v);
  if (!r.models) return null;
  const vl = r.models.filter((m) => /vl/i.test(m) && !/thinking/i.test(m));
  const score = (m) => (/qwen3/i.test(m) ? 1000 : /qwen2\.5/i.test(m) ? 500 : /qwen/i.test(m) ? 100 : 0) + (/instruct/i.test(m) ? 50 : 0) + (+((m.match(/(\d+)b/i) || [])[1] || 0)) / 10;
  vl.sort((a, b) => score(b) - score(a));
  return vl[0] || null;
}
ipcMain.handle('chat-image', async (_e, { b64, mime, ...payload }) => {
  const historyEpoch = brain.historyEpoch, memoryEpoch = memory ? memory.epoch('memory') : 0;
  const v = visionCfg();
  if (!v.apiKey && !llm.isLocal(v.apiBase)) return { error: '还没设置看图用的模型（右键 → 设置 → 看图）' };
  { const ki = llm.keyIssue(v.apiKey, v.keyLabel); if (ki) return { error: ki }; }
  if (!v.model) {
    const m = await pickVisionModel(v).catch(() => null);
    if (!m) return { error: '没找到能看图的模型，请在设置 → 看图 里填模型名' };
    settings.visionModel = m; save(); v.model = m;
  }
  const d = await llm.describeImage(v, { b64, mime, hint: payload.text || '' }).catch((e) => ({ error: e.message }));
  if (d.error) return { error: '看不了这张图：' + d.error };
  const name = settings.name || '你';
  const text = `${payload.text ? payload.text + '\n' : ''}（${name}发来一张图片。图片的内容：${d.text}）`;
  if (historyEpoch !== brain.historyEpoch) return { error: 'aborted' };
  const r = await handleChat({ ...payload, text }, { memoryEpoch, image: true });
  if (r) r.imageDesc = d.text;
  return r;
});
// 每次回复之后：好感按模型的判断变化，心情留下余韵
function afterReply(r, source) {
  if (!r || r.error || !affection) return;
  const ch = r.affection ? affection.apply(r.affection, source) : null;
  affection.feel(r.mood, r.intensity);
  sendLingering();
  if (ch && affWin) affWin.webContents.send('aff-changed');
}
function sendLingering() { if (win && affection) win.webContents.send('lingering', affection.lingering()); }
setInterval(sendLingering, 60000);

/* ---------- 看一眼屏幕 ---------- */
let lastLook = null;   // { at, ok, what, desc } 或 { at, skip }，设置页显示用
let lookBusy = false;
async function lookAtScreen(options = {}) {
  if (lookBusy) return { skip: '正在看屏幕，请稍后再试' };
  lookBusy = true;
  try { return await performScreenLook(options); }
  finally { lookBusy = false; }
}
async function performScreenLook({ force = false } = {}) {
  const done = (o) => { lastLook = { at: Date.now(), ...o }; if (setWin) setWin.webContents.send('look-status', lookStatus()); return o; };
  if (!force && !settings.screenLook) return done({ skip: '看屏幕没有打开' });
  const fg = dnd ? dnd.foreground() : null;
  if (fg && fg.self) return done({ skip: '前台是桌宠自己的窗口（先点一下你想让她看的窗口）' });
  const hit = screenLook.blockedBy(fg, settings.screenLookBlock);
  if (hit) return done({ skip: `前台程序在“不看”名单里（${hit}）` });
  const v = visionCfg();
  { const ki = llm.keyIssue(v.apiKey, v.keyLabel); if (ki) return done({ error: ki }); }
  if (!v.apiKey && !llm.isLocal(v.apiBase)) return done({ error: '还没设置看图用的模型' });
  if (!v.model) { const m = await pickVisionModel(v).catch(() => null); if (!m) return done({ error: '没找到能看图的模型' }); settings.visionModel = m; save(); v.model = m; }
  let shot;
  try { shot = await screenLook.capture({ scope: settings.screenLookScope, petWin: win, fgRect: fg ? fg.rect : null, allowLegacyFallback: settings.screenLookFallback === true }); }
  catch (e) { return done({ error: '截图失败：' + e.message }); }
  const what = shot.what;
  const d = await llm.describeImage(v, { b64: shot.b64, mime: shot.mime, system: screenLook.LOOK_PROMPT }).catch((e) => ({ error: e.message }));
  shot = null;   // 截图不留，描述完就丢掉
  if (d.error) return done({ error: '看不清：' + d.error });
  return done({ ok: true, what, desc: d.text });
}
function lookStatus() {
  const l = lastLook;
  if (!l) return '还没看过。';
  const t = new Date(l.at), hm2 = `${pad2(t.getHours())}:${pad2(t.getMinutes())}`;
  return l.ok ? `${hm2} 看了一眼，看到：${l.desc}` : l.skip ? `${hm2} 没看：${l.skip}` : `${hm2} 没看成：${l.error}`;
}
ipcMain.handle('look-now', async () => {
  const r = await lookAtScreen({ force: true });
  if (r.ok) sayLooked(r, true);
  return { status: r.skip || lookStatus(), ...r };
});
const LOOK_RATE = { rarely: 0.2, sometimes: 0.34, often: 0.5 };
// 看完以后让她说一句。asked = 是你让她看的（直接说，不排队）
async function sayLooked(r, asked) {
  const name = settings.name || '你';
  r = { ...r, desc: String(r.desc).trim().replace(/[。.！!]+$/, '') };
  const reason = asked
    ? `${name}让你看看ta的屏幕。你看了一眼（${r.what}），看到：${r.desc}。对ta正在做的事说一句，简短自然，别逐条复述屏幕内容`
    : `你看了一眼${name}的屏幕（${r.what}），看到：${r.desc}。想说就对ta正在做的事随口说一句，简短自然，别逐条复述屏幕内容；觉得没什么好说就不说`;
  if (!asked) return win && win.webContents.send('proactive', { reason, kind: 'look', id: ++proSeq, looked: true });
  const out = await handleChat({ text: reason, proactive: true, ...(lastLists || {}) });
  if (win && out && out.reply) win.webContents.send('ai-say', { t: out.reply, ja: out.ja, m: out.mood, a: out.action, intensity: out.intensity, audio: out.audio, tag: '看了一眼屏幕' });
}

/* ---------- 主动说话 ---------- */
let dnd = null;
let lastUserChat = 0;
const PRO_FILE = () => path.join(app.getPath('userData'), 'proactive.json');
let pro = { lastAt: 0, day: '', count: 0, fired: {} };
function loadProactive() { try { pro = { ...pro, ...JSON.parse(fs.readFileSync(PRO_FILE(), 'utf8')) }; } catch (e) {} }
function saveProactive() { try { fs.writeFileSync(PRO_FILE(), JSON.stringify(pro)); } catch (e) {} }
const dayKey = (d = new Date()) => `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
const RATE = { rare: 0.5, normal: 1, often: 2 };
const BAND_FACTOR = [0.3, 0.6, 1, 1.3, 1.6];        // 疏远 / 别扭 / 平常 / 亲近 / 依赖
const IDLE_REASONS = [
  '你忽然想和{name}说句话',
  '你在想{name}现在在做什么，但不一定要问出来',
  '你想起了之前和{name}聊过的某件事',
  '你刚才在想一件自己的事（学校、键盘练习、可爱的东西、想去的店、初音未来的新歌、Leo/need 的大家、哥哥……），想说给{name}听',
  '你只是想确认{name}还好',
  '你注意到窗外的天色或天气，想说一句',
];
let activeSince = Date.now(), awaySince = 0;
let proSeq = 0, inflight = null;     // 正在送给桌宠的特别事件
// 桌宠回报：done = 说出来了（或她决定不说），busy / failed = 没送到，之后再试
ipcMain.on('proactive-done', (_e, { id, status }) => {
  if (!inflight || inflight.id !== id) return;
  const { key, day } = inflight;
  inflight = null;
  if (status !== 'done') return;
  pro.fired[day + ':' + key] = 1;
  const old = dayKey(new Date(Date.now() - 7 * 86400000));
  for (const k of Object.keys(pro.fired)) if (k.slice(0, 10) < old) delete pro.fired[k];   // 只保留最近几天的记录
  saveProactive();
});
let idleTime = () => powerMonitor.getSystemIdleTime();   // 测试时可以换掉
let nowDate = () => new Date();

// 今天有没有纪念日：返回 { key, reason, line }
function todaysEvent(now) {
  const md = `${pad2(now.getMonth() + 1)}-${pad2(now.getDate())}`;
  if (md === '05-09') return { key: 'bday-saki', reason: '今天 5 月 9 日，是你自己的生日。你很期待被祝贺，更开心今年{name}也在身边', line: 'birthdaySaki' };
  if (/^\d{2}-\d{2}$/.test(settings.userBirthday || '') && settings.userBirthday === md) return { key: 'bday-user', reason: '今天是{name}的生日。你想对ta说生日快乐（用你自己的方式）', line: 'birthdayUser' };
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(settings.anniversary || '');
  if (m) {
    const start = new Date(+m[1], +m[2] - 1, +m[3]);
    const days = Math.round((new Date(now.getFullYear(), now.getMonth(), now.getDate()) - start) / 86400000) + 1;
    const years = now.getFullYear() - start.getFullYear();
    if (days > 1 && `${m[2]}-${m[3]}` === md && years > 0) return { key: 'anniv', reason: `今天是你和{name}在一起满 ${years} 年的纪念日`, line: 'anniversary' };
    if (days > 1 && days % 100 === 0) return { key: 'anniv', reason: `今天是你和{name}在一起的第 ${days} 天`, line: 'anniversary' };
  }
  return null;
}

function proactiveTick() {
  if (!win || !win.isVisible()) return;
  const now = nowDate(), t = Date.now();
  const idleSec = idleTime();
  // 离开 / 回来：记下来，下次聊天她知道
  if (idleSec > 1200) { if (!awaySince) awaySince = t - idleSec * 1000; return; }
  if (awaySince && idleSec < 60) {
    const mins = Math.round((t - awaySince) / 60000);
    if (mins >= 20 && brain) brain.note(`${pad2(now.getHours())}:${pad2(now.getMinutes())} ${settings.name || '对方'}离开了大约 ${mins} 分钟，刚回到电脑前`);
    awaySince = 0; activeSince = t;
  }
  if (!settings.proactiveEnabled) return;
  if (idleSec > 120) return;                                     // 人不在电脑前
  if (settings.dndFullscreen && dnd && dnd.busy()) return;       // 有程序全屏
  if (pro.day !== dayKey(now)) { pro.day = dayKey(now); pro.count = 0; saveProactive(); }
  const hasApi = llm.hasChatApi(settings);
  // 生日、纪念日、凌晨一点：发给桌宠后先记成“正在送”，等桌宠回报真的说出来了，才记成今天已经说过。
  // 桌宠在忙（聊天框开着、通话、拖动、打瞌睡……）会回报“忙”，下一分钟再试；3 分钟没回音也重试
  const fire = (key, reason, line) => {
    if (inflight && inflight.key === key && t - inflight.at < 180000) return;
    const id = ++proSeq;
    inflight = { key, id, at: t, day: dayKey(now) };
    win.webContents.send('proactive', { reason, kind: key, id, line: hasApi ? null : line });
  };
  const done = (key) => pro.fired[dayKey(now) + ':' + key];
  const h = now.getHours(), mi = now.getMinutes();

  // 纪念日：早上 7 点以后，你第一次在电脑前时
  const ev = todaysEvent(now);
  if (ev && h >= 7 && !done(ev.key)) return fire(ev.key, ev.reason, ev.line);
  // 凌晨一点：1:00–1:30 你还在电脑前
  if (settings.nightcord && h === 1 && mi < 30 && !done('nightcord')) {
    return fire('nightcord', '现在是凌晨一点了，{name}这个时间还在电脑前。你有点担心ta，想温柔地提醒一句', 'nightcord');
  }
  // 平时的闲聊（需要聊天模型）
  if (!hasApi) return;
  if (settings.quietNight && ((h === 1 && mi >= 30) || (h >= 2 && h < 7))) return;   // 夜里安静（凌晨一点那一句除外）
  if (t - pro.lastAt < 25 * 60000 || t - lastUserChat < 10 * 60000) return;   // 刚说过话、或者正在聊，就不插话
  if (pro.count >= 10) return;
  const band = BANDS.slice().reverse().findIndex((b) => affection.state.value >= b.min);
  const factor = BAND_FACTOR[BANDS.length - 1 - band] ?? 1;
  const perHour = (RATE[settings.proactiveRate] || 1) * factor;
  if (Math.random() > perHour / 60) return;
  let reason = IDLE_REASONS[Math.floor(Math.random() * IDLE_REASONS.length)];
  const activeMin = Math.round((t - activeSince) / 60000);
  if (activeMin >= 90) reason += `；{name}已经连续在电脑前 ${activeMin} 分钟了`;
  pro.lastAt = t;   // 先占住，避免下一分钟又触发
  saveProactive();
  // 开了“看屏幕”：偶尔先看一眼再说；看不成（名单里、出错）就照常说
  if (settings.screenLook && Math.random() < (LOOK_RATE[settings.screenLookRate] || 0.34)) {
    lookAtScreen().then((r) => (r.ok ? sayLooked(r, false) : win.webContents.send('proactive', { reason, kind: 'idle', id: ++proSeq })));
    return;
  }
  win.webContents.send('proactive', { reason, kind: 'idle', id: ++proSeq });
}

/* ---------- 语音通话：每一轮请求都带编号，可以随时取消 ---------- */
const turnCtrls = new Map();   // 轮次编号 → [AbortController...]
const cancelledKeys = [];      // 已经取消的通话 / 轮次：之后再要信号，直接给已取消的
const isCancelled = (key) => cancelledKeys.some((k) => key === k || key.startsWith(k + ':'));
function turnSignal(key) {
  const c = new AbortController();
  if (isCancelled(key)) { c.abort(); return c.signal; }
  if (!turnCtrls.has(key)) turnCtrls.set(key, []);
  turnCtrls.get(key).push(c);
  return c.signal;
}
ipcMain.on('call-cancel', (_e, key) => {
  // key 是前缀：取消一整个通话（callId）或某一轮（callId:turnId）
  cancelledKeys.push(key); if (cancelledKeys.length > 200) cancelledKeys.shift();
  for (const [k, list] of turnCtrls) if (k === key || k.startsWith(key + ':')) { list.forEach((c) => c.abort()); turnCtrls.delete(k); }
});
ipcMain.handle('call-asr', async (_e, { wav, key }) => {
  const r = await transcribe(settings, Buffer.from(wav), turnSignal(key));
  return r;
});
ipcMain.handle('call-turn', async (e, { key, ...payload }) => {
  const historyEpoch = brain.historyEpoch, memoryEpoch = memory ? memory.epoch('memory') : 0;
  if (!llm.hasChatApi(settings)) return { error: 'noapi' };
  // 流式：心情/动作和每一句一写完就转给桌宠，不等整段回复
  const send = (type, data) => { try { e.sender.send('call-stream', { key, type, data }); } catch (err) {} };
  // 这一轮的取消信号要在第一次等待之前就拿到：检索记忆期间挂断、打断，也能取消到这一轮
  const signal = turnSignal(key);
  const recall = memory ? await memory.recall(payload.text, { timeout: 1500 }) : '';
  if (signal.aborted || historyEpoch !== brain.historyEpoch) return { error: 'aborted' };
  const r = await brain.chat(settings, {
    ...payload, recall, mode: 'call', signal, turnKey: key,
    onMeta: (m) => send('meta', m), onSegment: (g) => send('seg', g),
  });
  // 已经取消的轮次：不执行动作、不记记忆、不动好感
  if (historyEpoch !== brain.historyEpoch) return { error: 'aborted' };
  if (signal.aborted || !r || r.error) return r;
  if (r.do && r.do.length) runActions(r.do.filter((a) => a.cmd !== 'call'), { delay: 2500, inCall: true });
  if (r.remember && r.remember.length) memory.remember(r.remember, { epoch: memoryEpoch }).then((a) => a.length && notifyMemory(a));
  afterReply(r, '通话');
  return r;
});
ipcMain.handle('call-tts', async (_e, { key, ja, mood }) => {
  if (!voiceOn()) return { error: 'novoice' };
  return voice.speak(settings, ja, mood, turnSignal(key), { words: settings.callKaraoke !== false });
});
ipcMain.handle('call-interrupted', (_e, { heard, total, key }) => brain.markInterrupted(heard, total, key));
// 只记录各环节耗时（不记录内容和录音），用来找延迟出在哪
ipcMain.on('call-debug', (_e, line) => {
  try { fs.appendFileSync(path.join(app.getPath('userData'), 'call-debug.log'), new Date().toISOString() + ' ' + String(line).slice(0, 400) + '\n'); } catch (e) {}
});
ipcMain.on('call-timing', (_e, line) => {
  try { fs.appendFileSync(path.join(app.getPath('userData'), 'call-timing.log'), new Date().toISOString() + ' ' + String(line).slice(0, 300) + '\n'); } catch (e) {}
});

// 固定台词配音（有缓存）
ipcMain.handle('speak', (_e, { ja, mood }) => (voiceOn() && settings.voiceFixed && !settings.muted ? voice.speak(settings, ja, mood) : { error: 'off' }));
ipcMain.on('focus', () => { if (win) { win.setIgnoreMouseEvents(false); win.focus(); } });
ipcMain.on('show-menu', () => buildMenu().popup({ window: win }));

function applySettings() {
  save();
  if (plugins) plugins.emit('settings:changed', publicSettings());
  if (settings.screenLook) void screenLook.prepare();
  else screenLook.stop();
  if (!win) return;
  // 改大小时让脚底位置保持不动
  const [w, h] = winSize();
  const b = win.getBounds();
  base = { x: Math.round(b.x + (b.width - w) / 2), y: b.y + b.height - h };
  repairPetPosition();
  settings.x = base.x; settings.y = base.y; save();
  win.setAlwaysOnTop(settings.alwaysOnTop);
  win.webContents.send('settings', publicSettings());
  if (tray) tray.setContextMenu(buildMenu());
}

/* ---------- 设置窗口（称呼、聊天 API、人设） ---------- */
function openSettings() {
  if (setWin) { setWin.focus(); return; }
  setWin = new BrowserWindow({
    width: 520, height: 680, minWidth: 420, minHeight: 520, title: '咲希桌宠 · 设置',
    icon: path.join(__dirname, 'icon.png'), autoHideMenuBar: true, backgroundColor: '#fcf8ed',
    webPreferences: { preload: path.join(__dirname, 'preload-settings.js'), contextIsolation: true },
  });
  setWin.loadFile(path.join(__dirname, 'src', 'settings.html'));
  setWin.on('closed', () => { setWin = null; });
}
const VOICE_FIELDS = ['ttsEnabled', 'ttsBase', 'ttsKey', 'ttsGroupId', 'ttsVoiceId', 'ttsModel', 'ttsSpeed', 'ttsEmotion', 'jaName', 'showJa', 'voiceFixed', 'volume',
  'asrBase', 'asrKey', 'asrModel', 'asrLang', 'vadSilenceMs', 'vadMaxSec', 'vadLevel', 'callShowJa', 'callStream', 'bargeIn', 'callKaraoke'];
ipcMain.handle('settings-get', () => ({
  name: settings.name, apiType: settings.apiType || '', apiBase: settings.apiBase, apiKey: settings.apiKey, model: settings.model,
  persona: settings.persona || DEFAULT_PERSONA, memoryTurns: settings.memoryTurns,
  ...Object.fromEntries(VOICE_FIELDS.map((k) => [k, settings[k]])),
  memoryEnabled: settings.memoryEnabled !== false, embBase: settings.embBase, embKey: settings.embKey, embModel: settings.embModel, memoryTopK: settings.memoryTopK,
  memoryStats: memory ? memory.stats() : null,
  idleTalk: settings.idleTalk, proactiveEnabled: settings.proactiveEnabled !== false, proactiveRate: settings.proactiveRate, dndFullscreen: settings.dndFullscreen !== false,
  quietNight: settings.quietNight !== false, nightcord: settings.nightcord !== false, userBirthday: settings.userBirthday || '', anniversary: settings.anniversary || '',
  dndStatus: dnd ? dnd.describe() : '',
  screenLook: !!settings.screenLook, screenLookFallback: settings.screenLookFallback === true, screenLookRate: settings.screenLookRate, screenLookScope: settings.screenLookScope, screenLookBlock: settings.screenLookBlock, lookStatus: lookStatus(),
  visionType: settings.visionType || '', visionBase: settings.visionBase, visionKey: settings.visionKey, visionModel: settings.visionModel, autoBackup: settings.autoBackup !== false,
  sfBase: settings.sfBase, sfKey: settings.sfKey, lyricsModel: settings.lyricsModel, lyricsAudioModel: settings.lyricsAudioModel, lyricsAsrModel: settings.lyricsAsrModel, lyricsTimeout: settings.lyricsTimeout,
  defaultPersona: DEFAULT_PERSONA, historyCount: brain.history.length / 2,
}));
ipcMain.handle('settings-save', (_e, v) => {
  settings.name = String(v.name || '').trim().slice(0, 12) || settings.name;
  settings.apiBase = String(v.apiBase || '').trim() || DEFAULTS.apiBase;
  settings.apiKey = llm.cleanKey(v.apiKey);
  settings.apiType = ['openai', 'anthropic', 'gemini'].includes(v.apiType) ? v.apiType : '';
  // 模型名留空时：DeepSeek 用默认的，其他平台就保持空（发消息时会提示去填）
  settings.model = String(v.model || '').trim() || (/deepseek/i.test(settings.apiBase) ? DEFAULTS.model : '');
  settings.persona = v.persona && v.persona.trim() !== DEFAULT_PERSONA.trim() ? v.persona : '';
  settings.memoryTurns = Math.max(0, Math.min(50, parseInt(v.memoryTurns, 10) || 0));
  settings.ttsEnabled = !!v.ttsEnabled;
  settings.ttsBase = String(v.ttsBase || '').trim() || DEFAULTS.ttsBase;
  settings.ttsKey = llm.cleanKey(v.ttsKey);
  settings.ttsGroupId = String(v.ttsGroupId || '').trim();
  settings.ttsVoiceId = String(v.ttsVoiceId || '').trim();
  settings.ttsModel = String(v.ttsModel || '').trim() || DEFAULTS.ttsModel;
  settings.ttsSpeed = Math.max(0.5, Math.min(2, Number(v.ttsSpeed) || 1));
  settings.ttsEmotion = !!v.ttsEmotion;
  settings.jaName = String(v.jaName || '').trim().slice(0, 20);
  settings.showJa = !!v.showJa;
  settings.voiceFixed = !!v.voiceFixed;
  settings.volume = Math.max(0, Math.min(1, Number(v.volume) || 0));
  settings.asrBase = String(v.asrBase || '').trim() || DEFAULTS.asrBase;
  settings.asrKey = llm.cleanKey(v.asrKey);
  settings.asrModel = String(v.asrModel || '').trim() || DEFAULTS.asrModel;
  settings.asrLang = ['', 'zh', 'ja', 'en'].includes(v.asrLang) ? v.asrLang : '';
  settings.vadSilenceMs = Math.max(400, Math.min(3000, parseInt(v.vadSilenceMs, 10) || DEFAULTS.vadSilenceMs));
  settings.vadMaxSec = Math.max(5, Math.min(60, parseInt(v.vadMaxSec, 10) || DEFAULTS.vadMaxSec));
  settings.vadLevel = ['low', 'normal', 'high'].includes(v.vadLevel) ? v.vadLevel : 'normal';
  settings.callShowJa = !!v.callShowJa;
  settings.callStream = !!v.callStream;
  settings.bargeIn = !!v.bargeIn;
  settings.callKaraoke = !!v.callKaraoke;
  if ('visionBase' in v) {
    settings.visionType = ['openai', 'anthropic', 'gemini'].includes(v.visionType) ? v.visionType : '';
    settings.visionBase = String(v.visionBase || '').trim() || DEFAULTS.visionBase;
    settings.visionKey = llm.cleanKey(v.visionKey);
    settings.visionModel = String(v.visionModel || '').trim();
    settings.autoBackup = !!v.autoBackup;
  }
  if ('screenLookBlock' in v) {
    settings.screenLook = !!v.screenLook;
    if ('screenLookFallback' in v) settings.screenLookFallback = !!v.screenLookFallback;
    settings.screenLookRate = ['rarely', 'sometimes', 'often'].includes(v.screenLookRate) ? v.screenLookRate : 'sometimes';
    settings.screenLookScope = ['screen', 'window'].includes(v.screenLookScope) ? v.screenLookScope : 'screen';
    settings.screenLookBlock = String(v.screenLookBlock || '').slice(0, 2000);
  }
  if ('proactiveEnabled' in v) {
    settings.proactiveEnabled = !!v.proactiveEnabled;
    settings.proactiveRate = ['rare', 'normal', 'often'].includes(v.proactiveRate) ? v.proactiveRate : 'normal';
    settings.idleTalk = ['off', 'rare', 'normal', 'often'].includes(v.idleTalk) ? v.idleTalk : 'normal';
    settings.dndFullscreen = !!v.dndFullscreen;
    settings.quietNight = !!v.quietNight;
    settings.nightcord = !!v.nightcord;
    const bd = String(v.userBirthday || '').trim().replace(/[.\/月]/g, '-').replace(/日$/, '');
    const bm = /^(\d{1,2})-(\d{1,2})$/.exec(bd);
    settings.userBirthday = bm ? `${pad2(+bm[1])}-${pad2(+bm[2])}` : '';
    const an = String(v.anniversary || '').trim().replace(/[.\/年月]/g, '-').replace(/日$/, '');
    const am = /^(\d{4})-(\d{1,2})-(\d{1,2})$/.exec(an);
    settings.anniversary = am ? `${am[1]}-${pad2(+am[2])}-${pad2(+am[3])}` : '';
  }
  if ('sfBase' in v) {
    settings.sfBase = String(v.sfBase || '').trim() || DEFAULTS.sfBase;
    settings.sfKey = llm.cleanKey(v.sfKey);
    settings.lyricsModel = String(v.lyricsModel || '').trim().slice(0, 120);
    settings.lyricsAudioModel = String(v.lyricsAudioModel || '').trim().slice(0, 120);
    settings.lyricsAsrModel = ['FunAudioLLM/SenseVoiceSmall', 'TeleAI/TeleSpeechASR'].includes(v.lyricsAsrModel) ? v.lyricsAsrModel : DEFAULTS.lyricsAsrModel;
    settings.lyricsTimeout = Math.max(20, Math.min(900, parseInt(v.lyricsTimeout, 10) || DEFAULTS.lyricsTimeout));
  }
  if ('memoryEnabled' in v) {
    settings.memoryEnabled = !!v.memoryEnabled;
    settings.embBase = String(v.embBase || '').trim() || DEFAULTS.embBase;
    settings.embKey = llm.cleanKey(v.embKey);
    settings.embModel = String(v.embModel || '').trim() || DEFAULTS.embModel;
    settings.memoryTopK = Math.max(1, Math.min(10, parseInt(v.memoryTopK, 10) || 5));
  }
  applySettings();
  return true;
});
ipcMain.handle('settings-test', async (_e, v) => {
  const cfg = { ...settings, ...v };
  const tmp = new Brain(path.join(app.getPath('temp'), 'saki-test.json'));
  tmp.history = [];
  const r = await tmp.chat(cfg, { text: '（测试连接）嗯，在吗？', moods: { calm: '平静' }, actions: { none: '不做动作' } });
  return r;
});
ipcMain.handle('list-models', (_e, v) => llm.listModels({ ...settings, ...v }));
ipcMain.handle('vision-test', async (_e, v) => {
  const keyLabel = v.visionKey ? '看图 API 密钥' : v.embKey ? '长期记忆的 embedding 密钥（看图借用了它）' : '语音识别 API 密钥（看图借用了它）';
  const vc = { apiType: v.visionType || '', apiBase: v.visionBase || DEFAULTS.visionBase, apiKey: v.visionKey || v.embKey || v.asrKey || '', keyLabel, model: v.visionModel || '' };
  { const ki = llm.keyIssue(vc.apiKey, keyLabel); if (ki) return { error: ki }; }
  if (!vc.model) {
    const r = await llm.listModels(vc).catch((e) => ({ error: e.message }));
    if (r.error) return { error: '读不到模型列表：' + r.error };
    vc.model = await pickVisionModel(vc).catch(() => null);
    if (!vc.model) return { error: '没找到能看图的模型，请手动填模型名' };
  }
  // 用一张 64×64 的淡紫色纯色小图测试
  const png = 'iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAIAAAAlC+aJAAAAeUlEQVR4nO3PwQkAIBDAsJvar5O5m0P4CEKhA6Sz1/m64YIGtKABLWhACxrQgga0oAEtaEALGtCCBrSgAS1oQAsa0IIGtKABLWhACxrQgga0oAEtaEALGtCCBrSgAS1oQAsa0IIGtKABLWhACxrQgga0oAEtaEALHruqGiGWMZTHmwAAAABJRU5ErkJggg==';
  const d = await llm.describeImage(vc, { b64: png, mime: 'image/png' }).catch((e) => ({ error: e.message }));
  return d.error ? d : { ok: true, model: vc.model, text: d.text };
});
ipcMain.handle('history-clear', () => { brain.clear(); return true; });
ipcMain.handle('voice-test', async (_e, v) => {
  const cfg = { ...settings, ...v };
  const name = cfg.jaName || cfg.name || '';
  return voice.speak(cfg, `${name}、聞こえる？……えへへ、よかった！`, 'happy');
});
ipcMain.handle('asr-test', async (_e, v) => {
  // 用一段静音测试：能连上、密钥对，就会返回空文本
  const cfg = { ...settings, ...v };
  const sr = 16000, n = sr / 2, buf = Buffer.alloc(44 + n * 2);
  buf.write('RIFF', 0); buf.writeUInt32LE(36 + n * 2, 4); buf.write('WAVE', 8); buf.write('fmt ', 12);
  buf.writeUInt32LE(16, 16); buf.writeUInt16LE(1, 20); buf.writeUInt16LE(1, 22); buf.writeUInt32LE(sr, 24);
  buf.writeUInt32LE(sr * 2, 28); buf.writeUInt16LE(2, 32); buf.writeUInt16LE(16, 34); buf.write('data', 36); buf.writeUInt32LE(n * 2, 40);
  return transcribe(cfg, buf);
});
ipcMain.handle('voice-clear-cache', () => { voice.clearCache(); return true; });

/* ---------- 合成器（电子琴：写简谱 / 五线谱） ---------- */
function openSynth() {
  if (synthWin) { synthWin.focus(); return; }
  synthWin = new BrowserWindow({
    width: 860, height: 920, minWidth: 640, minHeight: 640, title: '咲希桌宠 · 电子琴',
    icon: path.join(__dirname, 'icon.png'), autoHideMenuBar: true, backgroundColor: '#fcf8ed',
    webPreferences: { preload: path.join(__dirname, 'preload-synth.js'), contextIsolation: true },
  });
  synthWin.loadFile(path.join(__dirname, 'src', 'synth.html'));
  synthWin.on('closed', () => { synthWin = null; });
}
const SCORES_FILE = () => path.join(app.getPath('userData'), 'scores.json');
const readScores = () => { try { return JSON.parse(fs.readFileSync(SCORES_FILE(), 'utf8')); } catch (e) { return {}; } };
const writeScores = (o) => { try { fs.writeFileSync(SCORES_FILE(), JSON.stringify(o, null, 2)); } catch (e) {} };
ipcMain.handle('synth-list', () => readScores());
ipcMain.handle('synth-save', (_e, { title, text }) => {
  const o = readScores(); o[String(title).slice(0, 30)] = { text: String(text).slice(0, 20000), at: Date.now() }; writeScores(o); return true;
});
ipcMain.handle('synth-remove', (_e, name) => { const o = readScores(); delete o[name]; writeScores(o); return true; });
ipcMain.handle('synth-export', async (_e, { name, data }) => {
  const r = await dialog.showSaveDialog(synthWin || win, { title: '导出', defaultPath: path.join(app.getPath('music'), name) });
  if (r.canceled || !r.filePath) return {};
  fs.writeFileSync(r.filePath, Buffer.from(data));
  return { path: r.filePath };
});
/* ---------- 写词（根据曲子生成原创歌词，硅基流动） ---------- */
const lyrics = require('./lyrics')({
  getSettings: () => settings, icon: path.join(__dirname, 'icon.png'), appDir: __dirname,
  sayLine: (...a) => sayLine(...a), openSettings: () => openSettings(), getSynthWin: () => synthWin,
});
// 合成器里点“为这首写歌词”：把当前作品（曲名 + 简谱）直接交给写词窗口，不用导出文件
ipcMain.handle('synth-to-lyrics', (e, v = {}) => {
  if (!synthWin || e.sender !== synthWin.webContents) return { error: 'denied' };
  const text = String(v.text || '').slice(0, 20000);
  if (!text.trim()) return { error: '合成器里还没有曲子' };
  lyrics.open({ kind: 'synth', title: String(v.title || '').slice(0, 30), text, mine: !!v.mine, at: Date.now() });
  return { ok: true };
});
// 她写一段旋律：打开合成器，写好后她说一句，然后弹出来
let composing = null;
function checkScore(text) {
  const sc = Jianpu.parse(text);
  if (sc.error) return sc.error.msg + `（在“${text.slice(Math.max(0, sc.error.pos - 6), sc.error.pos + 6)}”附近）`;
  if (sc.notes.length < 6) return '太短了，至少写 4 个小节';
  if (sc.chordError) return sc.chordError;
  const bad = Jianpu.checkBars(sc);
  if (bad.length) return bad.slice(0, 4).map((b) => `第 ${b.bar} 小节是 ${b.got} 拍，应该是 ${sc.beats} 拍`).join('；');
  return null;
}
async function composeMelody(hint = '', { fromChat = false } = {}) {
  if (composing) return composing;
  composing = (async () => {
    const epoch = brain.historyEpoch;
    const stale = () => epoch !== brain.historyEpoch;
    openSynth();
    const sendSynth = (ch, v) => {
      const target = synthWin;
      if (!target || target.isDestroyed()) return;
      const go = () => {
        if (target !== synthWin || target.isDestroyed() || (ch === 'synth-load' && stale())) return;
        target.webContents.send(ch, v);
      };
      target.webContents.isLoading() ? target.webContents.once('did-finish-load', go) : go();
    };
    const canceled = () => { sendSynth('synth-status', { busy: false, text: '已取消写曲' }); return { error: 'aborted' }; };
    sendSynth('synth-status', { busy: true, text: '她在写……' });
    const recall = memory ? await memory.recall(hint || '此刻的心情 写一段旋律') : '';
    if (stale()) return canceled();
    const r = await brain.compose(settings, { hint, check: checkScore, recall });
    if (stale() || r.error === 'aborted') return canceled();
    if (!r.error && affection) { affection.feel(r.mood, r.intensity); sendLingering(); }
    if (r.error) {
      sendSynth('synth-status', { busy: false, text: r.error === 'noapi' ? '还没填聊天模型的 API' : '没写成：' + r.error, err: true });
      return r;
    }
    // 自动保存到“已保存的曲子”
    const title = '咲希 · ' + r.title;
    const o = readScores(); o[title] = { text: r.score, at: Date.now(), by: 'saki' }; writeScores(o);
    let audio = null;
    if (voiceOn() && !settings.muted && r.ja) {
      try {
        const v = await voice.speak(settings, r.ja, r.mood);
        if (v.audio) audio = v.audio; else r.voiceError = v.error || '配音没有返回音频';
      } catch (e) { r.voiceError = '配音失败：' + (e.message || String(e)); }
    }
    if (stale()) return canceled();
    const spokenText = r.reply || (r.replyError ? '曲子已经写好并保存，但模型没能生成作曲后的回应。' : '');
    if (win && spokenText) win.webContents.send('ai-say', { t: spokenText, ja: r.ja, m: r.mood, a: r.action, intensity: r.intensity, audio, tag: r.replyError ? '回应生成失败' : r.voiceError ? '配音不可用' : undefined });
    // 等她说完再弹
    const wait = r.reply ? Math.min(6000, 1200 + r.reply.length * 160) : 300;
    setTimeout(() => { if (!stale()) sendSynth('synth-load', { title, text: r.score, play: true, mine: true }); }, fromChat ? wait : wait);
    const warning = r.replyError ? '；谱子已保存，但回应生成失败：' + r.replyError : r.voiceError ? '；台词仅显示文字：' + r.voiceError : '';
    sendSynth('synth-status', { busy: false, text: `她写好了《${r.title}》${warning}`, err: !!warning });
    return r;
  })();
  try { return await composing; } finally { composing = null; }
}
ipcMain.handle('synth-compose', (_e, hint) => composeMelody(String(hint || '').slice(0, 100)));

// 弹给她听：她在桌面上听（点头之类），也记下来，下次聊天时她知道
let lastSynthReact = 0;
ipcMain.on('synth-played', (_e, title, mine) => {
  if (mine) return;   // 弹的是她自己写的，不用再“听”
  const d = new Date(), t = `${pad2(d.getHours())}:${pad2(d.getMinutes())}`;
  if (brain) brain.note(`${t} ${settings.name || '对方'}用合成器弹了一段电子琴给你听${title ? '：《' + String(title).slice(0, 30) + '》' : ''}`);
  if (win && Date.now() - lastSynthReact > 60000) { lastSynthReact = Date.now(); win.webContents.send('say', 'synthListen'); }
});

/* ---------- 好感（调试） ---------- */
let affWin = null;
function openAffection() {
  if (affWin) { affWin.focus(); return; }
  affWin = new BrowserWindow({
    width: 520, height: 600, minWidth: 420, minHeight: 460, title: '咲希桌宠 · 好感（调试）',
    icon: path.join(__dirname, 'icon.png'), autoHideMenuBar: true, backgroundColor: '#fcf8ed',
    webPreferences: { preload: path.join(__dirname, 'preload-affection.js'), contextIsolation: true },
  });
  affWin.loadFile(path.join(__dirname, 'src', 'affection.html'));
  affWin.on('closed', () => { affWin = null; });
}
ipcMain.on('open-affection', () => openAffection());
ipcMain.handle('aff-info', () => ({ ...affection.info(), file: path.join(app.getPath('userData'), 'affection.json'), tail: affection.tailText(settings.name || '你') }));
ipcMain.handle('aff-set', (_e, v) => { const r = affection.set(v); return r; });
ipcMain.handle('aff-clear-mood', () => { affection.clearMood(); sendLingering(); return true; });
ipcMain.handle('aff-cfg', (_e, v) => {
  settings.affectionEnabled = !!v.affectionEnabled;
  settings.affectionMaxStep = Math.max(1, Math.min(10, parseInt(v.affectionMaxStep, 10) || 3));
  settings.affectionDayCap = Math.max(1, Math.min(50, parseInt(v.affectionDayCap, 10) || 10));
  settings.moodHalfLife = Math.max(1, Math.min(240, parseInt(v.moodHalfLife, 10) || 20));
  save(); return true;
});
ipcMain.on('open-aff-file', () => shell.showItemInFolder(path.join(app.getPath('userData'), 'affection.json')));

/* ---------- 记忆管理窗口 ---------- */
let memWin = null;
function openMemory() {
  if (memWin) { memWin.focus(); return; }
  memWin = new BrowserWindow({
    width: 640, height: 680, minWidth: 480, minHeight: 500, title: '咲希桌宠 · 她的记忆',
    icon: path.join(__dirname, 'icon.png'), autoHideMenuBar: true, backgroundColor: '#fcf8ed',
    webPreferences: { preload: path.join(__dirname, 'preload-memory.js'), contextIsolation: true },
  });
  memWin.loadFile(path.join(__dirname, 'src', 'memory.html'));
  memWin.on('closed', () => { memWin = null; });
}
ipcMain.on('open-memory', () => openMemory());
// 记下新东西时：记忆窗口开着就刷新
function notifyMemory(added) { if (memWin) memWin.webContents.send('mem-changed', added); }
const memCall = (fn) => async (...a) => { try { return await fn(...a); } catch (e) { return { error: e.message }; } };
ipcMain.handle('mem-list', (_e, kind) => ({ items: memory.list(kind), stats: memory.stats(), ready: memory.ready(), lastRecall: memory.lastRecall || null, lastError: memory.lastError || '' }));
ipcMain.handle('mem-add', memCall((_e, { text, kind }) => memory.addManual(text, kind)));
ipcMain.handle('mem-edit', memCall((_e, { id, text }) => memory.edit(id, text)));
ipcMain.handle('mem-remove', (_e, id) => memory.remove(id));
ipcMain.handle('mem-remove-source', (_e, src) => memory.removeSource(src));
ipcMain.handle('mem-clear', (_e, kind) => memory.clear(kind));
ipcMain.handle('mem-search', memCall((_e, { text, kind }) => memory.semanticSearch(text, kind)));
ipcMain.handle('mem-reembed', memCall((e) => memory.reembed((d, n) => e.sender.send('mem-progress', { d, n }))));
ipcMain.handle('mem-test', memCall(async (_e, v) => {
  const saved = { ...settings };
  Object.assign(settings, { embBase: v.embBase || DEFAULTS.embBase, embKey: v.embKey || '', embModel: v.embModel || DEFAULTS.embModel, asrKey: v.asrKey ?? settings.asrKey });
  try { const [x] = await memory.embed(['测试']); return { ok: true, dim: x.length }; }
  finally { Object.assign(settings, { embBase: saved.embBase, embKey: saved.embKey, embModel: saved.embModel, asrKey: saved.asrKey }); }
}));
ipcMain.handle('mem-import', memCall(async (e) => {
  const r = await dialog.showOpenDialog(memWin || win, { title: '导入资料', properties: ['openFile', 'multiSelections'], filters: [{ name: '文本（txt / md）', extensions: ['txt', 'md', 'markdown'] }] });
  if (r.canceled || !r.filePaths.length) return { canceled: true };
  const done = [];
  for (const f of r.filePaths) {
    let text = fs.readFileSync(f);
    // 有的中文 txt 是 GBK 编码：UTF-8 读出乱码时换 GBK
    let str = text.toString('utf8');
    if (/\uFFFD/.test(str)) { try { str = new TextDecoder('gbk').decode(text); } catch (err) {} }
    const name = path.basename(f).replace(/\.(txt|md|markdown)$/i, '');
    const res = await memory.importText(name, str, (d, n) => e.sender.send('mem-progress', { d, n, name }));
    done.push({ name, ...res });
  }
  return { done };
}));

/* ---------- 数据备份：设置、聊天记录、记忆、好感、曲子 打包成一个文件 ---------- */
const BACKUP_FILES = ['settings.json', 'chat-history.json', 'memory.json', 'affection.json', 'scores.json', 'proactive.json', 'spoken-context.jsonl'];
const SECRET_KEYS = ['apiKey', 'ttsKey', 'asrKey', 'embKey', 'visionKey', 'sfKey'];
function makeBackup(withKeys) {
  save();
  const dir = app.getPath('userData'), files = {};
  for (const f of BACKUP_FILES) {
    try {
      if (f === 'spoken-context.jsonl') { files[f] = fs.readFileSync(path.join(dir, f), 'utf8'); continue; }
      let o = JSON.parse(fs.readFileSync(path.join(dir, f), 'utf8'));
      if (f === 'settings.json' && !withKeys) { o = { ...o }; for (const k of SECRET_KEYS) delete o[k]; }
      files[f] = o;
    } catch (e) {}
  }
  return { app: '咲希桌宠', kind: 'backup', version: app.getVersion(), at: new Date().toISOString(), withKeys: !!withKeys, files };
}
function backupSummary(b) {
  const f = b.files || {};
  const n = (x) => (Array.isArray(x) ? x.length : 0);
  return {
    at: b.at, version: b.version, withKeys: !!b.withKeys,
    chats: Math.floor(n(f['chat-history.json']) / 2),
    memories: n(f['memory.json'] && f['memory.json'].items),
    affection: f['affection.json'] ? f['affection.json'].value : null,
    scores: f['scores.json'] ? Object.keys(f['scores.json']).length : 0,
  };
}
ipcMain.handle('backup-export', async (_e, { withKeys }) => {
  const d = new Date();
  const r = await dialog.showSaveDialog(setWin || win, { title: '导出备份', defaultPath: path.join(app.getPath('documents'), `咲希桌宠备份_${dayKey(d)}.json`), filters: [{ name: '咲希桌宠备份', extensions: ['json'] }] });
  if (r.canceled || !r.filePath) return {};
  const b = makeBackup(withKeys);
  fs.writeFileSync(r.filePath, JSON.stringify(b));
  return { path: r.filePath, summary: backupSummary(b) };
});
let pendingRestore = null;
// 检查备份里每个文件的结构；有一个不对就整份不用。返回出错说明，没问题返回 null
function validateBackup(b) {
  if (!b || b.app !== '咲希桌宠' || !b.files || typeof b.files !== 'object' || Array.isArray(b.files)) return '这不是咲希桌宠的备份文件';
  const f = b.files, isObj = (x) => x && typeof x === 'object' && !Array.isArray(x);
  const known = Object.keys(f).filter((k) => BACKUP_FILES.includes(k));
  if (!known.length) return '备份里没有可以恢复的数据';
  if ('settings.json' in f) {
    if (!isObj(f['settings.json'])) return 'settings.json 的内容不对';
    for (const [k, list] of Object.entries(ENUMS)) if (k in f['settings.json'] && !list.includes(f['settings.json'][k])) return `settings.json 里的 ${k} 值不对（${JSON.stringify(f['settings.json'][k])}）`;
  }
  if ('chat-history.json' in f && !(Array.isArray(f['chat-history.json']) && f['chat-history.json'].every((m) => isObj(m) && ['user', 'assistant'].includes(m.role) && typeof m.content === 'string'))) return 'chat-history.json（聊天记录）的内容不对';
  if ('memory.json' in f && !(isObj(f['memory.json']) && Array.isArray(f['memory.json'].items) && f['memory.json'].items.every((x) => isObj(x) && typeof x.text === 'string' && ['memory', 'knowledge'].includes(x.kind)))) return 'memory.json（记忆）的内容不对';
  if ('affection.json' in f && !(isObj(f['affection.json']) && Number.isFinite(f['affection.json'].value))) return 'affection.json（好感）的内容不对';
  if ('scores.json' in f && !(isObj(f['scores.json']) && Object.values(f['scores.json']).every((x) => isObj(x) && typeof x.text === 'string'))) return 'scores.json（曲子）的内容不对';
  if ('spoken-context.jsonl' in f) {
    const raw = f['spoken-context.jsonl'];
    if (typeof raw !== 'string') return 'spoken-context.jsonl（发言记录）的内容不对';
    try {
      for (const line of raw.split('\n')) {
        if (!line.trim()) continue;
        const entry = JSON.parse(line);
        if (!isObj(entry) || (entry.type !== 'clear' && (typeof entry.id !== 'string' || typeof entry.text !== 'string' || !Number.isFinite(entry.at)))) return 'spoken-context.jsonl（发言记录）的条目不对';
      }
    } catch (_) { return 'spoken-context.jsonl（发言记录）不是有效的逐行JSON'; }
  }
  if ('proactive.json' in f && !isObj(f['proactive.json'])) return 'proactive.json 的内容不对';
  return null;
}
ipcMain.handle('backup-pick', async () => {
  const r = await dialog.showOpenDialog(setWin || win, { title: '选择备份文件', properties: ['openFile'], defaultPath: app.getPath('documents'), filters: [{ name: '咲希桌宠备份', extensions: ['json'] }] });
  if (r.canceled || !r.filePaths.length) return {};
  try {
    const b = JSON.parse(fs.readFileSync(r.filePaths[0], 'utf8'));
    const bad = validateBackup(b);
    if (bad) return { error: '这份备份不能用：' + bad };
    pendingRestore = b;
    return { name: path.basename(r.filePaths[0]), summary: backupSummary(b) };
  } catch (e) { return { error: '读不了这个文件：' + e.message }; }
});
ipcMain.handle('backup-restore', async () => {
  const b = pendingRestore; pendingRestore = null;
  if (!b) return { error: '先选择备份文件' };
  const bad = validateBackup(b);
  if (bad) return { error: bad };
  const dir = app.getPath('userData');
  const rescue = path.join(dir, 'backups', `恢复前_${Date.now()}.json`);
  // 恢复之前，先把现在的数据也存一份；存不下来就不恢复
  try {
    fs.mkdirSync(path.join(dir, 'backups'), { recursive: true });
    fs.writeFileSync(rescue, JSON.stringify(makeBackup(true)));
  } catch (e) { return { error: '没能先保存现在的数据，为了安全没有恢复：' + e.message }; }
  // 先准备所有临时文件与原字节；替换中途失败时逆序回滚。
  const staged = [], applied = [], before = new Map();
  try {
    const restoreFiles = Object.entries(b.files);
    // 旧备份没有补充发言记录：恢复聊天时清掉当前日志，避免未来的发言混回旧记录。
    if ('chat-history.json' in b.files && !('spoken-context.jsonl' in b.files)) restoreFiles.push(['spoken-context.jsonl', '']);
    for (const [f, o] of restoreFiles) {
      if (!BACKUP_FILES.includes(f)) continue;
      let data = o;
      if (f === 'settings.json') {
        data = sanitizeSettings(o);
        for (const k of SECRET_KEYS) if (!o[k] && settings[k]) data[k] = settings[k];   // 备份里没有密钥：保留现在的
      }
      const tmp = path.join(dir, f + '.restore-tmp');
      fs.writeFileSync(tmp, f === 'spoken-context.jsonl' ? data : JSON.stringify(data, null, f === 'settings.json' ? 2 : 0));
      const dst = path.join(dir, f);
      before.set(dst, fs.existsSync(dst) ? fs.readFileSync(dst) : null);
      staged.push([tmp, dst]);
    }
    for (const [tmp, dst] of staged) { fs.renameSync(tmp, dst); applied.push(dst); }
  } catch (e) {
    const failed = [];
    for (const dst of applied.reverse()) {
      try {
        const original = before.get(dst);
        if (original === null) fs.unlinkSync(dst);
        else { const tmp = dst + '.restore-rollback'; fs.writeFileSync(tmp, original); fs.renameSync(tmp, dst); }
      } catch (err) { failed.push(path.basename(dst)); }
    }
    for (const [tmp] of staged) try { fs.unlinkSync(tmp); } catch (err) {}
    return { error: failed.length
      ? `恢复失败，部分文件未能回滚（${failed.join('、')}）。请使用恢复前备份：${rescue}。原因：${e.message}`
      : '恢复失败，已回滚本次更改：' + e.message };
  }
  // 重新启动，让所有数据从文件重新读
  // 同一同步调用内退出，避免旧任务在重启等待期覆盖已恢复的文件。
  app.relaunch(); app.exit(0);
  return { ok: true };
});
ipcMain.on('backup-open-folder', () => { const d = path.join(app.getPath('userData'), 'backups'); fs.mkdirSync(d, { recursive: true }); shell.openPath(d); });
// 每天自动备份一次（不含密钥），只留最近 7 份
function autoBackup() {
  if (settings.autoBackup === false) return;
  try {
    const dir = path.join(app.getPath('userData'), 'backups');
    fs.mkdirSync(dir, { recursive: true });
    const f = path.join(dir, `自动备份_${dayKey()}.json`);
    if (fs.existsSync(f)) return;
    fs.writeFileSync(f, JSON.stringify(makeBackup(false)));
    const old = fs.readdirSync(dir).filter((x) => x.startsWith('自动备份_')).sort();
    for (const x of old.slice(0, Math.max(0, old.length - 7))) fs.unlinkSync(path.join(dir, x));
  } catch (e) {}
}

/* ---------- 她在聊天里答应做的事 ---------- */
const sayLine = (t, ja, m = 'calm', a = 'none') => { if (win) win.webContents.send('ai-say', { t, ja, m, a }); };
function findScore(title) {
  const o = readScores(), names = Object.keys(o);
  const q = String(title || '').replace(/[《》\s]/g, '').toLowerCase();
  if (!q) return null;
  const strip = (n) => n.replace(/^咲希 · /, '').replace(/\s/g, '').toLowerCase();
  const hit = names.find((n) => strip(n) === q) || names.find((n) => strip(n).includes(q) || q.includes(strip(n)));
  return hit ? { title: hit, text: o[hit].text, mine: o[hit].by === 'saki' } : null;
}
function addReminder({ minutes, at, say, ja }) {
  let when = null;
  if (typeof at === 'string' && /^\d{1,2}[:：]\d{2}$/.test(at.trim())) {
    const [h, m] = at.trim().split(/[:：]/).map(Number);
    const d = new Date(); d.setHours(h, m, 0, 0);
    if (d.getTime() <= Date.now() + 30000) d.setDate(d.getDate() + 1);   // 已经过了就是明天
    when = d.getTime();
  } else if (Number(minutes) > 0) when = Date.now() + Math.min(7 * 24 * 60, Number(minutes)) * 60000;
  if (!when) return null;
  const item = { id: Date.now().toString(36) + Math.random().toString(36).slice(2, 5), at: when, say: String(say || '时间到了。').slice(0, 60), ja: String(ja || '').slice(0, 80) };
  settings.customReminders = [...(settings.customReminders || []), item].sort((a, b) => a.at - b.at).slice(-30);
  save();
  tray && tray.setContextMenu(buildMenu());
  return item;
}
async function fireReminder(item) {
  settings.customReminders = (settings.customReminders || []).filter((x) => x.id !== item.id);
  save();
  tray && tray.setContextMenu(buildMenu());
  if (!win) return;
  if (!win.isVisible()) win.showInactive();
  let audio = null;
  if (voiceOn() && !settings.muted && item.ja) { const v = await voice.speak(settings, item.ja, 'soft').catch(() => ({})); if (v && v.audio) audio = v.audio; }
  win.webContents.send('remind', { t: item.say, ja: item.ja, audio });
  const d = new Date(item.at);
  if (brain) brain.note(`${pad2(d.getHours())}:${pad2(d.getMinutes())} 你按约定提醒了${settings.name || '对方'}：${item.say}`);
}
setInterval(() => {
  const now = Date.now();
  for (const it of (settings.customReminders || []).slice()) {
    if (it.at <= now) {
      if (now - it.at > 3 * 3600000) { settings.customReminders = settings.customReminders.filter((x) => x.id !== it.id); save(); }  // 关着电脑错过太久的就不提了
      else fireReminder(it);
    }
  }
}, 5000);
const hm = (ms) => { const d = new Date(ms); const today = new Date().toDateString() === d.toDateString(); return (today ? '' : `${d.getMonth() + 1}月${d.getDate()}日 `) + `${pad2(d.getHours())}:${pad2(d.getMinutes())}`; };

function runActions(list, { delay = 1500, inCall = false, allowLook = true } = {}) {
  setTimeout(async () => {
    let looked = false;
    for (const a of list) {
      try {
        switch (a.cmd) {
          case 'compose': composeMelody(String(a.hint || '').slice(0, 100), { fromChat: true }); break;
          case 'synth': openSynth(); break;
          case 'play': {
            const f = findScore(a.title);
            openSynth();
            if (!f) { sayLine('……没找到那首呢。在合成器里找找看？', '……その曲、見つからないな。シンセの中、探してみてくれる？', 'troubled', 'tilt'); break; }
            const go = () => synthWin && synthWin.webContents.send('synth-load', { title: f.title, text: f.text, play: true, mine: f.mine });
            synthWin.webContents.isLoading() ? synthWin.webContents.once('did-finish-load', () => setTimeout(go, 300)) : go();
            break;
          }
          case 'outfit': {
            const to = ['uniform', 'unit', 'casual', 'auto'].includes(a.to) ? a.to : null;
            if (to) { settings.outfitMode = to; save(); checkOutfit(true); tray && tray.setContextMenu(buildMenu()); }
            break;
          }
          case 'remind': {
            const it = addReminder(a);
            if (!it && !inCall) sayLine('……要几点提醒你？刚才没听清。', '……何時に知らせればいい？ごめん、聞き取れなかった。', 'think', 'tilt');
            break;
          }
          case 'size': if (['small', 'medium', 'large'].includes(a.to)) { settings.size = a.to; applySettings(); } break;
          case 'view': if (['full', 'half'].includes(a.to)) { settings.view = a.to; applySettings(); } break;
          case 'mute': settings.muted = a.on !== false; applySettings(); break;
          case 'call': if (win && !inCall) win.webContents.send('say', 'call'); break;
          case 'sleep': if (win && !inCall) win.webContents.send('say', 'sleep'); break;
          case 'look': {
            // 已看过屏幕后生成的自动评论不能再次截图；同一轮重复指令只执行一次。
            if (!allowLook || looked) break;
            looked = true;
            if (!settings.screenLook) { sayLine('……“看屏幕”还没打开哦。在设置里打开，我才能看。', '……画面を見る設定、オフになってるよ。設定でオンにしてくれたら、見られるから。', 'calm', 'tilt'); break; }
            const r = await lookAtScreen({ force: true });
            if (r.ok) await sayLooked(r, true);
            else sayLine(r.skip ? '……这个我就不看了。' : '……没看清楚。', r.skip ? '……これは、見ないでおくね。' : '……よく見えなかった。', 'calm', 'shake');
            break;
          }
        }
      } catch (e) {}
    }
  }, delay);
}

/* ---------- 菜单 ---------- */
function radio(label, key, value) {
  return { label, type: 'radio', checked: settings[key] === value, click: () => { settings[key] = value; applySettings(); } };
}
function buildMenu() {
  const visible = petIsShown();
  return Menu.buildFromTemplate([
    { label: '和她聊天', click: () => win && win.webContents.send('say', 'chat') },
    { label: '语音通话', click: () => win && win.webContents.send('say', 'call') },
    { label: '戳一下', click: () => win && win.webContents.send('say', 'body') },
    { label: '合成器（电子琴：简谱 / 五线谱）…', click: openSynth },
    { label: '根据曲子写歌词…', click: () => lyrics.open() },
    { label: '她的记忆和资料库…', click: openMemory },
    { label: '让她写一首曲子', click: () => composeMelody('') },
    { type: 'separator' },
    { label: '显示方式', submenu: [radio('全身', 'view', 'full'), radio('半身', 'view', 'half')] },
    { label: '衣服', submenu: [
      { label: '按时间自动换（周一到周五 8:00–18:00 校服，周日 8:00–15:00 队服）', type: 'radio', checked: settings.outfitMode === 'auto' || !OUTFIT_NAME[settings.outfitMode], click: () => { settings.outfitMode = 'auto'; save(); checkOutfit(true); tray && tray.setContextMenu(buildMenu()); } },
      { label: '一直穿校服', type: 'radio', checked: settings.outfitMode === 'uniform', click: () => { settings.outfitMode = 'uniform'; save(); checkOutfit(true); tray && tray.setContextMenu(buildMenu()); } },
      { label: '一直穿队服（Leo/need）', type: 'radio', checked: settings.outfitMode === 'unit', click: () => { settings.outfitMode = 'unit'; save(); checkOutfit(true); tray && tray.setContextMenu(buildMenu()); } },
      { label: '一直穿常服', type: 'radio', checked: settings.outfitMode === 'casual', click: () => { settings.outfitMode = 'casual'; save(); checkOutfit(true); tray && tray.setContextMenu(buildMenu()); } },
    ] },
    { label: '大小', submenu: [radio('小', 'size', 'small'), radio('中', 'size', 'medium'), radio('大', 'size', 'large')] },
    { type: 'separator' },
    { label: '喝水提醒', submenu: [radio('关闭', 'water', 0), radio('每 30 分钟', 'water', 30), radio('每 45 分钟', 'water', 45), radio('每 60 分钟', 'water', 60), radio('每 90 分钟', 'water', 90)] },
    { label: '休息提醒', submenu: [radio('关闭', 'rest', 0), radio('每 45 分钟', 'rest', 45), radio('每 60 分钟', 'rest', 60), radio('每 90 分钟', 'rest', 90), radio('每 120 分钟', 'rest', 120)] },
    { label: `她答应的提醒${(settings.customReminders || []).length ? '（' + settings.customReminders.length + '）' : ''}`, submenu: (settings.customReminders || []).length
      ? settings.customReminders.map((it) => ({ label: `${hm(it.at)}  ${it.say}（点一下取消）`, click: () => { settings.customReminders = settings.customReminders.filter((x) => x.id !== it.id); save(); tray && tray.setContextMenu(buildMenu()); } }))
      : [{ label: '还没有。聊天时跟她说“二十分钟后提醒我…”就行', enabled: false }] },
    { label: '待机时自言自语', submenu: [radio('关闭', 'idleTalk', 'off'), radio('很少（20–40 分钟一句）', 'idleTalk', 'rare'), radio('偶尔（8–16 分钟一句）', 'idleTalk', 'normal'), radio('常常（4–8 分钟一句）', 'idleTalk', 'often')] },
    { label: '熬夜提醒（23:30 以后）', type: 'checkbox', checked: settings.sleepRemind, click: (m) => { settings.sleepRemind = m.checked; applySettings(); } },
    { type: 'separator' },
    plugins ? plugins.menuTemplate() : { label: '插件', enabled: false },
    { label: '设置（称呼、聊天 API、人设）…', click: openSettings },
    { label: '静音', type: 'checkbox', checked: settings.muted, click: (m) => { settings.muted = m.checked; applySettings(); } },
    { label: '总在最前面', type: 'checkbox', checked: settings.alwaysOnTop, click: (m) => { settings.alwaysOnTop = m.checked; applySettings(); } },
    { label: '开机自动启动', type: 'checkbox', checked: settings.autoStart, click: (m) => { settings.autoStart = m.checked; app.setLoginItemSettings({ openAtLogin: m.checked }); save(); } },
    { label: '回到屏幕右下角', click: () => { const [w, h] = winSize(); const wa = screen.getPrimaryDisplay().workArea; base = { x: wa.x + wa.width - w - 40, y: wa.y + wa.height - h }; settings.x = base.x; settings.y = base.y; placeWindow(); save(); } },
    { label: '恢复桌宠显示（重建画面）', click: recoverPetDisplay },
    { label: '打开日志文件夹（排查问题用）', click: () => shell.openPath(app.getPath('userData')) },
    { type: 'separator' },
    { label: visible ? '暂时隐藏' : '显示', click: toggle },
    { label: '退出', click: () => app.quit() },
  ]);
}
function toggle() {
  if (isQuitting) return;
  if (petIsShown()) hidePetWindow(); else showPetWindow();
}

/* ---------- 提醒 ---------- */
const last = { water: Date.now(), rest: Date.now(), sleep: 0 };
function remind(type) {
  if (plugins) plugins.emit('remind', { type });
  if (!win) return;
  if (!win.isVisible()) { win.showInactive(); tray && tray.setContextMenu(buildMenu()); }
  win.webContents.send('remind', type);
}
setInterval(() => {
  const now = Date.now();
  // 人不在电脑前超过 5 分钟：不打扰；回来时重新计时（离开本身就算休息过了）
  const idleSec = powerMonitor.getSystemIdleTime();
  if (idleSec > 300) { last.rest = now; last.water = Math.max(last.water, now - settings.water * 60000 / 2); return; }

  if (settings.water > 0 && now - last.water >= settings.water * 60000) { last.water = now; remind('water'); return; }
  if (settings.rest > 0 && now - last.rest >= settings.rest * 60000) { last.rest = now; remind('rest'); return; }
  if (settings.sleepRemind) {
    const d = new Date(); const m = d.getHours() * 60 + d.getMinutes();
    const late = m >= 23 * 60 + 30 || m < 4 * 60;
    if (late && now - last.sleep >= 30 * 60000) { last.sleep = now; remind('sleep'); }
  }
}, 30000);

/* ---------- 插件 ---------- */
// 从 lines.js 读出可用的心情和动作名，告诉插件
function lineNames() {
  try {
    const w = {};
    require('vm').runInNewContext(fs.readFileSync(path.join(__dirname, 'src', 'lines.js'), 'utf8'), { window: w, Set, Map, Math, Object, Array, JSON }, { timeout: 1000 });
    return { moods: Object.keys(w.MOODS || {}), actions: Object.keys(w.ACTIONS || {}) };
  } catch (e) { return { moods: [], actions: [] }; }
}
function startPlugins() {
  try {
    plugins = new PluginManager({
      appId: require('./package.json').name, petName: '咲希', appVersion: app.getVersion(),
      userData: app.getPath('userData'), bundledDir: path.join(__dirname, 'plugins'), preloadDir: __dirname,
      icon: path.join(__dirname, 'icon.png'), theme: { bg: '#fcf8ed', ink: '#3f361b', sub: '#746844', line: '#edd693', accent: '#b58d16', soft: '#fbf2d6', card: '#ffffff', mark: '☆' },
      getWin: () => win,
      say: (t, ja, m, a) => sayLine(t, ja, m, a),
      trigger: (k) => { if (win && !win.isDestroyed()) win.webContents.send('say', k); },
      publicSettings: () => publicSettings(),
      refreshMenu: () => { if (tray) tray.setContextMenu(buildMenu()); },
      ...lineNames(),
    });
    plugins.attachWindow(win);
    global.__plugins = plugins;   // 供测试脚本使用
    plugins.start().catch((e) => plugins.log('', 'error', '插件启动失败：' + (e && e.stack || e)));
  } catch (e) {
    try { fs.appendFileSync(path.join(app.getPath('userData'), 'plugins.log'), new Date().toISOString() + ' 插件系统没有启动：' + (e && e.stack || e) + '\n'); } catch (_) {}
    plugins = null;
  }
}

/* ---------- 启动 ---------- */
app.on('will-quit', () => { screenLook.stop(); if (dnd) dnd.stop(); if (plugins) { plugins.emit('quit', {}); plugins.stopAll(); } });
app.whenReady().then(() => {
  loadProactive();
  dnd = new Dnd();
  if (settings.screenLook) void screenLook.prepare();
  setInterval(proactiveTick, 60000);
  setTimeout(autoBackup, 20000); setInterval(autoBackup, 3600000);
  session.defaultSession.setPermissionRequestHandler((wc, perm, cb) => cb(perm === 'media' && !!win && wc === win.webContents));
  session.defaultSession.setPermissionCheckHandler((wc, perm) => perm === 'media' && !!win && wc === win.webContents);
  if (process.platform === 'win32') app.setAppUserModelId('saki.desktop.pet');
  brain = new Brain(path.join(app.getPath('userData'), 'chat-history.json'));
  speechContext = new SpeechContext(brain, path.join(app.getPath('userData'), 'spoken-context.jsonl'), (msg) => console.warn(msg));
  affection = new Affection(path.join(app.getPath('userData'), 'affection.json'), () => settings);
  brain.env = () => { const a = affection.tailText(settings.name || '你'); return envLine() + (a ? '；' + a : ''); };
  memory = new Memory(path.join(app.getPath('userData'), 'memory.json'), () => settings);
  voice = new Voice(path.join(app.getPath('userData'), 'voice-cache'));
  createWindow();
  startPlugins();
  const img = nativeImage.createFromPath(path.join(__dirname, 'icon.png')).resize({ width: 16, height: 16 });
  tray = new Tray(img);
  tray.setToolTip('咲希');
  tray.setContextMenu(buildMenu());
  tray.on('click', toggle);
});
app.on('second-instance', () => { showPetWindow(); });
app.on('window-all-closed', () => {});
global.__openSettings = openSettings;   // 供测试脚本使用

// 测试用
module.exports = { _test: { lookAtScreen, lookStatus, setLook: (f) => { screenLook.capture = f; }, openSettings, setNow: (f) => { nowDate = f; }, setIdle: (f) => { idleTime = f; }, setLastChat: (v) => { lastUserChat = v; }, proactiveTick, pro: () => pro, setDnd: (d) => { dnd = d; }, todaysEvent, affection: () => affection, openAffection, brainHist: () => brain.history, openMemory, memory: () => memory, runActions, settings: () => settings, composeMelody, openSynth, openLyrics: (src) => lyrics.open(src), synthWin: () => synthWin, checkOutfit, setMode: (m) => { settings.outfitMode = m; } } };


/* ---------- 桌宠团：给团队主进程用的接口 ---------- */
if (TEAM) module.exports._team = {
  win: () => (win && !win.isDestroyed() ? win : null),
  settings: () => settings,
  size: () => winSize(),
  moveTo: (x, y) => { base = { x, y }; settings.x = x; settings.y = y; placeWindow(); save(); },
  applyShared: (changes) => { Object.assign(settings, changes); try { applySettings(); } catch (e) { save(); } },
  applyOwn: (changes) => { Object.assign(settings, changes); try { applySettings(); } catch (e) { save(); } },
  setAvatarMode: (v) => { settings.avatarMode = !!v; applySettings(); },
  voiceOn: () => voiceOn() && !settings.muted,
  speak: (ja, mood, signal) => voice.speak(settings, ja, mood, signal, { words: settings.callKaraoke !== false }),
  say: (p) => { if (win && !win.isDestroyed()) win.webContents.send('ai-say', p); },
  perform: (p) => { if (win && !win.isDestroyed()) win.webContents.send('team-perform', p); },
  note: (t) => { if (brain) { const d = new Date(); brain.note(`${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')} ${t}`); } },
  spokenContext: (history) => speechContext ? speechContext.context(history || []) : '',
  characterReference: (text) => brain && typeof brain.characterReference === 'function' ? brain.characterReference(text) : null,
  persona: () => String(settings.persona || ''),
  openSettings: () => openSettings(),
  // 合奏：把一个声部的谱子放进她自己的合成器窗口
  openSynthWith: (title, text) => {
    openSynth();
    const go = () => { if (synthWin && !synthWin.isDestroyed()) synthWin.webContents.send('synth-load', { title: String(title || '').slice(0, 30), text: String(text || ''), play: false, mine: false }); };
    if (synthWin) synthWin.webContents.isLoading() ? synthWin.webContents.once('did-finish-load', go) : go();
  },
  feature: () => ({ lyrics }),
  // 合奏：看谱子图片用她的看图设置
  visionCfg: () => visionCfg(),
  pickVisionModel: (v) => pickVisionModel(v),
};
