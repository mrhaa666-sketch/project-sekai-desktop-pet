'use strict';
/* 五线谱：把 Jianpu.toStaff() 排好的小节画成 SVG（高音谱表；有很低的音时用大谱表）。
   符号（谱号、休止符、升降号）用随程序带着的 Noto Music 字体（SIL OFL 授权，见 fonts/NotoMusic-OFL.txt），
   符头、符干、符尾、符杠、连音线自己画。
   Staff.draw(svg, data, { width }) → { items: [{ t, dur, el }], pick(y) }：items 用来播放时高亮；pick 把鼠标的高度换成第几个白键 */
(function (root) {
  const NS = 'http://www.w3.org/2000/svg';
  const S = 9;                 // 线间距（像素）
  const F = S * 4;             // 字体大小：字体里 1000 单位 = 4 个线间距，基线在最下面那条线
  const RX = S * 0.64, RY = S * 0.46;
  const STEM = S * 3.4;
  const LETTERS = 'CDEFGAB';
  const GLYPH = { treble: '\u{1D11E}', bass: '\u{1D122}', quarter: '\u{1D13D}', eighth: '\u{1D13E}', '16th': '\u{1D13F}', '32nd': '\u{1D140}',
    sharp: '♯', flat: '♭', natural: '♮', note: '♩' };
  const ACC_GLYPH = { '-2': '♭♭', '-1': GLYPH.flat, 0: GLYPH.natural, 1: GLYPH.sharp, 2: '\u{1D12A}' };
  const ACC_DY = { '-2': 0.1, '-1': 0.1, 0: 0.13, 1: 0.13, 2: 0.0 };   // 让升降号的中心对准符头（字体单位换算成字号的比例）
  // 调号里升号 / 降号的位置（高音谱表，白键序号；低音谱表减 14）
  const SHARP_STEPS = [38, 35, 39, 36, 33, 37, 34], FLAT_STEPS = [34, 37, 33, 36, 32, 35, 31];
  const FLAGS = { eighth: 1, '16th': 2, '32nd': 3 };

  function el(tag, attrs, parent, text) {
    const e = document.createElementNS(NS, tag);
    for (const k in attrs) e.setAttribute(k, attrs[k]);
    if (text !== undefined) e.textContent = text;
    if (parent) parent.appendChild(e);
    return e;
  }

  function itemWidth(it) {
    if (it.whole) return 46;
    const acc = it.pitches.some((p) => p.acc !== null && p.acc !== undefined) ? 11 : 0;
    return 15 + 30 * Math.sqrt(it.dur) + acc + (it.dots ? 6 : 0) + (FLAGS[it.type] && it.kind === 'note' ? 4 : 0);
  }

  function draw(svg, data, { width = 780 } = {}) {
    while (svg.firstChild) svg.removeChild(svg.firstChild);
    const grand = data.clef === 'grand';
    const nKey = Math.abs(data.fifths);
    const headW = (first) => 34 + nKey * 9 + (first ? 26 : 0) + 8;
    const mw = data.measures.map((m) => Math.max(60, m.items.reduce((a, it) => a + itemWidth(it), 0) + 14));
    // 分行
    const systems = [];
    let cur = null;
    data.measures.forEach((m, k) => {
      const avail = width - 12 - headW(systems.length === 0 && !cur);
      if (!cur || cur.w + mw[k] > avail) { cur = { ms: [], w: 0, avail: width - 12 - headW(systems.length === 0) }; systems.push(cur); }
      cur.ms.push(k); cur.w += mw[k];
    });
    const sysH = (22 + 3.6 * S) + 4 * S + (grand ? 6.5 * S + 4 * S : 0) + 3.6 * S;
    svg.setAttribute('width', width);
    svg.setAttribute('height', systems.length * sysH + 8);
    const items = [], staffs = [];
    const ties = [];
    let lastHeads = [];   // 上一个音的符头（连音线用）
    systems.forEach((sys, si) => {
      const top = 8 + si * sysH + 22 + 3.6 * S;
      const tb = top + 4 * S;
      const bTop = tb + 6.5 * S, bb = bTop + 4 * S;
      const yOf = (step, staff) => staff === 'bass' ? bb - (step - 18) * S / 2 : tb - (step - 30) * S / 2;
      staffs.push({ y0: top - 3.5 * S, y1: tb + (grand ? 2.4 * S : 3.5 * S), staff: 'treble', base: tb, baseStep: 30 });
      if (grand) staffs.push({ y0: bTop - 2.4 * S, y1: bb + 3.5 * S, staff: 'bass', base: bb, baseStep: 18 });
      const gStaff = el('g', {}, svg);
      const x0 = 6, x1 = width - 6;
      for (let k = 0; k < 5; k++) el('line', { x1: x0, x2: x1, y1: top + k * S, y2: top + k * S, class: 'ln' }, gStaff);
      if (grand) {
        for (let k = 0; k < 5; k++) el('line', { x1: x0, x2: x1, y1: bTop + k * S, y2: bTop + k * S, class: 'ln' }, gStaff);
        el('line', { x1: x0, x2: x0, y1: top, y2: bb, class: 'bl' }, gStaff);
      }
      // 谱号、调号、拍号
      let x = x0 + 4;
      el('text', { x, y: tb, class: 'g', 'font-size': F }, gStaff, GLYPH.treble);
      if (grand) el('text', { x: x + 1, y: bb, class: 'g', 'font-size': F }, gStaff, GLYPH.bass);
      x += 32;
      const keySteps = data.fifths > 0 ? SHARP_STEPS : FLAT_STEPS;
      for (let k = 0; k < nKey; k++) {
        const g = data.fifths > 0 ? GLYPH.sharp : GLYPH.flat, dy = data.fifths > 0 ? ACC_DY[1] : ACC_DY[-1];
        el('text', { x: x + k * 9, y: yOf(keySteps[k], 'treble') + dy * F, class: 'g', 'font-size': F }, gStaff, g);
        if (grand) el('text', { x: x + k * 9, y: yOf(keySteps[k] - 14, 'bass') + dy * F, class: 'g', 'font-size': F }, gStaff, g);
      }
      x += nKey * 9 + 4;
      if (si === 0) {
        for (const [base, pos] of [[top, 0], ...(grand ? [[bTop, 0]] : [])]) {
          el('text', { x: x + 9, y: base + S * 2 - 1, class: 'num', 'text-anchor': 'middle' }, gStaff, data.beats);
          el('text', { x: x + 9, y: base + S * 4 - 1, class: 'num', 'text-anchor': 'middle' }, gStaff, data.beatUnit);
        }
        el('text', { x: x0 + 2, y: top - 3.5 * S - 4, class: 'tempo' }, gStaff, `${GLYPH.note} = ${data.bpm}`);
        x += 26;
      }
      x += 4;
      const last = si === systems.length - 1;
      const stretch = last && sys.w < sys.avail * 0.7 ? 1 : (sys.avail) / sys.w;
      for (const mi of sys.ms) {
        const m = data.measures[mi];
        const mx0 = x, w = mw[mi] * stretch;
        const scale = w / mw[mi];
        let ix = x + 8 * scale;
        const drawn = [];
        // 和弦名
        for (const c of m.chords) {
          const it = m.items.find((it) => it.t + it.dur > c.t + 1e-6) || m.items[m.items.length - 1];
          const before = m.items.slice(0, m.items.indexOf(it)).reduce((a, b) => a + itemWidth(b), 0);
          el('text', { x: x + 8 * scale + before * scale, y: top - 3.5 * S + 8, class: 'chord' }, gStaff, c.name);
        }
        for (const it of m.items) {
          const iw = itemWidth(it) * scale;
          const g = el('g', { class: 'it' }, svg);
          el('rect', { x: ix - 5, y: top - 2 * S, width: Math.max(14, iw - 4), height: (grand ? bb : tb) - top + 4 * S, rx: 4, class: 'hl' }, g);
          items.push({ t: mi * data.beats + it.t, dur: it.dur, el: g, idx: it.idx });
          if (it.kind === 'rest') {
            const rx = it.whole ? mx0 + w / 2 - S * 0.6 : ix;
            const staffsHere = grand ? [['treble', top], ['bass', bTop]] : [['treble', top]];
            for (const [, st] of (it.whole ? staffsHere : staffsHere.slice(0, 1))) {
              if (it.type === 'whole') el('rect', { x: rx, y: st + S, width: S * 1.2, height: S * 0.5, class: 'beam' }, g);
              else if (it.type === 'half') el('rect', { x: rx, y: st + 2 * S - S * 0.5, width: S * 1.2, height: S * 0.5, class: 'beam' }, g);
              else el('text', { x: rx, y: st + 4 * S, class: 'g', 'font-size': F }, g, GLYPH[it.type] || GLYPH.quarter);
              if (it.dots) el('circle', { cx: rx + S * 1.7, cy: st + 1.5 * S, r: 1.6, class: 'beam' }, g);
            }
            lastHeads = [];
            ix += iw;
            continue;
          }
          // 按谱表分组（大谱表：中央 C 以下放到低音谱表）
          const groups = {};
          for (const p of it.pitches) { const st = grand && p.midi < 60 ? 'bass' : 'treble'; (groups[st] = groups[st] || []).push(p); }
          const heads = [];
          const hasAcc = it.pitches.some((p) => p.acc !== null && p.acc !== undefined);
          const hx = ix + (hasAcc ? 11 : 0) + RX;
          for (const st in groups) {
            const ps = groups[st].sort((a, b) => a.step - b.step);
            const mid = st === 'bass' ? 22 : 34;
            const avg = ps.reduce((a, p) => a + p.step, 0) / ps.length;
            const up = avg < mid;
            const ys = ps.map((p) => yOf(p.step, st));
            // 加线
            const lo = ps[0].step, hi = ps[ps.length - 1].step;
            const bottomStep = st === 'bass' ? 18 : 30, topStep = bottomStep + 8;
            for (let s2 = bottomStep - 2; s2 >= lo; s2 -= 2) el('line', { x1: hx - RX - 4, x2: hx + RX + 4, y1: yOf(s2, st), y2: yOf(s2, st), class: 'ln' }, g);
            for (let s2 = topStep + 2; s2 <= hi; s2 += 2) el('line', { x1: hx - RX - 4, x2: hx + RX + 4, y1: yOf(s2, st), y2: yOf(s2, st), class: 'ln' }, g);
            // 符头（相邻的二度音错开）
            let prevStep = -99, side = 0;
            ps.forEach((p, k) => {
              side = p.step - prevStep === 1 && side === 0 ? 1 : 0;
              prevStep = p.step;
              const cx = hx + (side ? (up ? 2 * RX - 1 : -(2 * RX - 1)) : 0);
              el('ellipse', { cx, cy: ys[k], rx: RX, ry: RY, transform: `rotate(-20 ${cx} ${ys[k]})`, class: 'head' + (it.type === 'half' || it.type === 'whole' ? ' open' : '') }, g);
              if (p.acc !== null && p.acc !== undefined) el('text', { x: hx - RX - 12 - (k % 2 && ps.length > 2 ? 7 : 0), y: ys[k] + ACC_DY[p.acc] * F, class: 'g', 'font-size': F }, g, ACC_GLYPH[p.acc]);
              if (it.dots) { const onLine = (p.step - bottomStep) % 2 === 0; el('circle', { cx: hx + RX + 5 + (side ? 2 * RX : 0), cy: ys[k] - (onLine ? S / 2 : 0), r: 1.7, class: 'beam' }, g); }
              heads.push({ step: p.step, x: cx, y: ys[k], st, up, tieStart: it.tieStart });
            });
            if (it.type !== 'whole') {
              const sx = up ? hx + RX - 0.6 : hx - RX + 0.6;
              const yEnd = up ? Math.min(...ys) - STEM : Math.max(...ys) + STEM;
              const yStart = up ? Math.max(...ys) : Math.min(...ys);
              const stem = el('line', { x1: sx, x2: sx, y1: yStart, y2: yEnd, class: 'stem' }, g);
              drawn.push({ it, g, st, up, sx, yEnd, yStart, stem, ys, flags: FLAGS[it.type] || 0, beat: Math.floor(it.t + 1e-6) });
            }
          }
          // 连音线：接上一个音里同一个音高的符头
          for (const h of heads) {
            const from = lastHeads.find((p) => p.tieStart && p.step === h.step && p.st === h.st);
            if (from) ties.push([from, h]);
          }
          lastHeads = heads;
          ix += iw;
        }
        // 符杠：同一拍里连着的八分 / 十六分音符连起来；单独的画符尾
        const groups = [];
        for (const d of drawn) {
          const g0 = groups[groups.length - 1];
          const prevItem = g0 && g0[g0.length - 1].it;
          const adjacent = prevItem && m.items.indexOf(d.it) === m.items.indexOf(prevItem) + 1;
          if (d.flags && g0 && g0[0].flags && g0[0].beat === d.beat && g0[0].st === d.st && adjacent) g0.push(d);
          else groups.push([d]);
        }
        for (const gr of groups) {
          if (!gr[0].flags) continue;
          if (gr.length === 1) {
            const d = gr[0];
            for (let k = 0; k < d.flags; k++) {
              const y = d.yEnd + (d.up ? k * S * 0.8 : -k * S * 0.8), dir = d.up ? 1 : -1;
              el('path', { d: `M${d.sx} ${y} c ${S * 0.2} ${dir * S * 0.9}, ${S * 1.4} ${dir * S * 1.2}, ${S * 0.9} ${dir * S * 2.6} c ${S * 0.25} ${-dir * S * 1.1}, ${-S * 0.4} ${-dir * S * 1.4}, ${-S * 0.9} ${-dir * S * 1.9} Z`, class: 'beam' }, d.g);
            }
            continue;
          }
          const up = gr.reduce((a, d) => a + (d.up ? 1 : -1), 0) >= 0;
          // 方向统一以后重新算符干
          for (const d of gr) {
            if (d.up !== up) { d.up = up; d.sx = up ? d.sx + 2 * RX - 1.2 : d.sx - 2 * RX + 1.2; d.yStart = up ? Math.max(...d.ys) : Math.min(...d.ys); }
          }
          const a = gr[0], b = gr[gr.length - 1];
          const ext = up ? Math.min(...gr.map((d) => Math.min(...d.ys))) - STEM : Math.max(...gr.map((d) => Math.max(...d.ys))) + STEM;
          const slope = Math.max(-0.12, Math.min(0.12, ((up ? Math.min(...b.ys) : Math.max(...b.ys)) - (up ? Math.min(...a.ys) : Math.max(...a.ys))) / Math.max(1, b.sx - a.sx) * 0.5));
          const beamY = (x) => ext + (x - a.sx) * slope - (up ? Math.max(0, (b.sx - a.sx) * slope) : Math.min(0, (b.sx - a.sx) * slope));
          for (const d of gr) {
            d.stem.setAttribute('x1', d.sx); d.stem.setAttribute('x2', d.sx);
            d.stem.setAttribute('y1', d.yStart); d.stem.setAttribute('y2', beamY(d.sx));
          }
          const T = S * 0.5, dir = up ? 1 : -1;
          const bar = (xa, xb, lvl, gEl) => {
            const off = lvl * S * 0.8 * dir;
            el('path', { d: `M${xa} ${beamY(xa) + off} L${xb} ${beamY(xb) + off} L${xb} ${beamY(xb) + off + T * dir} L${xa} ${beamY(xa) + off + T * dir} Z`, class: 'beam' }, gEl);
          };
          bar(a.sx, b.sx, 0, a.g);
          for (let lvl = 1; lvl < 3; lvl++) {
            for (let k = 0; k < gr.length; k++) {
              if (gr[k].flags <= lvl) continue;
              let j = k;
              while (j + 1 < gr.length && gr[j + 1].flags > lvl) j++;
              if (j > k) bar(gr[k].sx, gr[j].sx, lvl, gr[k].g);
              else { const stub = S * 1.1; bar(k === gr.length - 1 ? gr[k].sx - stub : gr[k].sx, k === gr.length - 1 ? gr[k].sx : gr[k].sx + stub, lvl, gr[k].g); }
              k = j;
            }
          }
        }
        // 大谱表里，低音谱表这一小节没有音：画一个全休止符
        if (grand && !m.items.some((it) => it.pitches.some((p) => p.midi < 60)) && !(m.items.length === 1 && m.items[0].whole)) {
          el('rect', { x: mx0 + w / 2 - S * 0.6, y: bTop + S, width: S * 1.2, height: S * 0.5, class: 'beam' }, gStaff);
        }
        x += w;
        const lastBar = mi === data.measures.length - 1;
        const yb = grand ? bb : tb;
        if (lastBar) {
          el('line', { x1: x - 5, x2: x - 5, y1: top, y2: yb, class: 'bl' }, gStaff);
          el('rect', { x: x - 3, y: top, width: 3.5, height: yb - top, class: 'beam' }, gStaff);
        } else el('line', { x1: x, x2: x, y1: top, y2: yb, class: 'bl' }, gStaff);
      }
      // 这一行最后还没连上的连音线：画半截到行尾
      for (const h of lastHeads) if (h.tieStart && !last) ties.push([h, { x: x1 - 2, y: h.y, open: true, up: h.up }]);
      if (!last) lastHeads = lastHeads.map((h) => ({ ...h, x: x0 + 70 }));
    });
    for (const [a, b] of ties) {
      const dir = a.up ? 1 : -1;
      const ya = a.y + dir * RY * 1.6, yb2 = (b.y ?? a.y) + dir * RY * 1.6;
      const xa = a.x + RX * 0.6, xb = b.x - RX * 0.6;
      if (xb - xa < 4) continue;
      const bulge = Math.min(S * 1.1, (xb - xa) * 0.18) * dir;
      el('path', { d: `M${xa} ${ya} C ${xa + (xb - xa) * 0.3} ${ya + bulge}, ${xb - (xb - xa) * 0.3} ${yb2 + bulge}, ${xb} ${yb2} C ${xb - (xb - xa) * 0.3} ${yb2 + bulge * 0.7}, ${xa + (xb - xa) * 0.3} ${ya + bulge * 0.7}, ${xa} ${ya} Z`, class: 'beam' }, svg);
    }
    // 鼠标的高度 → 哪个谱表的第几个白键
    const pick = (y) => {
      for (const s of staffs) {
        if (y < s.y0 || y > s.y1) continue;
        const step = s.baseStep + Math.round((s.base - y) / (S / 2));
        return { step, staff: s.staff, y: s.base - (step - s.baseStep) * S / 2 };
      }
      return null;
    };
    return { items, pick };
  }

  root.Staff = { draw, S, RX, RY, LETTERS };
})(window);
