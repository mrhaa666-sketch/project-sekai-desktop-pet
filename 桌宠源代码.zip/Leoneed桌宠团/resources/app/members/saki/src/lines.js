// 台词、心情、动作。对你的她：开朗、坦率、很会撒点小娇，但也会认真地关心你；身体不算太好，偶尔会累。
// t = 台词，ja = 配音用的日语（空 = 不配音），m = 心情（决定表情），a = 动作（决定身体动作）。
// {name} 会替换成设置里的称呼（日语里换成「日语称呼」）。
'use strict';

// 表情代号表：代号 → [文件名, 说明]。文件在 model/faces/文件名.motion3.json（三套衣服都有）。
// 文件名保持英文，是为了解压时不会因为中文文件名出乱码；平时只用中文代号。
// 想加新表情：把文件放进三套衣服的 faces/，再在这里加一行。
window.FACES = {
  '平常': ['face_normal_01', '平常的脸，带一点笑意（默认）'],
  '平静': ['face_smallmouth_01', '平静，嘴很小'],
  '微笑1': ['face_smile_01', '开朗的微笑'],
  '微笑2': ['face_smile_06', '温和的微笑'],
  '微笑3': ['face_smile_07', '轻松的微笑，脸有点红'],
  '甜笑': ['face_smile_09', '甜甜地笑，脸红'],
  '脸红微笑': ['face_smile_02', '脸红红地笑'],
  '开心': ['face_smile_03', '很开心，张嘴笑'],
  '大笑': ['face_smile_05', '笑得很开心，脸红'],
  '眯眼笑': ['face_smile_04', '闭着眼笑，脸红'],
  '超开心': ['face_smile_08', '开心到眼睛变成 >< '],
  '安心笑': ['face_ncsmile_04', '闭着眼、放下心来的笑'],
  '咧嘴笑': ['face_e_01', '露出牙齿的笑'],
  '调皮1': ['face_play_01', '有点调皮'],
  '调皮2': ['face_play_02', '调皮地笑'],
  '得意': ['face_smug_01', '得意洋洋'],
  '眨眼': ['face_wink_01', '眨一只眼'],
  '陶醉': ['face_spoony_01', '看到可爱的东西，陶醉'],
  '闪亮1': ['face_sparkling_01', '眼睛发亮（聊到喜欢的东西）'],
  '闪亮2': ['face_sparkling_02', '眼睛发亮地笑'],
  '好奇': ['face_interest_02', '好奇、感兴趣'],
  '害羞1': ['face_shy_01', '害羞，脸红'],
  '害羞2': ['face_shy_02', '害羞地笑'],
  '苦笑': ['face_ossmile_05', '冒汗的苦笑'],
  '苦笑闭眼': ['face_ossmile_04', '闭着眼苦笑'],
  '窘迫': ['face_ossad_01', '难为情，冒汗'],
  '窘迫低头': ['face_oslookdown_01', '难为情地低下视线'],
  '窘迫闭眼': ['face_oscloseeye_03', '难为情地闭紧眼睛'],
  '慌张': ['face_ossurprise_03', '慌了，冒汗'],
  '冒汗困扰': ['face_ostrouble_04', '为难，冒汗'],
  '闭眼': ['face_closeeye_01', '静静地闭着眼'],
  '闭眼微笑': ['face_closeeye_04', '闭着眼微笑'],
  '闭眼放松': ['face_closeeye_02', '闭眼，很放松'],
  '闭眼想': ['face_closeeye_03', '闭着眼想事情'],
  '困': ['face_sleepy_01', '困了，眼睛半睁'],
  '困得睁不开': ['face_sleepy_02', '困得一只眼睁不开'],
  '认真1': ['face_serious_01', '认真起来'],
  '认真2': ['face_serious_02', '认真，有点紧张'],
  '惊讶1': ['face_surprise_01', '“诶！”地张大嘴'],
  '惊讶2': ['face_surprise_02', '惊讶'],
  '惊讶3': ['face_surprise_03', '有点意外，“哦”'],
  '睁大眼': ['face_surprise_04', '眼睛睁圆'],
  '震惊': ['face_shock_01', '受到冲击'],
  '张嘴': ['face_eat_01', '“啊——”地张开嘴'],
  '嚼': ['face_eat_02', '嘴里在吃东西'],
  '><': ['face_baffling_01', '眼睛变成 ><，脑子乱了'],
  '委屈><': ['face_sad_04', '委屈地 ><'],
  '难受><': ['face_sad_05', '难受地 ><'],
  '哭唧唧><': ['face_sad_06', '快哭了的 ><'],
  '困扰1': ['face_trouble_01', '困扰'],
  '困扰2': ['face_trouble_02', '困扰，有点慌'],
  '困扰3': ['face_trouble_03', '为难'],
  '困扰4': ['face_trouble_04', '很为难'],
  '担心': ['face_worry_01', '担心地看着你'],
  '难过1': ['face_sad_01', '难过'],
  '难过2': ['face_sad_03', '难过，垂着眉'],
  '难过闭眼': ['face_sad_02', '难过地闭上眼'],
  '低头': ['face_lookdown_01', '眼睛往下看'],
  '低头2': ['face_lookdown_02', '低着头，有点落寞'],
  '眼眶湿': ['face_cry_01', '眼眶湿了'],
  '含泪': ['face_cry_02', '含着泪'],
  '感动': ['face_cry_03', '感动得眼眶发红，脸红'],
  '快哭了': ['face_cry_04', '快要哭了'],
  '含泪笑': ['face_cry_05', '含着泪笑'],
  '哭': ['face_cry_06', '哭了，脸红'],
  '流泪': ['face_cry_07', '掉眼泪'],
  '哭2': ['face_cry_08', '哭得很伤心'],
  '喜极而泣': ['face_cry_09', '闭着眼，又哭又笑'],
  '不满': ['face_angry_01', '不满，皱眉'],
  '鼓脸': ['face_angry_02', '鼓起脸生气，脸红'],
  '哼': ['face_angry_03', '闭着眼“哼”一声，脸红'],
  '不快1': ['face_disgust_01', '不快，皱眉'],
  '不快2': ['face_disgust_02', '嫌弃'],
  '不快3': ['face_disgust_03', '不太高兴'],
  '不快4': ['face_disgust_04', '有点不耐烦'],
  '脸红嫌弃': ['face_disgust_05', '红着脸嫌弃'],
};

// 心情 → 表情 + 动作。
// faces：[表情代号, 强度]，强度 0~1（1 是完整的表情，小一点会更接近「平常」）。
// rare：偶尔才出现的表情，chance 是出现概率。
// actions：这个心情常用的身体动作；AI 没选动作时从这里挑。
window.MOODS = {
  calm:       { faces: [['平常', 1], ['微笑2', 0.7]], rare: { chance: 0.25, faces: [['平静', 1], ['微笑1', 0.6]] }, actions: ['none', 'nod', 'tilt'], desc: '平常的样子（默认，她平常就带着一点笑）' },
  smile:      { faces: [['微笑1', 0.9], ['微笑2', 0.9], ['微笑3', 0.85], ['甜笑', 0.85]], actions: ['nod', 'tilt'], desc: '心情不错，笑眯眯的' },
  happy:      { faces: [['开心', 0.9], ['大笑', 0.85], ['眯眼笑', 0.9], ['咧嘴笑', 0.85]], actions: ['glad', 'nod'], desc: '开心' },
  excited:    { faces: [['闪亮1', 0.95], ['闪亮2', 0.95], ['超开心', 0.9]], actions: ['excited', 'glad'], desc: '兴奋、眼睛发亮（聊到可爱的东西、Leo/need、初音未来、出去玩时常有）' },
  playful:    { faces: [['调皮1', 0.9], ['调皮2', 0.9], ['眨眼', 1], ['得意', 0.85]], actions: ['wink', 'proud'], desc: '调皮、开玩笑、有点小得意' },
  proud:      { faces: [['得意', 0.9], ['咧嘴笑', 0.85]], actions: ['proud', 'cheer'], desc: '得意（“交给我吧！”“厉害吧？”）' },
  warm:       { faces: [['安心笑', 0.9], ['闭眼微笑', 0.85], ['甜笑', 0.85]], actions: ['warm', 'nod'], desc: '被打动、心里暖暖的、放下心来' },
  moved:      { faces: [['感动', 0.9], ['含泪笑', 0.85], ['喜极而泣', 0.85]], actions: ['warm', 'glad'], desc: '感动得快哭了（但是开心的）' },
  shy:        { faces: [['害羞1', 0.85], ['害羞2', 0.85], ['脸红微笑', 0.8]], actions: ['shy', 'fidget'], desc: '害羞、不好意思' },
  flustered:  { faces: [['窘迫', 0.85], ['慌张', 0.85], ['窘迫闭眼', 0.85], ['><', 0.9]], actions: ['shy', 'look_away'], desc: '被说中、慌了、很难为情' },
  curious:    { faces: [['好奇', 0.9], ['睁大眼', 0.8]], actions: ['tilt', 'think'], desc: '好奇、想知道更多' },
  think:      { faces: [['平静', 1], ['闭眼想', 0.75], ['好奇', 0.6]], actions: ['think', 'tilt'], desc: '在想事情' },
  determined: { faces: [['认真1', 0.85], ['认真2', 0.8], ['咧嘴笑', 0.8]], actions: ['resolve', 'cheer'], desc: '下定决心、干劲满满（“一起加油吧！”）' },
  yummy:      { faces: [['陶醉', 0.9], ['嚼', 0.9], ['眯眼笑', 0.85]], actions: ['yummy', 'glad'], desc: '吃到好吃的、看到可爱的东西，很幸福' },
  sad:        { faces: [['难过1', 0.75], ['难过2', 0.75], ['低头2', 0.7]], actions: ['look_down', 'sigh'], desc: '低落、难过' },
  hurt:       { faces: [['眼眶湿', 0.8], ['快哭了', 0.75], ['含泪', 0.75]], actions: ['look_down', 'sigh'], desc: '受伤、很难受' },
  pouty:      { faces: [['委屈><', 0.9], ['哭唧唧><', 0.85], ['鼓脸', 0.8]], actions: ['shake', 'fidget'], desc: '委屈、撒娇地抱怨（“好过分～”）' },
  worried:    { faces: [['担心', 0.9], ['困扰1', 0.8]], actions: ['trouble', 'tilt'], desc: '担心你' },
  troubled:   { faces: [['困扰2', 0.8], ['困扰3', 0.8], ['苦笑', 0.85], ['冒汗困扰', 0.8]], actions: ['trouble', 'shake'], desc: '困扰、为难' },
  surprised:  { faces: [['惊讶1', 0.85], ['惊讶2', 0.9], ['惊讶3', 0.9], ['睁大眼', 0.85]], actions: ['tilt', 'nod'], desc: '吃惊、意外' },
  sleepy:     { faces: [['困', 1], ['困得睁不开', 1], ['闭眼', 1]], actions: ['sleep'], desc: '困了、有点累' },
  sulky:      { faces: [['鼓脸', 0.8], ['哼', 0.85], ['不快3', 0.7]], actions: ['arms', 'look_away', 'angry'], desc: '闹别扭、鼓起脸' },
  angry:      { faces: [['不满', 1], ['鼓脸', 0.95], ['不快1', 0.85]], actions: ['angry', 'arms'], desc: '生气（她生气时更像鼓着脸，气消得很快）' },
};

// 动作 → 身体动作（随机挑一个）。
// 同一个动作准备了几种站姿下的版本：桌宠会优先挑和她现在站姿一样的那个，衔接不会突然换手、换姿势。
// 挥手、举起双手、身体大幅前倾的动作都不用（会伸出窗口或上下移动）。
window.ACTIONS = {
  none:      { bodies: [], desc: '不做动作' },
  nod:       { bodies: ['w-normal-nod01', 'w-normal-nod03', 'w-normal-nod04', 'w-normal-nod05', 'w-normal-nod02', 'w-normal-nod01r', 'w-cute-nod02', 'w-happy-nod05'], desc: '点头' },
  tilt:      { bodies: ['w-normal-tilthead01', 'w-normal-tilthead03', 'w-normal-tilthead04', 'w-normal-tilthead05', 'w-normal-tilthead02', 'w-normal-tilthead01r', 'w-cute-tilthead04', 'w-cute-tilthead01'], desc: '歪头' },
  think:     { bodies: ['w-adult-think01', 'w-adult-think02', 'w-normalcool-tilthead0204', 'w-cool-tilthead03'], desc: '想事情（手托下巴）' },
  glad:      { bodies: ['w-normal-glad01', 'w-normal-glad02', 'w-cute-glad05', 'w-cute-glad03', 'w-adult-glad02'], desc: '开心地双手合在胸前' },
  excited:   { bodies: ['w-cute-glad04', 'w-cute-glad06', 'w-cute-glad01', 'w-adult-glad01'], desc: '兴奋得双手捧在脸边' },
  cheer:     { bodies: ['w-happy-glad01', 'w-happy-nod02', 'w-happy-tilthead02'], desc: '双手叉腰，元气满满（“交给我吧！”）' },
  proud:     { bodies: ['w-cute-smug01', 'w-happy-nod02', 'w-happy-tilthead01'], desc: '叉腰得意（“厉害吧？”）' },
  resolve:   { bodies: ['w-normal-purpose01', 'w-happy-purpose01'], desc: '握拳、下定决心' },
  warm:      { bodies: ['w-normal-relief01', 'w-adult-relief01'], desc: '手按在胸口（安心、被打动）' },
  shy:       { bodies: ['w-normal-shy01', 'w-normal-blushed01', 'w-cute-shy01', 'w-adult-blushed01'], desc: '害羞地缩一下' },
  fidget:    { bodies: ['w-normal-fidget01', 'w-cute-fidget01'], desc: '手指绞在一起，扭扭捏捏' },
  greet:     { bodies: ['w-normal-greeting01'], desc: '打招呼、轻轻鞠一躬' },
  wink:      { bodies: ['w-cute-wink02'], desc: '俏皮地眨眼' },
  yummy:     { bodies: ['w-cute-delicious01', 'w-adult-delicious01'], desc: '双手捧着脸，好幸福（好吃、好可爱）' },
  look_down: { bodies: ['w-normal-sad01', 'w-happy-sad01', 'w-happy-sad02'], desc: '垂下视线（低落）' },
  sigh:      { bodies: ['w-normal-sigh01', 'w-happy-sigh01', 'w-cool-sigh02'], desc: '叹气' },
  trouble:   { bodies: ['w-normal-trouble01', 'w-normal-trouble02', 'w-adult-trouble02'], desc: '为难、担心' },
  shake:     { bodies: ['w-normal-shakehead01', 'w-normal-shakehead03', 'w-normal-shakehead04', 'w-normal-shakehead05', 'w-normal-shakehead02', 'w-normal-shakehead01r', 'w-cute-shakehead02'], desc: '摇头' },
  look_away: { bodies: ['w-normal-lookaway01', 'w-happy-lookaway01'], desc: '移开视线、看看旁边' },
  arms:      { bodies: ['w-cool-shakehead02', 'w-cool-sigh02', 'w-cool-nod02'], desc: '抱起胳膊' },
  angry:     { bodies: ['w-normal-angry01', 'w-happy-angry01', 'w-cute-angry01'], desc: '生气（叉腰、跺一下）' },
  music:     { bodies: ['w-normal-yurayura01', 'w-normal-nod03', 'w-normal-nod05', 'w-cute-nod02'], desc: '跟着节奏轻轻摇晃（听歌、弹琴时）' },
  sleep:     { bodies: ['w-adult-sleep01', 'w-adult-sleep02'], desc: '打瞌睡' },
};

// AI 直接点名表情代号时的强度
window.FACE_STRENGTH_DEFAULT = 0.85;
// 脸上的阴影（ParamFaceShadow）一律不加（她的表情里没有阴影效果）
window.SHADOW_FACES = new Set([]);
window.FACE_STRENGTH_FULL = new Set(['平常', '平静', '闭眼', '困', '困得睁不开', '眨眼', '超开心', '><', '委屈><', '难受><', '哭唧唧><']);

window.LINES = {
  // 没接聊天模型时，凌晨一点和纪念日用的固定台词
  nightcord: [{ t: '{name}，已经一点了哦！还不睡的话，明天会变成熊猫眼的～', ja: '{name}、もう一時だよ！まだ寝ないと、明日パンダみたいな目になっちゃうよ～', m: 'worried', a: 'trouble' }],
  birthdaySaki: [{ t: '今天是我的生日！……嘿嘿，{name}记得的话，我会超——开心的！', ja: '今日はアタシの誕生日！……えへへ、{name}が覚えててくれたら、すっごく嬉しいな！', m: 'excited', a: 'excited' }],
  birthdayUser: [{ t: '{name}，生日快乐！今天你就是主角哦，想做什么我都陪你！', ja: '{name}、誕生日おめでとう！今日の主役はキミだよ。やりたいこと、なんでも付き合うからね！', m: 'happy', a: 'glad' }],
  anniversary: [{ t: '今天是我们的纪念日！……我可是一直数着日子的哦。', ja: '今日はアタシたちの記念日だね！……ずっと数えてたんだから。', m: 'shy', a: 'fidget' }],
  // 你用合成器弹曲子给她听
  synthListen: [
    { t: '嗯嗯，我在听！', ja: 'うんうん、聴いてるよ！', m: 'smile', a: 'music' },
    { t: '是{name}写的吗？好厉害！再弹一遍嘛～', ja: '{name}が作ったの？すごい！もう一回弾いて～', m: 'excited', a: 'excited' },
    { t: '电子琴的声音，果然很可爱呢。', ja: 'キーボードの音って、やっぱり可愛いよね。', m: 'happy', a: 'music' },
    { t: '这里的旋律我好喜欢！感觉心情都变轻快了。', ja: 'ここのメロディ、すっごく好き！気分まで軽くなっちゃう。', m: 'happy', a: 'glad' },
  ],
  outfitCasual: [
    { t: '换好衣服啦！怎么样，今天这身可爱吗？', ja: '着替えたよ！どう？今日のコーデ、可愛い？', m: 'playful', a: 'wink' },
    { t: '今天也辛苦啦！接下来就是放松时间～', ja: '今日もお疲れさま！ここからはのんびりタイムだね～', m: 'happy', a: 'glad' },
    { t: '换下来了。……待会儿要不要一起聊聊天？', ja: '着替えちゃった。……あとで一緒におしゃべりしない？', m: 'smile', a: 'tilt' },
  ],
  outfitUniform: [
    { t: '要去学校啦！今天也要元气满满地出发！', ja: 'そろそろ学校だ！今日も元気に行ってきまーす！', m: 'determined', a: 'cheer' },
    { t: '制服换好了。嗯，领结也系好了！', ja: '制服、着たよ。うん、リボンもばっちり！', m: 'smile', a: 'nod' },
  ],
  outfitUnit: [
    { t: '今天是练习的日子！我去和一歌她们会合啦！', ja: '今日は練習の日！いっちゃんたちと合流してくるね！', m: 'excited', a: 'cheer' },
    { t: '换上演出服了！……有点紧张，不过更多的是期待！', ja: 'ステージ衣装、着てみた！……ちょっと緊張するけど、それより楽しみ！', m: 'determined', a: 'resolve' },
  ],
  greet: {
    morning: [
      { t: '早上好，{name}！今天也要一起加油哦！', ja: 'おはよう、{name}！今日も一緒にがんばろうね！', m: 'happy', a: 'greet' },
      { t: '早～……唔，还有一点点困。', ja: 'おはよ～……うーん、まだちょっとだけ眠いかも。', m: 'sleepy', a: 'tilt' },
    ],
    day: [
      { t: '啊，{name}！等你好久啦！', ja: 'あっ、{name}！待ってたんだよ！', m: 'excited', a: 'glad' },
      { t: '{name}，正好想见你呢。嘿嘿。', ja: '{name}、ちょうど会いたいなって思ってたんだ。えへへ。', m: 'shy', a: 'shy' },
    ],
    evening: [
      { t: '欢迎回来！今天发生了什么开心的事吗？', ja: 'おかえり！今日はなにか楽しいことあった？', m: 'smile', a: 'tilt' },
      { t: '辛苦啦，{name}。……我一直在等你哦。', ja: 'お疲れさま、{name}。……ずっと待ってたんだよ。', m: 'warm', a: 'warm' },
    ],
    night: [
      { t: '这么晚了……{name}也还没睡呀。', ja: 'こんな時間……{name}もまだ起きてたんだ。', m: 'worried', a: 'tilt' },
      { t: '晚上好！就聊一会儿，然后要好好睡觉哦。', ja: 'こんばんは！ちょっとだけおしゃべりしたら、ちゃんと寝ようね。', m: 'smile', a: 'nod' },
    ],
  },

  // 点头部
  head: [
    { t: '诶嘿嘿，摸头？……再多摸一下也可以哦。', ja: 'えへへ、なでなで？……もうちょっとしてもいいよ。', m: 'shy', a: 'shy' },
    { t: '哇，头发！好不容易才弄好的发型啦～', ja: 'わっ、髪！せっかくセットしたのに～', m: 'pouty', a: 'fidget' },
    { t: '……嗯，感觉好安心。', ja: '……うん、なんだか安心する。', m: 'warm', a: 'warm' },
    { t: '{name}，你是把我当小孩子了吧？……不过，不讨厌。', ja: '{name}、アタシのこと子ども扱いしてない？……でも、嫌いじゃないよ。', m: 'shy', a: 'look_away' },
  ],

  // 点身体
  body: [
    { t: '怎么啦？', ja: 'どうしたの？', m: 'curious', a: 'tilt' },
    { t: '嗯嗯，我在听哦！', ja: 'うんうん、聞いてるよ！', m: 'smile', a: 'nod' },
    { t: '{name}，今天过得怎么样？', ja: '{name}、今日はどうだった？', m: 'smile', a: 'tilt' },
    { t: '在忙吗？那我就在旁边乖乖陪着你。', ja: '忙しい？じゃあアタシ、横でおとなしくしてるね。', m: 'smile', a: 'nod' },
    { t: '有烦恼的话，要跟我说哦。我可是很会听人说话的！', ja: '悩みがあったら言ってね。アタシ、聞き上手なんだから！', m: 'proud', a: 'proud' },
    { t: '最近在练一段新的键盘伴奏！练好了第一个弹给你听！', ja: '最近、新しいキーボードのフレーズ練習してるんだ！弾けるようになったら、一番に聴かせるね！', m: 'excited', a: 'cheer' },
    { t: '下次一起去逛街吧！我想去看新开的那家杂货店～', ja: '今度一緒にお買い物行こうよ！新しくできた雑貨屋さん、見てみたいな～', m: 'excited', a: 'excited' },
    { t: '和{name}在一起的时候，感觉每天都闪闪发光的。', ja: '{name}といると、毎日がキラキラしてる感じがするんだ。', m: 'warm', a: 'warm' },
    { t: '累了的话，休息一下吧！我陪着你。', ja: '疲れたら、ちょっと休もう！アタシがついてるから。', m: 'warm', a: 'nod' },
    { t: '……再这样待一会儿，好不好？', ja: '……もうちょっとだけ、こうしてていい？', m: 'shy', a: 'fidget' },
    { t: '{name}，有好好吃饭吗？', ja: '{name}、ご飯ちゃんと食べた？', m: 'worried', a: 'tilt' },
    { t: '你听过未来的新歌了吗？超级可爱的！', ja: 'ミクちゃんの新曲、もう聴いた？すっごく可愛いんだよ！', m: 'excited', a: 'glad' },
  ],

  // 连续点很多下（越点越不高兴）
  poke: [
    { t: '等、等一下啦，{name}！好痒！', ja: 'ちょ、ちょっと待って、{name}！くすぐったいってば！', m: 'flustered', a: 'shy' },
    { t: '……那个，戳太多下了吧？', ja: '……あの、つつきすぎじゃない？', m: 'troubled', a: 'trouble' },
  ],
  pokeAngry: [
    { t: '真是的！{name}，我要生气啦！', ja: 'もうっ！{name}、怒るよ！', m: 'angry', a: 'angry' },
    { t: '说了不要再戳了嘛——！', ja: 'もうやめてって言ってるのに～！', m: 'pouty', a: 'shake' },
  ],
  // 生气时偶尔苦笑着数落你
  pokeMask: [
    { t: '……{name}有时候比我哥哥还像小孩子耶。', ja: '……{name}って、たまにお兄ちゃんより子どもっぽいよね。', m: 'troubled', a: 'sigh' },
    { t: '好啦好啦，我知道你很闲了～', ja: 'はいはい、ヒマなのはわかったから～', m: 'troubled', a: 'shake' },
  ],
  // 刚生过气时摸她
  stillSulky: [
    { t: '……哼。现在不理你。', ja: '……ふーんだ。今は知らない。', m: 'sulky', a: 'look_away' },
    { t: '……再等一下下。我还没消气呢。', ja: '……もうちょっと待って。まだ怒ってるんだから。', m: 'sulky', a: 'arms' },
  ],

  // 拖动后放下
  drop: [
    { t: '这里吗？好，就待在这儿！', ja: 'ここ？うん、ここにいるね！', m: 'smile', a: 'nod' },
    { t: '哇哇……突然拎起来，吓我一跳！', ja: 'わわっ……急に持ち上げるから、びっくりした！', m: 'surprised', a: 'shake' },
  ],

  // 待机时的自言自语：按时段、衣服挑；同一句近期不会重复（见 renderer.js 的 nextIdleLine）
  // when: morning 5–11 / day 11–17 / evening 17–23 / night 23–5；不写就是什么时候都行
  // outfit: uniform 校服 / unit 队服 / casual 常服；不写就是都行
  idle: [
    { t: '……', ja: '', m: 'calm', a: 'look_away' },
    { t: '副歌那里的伴奏，换成分解和弦会不会更闪亮一点呢……', ja: 'サビのところ、アルペジオにしたらもっとキラキラするかな……', m: 'think', a: 'think' },
    { t: '你忙的话，我就安静地待着！……大概。', ja: '忙しいなら、静かにしてるね！……たぶん。', m: 'playful', a: 'wink' },
    { t: '刚才想到一个超可爱的音色！得赶紧记下来！', ja: 'さっき、すっごく可愛い音色思いついちゃった！忘れないうちにメモしなきゃ！', m: 'excited', a: 'excited' },
    { t: '一歌又练吉他练到很晚了吧。……我也不能输！', ja: 'いっちゃん、またギター遅くまで練習してるのかな。……アタシも負けてられない！', m: 'determined', a: 'resolve' },
    { t: '穗波做的点心真的好好吃……光是想想就饿了。', ja: 'ほなちゃんのお菓子、ほんとに美味しいんだよね……考えただけでお腹すいてきちゃった。', m: 'yummy', a: 'yummy' },
    { t: '志步说我练习的时候太爱讲话了……才没有呢！', ja: 'しほちゃんに「練習中しゃべりすぎ」って言われちゃった……そんなことないもん！', m: 'pouty', a: 'shake' },
    { t: '……这样待着，好幸福呀。', ja: '……こうしてるの、幸せだなぁ。', m: 'warm', a: 'warm' },
    { t: '哥哥今天又在家里大声练台词了……邻居会不会听到啊。', ja: 'お兄ちゃん、今日も家で大きな声でセリフの練習してた……ご近所さんに聞こえてないかな。', m: 'troubled', a: 'trouble' },
    { t: '以前在医院的时候，一直想着“好想和大家一起上学”。……现在每天都很开心哦。', ja: '前に入院してた頃、ずっと「みんなと学校行きたいな」って思ってたんだ。……今は毎日、楽しいよ。', m: 'warm', a: 'warm' },
    { t: '……刚才在想什么来着？一下子忘了。', ja: '……さっき何考えてたんだっけ？忘れちゃった。', m: 'think', a: 'tilt' },
    { t: '不说话也没关系哦！我就在这里。', ja: 'しゃべらなくても大丈夫だよ！アタシはここにいるから。', m: 'smile', a: 'nod' },
    { t: '一直盯着屏幕，眼睛会累的哦。', ja: '画面ばっかり見てると、目が疲れちゃうよ。', m: 'worried', a: 'tilt' },
    { t: '下次拍大头贴的时候，{name}也要一起来！', ja: '今度プリ撮るとき、{name}も一緒だからね！', m: 'excited', a: 'cheer' },
    { t: '……你刚才是不是叹气了？', ja: '……今、ため息ついた？', m: 'worried', a: 'tilt' },
    { t: '早上的空气凉凉的，好舒服！', ja: '朝の空気、ひんやりして気持ちいいね！', m: 'smile', a: 'none', when: 'morning' },
    { t: '呼啊……还有一点困。今天也要加油……', ja: 'ふわぁ……まだちょっと眠い。今日もがんばろ……', m: 'sleepy', a: 'tilt', when: 'morning' },
    { t: '早饭吃了吗？不吃的话，上午会没力气的！', ja: '朝ごはん食べた？食べないと午前中もたないよ！', m: 'worried', a: 'tilt', when: 'morning' },
    { t: '午休快结束了……下午的课好想睡觉。', ja: 'もうすぐ昼休み終わっちゃう……午後の授業、眠くなりそう。', m: 'sleepy', a: 'sigh', when: 'day', outfit: 'uniform' },
    { t: '下午的阳光暖洋洋的～', ja: '午後の日差し、ぽかぽかだね～', m: 'smile', a: 'look_away', when: 'day' },
    { t: '练习结束！今天大家的声音合得超好！', ja: '練習おわり！今日はみんなの音、すっごく揃ってた！', m: 'happy', a: 'glad', when: 'day', outfit: 'unit' },
    { t: '演出服的这个设计，果然好可爱！', ja: 'ステージ衣装のここのデザイン、やっぱり可愛いよね！', m: 'excited', a: 'excited', outfit: 'unit' },
    { t: '放学啦！今天也辛苦了～', ja: '放課後だー！今日もお疲れさま～', m: 'happy', a: 'cheer', when: 'evening', outfit: 'casual' },
    { t: '天黑得越来越早了呢。', ja: '暗くなるの、どんどん早くなってるね。', m: 'calm', a: 'look_away', when: 'evening' },
    { t: '晚饭吃什么好呢……{name}呢？', ja: '晩ごはん何にしよっかな……{name}は？', m: 'think', a: 'tilt', when: 'evening' },
    { t: '作业写完啦！睡前再练一会儿键盘吧。', ja: '宿題終わり！寝る前にちょっとだけキーボード練習しよっと。', m: 'determined', a: 'resolve', when: 'evening' },
    { t: '……已经这么晚了。{name}还不睡吗？', ja: '……もうこんな時間。{name}、まだ寝ないの？', m: 'worried', a: 'tilt', when: 'night' },
    { t: '熬夜对身体不好的……这一点我可是最清楚的。', ja: '夜更かしは体に悪いよ……それ、アタシが一番よく知ってるんだから。', m: 'worried', a: 'trouble', when: 'night' },
    { t: '……这身衣服好舒服，好想就这样窝着。', ja: '……この服、楽ちんでずっとゴロゴロしてたくなっちゃう。', m: 'smile', a: 'none', outfit: 'casual' },
    { t: '制服的领结今天好像系歪了……没问题吧？', ja: '制服のリボン、今日ちょっと曲がってるかも……大丈夫かな？', m: 'troubled', a: 'look_away', outfit: 'uniform' },
  ],

  water: [
    { t: '{name}，喝点水吧！我看着你喝哦。', ja: '{name}、お水飲も！ちゃんと見てるからね。', m: 'smile', a: 'tilt' },
    { t: '好久没喝水了吧？快去倒一杯！', ja: 'しばらくお水飲んでないでしょ？一杯ついでおいで！', m: 'worried', a: 'tilt' },
  ],

  rest: [
    { t: '看屏幕太久啦，站起来伸个懒腰吧！', ja: '画面見すぎだよ～。立ってのびーってしよう！', m: 'worried', a: 'tilt' },
    { t: '休息五分钟吧！我等你回来。', ja: '五分だけ休憩しよっ！待ってるね。', m: 'smile', a: 'nod' },
  ],

  sleep: [
    { t: '已经很晚了……{name}，去睡觉吧。', ja: 'もう遅いよ……{name}、そろそろ寝よう。', m: 'worried', a: 'sigh' },
    { t: '身体搞坏了，可就什么都做不了了。……我是认真的哦。', ja: '体壊したら、何もできなくなっちゃうんだよ。……本気で言ってるからね。', m: 'worried', a: 'trouble' },
    { t: '剩下的明天再做吧。晚安，{name}！', ja: '続きはまた明日にしよ。おやすみ、{name}！', m: 'sleepy', a: 'sleep' },
  ],

  doze: [{ t: '……呼啊，有点困了……', ja: '……ふわぁ、ちょっと眠くなってきちゃった……', m: 'sleepy', a: 'sleep' }],
  wake: [{ t: '……啊！{name}，你回来啦！', ja: '……あっ！{name}、おかえり！', m: 'surprised', a: 'tilt' }],

  // 聊天时没接 API
  noApi: [{ t: '……好像还没连上呢。右键 → 设置，填好 API 就能聊天啦。', m: 'troubled', a: 'tilt' }],
  apiError: [{ t: '……诶？刚才没听清，能再说一次吗？', ja: '……あれ？今のよく聞こえなかった。もう一回言ってくれる？', m: 'troubled', a: 'tilt' }],
};

// 平时站着的姿势和表情（一只手轻轻放在胸前）
window.IDLE = { b: 'w-normal-pose01', f: '平常' };

// 站姿：每个身体动作开始和结束时更接近哪种站姿（按手臂、手、腿的参数和官方的站姿动作比出来的）。
// 站姿的名字就是这个站姿的待机动作（循环播放）。
// 桌宠据此挑动作：同一站姿的版本优先；动作做完就停在它结束时的站姿上，不会突然跳回别的姿势。
window.HOME_STANCE = 'w-normal-pose01';
window.MOTION_STANCE = {
  'w-adult-delicious01': ['w-adult-posetrouble02', 'w-adult-posetrouble02'],
  'w-adult-glad01': ['w-adult-posetilthead01', 'w-adult-posetilthead01'],
  'w-adult-glad02': ['w-adult-posetrouble02', 'w-adult-posetrouble02'],
  'w-adult-relief01': ['w-adult-posetilthead01', 'w-adult-posetilthead01'],
  'w-adult-think02': ['w-adult-posetilthead03', null],
  'w-adult-trouble02': ['w-adult-posetrouble02', 'w-adult-posetrouble02'],
  'w-animal-fidget01': [null, 'w-cute-poseforward02'],
  'w-cool-nod02': ['w-cool-posenod03', 'w-cool-posenod03'],
  'w-cool-shakehead02': ['w-cool-posenod03', 'w-cool-posenod03'],
  'w-cool-sigh02': ['w-cool-posenod03', 'w-cool-posenod03'],
  'w-cool-tilthead03': ['w-cool-posetilthead03', 'w-cool-posetilthead03'],
  'w-cute-delicious01': ['w-cute-posetilthead04', null],
  'w-cute-fidget01': [null, 'w-cute-posetilthead07'],
  'w-cute-glad01': [null, 'w-cute-posetilthead04'],
  'w-cute-glad03': ['w-cute-posetilthead07', null],
  'w-cute-glad05': ['w-cute-posetilthead07', 'w-cute-posetilthead07'],
  'w-cute-nod02': ['w-cute-posenod02', null],
  'w-cute-shakehead02': ['w-cute-posenod02', 'w-cute-posenod02'],
  'w-cute-shy01': ['w-cute-posetilthead04', null],
  'w-cute-smug01': ['w-cute-posenod01', null],
  'w-cute-tilthead01': ['w-cute-posenod01', 'w-cute-posenod01'],
  'w-cute-tilthead04': ['w-cute-posetilthead04', 'w-cute-posetilthead04'],
  'w-cute-wink02': [null, 'w-adult-posenod02'],
  'w-cutenormal-tilthead0705': ['w-cute-posetilthead07', 'w-normal-pose05'],
  'w-happy-angry01': ['w-cool-posenod02', 'w-cool-posenod02'],
  'w-happy-nod05': ['w-normal-pose02', 'w-normal-pose02'],
  'w-happy-sad02': ['w-normal-pose02', null],
  'w-happy-sigh01': ['w-cool-posenod02', 'w-cool-posenod02'],
  'w-happy-tilthead01': ['w-cool-posenod02', null],
  'w-happy-tilthead04': ['w-normal-pose02', null],
  'w-normal-angry01': ['w-normal-pose03', null],
  'w-normal-blushed01': ['w-normal-pose01', 'w-normal-pose01'],
  'w-normal-greeting01': ['w-normal-pose05', 'w-normal-pose05'],
  'w-normal-lookaway01': ['w-normal-pose05', 'w-normal-pose05'],
  'w-normal-nod01': ['w-normal-pose01', 'w-normal-pose01'],
  'w-normal-nod01r': ['w-normal-posetrouble02', 'w-normal-posetrouble02'],
  'w-normal-nod02': ['w-normal-posenod02', 'w-normal-posenod02'],
  'w-normal-nod03': ['w-normal-pose03', 'w-normal-pose03'],
  'w-normal-nod04': ['w-normal-pose04', 'w-normal-pose04'],
  'w-normal-nod05': ['w-normal-pose05', 'w-normal-pose05'],
  'w-normal-relief01': ['w-normal-pose01', 'w-normal-pose01'],
  'w-normal-sad01': ['w-normal-posenod02', 'w-normal-posenod02'],
  'w-normal-shakehead01': ['w-normal-pose01', 'w-normal-pose01'],
  'w-normal-shakehead01r': ['w-normal-posetrouble02', 'w-normal-posetrouble02'],
  'w-normal-shakehead02': ['w-normal-posenod02', 'w-normal-posenod02'],
  'w-normal-shakehead03': ['w-normal-pose03', 'w-normal-pose03'],
  'w-normal-shakehead04': ['w-normal-pose04', 'w-normal-pose04'],
  'w-normal-shakehead05': ['w-normal-pose05', 'w-normal-pose05'],
  'w-normal-shy01': ['w-normal-pose05', 'w-normal-pose05'],
  'w-normal-sigh01': ['w-normal-posenod02', 'w-normal-posenod02'],
  'w-normal-tilthead01': ['w-normal-pose01', 'w-normal-pose01'],
  'w-normal-tilthead0103': ['w-normal-pose01', 'w-normal-pose03'],
  'w-normal-tilthead01r': ['w-normal-posetrouble02', 'w-normal-posetrouble02'],
  'w-normal-tilthead02': ['w-normal-posenod02', 'w-normal-posenod02'],
  'w-normal-tilthead03': ['w-normal-pose03', 'w-normal-pose03'],
  'w-normal-tilthead0301': ['w-normal-pose03', 'w-normal-pose01'],
  'w-normal-tilthead0305': ['w-normal-pose03', 'w-normal-pose05'],
  'w-normal-tilthead04': ['w-normal-pose04', 'w-normal-pose04'],
  'w-normal-tilthead0406': ['w-normal-pose04', 'w-normal-pose01'],
  'w-normal-tilthead05': ['w-normal-pose05', 'w-normal-pose05'],
  'w-normal-tilthead0503': ['w-normal-pose05', 'w-normal-pose03'],
  'w-normal-tilthead0506': ['w-normal-pose05', 'w-normal-pose01'],
  'w-normal-trouble01': ['w-normal-pose01', 'w-normal-pose01'],
  'w-normal-trouble02': ['w-normal-posetrouble02', 'w-normal-posetrouble02'],
  'w-normal-yurayura01': ['w-cool-posesad01', null],
  'w-normalcool-tilthead0204': ['w-normal-posenod02', 'w-cool-posetilthead04'],
};

// 待机小动作（不说话）：按现在的站姿挑。包括几个“换站姿”的动作，让她偶尔自然地换一下姿势。
window.IDLE_MOVES = {
  'w-normal-pose01': ['w-normal-tilthead01', 'w-normal-nod01', 'w-normal-tilthead0103'],
  'w-normal-pose03': ['w-normal-tilthead03', 'w-normal-tilthead0301', 'w-normal-tilthead0305'],
  'w-normal-pose05': ['w-normal-tilthead05', 'w-normal-lookaway01', 'w-normal-tilthead0503', 'w-normal-tilthead0506'],
  'w-normal-pose04': ['w-normal-tilthead04', 'w-normal-tilthead0406'],
  'w-normal-posenod02': ['w-normal-tilthead02'],
  'w-normal-posetrouble02': ['w-normal-tilthead01r'],
};
