'use strict';
/* 写词窗口：选曲子 → 本地分析（后台线程）→ 可选听曲 → 写词（流式）→ 复制 / 保存；另附识别原有歌词 */
const api = window.lyricsAPI;
const $ = (id) => document.getElementById(id);
const EXT = ['mp3', 'wav', 'flac', 'ogg', 'oga', 'm4a', 'aac', 'opus', 'webm'];
const MAX_BYTES = 100 * 1024 * 1024, MAX_SEC = 15 * 60, MIN_SEC = 8;
const mb = (n) => (n / 1024 / 1024).toFixed(n < 10 * 1024 * 1024 ? 1 : 0) + ' MB';
const mmss = (s) => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`;
const setMsg = (id, t, cls = '') => { const e = $(id); e.textContent = t; e.className = 'msg' + (cls ? ' ' + cls : ''); };
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

let cfg = null;
let source = 'file';                 // file | synth
let file = null, decoded = null;     // 导入的文件、解码后的 AudioBuffer
let synthPiece = null;               // { title, text, mine }
let analysis = null, analysisFor = null;
let worker = null, workerJob = 0;
let genJob = null, asrJob = null, listenJob = null;
const progressHandlers = new Map();
api.onProgress((p) => { const h = progressHandlers.get(p.id); if (h) h(p); });
const newId = () => 'j' + Date.now() + Math.random().toString(36).slice(2, 7);

/* ---------- 设置状态 ---------- */
async function loadConfig() {
  cfg = await api.config();
  const pill = $('apiPill');
  if (!cfg.hasKey) { pill.textContent = '还没填硅基流动密钥'; pill.className = 'pill bad'; }
  else if (!cfg.model) { pill.textContent = '还没选写词模型'; pill.className = 'pill bad'; }
  else { pill.textContent = '写词模型：' + cfg.model; pill.className = 'pill ok'; pill.title = cfg.base; }
  const lh = $('listenHint');
  if (!cfg.audioModel) { $('listen').checked = false; $('listen').disabled = true; lh.textContent = '没有设置听曲模型，只用本地分析。（设置 → 写词（硅基流动） → 听曲模型）'; }
  else {
    $('listen').disabled = false;
    lh.textContent = `听曲模型：${cfg.audioModel}` + (cfg.audioLikely ? '' : '。注意：官方文档只有 Qwen3-Omni 系列标注支持音频输入，这个模型可能会拒绝音频；可以先在设置里点“检测音频输入”。');
  }
  refreshButtons();
}
$('openSettings').onclick = () => api.openSettings();
window.addEventListener('focus', () => loadConfig());

/* ---------- 来源切换 ---------- */
function setSource(s) {
  source = s;
  $('tabFile').classList.toggle('on', s === 'file'); $('tabSynth').classList.toggle('on', s === 'synth');
  $('paneFile').hidden = s !== 'file'; $('paneSynth').hidden = s !== 'synth';
  $('listenBox').hidden = s !== 'file';
  showAnalysis(analysisFor === s ? analysis : null);
  refreshButtons();
}
$('tabFile').onclick = () => setSource('file');
$('tabSynth').onclick = () => setSource('synth');

function refreshButtons() {
  const ready = !!(analysis && analysisFor === source);
  const busy = !!genJob;
  $('gen').disabled = !ready || busy;
  $('genCancel').disabled = !busy;
  $('genHint').textContent = !ready ? (source === 'synth' ? '先读取合成器作品' : '先选曲子并完成分析') : !cfg || !cfg.hasKey ? '还没填密钥：点右上角“设置”' : !cfg.model ? '还没选写词模型：点右上角“设置”' : '';
  $('analyze').disabled = !decoded && !file || !!worker;
  $('asr').disabled = !file || !!asrJob;
  $('asrCancel').disabled = !asrJob;
  const has = !!$('out').value.trim();
  $('copy').disabled = !has; $('save').disabled = !has; $('checkFit').disabled = !has || !ready;
}
$('out').addEventListener('input', refreshButtons);

/* ---------- 导入文件：格式和大小检查 ---------- */
function checkFile(f) {
  const ext = (f.name.split('.').pop() || '').toLowerCase();
  if (!EXT.includes(ext) && !/^audio\//.test(f.type)) return `不支持这个格式（.${ext}）。请选择 ${EXT.join(' / ')} 文件。`;
  if (!f.size) return '这个文件是空的。';
  if (f.size > MAX_BYTES) return `文件太大（${mb(f.size)}），本地分析最多 100MB。`;
  return '';
}
function takeFile(f) {
  if (!f) return;
  const bad = checkFile(f);
  if (bad) { setMsg('anaMsg', bad, 'err'); return; }
  cancelAnalysis();
  file = f; decoded = null;
  if (analysisFor === 'file') { analysis = null; analysisFor = null; showAnalysis(null); }
  $('fileInfo').innerHTML = `<b>${esc(f.name)}</b><br><span class="sub">${mb(f.size)}</span>`;
  setMsg('anaMsg', '已选好。点“分析曲子”开始本地分析（不会上传）。');
  $('asrOut').value = ''; setMsg('asrMsg', '');
  refreshButtons();
}
$('pick').onclick = () => $('file').click();
$('file').onchange = () => { takeFile($('file').files[0]); $('file').value = ''; };
const drop = $('drop');
drop.addEventListener('dragover', (e) => { e.preventDefault(); drop.classList.add('over'); });
drop.addEventListener('dragleave', () => drop.classList.remove('over'));
drop.addEventListener('drop', (e) => { e.preventDefault(); drop.classList.remove('over'); if (e.dataTransfer.files.length) { setSource('file'); takeFile(e.dataTransfer.files[0]); } });

/* ---------- 本地分析（解码 → 重采样 → 后台线程） ---------- */
function anaProgress(p, stage) {
  $('anaProg').classList.add('on');
  $('anaBar').style.width = Math.round(p * 100) + '%';
  $('anaStage').textContent = `${stage}… ${Math.round(p * 100)}%`;
}
function anaDone() { $('anaProg').classList.remove('on'); }
function cancelAnalysis() {
  if (worker) { worker.terminate(); worker = null; }
  workerJob++;
  anaDone(); refreshButtons();
}
$('anaCancel').onclick = () => { cancelAnalysis(); setMsg('anaMsg', '已取消分析。'); };

async function analyzeFile() {
  if (!file) return;
  const myJob = ++workerJob;
  setMsg('anaMsg', '');
  try {
    anaProgress(0.01, '读取文件');
    if (!decoded) {
      const buf = await file.arrayBuffer();
      if (myJob !== workerJob) return;
      anaProgress(0.03, '解码音频');
      try {
        const audio = await new OfflineAudioContext(1, 1, 44100).decodeAudioData(buf);
        if (myJob !== workerJob) return;
        decoded = audio;
      }
      catch (e) { throw new Error('解码失败：这个文件可能已损坏，或者编码格式不受支持。'); }
    }
    if (decoded.duration < MIN_SEC) throw new Error(`曲子太短（${decoded.duration.toFixed(1)} 秒），至少需要 ${MIN_SEC} 秒。`);
    if (decoded.duration > MAX_SEC) throw new Error(`曲子太长（${mmss(decoded.duration)}），本地分析最多 15 分钟。`);
    $('fileInfo').innerHTML = `<b>${esc(file.name)}</b><br><span class="sub">${mb(file.size)} · ${mmss(decoded.duration)} · ${decoded.numberOfChannels} 声道 ${decoded.sampleRate} Hz</span>`;
    anaProgress(0.04, '转成单声道 22050Hz');
    const sr = 22050;
    const oc = new OfflineAudioContext(1, Math.ceil(decoded.duration * sr), sr);
    const src = oc.createBufferSource(); src.buffer = decoded; src.connect(oc.destination); src.start();
    const mono = (await oc.startRendering()).getChannelData(0).slice();
    if (myJob !== workerJob) return;
    worker = new Worker('lyrics-worker.js');
    refreshButtons();
    const result = await new Promise((resolve, reject) => {
      worker.onmessage = (e) => {
        const d = e.data;
        if (d.progress != null) anaProgress(0.05 + d.progress * 0.95, d.stage);
        if (d.result) resolve(d.result);
        if (d.error) reject(new Error(d.error));
      };
      worker.onerror = (e) => reject(new Error('分析线程出错：' + (e.message || '未知错误')));
      worker.postMessage({ id: myJob, samples: mono, sampleRate: sr }, [mono.buffer]);
    });
    if (myJob !== workerJob) return;
    result.fileName = file.name;
    analysis = result; analysisFor = 'file';
    showAnalysis(result);
    setMsg('anaMsg', `分析完成：${result.sections.length} 个段落，${result.tempo.reliable ? '约 ' + result.tempo.bpm + ' BPM' : '节拍不明显'}，${result.key.text}。`, 'ok');
  } catch (e) {
    if (myJob === workerJob) setMsg('anaMsg', e.message, 'err');
  } finally {
    if (myJob === workerJob) { if (worker) { worker.terminate(); worker = null; } anaDone(); refreshButtons(); }
  }
}
$('analyze').onclick = analyzeFile;

/* ---------- 合成器作品 ---------- */
function takeSynth(p) {
  if (!p || p.error) {
    $('synthBox').className = 'empty';
    $('synthBox').innerHTML = esc(p && p.error ? p.error : '没有可用的合成器作品。');
    if (analysisFor === 'synth') { analysis = null; analysisFor = null; showAnalysis(null); }
    refreshButtons();
    return;
  }
  setSource('synth');
  try {
    const parsed = Jianpu.parse(p.text);
    const r = LyricsAnalysis.analyzeScore(parsed, p.text);
    r.title = p.title || '';
    synthPiece = p; analysis = r; analysisFor = 'synth';
    $('synthBox').className = '';
    $('synthBox').innerHTML = `<span class="source-tag">输入来自当前合成器作品</span><div><b>${esc(p.title || '（未命名）')}</b>${p.mine ? ' <span class="sub">· 一歌写的曲子</span>' : ''}</div>` +
      `<div class="sub">${esc(r.key.text)} · ${esc(r.meter.text)} · ♩=${r.tempo.bpm} · ${r.bars} 小节 · ${r.phrases.length} 个乐句 · ${r.noteCount} 个音</div>`;
    showAnalysis(r);
    setMsg('anaMsg', '已读取合成器作品的谱面数据（本地完成，没有上传）。', 'ok');
  } catch (e) {
    analysis = null; analysisFor = null; showAnalysis(null);
    $('synthBox').className = 'empty'; $('synthBox').textContent = '这首作品用不了：' + e.message;
    setMsg('anaMsg', e.message, 'err');
  }
  refreshButtons();
}
api.onSource((s) => { if (s && s.kind === 'synth') takeSynth(s); });
$('readSynth').onclick = async () => {
  setMsg('anaMsg', '正在向合成器读取当前作品…');
  const r = await api.synthCurrent();
  if (r && r.error) { takeSynth(r); setMsg('anaMsg', r.error, 'err'); return; }
  takeSynth(r);
};

/* ---------- 显示分析结果 ---------- */
function showAnalysis(a) {
  $('resultCard').hidden = !a;
  if (!a) return;
  const chips = [];
  if (a.kind === 'audio') {
    $('resultSrc').textContent = '来源：导入的音乐文件（本地分析）';
    chips.push(['时长', mmss(a.duration)], ['速度', a.tempo.reliable ? a.tempo.bpm + ' BPM' : '不明显'], ['拍号', a.meter.text], ['调性', `${a.key.text}（${Math.round(a.key.confidence * 100)}%）`], ['段落', a.sections.length + ' 个']);
    $('tbl').innerHTML = '<tr><th>段落（推测）</th><th>重复</th><th>时间</th><th>小节</th><th>力度</th><th>节奏</th><th>建议</th></tr>' +
      a.sections.map((s) => `<tr><td>${esc(s.label)}</td><td>${esc(s.repeat)}</td><td>${s.time}</td><td>${s.bars ?? '–'}</td><td>${s.energyLevel}</td><td>${s.density}</td><td>${s.instrumental ? '器乐/不写' : `${s.lines} 行 × ${s.syllables} 字`}</td></tr>`).join('');
    $('method').innerHTML = `<b>分析方式：</b>${esc(a.method)}。<br>整体：${esc(a.mood.join('；'))}。<br>` + a.notes.map(esc).join('<br>');
  } else {
    $('resultSrc').textContent = '来源：当前合成器作品（谱面数据）';
    chips.push(['调号', a.key.text], ['拍号', a.meter.text], ['速度', '♩=' + a.tempo.bpm], ['长度', `${a.bars} 小节 · ${a.duration} 秒`], ['乐句', a.phrases.length + ' 句']);
    $('tbl').innerHTML = '<tr><th>#</th><th>段落</th><th>旋律型</th><th>小节</th><th>音符数＝字数</th><th>时值（拍）</th><th>音高</th></tr>' +
      a.phrases.map((p) => `<tr><td>${p.no}</td><td>${esc(p.section)}</td><td>${esc(p.repeat)}</td><td>${p.bar}</td><td><b>${p.syllables}</b></td><td>${esc(p.rhythm)}</td><td>${esc(p.degrees)}</td></tr>`).join('');
    $('method').innerHTML = `<b>分析方式：</b>${esc(a.method)}。<br>段落依据：${esc(a.sectionSource)}；${esc(a.key.mode)}；节奏感：${esc(a.rhythmFeel)}。`;
  }
  $('chips').innerHTML = chips.map(([k, v]) => `<span class="chip">${k} <b>${esc(v)}</b></span>`).join('');
  drawViz(a);
}
const COLORS = { 前奏: '#e8d69d', 主歌: '#eab20a', 预副歌: '#d6a6c9', 副歌: '#ba9013', 桥段: '#b9a772', 尾奏: '#e8d69d' };
function drawViz(a) {
  const c = $('viz'), g = c.getContext('2d'), W = c.width, H = c.height;
  g.clearRect(0, 0, W, H);
  g.font = '20px "Microsoft YaHei UI", sans-serif'; g.textBaseline = 'top';
  if (a.kind === 'audio') {
    const T = a.duration;
    for (const s of a.sections) {
      const x0 = s.start / T * W, x1 = s.end / T * W;
      g.fillStyle = (COLORS[s.label.replace(/\d+$/, '')] || '#bbb') + '55'; g.fillRect(x0, 0, x1 - x0, H);
      g.fillStyle = '#6c5d2e'; g.fillText(s.label, x0 + 6, 6);
      g.strokeStyle = '#ffffff'; g.lineWidth = 3; g.beginPath(); g.moveTo(x0, 0); g.lineTo(x0, H); g.stroke();
    }
    const mx = Math.max(...a.curve, 1e-6);
    g.strokeStyle = '#8e6f11'; g.lineWidth = 2; g.beginPath();
    a.curve.forEach((v, i) => { const x = i / (a.curve.length - 1) * W, y = H - 8 - v / mx * (H - 44); i ? g.lineTo(x, y) : g.moveTo(x, y); });
    g.stroke();
  } else {
    const T = a.totalBeats || 1;
    a.phrases.forEach((p, i) => {
      const x0 = p.startBeat / T * W, x1 = (p.startBeat + p.beats) / T * W;
      g.fillStyle = i % 2 ? '#a59ddb88' : '#7f76bd88'; g.fillRect(x0 + 1, 36, Math.max(2, x1 - x0 - 2), H - 46);
      g.fillStyle = '#6c5d2e'; g.fillText(String(p.syllables), x0 + 5, 40);
    });
    let last = '';
    a.phrases.forEach((p) => { if (p.section !== last) { last = p.section; const x = p.startBeat / T * W; g.fillStyle = '#6c5d2e'; g.fillText(p.section, x + 4, 6); } });
  }
}

/* ---------- 听曲片段：从原曲里剪出最多 3 段，重采样成 16k 单声道 WAV ---------- */
async function buildExcerpt() {
  const pick = [];
  const by = (re) => analysis.sections.find((s) => re.test(s.label) && !pick.includes(s));
  for (const re of [/^副歌/, /^主歌/, /^(桥段|预副歌)/]) { const s = by(re); if (s) pick.push(s); }
  if (!pick.length) pick.push(analysis.sections[0]);
  const sr = 16000, clip = 15, gap = 0.5;
  const parts = pick.map((s) => ({ from: Math.min(s.start + 1, Math.max(0, decoded.duration - clip)), len: Math.min(clip, Math.max(4, s.end - s.start - 1)) }));
  const total = parts.reduce((t, p) => t + p.len + gap, 0);
  const oc = new OfflineAudioContext(1, Math.ceil(total * sr), sr);
  let at = 0;
  for (const p of parts) { const src = oc.createBufferSource(); src.buffer = decoded; src.connect(oc.destination); src.start(at, p.from, p.len); at += p.len + gap; }
  const data = (await oc.startRendering()).getChannelData(0);
  const n = data.length, buf = new ArrayBuffer(44 + n * 2), v = new DataView(buf);
  const w = (o, s) => { for (let i = 0; i < s.length; i++) v.setUint8(o + i, s.charCodeAt(i)); };
  w(0, 'RIFF'); v.setUint32(4, 36 + n * 2, true); w(8, 'WAVEfmt '); v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, 1, true);
  v.setUint32(24, sr, true); v.setUint32(28, sr * 2, true); v.setUint16(32, 2, true); v.setUint16(34, 16, true); w(36, 'data'); v.setUint32(40, n * 2, true);
  for (let i = 0; i < n; i++) v.setInt16(44 + i * 2, Math.max(-1, Math.min(1, data[i])) * 32767, true);
  const bytes = new Uint8Array(buf);
  let bin = '';
  for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
  return { b64: btoa(bin), seconds: Math.round(total), labels: pick.map((s) => s.label).join('、') };
}

/* ---------- 写词 ---------- */
function startJob(kind) { const id = newId(); return { id, kind }; }
$('gen').onclick = async () => {
  if (!analysis || analysisFor !== source) return;
  await loadConfig();
  if (!cfg.hasKey) { setMsg('genMsg', '还没有填写硅基流动的 API 密钥：点右上角“设置”，在“写词（硅基流动）”里填写。', 'err'); return; }
  if (!cfg.model) { setMsg('genMsg', '还没有选择写词模型：点右上角“设置” → 写词（硅基流动） → 读取模型列表。', 'err'); return; }
  const a = analysis;
  const brief = LyricsAnalysis.promptBrief(a) + (a.kind === 'score' && a.title ? `\n作品名：${a.title}` : '');
  setMsg('genMsg', ''); setMsg('outMsg', '');
  $('fit').classList.remove('on');
  $('genProg').classList.add('on');
  let listened = '', listenNote = '';
  genJob = startJob('generate');
  refreshButtons();
  const myJob = genJob;
  try {
    if (source === 'file' && $('listen').checked && cfg.audioModel) {
      $('genStage').textContent = '准备音频片段…';
      const ex = await buildExcerpt();
      if (genJob !== myJob) return;
      listenJob = { id: newId() };
      myJob.sub = listenJob.id;
      progressHandlers.set(listenJob.id, (p) => {
        if (p.stage === 'upload') $('genStage').textContent = `上传 ${ex.labels} 共 ${ex.seconds} 秒（${mb(p.bytes)}）给 ${cfg.audioModel}…`;
        if (p.stage === 'wait') { $('genStage').textContent = `${cfg.audioModel} 正在听…`; $('genTime').textContent = p.elapsed + ' 秒'; }
      });
      const lr = await api.run('listen', { id: listenJob.id, wav: ex.b64, brief: `片段依次为：${ex.labels}` });
      progressHandlers.delete(listenJob.id); listenJob = null;
      if (genJob !== myJob) return;
      if (lr.canceled) throw Object.assign(new Error('已取消'), { canceled: true });
      if (lr.ok) { listened = lr.text; listenNote = `听曲模型的描述：${lr.text}`; }
      else listenNote = `听曲没有成功（${lr.error}）。本次只使用本地分析结果写词。`;
    }
    $('genStage').textContent = `等待 ${cfg.model} 开始写…`; $('genTime').textContent = '';
    $('out').value = '';
    progressHandlers.set(myJob.id, (p) => {
      if (p.stage === 'wait') $('genTime').textContent = p.elapsed + ' 秒';
      if (p.stage === 'stream') {
        $('genStage').textContent = p.chars ? `已收到 ${p.chars} 字` : `模型思考中（${p.reasoning} 字）`;
        if (p.text != null) { $('out').value = p.text; $('out').scrollTop = $('out').scrollHeight; }
      }
    });
    const r = await api.run('generate', {
      id: myJob.id, kind: a.kind, brief, listened,
      theme: $('theme').value.trim(), language: $('language').value, style: $('style').value.trim(), extra: $('extra').value.trim(), ichika: $('ichika').checked,
    });
    if (genJob !== myJob) return;
    if (r.ok) {
      $('out').value = r.text.trim();
      $('outMeta').textContent = `${r.model} · ${r.seconds} 秒${r.finish === 'length' ? ' · 输出被截断' : ''}`;
      setMsg('genMsg', (listenNote ? listenNote + '\n' : '') + `写好了（${a.kind === 'score' ? '依据合成器作品的谱面数据' : listened ? '依据本地分析 + 听曲描述' : '依据本地分析'}）。`, listenNote && !listened ? 'warn' : 'ok');
      if (r.finish === 'length') setMsg('outMsg', '模型的输出长度到了上限，最后几行可能不完整。', 'warn');
      checkFit();
      api.done(titleOf($('out').value));
    } else {
      setMsg('genMsg', (r.canceled ? '已取消。' : r.error) + (listenNote ? '\n' + listenNote : ''), r.canceled ? '' : 'err');
    }
  } catch (e) {
    if (genJob === myJob) setMsg('genMsg', e.canceled ? '已取消。' : e.message, e.canceled ? '' : 'err');
  } finally {
    if (genJob === myJob) { progressHandlers.delete(myJob.id); genJob = null; $('genProg').classList.remove('on'); refreshButtons(); }
  }
};
$('genCancel').onclick = () => {
  if (!genJob) return;
  api.cancel(genJob.id);
  if (listenJob) api.cancel(listenJob.id);
  const j = genJob; genJob = null;
  progressHandlers.delete(j.id);
  $('genProg').classList.remove('on');
  setMsg('genMsg', '已取消。');
  refreshButtons();
};

/* ---------- 歌词：标题、复制、保存、对拍检查 ---------- */
function titleOf(t) { const m = /^\s*标题[:：]\s*(.+)$/m.exec(t); return m ? m[1].trim().replace(/[《》]/g, '').slice(0, 40) : ''; }
$('copy').onclick = async () => { await api.copy($('out').value); setMsg('outMsg', '已复制到剪贴板。', 'ok'); };
$('save').onclick = async () => {
  const name = titleOf($('out').value) || (analysis && analysis.kind === 'score' && analysis.title) || (file ? file.name.replace(/\.[^.]+$/, '') + ' 歌词' : '歌词');
  const r = await api.save({ name, text: $('out').value });
  if (r && r.ok) setMsg('outMsg', '已保存：' + r.path, 'ok'); else if (r && r.error) setMsg('outMsg', r.error, 'err');
};
// 粗略计数：中文按汉字，日语按假名（拗音小字不算），英语按元音组
function countUnits(line, lang) {
  if (lang === 'en') return (line.toLowerCase().match(/[aeiouy]+/g) || []).length;
  if (lang === 'ja') return (line.match(/[ぁ-ゖァ-ヺー一-鿿]/g) || []).length - (line.match(/[ゃゅょャュョぁぃぅぇぉァィゥェォ]/g) || []).length;
  return (line.match(/[一-鿿ぁ-ヿ]/g) || []).length + (line.match(/[A-Za-z]+/g) || []).length;
}
function parseLyrics(t) {
  const secs = []; let cur = null;
  for (const raw of t.split(/\r?\n/)) {
    const l = raw.trim();
    if (!l || /^标题[:：]/.test(l)) continue;
    const h = /^【(.+?)】/.exec(l) || /^\[(.+?)\]$/.exec(l);
    if (h) { cur = { name: h[1], lines: [] }; secs.push(cur); continue; }
    if (/^[（(]器乐[)）]$/.test(l)) continue;
    if (!cur) { cur = { name: '', lines: [] }; secs.push(cur); }
    cur.lines.push(l);
  }
  return secs;
}
function checkFit() {
  if (!analysis || !$('out').value.trim()) return;
  const lang = $('language').value, secs = parseLyrics($('out').value), rows = [];
  if (analysis.kind === 'score') {
    const lines = secs.flatMap((s) => s.lines);
    analysis.phrases.forEach((p, i) => {
      const l = lines[i];
      const n = l ? countUnits(l, lang) : 0;
      rows.push(`<div class="${l && n === p.syllables ? 'ok' : 'off'}">乐句${p.no}：${p.syllables} 个音 · ${l ? `${n} 字 “${esc(l)}”` : '没有对应的歌词行'}</div>`);
    });
    if (lines.length > analysis.phrases.length) rows.push(`<div class="off">多出 ${lines.length - analysis.phrases.length} 行歌词</div>`);
  } else {
    for (const s of analysis.sections) {
      const got = secs.find((x) => x.name.replace(/\s/g, '') === s.label);
      if (s.instrumental) { rows.push(`<div class="ok">${esc(s.label)}：器乐段${got && got.lines.length ? `（写了 ${got.lines.length} 行）` : ''}</div>`); continue; }
      if (!got) { rows.push(`<div class="off">${esc(s.label)}：歌词里没找到这一段</div>`); continue; }
      const [lo, hi] = s.syllables.split('–').map(Number);
      const counts = got.lines.map((l) => countUnits(l, lang));
      const inRange = counts.filter((n) => n >= lo - 2 && n <= hi + 2).length;
      rows.push(`<div class="${got.lines.length === s.lines && inRange === counts.length ? 'ok' : 'off'}">${esc(s.label)}：${got.lines.length}/${s.lines} 行，每行 ${counts.join('、')} 字（建议 ${s.syllables}）</div>`);
    }
  }
  $('fit').innerHTML = `<div class="sub">对照${analysis.kind === 'score' ? '每个乐句的音符数' : '分析建议的行数和字数'}（${lang === 'ja' ? '日语按假名粗略计数' : lang === 'en' ? '英语按元音组粗略估算音节' : '中文按字数'}）：</div>` + rows.join('');
  $('fit').classList.add('on');
}
$('checkFit').onclick = checkFit;

/* ---------- 识别原有歌词（辅助） ---------- */
$('asr').onclick = async () => {
  if (!file) return;
  await loadConfig();
  if (!cfg.hasKey) { setMsg('asrMsg', '还没有填写硅基流动的 API 密钥（右上角“设置”）。', 'err'); return; }
  if (file.size > cfg.limits.asrBytes) { setMsg('asrMsg', `文件 ${mb(file.size)}，超过语音识别接口的 50MB 上限。`, 'err'); return; }
  if (decoded && decoded.duration > 3600) { setMsg('asrMsg', '时长超过 1 小时，超出语音识别接口的限制。', 'err'); return; }
  asrJob = { id: newId() };
  const my = asrJob;
  refreshButtons();
  setMsg('asrMsg', '');
  progressHandlers.set(my.id, (p) => {
    if (p.stage === 'upload') $('asrState').textContent = `上传 ${mb(p.bytes)} 给 ${cfg.asrModel}…`;
    if (p.stage === 'wait') $('asrState').textContent = `识别中… ${p.elapsed} 秒`;
  });
  try {
    const bytes = await file.arrayBuffer();
    if (asrJob !== my) return;
    const r = await api.run('asr', { id: my.id, bytes, name: file.name });
    if (asrJob !== my) return;
    if (r.ok) { $('asrOut').value = r.text || ''; setMsg('asrMsg', r.text ? '识别完成（这是原曲里识别出的词，不是新写的歌词）。' : '没有识别出文字（可能是纯音乐，或伴奏太响）。', r.text ? 'ok' : 'warn'); }
    else setMsg('asrMsg', r.canceled ? '已取消。' : r.error, r.canceled ? '' : 'err');
  } finally {
    if (asrJob === my) { progressHandlers.delete(my.id); asrJob = null; $('asrState').textContent = ''; refreshButtons(); $('asrCopy').disabled = $('asrSave').disabled = !$('asrOut').value.trim(); }
  }
};
$('asrCancel').onclick = () => { if (!asrJob) return; api.cancel(asrJob.id); progressHandlers.delete(asrJob.id); asrJob = null; $('asrState').textContent = ''; setMsg('asrMsg', '已取消。'); refreshButtons(); };
$('asrCopy').onclick = async () => { await api.copy($('asrOut').value); setMsg('asrMsg', '已复制。', 'ok'); };
$('asrSave').onclick = async () => { const r = await api.save({ name: (file ? file.name.replace(/\.[^.]+$/, '') : '原曲') + ' 识别歌词', text: $('asrOut').value }); if (r && r.ok) setMsg('asrMsg', '已保存：' + r.path, 'ok'); };
$('asrOut').addEventListener('input', () => { $('asrCopy').disabled = $('asrSave').disabled = !$('asrOut').value.trim(); });

loadConfig();
refreshButtons();
