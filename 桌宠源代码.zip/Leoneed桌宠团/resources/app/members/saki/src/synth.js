'use strict';
/* 电子琴窗口：写简谱（或照着五线谱写音名）→ 用电子琴的声音弹出来，配上和弦伴奏；
   下面同时排出五线谱，点五线谱或键盘就能把音写进去；可以保存、导出 WAV / MIDI / 五线谱（MusicXML）；弹的时候告诉咲希 */
const $ = (id) => document.getElementById(id);
const api = window.synthAPI;
const msg = (t, cls = '') => { $('msg').textContent = t; $('msg').className = cls; };

let mineLoaded = false;   // 现在框里是她写的曲子
let ac = null, src = null, raf = 0, cache = { text: null, buf: null, score: null };
const ctx = () => (ac || (ac = new AudioContext()));
const TONE_NAME = Jianpu.TONES, STYLE_NAME = Jianpu.STYLES;

/* ---------- 预览：把每个音包成一个可以高亮的块 ---------- */
function buildPv(elm, text, items) {
  elm.textContent = '';
  const order = items.map((it, k) => ({ ...it, k })).filter((it) => it.src).sort((a, b) => a.src[0] - b.src[0]);
  const spans = new Array(items.length);
  let pos = 0;
  for (const it of order) {
    const [a, b] = it.src;
    if (a < pos) continue;
    if (a > pos) elm.appendChild(document.createTextNode(text.slice(pos, a)));
    const sp = document.createElement('span');
    sp.className = 'n'; sp.textContent = text.slice(a, b);
    elm.appendChild(sp); spans[it.k] = sp;
    pos = b;
  }
  if (pos < text.length) elm.appendChild(document.createTextNode(text.slice(pos)));
  return spans;
}
let hl = [];          // [{ t, dur, node, cls }]：播放时要高亮的东西（简谱的字、五线谱的音）
let staffPick = null; // 五线谱：鼠标高度 → 音
let lastScore = null;

function drawStaff(score) {
  const svg = $('staff');
  $('staffBox').hidden = !$('showStaff').checked;
  if (!$('showStaff').checked || !score) { staffPick = null; return; }
  const width = Math.max(420, $('staffBox').clientWidth - 18);
  const r = Staff.draw(svg, Jianpu.toStaff(score), { width });
  staffPick = r.pick;
  for (const it of r.items) if (it.idx >= 0) hl.push({ t: it.t, dur: it.dur, node: it.el, cls: 'on' });
}

function check() {
  const text = $('score').value;
  const score = Jianpu.parse(text);
  hl = [];
  lastScore = null;
  if (score.error) {
    msg(`第 ${text.slice(0, score.error.pos).split('\n').length} 行：${score.error.msg}`, 'err');
    buildPv($('preview'), '', []);
    return null;
  }
  if ($('tone').value !== TONE_NAME[score.tone]) $('tone').value = TONE_NAME[score.tone];
  const styleHere = /(伴奏|style)\s*[=:：]/.test(text) ? STYLE_NAME[score.style] : '';
  if ($('style').value !== styleHere) $('style').value = styleHere;
  if (!score.notes.length && !score.chords.length) {
    msg('还没有写音符：可以直接写简谱，或者点下面的五线谱、键盘');
    buildPv($('preview'), '', []);
    drawStaff(null);
    return null;
  }
  lastScore = score;
  const sec = score.total * 60 / score.bpm;
  const len = sec < 60 ? Math.round(sec) + ' 秒' : Math.floor(sec / 60) + ' 分 ' + Math.round(sec % 60) + ' 秒';
  const bad = Jianpu.checkBars(score);
  msg(`${score.notes.length} 个音${score.chords.length ? ' · ' + score.chords.length + ' 个和弦（' + STYLE_NAME[score.style] + '伴奏）' : ''} · 1=${score.key} · ${score.beats}/${score.beatUnit} · ♩=${score.bpm} · ${TONE_NAME[score.tone]} · 大约 ${len}` +
    (bad.length ? `　（第 ${bad.slice(0, 3).map((b) => b.bar).join('、')} 小节的拍数不对，五线谱会按 ${score.beats} 拍一小节排）` : ''));
  const spans = buildPv($('preview'), text, score.notes);
  score.notes.forEach((n, k) => spans[k] && hl.push({ t: n.t, dur: n.dur, node: spans[k], cls: 'on' }));
  drawStaff(score);
  return score;
}
let checkTimer = 0;
$('score').addEventListener('input', () => { mineLoaded = false; clearTimeout(checkTimer); checkTimer = setTimeout(check, 250); });
$('showStaff').addEventListener('change', check);
let resizeTimer = 0;
window.addEventListener('resize', () => { clearTimeout(resizeTimer); resizeTimer = setTimeout(check, 200); });

// 定位到出错的地方
$('msg').addEventListener('click', () => {
  const s = Jianpu.parse($('score').value);
  if (s.error) { $('score').focus(); $('score').setSelectionRange(s.error.pos, s.error.pos + 1); }
});

/* ---------- 音色、伴奏：改写谱子第一行（没有就加上） ---------- */
function setHeader(keyRe, word, value) {
  const ta = $('score');
  let text = ta.value;
  const re = new RegExp(`(${keyRe})\\s*[=:：]\\s*[一-龥A-Za-z]+`);
  if (!value) text = text.replace(new RegExp(`\\s*(${keyRe})\\s*[=:：]\\s*[一-龥A-Za-z]+`), '');
  else if (re.test(text)) text = text.replace(re, word + '=' + value);
  else {
    const lines = text.split('\n');
    const k = lines.findIndex((l) => /1\s*=|♩|bpm|\d\s*\/\s*\d|音色|伴奏/.test(l) && !/^\s*(和弦|chords?)\s*[:：]/i.test(l));
    if (k >= 0) lines[k] = lines[k].replace(/\s*(\/\/.*)?$/, (m, c) => ` ${word}=${value}` + (c ? '   ' + c : ''));
    else lines.unshift(`${word}=${value}`);
    text = lines.join('\n');
  }
  ta.value = text; mineLoaded = false;
  check();
}
$('tone').onchange = () => setHeader('音色|tone', '音色', $('tone').value);
$('style').onchange = () => setHeader('伴奏|style', '伴奏', $('style').value);

async function getBuffer() {
  const text = $('score').value;
  if (cache.text === text && cache.buf) return cache;
  const score = check();
  if (!score) return null;
  msg('合成中…');
  await new Promise((r) => setTimeout(r, 20));   // 让“合成中”先显示出来
  const buf = await Jianpu.render(score);
  cache = { text, buf, score };
  check();
  return cache;
}

/* ---------- 播放 ---------- */
const keyEls = new Map();   // midi → 键盘上的键
function stop() {
  if (src) { try { src.stop(); } catch (e) {} src = null; }
  cancelAnimationFrame(raf);
  hl.forEach((h) => h.node.classList.remove(h.cls));
  keyEls.forEach((e) => e.classList.remove('lit'));
  $('play').disabled = false; $('stop').disabled = true;
}
$('stop').onclick = stop;
$('play').onclick = async () => {
  stop();
  $('play').disabled = true;
  const c = await getBuffer();
  if (!c) { $('play').disabled = false; return; }
  const a = ctx(); if (a.state === 'suspended') await a.resume();
  src = a.createBufferSource(); src.buffer = c.buf; src.connect(a.destination);
  const t0 = a.currentTime + 0.05;
  src.start(t0);
  src.onended = () => { if (src) stop(); };
  $('play').disabled = true; $('stop').disabled = false;
  if ($('share').checked || mineLoaded) api.played($('title').value.trim(), mineLoaded);
  const spb = 60 / c.score.bpm;
  const lit = new Set();
  const notes = c.score.notes;
  const tick = () => {
    const beat = (a.currentTime - t0) / spb;
    for (const h of hl) {
      const on = beat >= h.t && beat < h.t + h.dur;
      if (on && !lit.has(h)) {
        lit.add(h); h.node.classList.add(h.cls);
        if (h.node.scrollIntoView) h.node.scrollIntoView({ block: 'nearest', inline: 'nearest' });
      } else if (!on && lit.has(h)) { lit.delete(h); h.node.classList.remove(h.cls); }
    }
    // 键盘上亮起正在弹的旋律音
    const now = new Set();
    for (const n of notes) if (beat >= n.t && beat < n.t + n.dur) n.midi.forEach((m) => now.add(m));
    keyEls.forEach((e, m) => e.classList.toggle('lit', now.has(m)));
    raf = requestAnimationFrame(tick);
  };
  tick();
};

/* ---------- 导出 ---------- */
const fname = () => ($('title').value.trim() || '无题').replace(/[\\/:*?"<>|]/g, '_');
$('wav').onclick = async () => {
  const c = await getBuffer(); if (!c) return;
  const r = await api.exportFile({ name: fname() + '.wav', data: Jianpu.toWav(c.buf) });
  if (r && r.path) msg('已导出：' + r.path, 'ok');
};
$('midi').onclick = async () => {
  const score = check(); if (!score) return;
  const r = await api.exportFile({ name: fname() + '.mid', data: Jianpu.toMidi(score) });
  if (r && r.path) msg('已导出：' + r.path, 'ok');
};
$('xml').onclick = async () => {
  const score = check(); if (!score) return;
  const r = await api.exportFile({ name: fname() + '（五线谱）.musicxml', data: Jianpu.toMusicXML(score, $('title').value.trim()) });
  if (r && r.path) msg('已导出五线谱：' + r.path + '（可以用 MuseScore 等打谱软件打开、打印）', 'ok');
};

/* ---------- 保存的曲子 ---------- */
let saved = {};
async function refreshSaved(select) {
  saved = await api.list();
  const sel = $('saved');
  sel.innerHTML = '<option value="">已保存的曲子…</option>';
  for (const name of Object.keys(saved).sort((a, b) => (saved[b].at || 0) - (saved[a].at || 0))) {
    const o = document.createElement('option'); o.value = name; o.textContent = name; sel.appendChild(o);
  }
  if (select) sel.value = select;
}
$('saved').onchange = () => {
  const name = $('saved').value; if (!name || !saved[name]) return;
  stop();
  $('title').value = name; $('score').value = saved[name].text; mineLoaded = saved[name].by === 'saki'; check();
};
$('save').onclick = async () => {
  const name = $('title').value.trim();
  if (!name) { msg('先给曲子起个名字', 'err'); $('title').focus(); return; }
  await api.save({ title: name, text: $('score').value });
  await refreshSaved(name);
  msg('已保存', 'ok');
};
$('del').onclick = async () => {
  const name = $('saved').value;
  if (!name) { msg('先在右边选一首要删除的曲子', 'err'); return; }
  await api.remove(name);
  await refreshSaved('');
  msg(`已删除《${name}》`, 'ok');
};

/* ---------- 把一个音写进编辑框（键盘、五线谱共用） ---------- */
const SHARP_NAMES = ['1', '#1', '2', '#2', '3', '4', '#4', '5', '#5', '6', '#6', '7'];
const FLAT_NAMES = ['1', 'b2', '2', 'b3', '3', '4', 'b5', '5', 'b6', '6', 'b7', '7'];
const SUFFIX = { 0.25: '__', 0.5: '_', 1: '', 1.5: '.', 2: ' -', 4: ' - - -' };
function jianpuToken(midi, sc) {
  const tonic = sc.tonic || 60;
  const d = midi - tonic, oct = Math.floor(d / 12), r = ((d % 12) + 12) % 12;
  return ((sc.fifths || 0) < 0 ? FLAT_NAMES : SHARP_NAMES)[r] + (oct > 0 ? "'".repeat(oct) : ','.repeat(-oct));
}
function nameToken(sp) {
  const L = Jianpu.LETTERS[((sp.step % 7) + 7) % 7], oct = Math.floor(sp.step / 7);
  return L + (sp.alter > 0 ? '#'.repeat(sp.alter) : 'b'.repeat(-sp.alter)) + oct;
}
function writeNote(midi, spell) {
  const ta = $('score');
  const sc = Jianpu.parse(ta.value);
  const useName = $('as').value === 'name' || ($('as').value === 'auto' && /(^|[\s|[\]])[A-G](##|bb|#|b)?\d/m.test(ta.value.replace(/^[ \t]*(和弦|chords?)\s*[:：].*$/gim, '').replace(/1\s*=\s*[#b]?[A-G][#b]?/g, '')));
  const tok = useName ? nameToken(spell || Jianpu.spellDefault(midi, sc.fifths || 0)) : jianpuToken(midi, sc);
  // 写进光标的位置（光标在“和弦：”那一行里时，写到旋律的最后）
  let p = ta.selectionStart, q = ta.selectionEnd;
  const v = ta.value;
  const lineStart = v.lastIndexOf('\n', p - 1) + 1;
  if (/^[ \t]*(和弦|chords?)\s*[:：]/i.test(v.slice(lineStart))) {
    const lines = v.split('\n');
    let k = lines.length - 1;
    while (k > 0 && /^[ \t]*(和弦|chords?)\s*[:：]|^\s*$/i.test(lines[k])) k--;
    p = q = lines.slice(0, k + 1).join('\n').length;
  }
  const before = v.slice(0, p), sep = before && !/[\s|[]$/.test(before) ? ' ' : '';
  const ins = sep + tok + (SUFFIX[$('len').value] ?? '');
  ta.value = before + ins + v.slice(q);
  ta.focus();
  ta.setSelectionRange(p + ins.length, p + ins.length);
  mineLoaded = false;
  check();
}
const tapCache = new Map();
async function sound(midi) {
  const tone = (Jianpu.parse($('score').value).tone) || 'keys';
  const key = midi + '|' + tone;
  if (!tapCache.has(key)) tapCache.set(key, Jianpu.render({ bpm: 60, total: 1, tone, notes: [{ t: 0, dur: 0.7, midi: [midi] }], chords: [] }));
  const buf = await tapCache.get(key);
  const a = ctx(); if (a.state === 'suspended') await a.resume();
  const s = a.createBufferSource(); s.buffer = buf; s.connect(a.destination); s.start();
}

/* ---------- 五线谱：点一下写进一个音 ---------- */
(function staffInput() {
  const svg = $('staff'), tip = $('ghostTip');
  let ghost = null;
  const at = (e) => {
    if (!staffPick) return null;
    const r = svg.getBoundingClientRect();
    const hit = staffPick(e.clientY - r.top);
    if (!hit) return null;
    const sc = Jianpu.parse($('score').value);
    const L = Jianpu.LETTERS[((hit.step % 7) + 7) % 7], oct = Math.floor(hit.step / 7);
    const alter = Jianpu.keyAlters(sc.error ? 0 : sc.fifths || 0)[L];
    const midi = 12 * (oct + 1) + Jianpu.LETTER_PC[Jianpu.LETTERS.indexOf(L)] + alter;
    return { ...hit, x: e.clientX - r.left, midi, spell: { step: hit.step, alter, midi }, sc };
  };
  svg.addEventListener('mousemove', (e) => {
    const h = at(e);
    if (!h || h.midi < 21 || h.midi > 108) { if (ghost) ghost.remove(); ghost = null; tip.style.display = 'none'; return; }
    if (!ghost || !ghost.isConnected) ghost = document.createElementNS('http://www.w3.org/2000/svg', 'ellipse');
    ghost.setAttribute('class', 'ghost'); ghost.setAttribute('rx', Staff.RX); ghost.setAttribute('ry', Staff.RY);
    ghost.setAttribute('cx', h.x); ghost.setAttribute('cy', h.y); ghost.setAttribute('transform', `rotate(-20 ${h.x} ${h.y})`);
    svg.appendChild(ghost);
    tip.style.display = 'block';
    tip.style.left = (h.x + 22) + 'px'; tip.style.top = (h.y + $('staff').offsetTop - 10) + 'px';
    tip.textContent = `${nameToken(h.spell)}　简谱 ${jianpuToken(h.midi, h.sc.error ? { tonic: 60, fifths: 0 } : h.sc)}`;
  });
  svg.addEventListener('mouseleave', () => { if (ghost) ghost.remove(); ghost = null; tip.style.display = 'none'; });
  svg.addEventListener('mousedown', (e) => {
    const h = at(e);
    if (!h || h.midi < 21 || h.midi > 108) return;
    e.preventDefault();
    writeNote(h.midi, h.spell);
    sound(h.midi);
  });
})();

/* ---------- 键盘：C3 到 C6 ---------- */
(function buildKeyboard() {
  const kb = $('kb'), OCT = 3, W = 100 / (OCT * 7 + 1), LOWEST = 48;
  const white = [0, 2, 4, 5, 7, 9, 11], black = { 1: 0, 3: 1, 6: 3, 8: 4, 10: 5 };
  const tap = (midi, el) => {
    el.classList.add('down'); setTimeout(() => el.classList.remove('down'), 180);
    writeNote(midi, null);
    sound(midi);
  };
  let wi = 0;
  for (let o = 0; o < OCT; o++) {
    for (const st of white) {
      const midi = LOWEST + o * 12 + st, el = document.createElement('div');
      el.className = 'w'; el.style.left = wi * W + '%'; el.style.width = `calc(${W}% - 2px)`;
      el.textContent = st === 0 ? 'C' + (3 + o) : '';
      el.title = Jianpu.LETTERS[white.indexOf(st)] + (3 + o);
      el.onmousedown = (e) => { e.preventDefault(); tap(midi, el); };
      kb.appendChild(el); keyEls.set(midi, el); wi++;
    }
    for (const st in black) {
      const midi = LOWEST + o * 12 + +st, el = document.createElement('div');
      el.className = 'b'; el.style.left = `calc(${(o * 7 + black[st] + 1) * W}% - ${W * 0.3}%)`; el.style.width = W * 0.6 + '%';
      el.onmousedown = (e) => { e.preventDefault(); tap(midi, el); };
      kb.appendChild(el); keyEls.set(midi, el);
    }
  }
  const midi = LOWEST + OCT * 12, el = document.createElement('div');
  el.className = 'w'; el.style.left = wi * W + '%'; el.style.width = `calc(${W}% - 2px)`; el.textContent = 'C' + (3 + OCT);
  el.onmousedown = (e) => { e.preventDefault(); tap(midi, el); };
  kb.appendChild(el); keyEls.set(midi, el);
})();

/* ---------- 让她写一首 ---------- */
$('compose').onclick = async () => { stop(); await api.compose(''); };
api.onStatus(({ busy, text, err }) => {
  $('compose').disabled = !!busy;
  msg(text, err ? 'err' : busy ? '' : 'ok');
});
api.onLoad(async ({ title, text, play, mine }) => {
  stop();
  await refreshSaved(title);
  $('title').value = title; $('score').value = text; mineLoaded = !!mine;
  check();
  if (play) $('play').click();
});

/* ---------- 开始 ---------- */
(async () => {
  await refreshSaved('');
  const names = Object.keys(saved);
  if (!names.length) {
    $('title').value = '放学后的星星（示例）';
    $('score').value = "1=C 4/4 ♩=126 音色=电子琴 伴奏=流行   // 示例：可以直接点“播放”\n5 1'_ 2'_ 3' 2'_ 1'_ | 6 - 5 3_ 5_ | 6 1'_ 6_ 5 3_ 2_ | 3 - - 0 |\n5 1'_ 2'_ 3' 5'_ 3'_ | 4' 3'_ 2'_ 1' 6_ 1'_ | 2' 1'_ 7_ 1'_ 2'_ 3'_ 2'_ | 1' - - 0 |\n和弦：| C | F G | Am | Em | C | F | Dm G | C |";
  }
  check();
})();

/* ---------- 写词：把当前作品直接交给写词窗口（不用先导出文件） ---------- */
function currentPiece() {
  const text = $('score').value, title = $('title').value.trim();
  if (!text.trim()) return { error: '合成器里还没有曲子：先写一段，或者从“已保存的曲子”里选一首，再点“为这首写歌词”。' };
  const p = Jianpu.parse(text);
  if (p.error) return { error: '这首谱子有错误，先改好再写歌词：' + p.error.msg };
  if (!p.notes.some((n) => n.midi.length)) return { error: '这首谱子里还没有音符（只有休止、和弦或空白）。' };
  return { kind: 'synth', title, text, mine: mineLoaded };
}
$('toLyrics').onclick = async () => {
  clearTimeout(checkTimer);   // 不让输入检查的提示盖掉这里的提示
  const c = currentPiece();
  if (c.error) { msg(c.error, 'err'); return; }
  const r = await api.toLyrics(c);
  if (r && r.error) msg(r.error, 'err');
  else msg(`已经把${c.title ? '《' + c.title + '》' : '当前这首'}交给写词窗口（编辑框里的内容没有改动）。`, 'ok');
};
api.onGetCurrent && api.onGetCurrent((reqId) => api.currentReply(reqId, currentPiece()));
