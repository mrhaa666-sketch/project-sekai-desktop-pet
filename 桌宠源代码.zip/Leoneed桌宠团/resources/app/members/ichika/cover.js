// 翻唱：用她克隆后的音色（MiniMax 音色 ID）翻唱一首歌。
// 主进程这边负责：开窗口、在后台线程里分离人声（cover-worker.js）、语音识别歌词、用聊天模型把歌词转成假名、
// 用 MiniMax 念每个音节（有缓存）、保存文件。声音的分析、对齐和合成在页面里（src/cover-dsp.js）。
const { BrowserWindow, ipcMain, dialog } = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');
const { Worker } = require('worker_threads');

module.exports = function setupCover({ getSettings, icon, appDir, userData, sayLine, openSettings, voice, llm, transcribe, note }) {
  let win = null, sepJob = null;
  const requests = new Set();
  async function requestJob(fn) {
    const ctl = new AbortController(); requests.add(ctl);
    try {
      const result = await fn(ctl.signal);
      return ctl.signal.aborted ? { error: '已取消', canceled: true } : result;
    } catch (e) { return { error: ctl.signal.aborted ? '已取消' : String(e.message || e), canceled: ctl.signal.aborted }; }
    finally { requests.delete(ctl); }
  }
  const send = (ch, v) => { if (win && !win.isDestroyed()) win.webContents.send(ch, v); };
  const fromWin = (e) => win && !win.isDestroyed() && e.sender === win.webContents;
  const cacheDir = path.join(userData, 'cover-cache');
  const modelPath = path.join(appDir, 'models', 'Kim_Vocal_2.onnx');

  function open() {
    if (win && !win.isDestroyed()) { win.focus(); return win; }
    win = new BrowserWindow({
      width: 1000, height: 820, minWidth: 820, minHeight: 620, title: '一歌桌宠 · 用她的声音翻唱',
      icon, autoHideMenuBar: true, backgroundColor: '#f4f9fc',
      webPreferences: { preload: path.join(appDir, 'preload-cover.js'), contextIsolation: true },
    });
    win.loadFile(path.join(appDir, 'src', 'cover.html'));
    win.on('closed', () => { cancelAll(); win = null; });
    return win;
  }
  function cancelAll() {
    const job = sepJob;
    if (job) { job.cancelled = true; try { job.worker.postMessage({ type: 'cancel' }); setTimeout(() => { try { if (!job.finished) job.worker.terminate(); } catch (e) {} }, 300); } catch (e) {} }
    for (const ctl of requests) ctl.abort();
  }

  const voiceReady = (s) => !!(s.ttsKey && s.ttsVoiceId);
  ipcMain.handle('cover-config', () => {
    const s = getSettings();
    return { hasVoice: voiceReady(s), voiceOn: !!s.ttsEnabled, hasAsr: !!s.asrKey, hasChat: llm.hasChatApi(s), hasModel: fs.existsSync(modelPath), threads: threadCount(), name: s.name || '' };
  });
  const threadCount = () => Math.max(1, Math.min(8, (os.cpus() || []).length - 1));

  /* ---------- 人声分离（有缓存：同一首歌第二次不用再算） ---------- */
  const toF32 = (v) => {
    if (v instanceof Float32Array) return v;
    if (ArrayBuffer.isView(v)) return new Float32Array(v.buffer.slice(v.byteOffset, v.byteOffset + v.byteLength));
    return new Float32Array(v);
  };
  function readCache(hash) {
    try {
      const f = path.join(cacheDir, hash + '.vocal');
      const b = fs.readFileSync(f);
      const n = b.readUInt32LE(0);
      const i16 = new Int16Array(b.buffer.slice(b.byteOffset + 4, b.byteOffset + 4 + n * 4));
      const L = new Float32Array(n), R = new Float32Array(n);
      for (let i = 0; i < n; i++) { L[i] = i16[2 * i] / 32767; R[i] = i16[2 * i + 1] / 32767; }
      const now = new Date(); fs.utimesSync(f, now, now);
      return { L, R };
    } catch (e) { return null; }
  }
  function writeCache(hash, L, R) {
    try {
      fs.mkdirSync(cacheDir, { recursive: true });
      const n = L.length, i16 = new Int16Array(n * 2);
      for (let i = 0; i < n; i++) { i16[2 * i] = Math.round(Math.max(-1, Math.min(1, L[i])) * 32767); i16[2 * i + 1] = Math.round(Math.max(-1, Math.min(1, R[i])) * 32767); }
      const head = Buffer.alloc(4); head.writeUInt32LE(n, 0);
      const b = Buffer.concat([head, Buffer.from(i16.buffer)]);
      fs.writeFileSync(path.join(cacheDir, hash + '.vocal'), b);
      // 只留最近 3 首
      const files = fs.readdirSync(cacheDir).filter((f) => f.endsWith('.vocal')).map((f) => ({ f, t: fs.statSync(path.join(cacheDir, f)).mtimeMs })).sort((a, b2) => b2.t - a.t);
      for (const x of files.slice(3)) fs.unlinkSync(path.join(cacheDir, x.f));
    } catch (e) {}
  }
  ipcMain.handle('cover-separate', async (e, { L, R, hash }) => {
    if (!fromWin(e)) return { error: 'denied' };
    if (sepJob) return { error: '正在分离另一首，请稍等' };
    if (!fs.existsSync(modelPath)) return { error: '缺少人声分离模型（resources\\app\\models\\Kim_Vocal_2.onnx）' };
    const safeHash = /^[0-9a-f]{16,64}$/.test(String(hash || '')) ? String(hash) : '';
    if (safeHash) { const c = readCache(safeHash); if (c && c.L.length === (L.length || L.byteLength / 4)) return { L: c.L, R: c.R, cached: true }; }
    const l = toF32(L), r = toF32(R);
    const sL = new SharedArrayBuffer(l.length * 4), sR = new SharedArrayBuffer(r.length * 4);
    new Float32Array(sL).set(l); new Float32Array(sR).set(r);
    return new Promise((resolve) => {
      const worker = new Worker(path.join(appDir, 'cover-worker.js'), { workerData: { modelPath, threads: threadCount(), sab: { L: sL, R: sR } } });
      const job = { worker, cancelled: false, finished: false }; sepJob = job;
      const finish = (v) => { if (job.finished) return; job.finished = true; if (sepJob === job) sepJob = null; try { worker.terminate(); } catch (err) {} resolve(job.cancelled ? { error: '已取消', canceled: true } : v); };
      worker.on('message', (m) => {
        if (m.type === 'progress') send('cover-progress', { stage: m.stage, done: m.done, total: m.total, eta: m.eta });
        else if (m.type === 'done') { if (safeHash && !job.cancelled && !job.finished) writeCache(safeHash, m.L, m.R); finish({ L: m.L, R: m.R }); }
        else if (m.type === 'error') finish({ error: m.error === 'cancelled' ? '已取消' : '分离失败：' + m.error, canceled: m.error === 'cancelled' });
      });
      worker.on('error', (err) => finish({ error: '分离失败：' + err.message }));
      worker.on('exit', (code) => { if (sepJob && sepJob.worker === worker) finish({ error: code ? '分离被中断了' : '已取消', canceled: true }); });
    });
  });
  ipcMain.on('cover-cancel', (e) => { if (fromWin(e)) cancelAll(); });

  /* ---------- 识别歌词：按乐句分段交给语音识别 ---------- */
  ipcMain.handle('cover-asr', async (e, { chunks }) => {
    if (!fromWin(e)) return { error: 'denied' };
    return requestJob(async (signal) => {
    const s = getSettings();
    if (!s.asrKey) return { error: '还没填语音识别的密钥（右键 → 设置 → 语音通话（语音识别））' };
    const lines = [];
    for (let i = 0; i < chunks.length; i++) {
      if (signal.aborted) return { canceled: true };
      send('cover-progress', { stage: 'asr', done: i, total: chunks.length });
      const r = await transcribe(s, Buffer.from(chunks[i]), signal);
      if (signal.aborted) return { canceled: true };
      if (r.error && r.error !== 'noasr') return { error: '识别出错：' + r.error, lines };
      lines.push(r.text || '');
    }
    send('cover-progress', { stage: 'asr', done: chunks.length, total: chunks.length });
    return { lines };
    });
  });

  /* ---------- 歌词转成假名（聊天模型） ---------- */
  ipcMain.handle('cover-kana', async (e, { lines, lang }) => {
    if (!fromWin(e)) return { error: 'denied' };
    return requestJob(async (signal) => {
    const s = getSettings();
    if (!llm.hasChatApi(s)) return { error: '还没填聊天模型的 API（右键 → 设置）' };
    const zh = lang === 'zh';
    const system = zh
      ? '你是歌词整理助手。把用户给的每一行歌词整理成适合逐字演唱的中文：数字写成汉字，英文单词保留，去掉标点和括号里的注释。行数和顺序保持不变。只输出 JSON：{"lines": ["…", "…"]}'
      : 'あなたは歌詞の読み仮名を付けるアシスタントです。与えられた各行の日本語の歌詞を、歌うときの読み方どおりにすべてひらがなに変換してください（漢字・カタカナ・英語・数字もひらがなの読みに。「は」「へ」の助詞は発音どおり「わ」「え」、長音は「ー」でも可）。句読点や括弧の注釈は除き、単語の区切りに半角スペースを入れてよい。行数と順番は変えないこと。JSON だけを出力：{"lines": ["…", "…"]}';
    try {
      const r = await llm.request(s, { system, messages: [{ role: 'user', content: JSON.stringify({ lines: lines.slice(0, 200) }) }], maxTokens: 4000, signal: AbortSignal.any([signal, AbortSignal.timeout(120000)]) });
      if (r.error) return { error: r.error };
      const content = r.data?.choices?.[0]?.message?.content || '';
      const m = content.match(/\{[\s\S]*\}/);
      const o = JSON.parse(m ? m[0] : content);
      if (!Array.isArray(o.lines) || o.lines.length !== Math.min(lines.length, 200) || !o.lines.every(x => typeof x === 'string')) return { error: '模型返回的歌词行数或格式不对，请重试' };
      return { lines: o.lines.map((x) => String(x || '')) };
    } catch (err) { return { error: '转换失败：' + (err.name === 'TimeoutError' ? '等太久没有回应' : err.message) }; }
    });
  });

  /* ---------- 用她的音色念每个音节（MiniMax，有缓存） ---------- */
  ipcMain.handle('cover-tts', async (e, { items, lang }) => {
    if (!fromWin(e)) return { error: 'denied' };
    return requestJob(async (signal) => {
    const s = getSettings();
    if (!voiceReady(s)) return { error: '还没设置她的声音：右键 → 设置 → 语音，填 MiniMax 密钥和音色 ID' };
    const out = {}, list = [...new Set(items.map(String))].slice(0, 1500);
    let done = 0, firstErr = null, idx = 0;
    const one = async () => {
      while (idx < list.length && !signal.aborted && !firstErr) {
        const text = list[idx++];
        // 不带语气、语速稍慢，元音长一点好拉伸
        let r = await voice.speak(s, text, 'calm', signal, { lang, speed: 0.9, emotion: '' });
        if (r.error && /频繁|1002|1039|429/.test(r.error)) { await new Promise((ok) => setTimeout(ok, 1500)); r = await voice.speak(s, text, 'calm', signal, { lang, speed: 0.9, emotion: '' }); }
        if (r.audio) out[text] = r.audio; else if (r.error !== 'aborted') firstErr = firstErr || r.error;
        done++;
        send('cover-progress', { stage: 'tts', done, total: list.length, cached: !!r.cached });
      }
    };
    await Promise.all([one(), one(), one()]);
    if (signal.aborted) return { error: '已取消', canceled: true };
    if (firstErr && Object.keys(out).length < list.length) return { error: '她的声音合成出错：' + firstErr, audio: out };
    return { audio: out };
    });
  });

  /* ---------- 保存 ---------- */
  ipcMain.handle('cover-save', async (e, { name, data }) => {
    if (!fromWin(e)) return { error: 'denied' };
    const safe = (String(name || '翻唱').replace(/[\\/:*?"<>|\r\n]/g, '_').trim() || '翻唱').slice(0, 80);
    const r = await dialog.showSaveDialog(win, { title: '保存', defaultPath: safe + '.wav', filters: [{ name: 'WAV 音频', extensions: ['wav'] }] });
    if (r.canceled || !r.filePath) return { canceled: true };
    fs.writeFileSync(r.filePath, Buffer.from(data));
    return { ok: true, path: r.filePath };
  });
  ipcMain.on('cover-open-settings', (e) => { if (fromWin(e)) openSettings(); });
  ipcMain.on('cover-done', (e, title) => {
    if (!fromWin(e)) return;
    const t = String(title || '').slice(0, 30);
    if (note) note(`你用自己的声音翻唱了${t ? '《' + t + '》' : '一首歌'}给${getSettings().name || '对方'}听`);
    sayLine(`唱好了${t ? '，《' + t + '》' : ''}。……有点不好意思，你听听看？`, `歌えたよ${t ? '、「' + t + '」' : ''}。……ちょっと恥ずかしいけど、聴いてみて？`, 'shy', 'shy');
  });

  return { open };
};
