// 翻唱窗口：只暴露翻唱需要的接口（密钥不会传到页面）
const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('coverAPI', {
  config: () => ipcRenderer.invoke('cover-config'),
  separate: (v) => ipcRenderer.invoke('cover-separate', v),
  cancel: () => ipcRenderer.send('cover-cancel'),
  asr: (chunks) => ipcRenderer.invoke('cover-asr', { chunks }),
  kana: (lines, lang) => ipcRenderer.invoke('cover-kana', { lines, lang }),
  tts: (items, lang) => ipcRenderer.invoke('cover-tts', { items, lang }),
  save: (v) => ipcRenderer.invoke('cover-save', v),
  openSettings: () => ipcRenderer.send('cover-open-settings'),
  done: (title) => ipcRenderer.send('cover-done', title),
  onProgress: (cb) => ipcRenderer.on('cover-progress', (_e, v) => cb(v)),
});
