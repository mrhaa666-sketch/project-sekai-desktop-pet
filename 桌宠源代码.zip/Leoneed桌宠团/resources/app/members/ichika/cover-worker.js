'use strict';
// 翻唱用的人声分离（在后台线程里跑，不卡桌宠）。
// 模型：MDX-Net（Kim_Vocal_2，UVR 的人声模型，ONNX），用 onnxruntime-web 的 WebAssembly 版本在本机 CPU 上算，不联网。
// 流程：每段约 5.9 秒做短时傅里叶变换（n_fft 7680，hop 1024）→ 模型估计人声的频谱 → 逆变换回波形 → 拼起来。
// 伴奏 = 原曲 − 人声（在页面里算）。
const { parentPort, workerData, isMainThread } = require('worker_threads');
const path = require('path');
const fs = require('fs');

const N_FFT = 7680, HOP = 1024, DIM_F = 3072, DIM_T = 256;
const TRIM = N_FFT / 2;
const CHUNK = HOP * (DIM_T - 1);          // 261120 个采样
const GEN = CHUNK - 2 * TRIM;             // 每段实际留下的长度
const BINS = N_FFT / 2 + 1;
const COMPENSATE = 1.009;

/* ---------- FFT：7680 = 512 × 15（512 点用基 2，15 点直接算） ---------- */
class FFT7680 {
  constructor() {
    this.N = N_FFT; this.N1 = 512; this.N2 = 15;
    const N1 = this.N1, N2 = this.N2, N = this.N;
    // 512 点 FFT 的位反转和旋转因子
    this.rev = new Uint16Array(N1);
    const bits = 9;
    for (let i = 0; i < N1; i++) { let r = 0; for (let b = 0; b < bits; b++) if (i & (1 << b)) r |= 1 << (bits - 1 - b); this.rev[i] = r; }
    this.c1 = new Float64Array(N1 / 2); this.s1 = new Float64Array(N1 / 2);
    for (let i = 0; i < N1 / 2; i++) { this.c1[i] = Math.cos(-2 * Math.PI * i / N1); this.s1[i] = Math.sin(-2 * Math.PI * i / N1); }
    // 中间的旋转因子 W_N^(n2*k1)
    this.tc = new Float64Array(N2 * N1); this.ts = new Float64Array(N2 * N1);
    for (let n2 = 0; n2 < N2; n2++) for (let k1 = 0; k1 < N1; k1++) { const a = -2 * Math.PI * n2 * k1 / N; this.tc[n2 * N1 + k1] = Math.cos(a); this.ts[n2 * N1 + k1] = Math.sin(a); }
    // 15 点 DFT 矩阵
    this.dc = new Float64Array(N2 * N2); this.ds = new Float64Array(N2 * N2);
    for (let a = 0; a < N2; a++) for (let b = 0; b < N2; b++) { const t = -2 * Math.PI * a * b / N2; this.dc[a * N2 + b] = Math.cos(t); this.ds[a * N2 + b] = Math.sin(t); }
    this.yr = new Float64Array(N); this.yi = new Float64Array(N);
  }
  fft512(re, im) {
    const N1 = this.N1, rev = this.rev;
    for (let i = 0; i < N1; i++) { const j = rev[i]; if (j > i) { let t = re[i]; re[i] = re[j]; re[j] = t; t = im[i]; im[i] = im[j]; im[j] = t; } }
    for (let size = 2; size <= N1; size <<= 1) {
      const half = size >> 1, step = N1 / size;
      for (let i = 0; i < N1; i += size) {
        for (let j = 0, k = 0; j < half; j++, k += step) {
          const c = this.c1[k], s = this.s1[k];
          const a = i + j, b = a + half;
          const tr = re[b] * c - im[b] * s, ti = re[b] * s + im[b] * c;
          re[b] = re[a] - tr; im[b] = im[a] - ti; re[a] += tr; im[a] += ti;
        }
      }
    }
  }
  // 正变换（in/out：长度 7680 的实部、虚部数组）
  forward(xr, xi, outR, outI) {
    const N1 = this.N1, N2 = this.N2;
    const yr = this.yr, yi = this.yi;
    const br = new Float64Array(N1), bi = new Float64Array(N1);
    for (let n2 = 0; n2 < N2; n2++) {
      for (let n1 = 0; n1 < N1; n1++) { br[n1] = xr[N2 * n1 + n2]; bi[n1] = xi ? xi[N2 * n1 + n2] : 0; }
      this.fft512(br, bi);
      const o = n2 * N1;
      for (let k1 = 0; k1 < N1; k1++) {
        const c = this.tc[o + k1], s = this.ts[o + k1];
        yr[o + k1] = br[k1] * c - bi[k1] * s; yi[o + k1] = br[k1] * s + bi[k1] * c;
      }
    }
    for (let k1 = 0; k1 < N1; k1++) {
      for (let k2 = 0; k2 < N2; k2++) {
        let sr = 0, si = 0;
        const row = k2 * N2;
        for (let n2 = 0; n2 < N2; n2++) {
          const c = this.dc[row + n2], s = this.ds[row + n2];
          const ar = yr[n2 * N1 + k1], ai = yi[n2 * N1 + k1];
          sr += ar * c - ai * s; si += ar * s + ai * c;
        }
        outR[k1 + N1 * k2] = sr; outI[k1 + N1 * k2] = si;
      }
    }
  }
}

const fft = new FFT7680();
const WIN = new Float64Array(N_FFT);
for (let i = 0; i < N_FFT; i++) WIN[i] = 0.5 - 0.5 * Math.cos(2 * Math.PI * i / N_FFT);   // periodic hann

// 一段（CHUNK 长）的双声道波形 → 模型输入 [1, 4, 3072, 256]
function stftChunk(L, R, input) {
  const fr = new Float64Array(N_FFT), outR = new Float64Array(N_FFT), outI = new Float64Array(N_FFT);
  const chans = [L, R];
  for (let ch = 0; ch < 2; ch++) {
    const x = chans[ch];
    for (let t = 0; t < DIM_T; t++) {
      const start = t * HOP - N_FFT / 2;
      for (let i = 0; i < N_FFT; i++) {
        let p = start + i;
        // center=True 的反射补边
        if (p < 0) p = -p; else if (p >= CHUNK) p = 2 * (CHUNK - 1) - p;
        fr[i] = x[p] * WIN[i];
      }
      fft.forward(fr, null, outR, outI);
      const baseR = (ch * 2) * DIM_F * DIM_T, baseI = (ch * 2 + 1) * DIM_F * DIM_T;
      for (let f = 0; f < DIM_F; f++) { input[baseR + f * DIM_T + t] = outR[f]; input[baseI + f * DIM_T + t] = outI[f]; }
    }
  }
}

// 模型输出 [1, 4, 3072, 256] → 双声道波形（CHUNK 长）
function istftChunk(spec, outL, outR) {
  const xr = new Float64Array(N_FFT), xi = new Float64Array(N_FFT), yr = new Float64Array(N_FFT), yi = new Float64Array(N_FFT);
  const padLen = CHUNK + N_FFT;
  const outs = [outL, outR];
  for (let ch = 0; ch < 2; ch++) {
    const acc = new Float64Array(padLen), wsum = new Float64Array(padLen);
    const baseR = (ch * 2) * DIM_F * DIM_T, baseI = (ch * 2 + 1) * DIM_F * DIM_T;
    for (let t = 0; t < DIM_T; t++) {
      xr.fill(0); xi.fill(0);
      for (let f = 0; f < DIM_F; f++) { xr[f] = spec[baseR + f * DIM_T + t]; xi[f] = spec[baseI + f * DIM_T + t]; }
      // 共轭对称补全，再用“共轭 → 正变换 → 共轭”做逆变换
      for (let f = 1; f < BINS - 1; f++) { xr[N_FFT - f] = xr[f]; xi[N_FFT - f] = -xi[f]; }
      for (let i = 0; i < N_FFT; i++) xi[i] = -xi[i];
      fft.forward(xr, xi, yr, yi);
      const off = t * HOP;
      for (let i = 0; i < N_FFT; i++) { const v = yr[i] / N_FFT; acc[off + i] += v * WIN[i]; wsum[off + i] += WIN[i] * WIN[i]; }
    }
    const out = outs[ch];
    for (let i = 0; i < CHUNK; i++) { const w = wsum[i + N_FFT / 2]; out[i] = w > 1e-8 ? acc[i + N_FFT / 2] / w : 0; }
  }
}

async function run() {
  const { modelPath, threads, sab } = workerData;
  const L = new Float32Array(sab.L), R = new Float32Array(sab.R);
  const n = L.length;
  const ort = require('onnxruntime-web');
  ort.env.wasm.numThreads = threads;
  ort.env.logLevel = 'error';
  parentPort.postMessage({ type: 'progress', stage: 'load', done: 0, total: 1 });
  const session = await ort.InferenceSession.create(fs.readFileSync(modelPath), { executionProviders: ['wasm'], graphOptimizationLevel: 'all' });
  const inName = session.inputNames[0], outName = session.outputNames[0];
  // 补边：前后各 TRIM，后面补到 GEN 的整数倍
  const pad = GEN - (n % GEN);
  const total = TRIM + n + pad + TRIM;
  const mL = new Float32Array(total), mR = new Float32Array(total);
  mL.set(L, TRIM); mR.set(R, TRIM);
  const vL = new Float32Array(n), vR = new Float32Array(n);
  const steps = Math.ceil((n + pad) / GEN);
  const input = new Float32Array(4 * DIM_F * DIM_T);
  const oL = new Float32Array(CHUNK), oR = new Float32Array(CHUNK);
  const t0 = Date.now();
  for (let s = 0; s < steps; s++) {
    if (cancelled) throw new Error('cancelled');
    const i = s * GEN;
    stftChunk(mL.subarray(i, i + CHUNK), mR.subarray(i, i + CHUNK), input);
    const res = await session.run({ [inName]: new ort.Tensor('float32', input, [1, 4, DIM_F, DIM_T]) });
    istftChunk(res[outName].data, oL, oR);
    // 留下中间那段（去掉两头各 TRIM）
    for (let k = 0; k < GEN; k++) {
      const p = i + k;            // 在原曲里的位置
      if (p >= n) break;
      vL[p] = oL[TRIM + k] * COMPENSATE; vR[p] = oR[TRIM + k] * COMPENSATE;
    }
    const el = (Date.now() - t0) / 1000;
    parentPort.postMessage({ type: 'progress', stage: 'separate', done: s + 1, total: steps, eta: Math.round(el / (s + 1) * (steps - s - 1)) });
  }
  try { await session.release(); } catch (e) {}
  parentPort.postMessage({ type: 'done', L: vL, R: vR }, [vL.buffer, vR.buffer]);
}

let cancelled = false;
if (!isMainThread && workerData && workerData.sab) {
  parentPort.on('message', (m) => { if (m && m.type === 'cancel') cancelled = true; });
  run().catch((e) => parentPort.postMessage({ type: 'error', error: String(e && e.message || e) }));
}

module.exports = { FFT7680, stftChunk, istftChunk, CHUNK, N_FFT };
