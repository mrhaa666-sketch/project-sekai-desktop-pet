// 台词、心情、动作。对你的她：安静、坦率、温柔，偶尔有点笨拙；会好好看着你说话。
// t = 台词，ja = 配音用的日语（空 = 不配音），m = 心情（决定表情），a = 动作（决定身体动作）。
// {name} 会替换成设置里的称呼（日语里换成「日语称呼」）。
'use strict';

// 表情代号表：代号 → [文件名, 说明]。文件在 model/faces/文件名.motion3.json（三套衣服都有）。
// 文件名保持英文，是为了解压时不会因为中文文件名出乱码；平时只用中文代号。
// 想加新表情：把文件放进三套衣服的 faces/，再在这里加一行。
window.FACES = {
  '平常': ['face_normal_01', '平常的脸，安静柔和（默认）'],
  '平静': ['face_smallmouth_01', '平静，嘴很小'],
  '微笑1': ['face_smile_01', '浅浅的微笑'],
  '微笑2': ['face_smile_02', '温和的微笑'],
  '微笑3': ['face_smile_04', '轻松的微笑'],
  '淡笑': ['face_smile_09', '嘴角微微上扬'],
  '温柔笑': ['face_smile_10', '温柔地看着你笑'],
  '认真微笑': ['face_smile_11', '带着干劲的微笑'],
  '笑眼': ['face_smile_03', '眯起眼睛笑'],
  '脸红微笑': ['face_smile_05', '脸红红地笑'],
  '开心': ['face_smile_06', '很开心，脸有点红'],
  '眯眼大笑': ['face_smile_07', '闭着眼开心地笑，脸红'],
  '安心笑': ['face_ncsmile_03', '闭着眼、放下心来的笑'],
  '咧嘴笑': ['face_e_01', '露出一点牙齿的笑'],
  '调皮': ['face_play_02', '有点调皮的笑'],
  '苦笑': ['face_smile_08', '冒汗的苦笑'],
  '闪亮1': ['face_sparkling_01', '眼睛发亮（聊到喜欢的东西）'],
  '闪亮2': ['face_sparkling_02', '眼睛发亮，脸红'],
  '闪亮3': ['face_sparkling_03', '眼睛发亮地笑'],
  '害羞1': ['face_shy_01', '害羞，脸红'],
  '害羞2': ['face_shy_02', '害羞，眉毛为难'],
  '害羞3': ['face_shy_03', '害羞地抿嘴'],
  '窘迫': ['face_ossad_01', '难为情，冒汗'],
  '窘迫低头': ['face_oslookdown_01', '难为情地低下视线'],
  '窘迫闭眼': ['face_osscream_01', '难为情地闭紧眼睛'],
  '闭眼': ['face_closeeye_01', '静静地闭着眼'],
  '闭眼微笑': ['face_closeeye_02', '闭着眼微笑'],
  '闭眼放松': ['face_closeeye_03', '闭眼，很放松'],
  '闭眼想': ['face_closeeye_04', '闭着眼想事情'],
  '闭眼为难': ['face_closeeye_05', '闭着眼，有点为难'],
  '闭眼叹气': ['face_closeeye_06', '闭眼叹一口气'],
  '松口气': ['face_breath_01', '闭眼呼出一口气'],
  '困': ['face_sleepy_01', '困了，眼睛半睁'],
  '哈欠': ['face_yawn_01', '打哈欠'],
  '认真': ['face_sharp_01', '认真起来的眼神'],
  '坚定': ['face_purpose_02', '下定决心'],
  '惊讶1': ['face_surprise_01', '惊讶'],
  '惊讶2': ['face_surprise_02', '惊讶，眉毛扬起'],
  '惊讶3': ['face_surprise_03', '有点意外'],
  '张嘴': ['face_eat_01', '“啊”地张开嘴'],
  '晕乎乎': ['face_guruguru_01', '脑子转不过来了'],
  '困扰1': ['face_trouble_01', '困扰'],
  '困扰2': ['face_trouble_02', '困扰，有点慌'],
  '担心1': ['face_worry_01', '担心'],
  '担心2': ['face_worry_02', '担心地看着你'],
  '叹气': ['face_sigh_01', '无奈地叹气'],
  '后悔': ['face_regret_01', '后悔、自责'],
  '难过1': ['face_sad_01', '难过'],
  '难过2': ['face_sad_02', '难过，嘴微张'],
  '难过3': ['face_sad_03', '难过，垂着眉'],
  '难过4': ['face_sad_04', '难过，忍着'],
  '难过5': ['face_sad_05', '很难过'],
  '想哭1': ['face_cry_01', '眼眶湿了'],
  '想哭2': ['face_cry_02', '快要哭了'],
  '想哭3': ['face_cry_03', '含着泪'],
  '流泪': ['face_cry_04', '掉眼泪'],
  '移开视线': ['face_lookaway_01r', '眼睛看向旁边'],
  '移开视线2': ['face_lookaway_01l', '眼睛看向另一边'],
  '低头': ['face_lookdown_01', '眼睛往下看'],
  '不满': ['face_angry_01', '不满，皱眉'],
  '脸红生气': ['face_angry_02', '红着脸生气'],
  '不快': ['face_disgust_01', '不快，皱眉'],
  '讨厌': ['face_hate_01', '讨厌、受不了'],
  '阴沉': ['face_shadow_01', '脸上有阴影，很受打击'],
};

// 心情 → 表情 + 动作。
// faces：[表情代号, 强度]，强度 0~1（1 是完整的表情，小一点会更接近「平常」）。
// rare：偶尔才出现的表情，chance 是出现概率。
// actions：这个心情常用的身体动作；AI 没选动作时从这里挑。
window.MOODS = {
  calm:       { faces: [['平常', 1], ['平静', 1]], rare: { chance: 0.25, faces: [['淡笑', 0.8], ['微笑1', 0.6]] }, actions: ['none', 'nod', 'tilt'], desc: '平静、平常的样子（默认）' },
  smile:      { faces: [['微笑1', 0.9], ['微笑2', 0.9], ['淡笑', 1], ['微笑3', 0.85]], actions: ['nod', 'tilt'], desc: '心情不错，温和地笑' },
  happy:      { faces: [['开心', 0.9], ['笑眼', 0.9], ['脸红微笑', 0.85], ['咧嘴笑', 0.8]], actions: ['glad', 'nod'], desc: '开心' },
  excited:    { faces: [['闪亮1', 0.9], ['闪亮3', 0.9], ['眯眼大笑', 0.85]], actions: ['glad', 'cheer'], desc: '兴奋、眼睛发亮（聊到初音未来、吉他、乐队时常有）' },
  warm:       { faces: [['温柔笑', 0.9], ['安心笑', 0.85], ['闭眼微笑', 0.85]], actions: ['warm', 'nod'], desc: '被打动、心里暖暖的、放下心来' },
  shy:        { faces: [['害羞1', 0.85], ['害羞3', 0.85], ['脸红微笑', 0.7]], actions: ['shy', 'fidget'], desc: '害羞、不好意思' },
  flustered:  { faces: [['窘迫', 0.85], ['害羞2', 0.9], ['窘迫闭眼', 0.8]], actions: ['shy', 'look_away'], desc: '被说中、慌了、很难为情' },
  think:      { faces: [['平静', 1], ['闭眼想', 0.7], ['移开视线', 0.6]], actions: ['think', 'tilt'], desc: '在想事情' },
  determined: { faces: [['坚定', 0.9], ['认真微笑', 0.9], ['认真', 0.8]], actions: ['resolve', 'cheer'], desc: '下定决心、有干劲（“一起加油吧”）' },
  sad:        { faces: [['难过1', 0.75], ['难过3', 0.75], ['难过4', 0.7]], actions: ['look_down', 'sigh'], desc: '低落、难过' },
  hurt:       { faces: [['想哭1', 0.8], ['难过5', 0.75], ['想哭3', 0.7]], actions: ['look_down', 'sigh'], desc: '受伤、很难受' },
  worried:    { faces: [['担心1', 0.85], ['担心2', 0.85]], actions: ['trouble', 'tilt'], desc: '担心你' },
  troubled:   { faces: [['困扰1', 0.8], ['困扰2', 0.8], ['苦笑', 0.8]], actions: ['trouble', 'shake'], desc: '困扰、为难' },
  surprised:  { faces: [['惊讶1', 0.85], ['惊讶3', 0.9], ['惊讶2', 0.8]], actions: ['tilt', 'nod'], desc: '吃惊、意外' },
  sleepy:     { faces: [['困', 1], ['闭眼', 1]], actions: ['sleep'], desc: '困了' },
  sulky:      { faces: [['不满', 0.7], ['不快', 0.65], ['叹气', 0.8]], actions: ['shake', 'sigh', 'look_away'], desc: '有点不高兴、闹别扭' },
  angry:      { faces: [['不满', 1], ['脸红生气', 0.9], ['讨厌', 0.75]], actions: ['angry', 'arms', 'shake'], desc: '生气（她很少真的生气）' },
};

// 动作 → 身体动作（随机挑一个）。
// 同一个动作准备了几种站姿下的版本：桌宠会优先挑和她现在站姿一样的那个，衔接不会突然换手、换姿势。
// 张开双臂、跳起来、身体大幅前倾的动作都不用（会伸出窗口或上下移动）。
window.ACTIONS = {
  none:      { bodies: [], desc: '不做动作' },
  nod:       { bodies: ['w-normal16-nod', 'w-noromal16-nod', 'w-normal15-nod', 'w-normal03-nod', 'w-normal07-nod', 'w-normal17-nod', 'w-cool13-nod'], desc: '点头' },
  tilt:      { bodies: ['w-normal16-tilthead', 'w-noromal16-tilthead', 'w-normal15-tilthead', 'w-normal03-tilthead', 'w-normal07-tilthead', 'w-normal17-tilthead'], desc: '歪头' },
  think:     { bodies: ['w-adult05-think', 'w-cool13-tilthead', 'w-normal03-tiltheadB', 'w-normal07-tiltheadB'], desc: '想事情（手托下巴、抱臂歪头）' },
  glad:      { bodies: ['w-normal01-glad', 'w-adult12-glad', 'w-cute11-glad'], desc: '开心地双手合在胸前' },
  cheer:     { bodies: ['w-normal01-guts', 'w-happy11-guts', 'w-cool02-guts'], desc: '握拳打气（“加油”）' },
  thumb:     { bodies: ['w-cool01-thumb', 'w-cool02-thumb'], desc: '竖大拇指（“很棒”）' },
  resolve:   { bodies: ['w-normal01-purpose', 'w-happy02-purpose'], desc: '握住手、下定决心' },
  warm:      { bodies: ['w-normal03-relief', 'w-normal04-relief', 'w-adult12-relief'], desc: '手按在胸口（安心、被打动）' },
  shy:       { bodies: ['w-normal15-shy', 'w-normal03-blushed', 'w-normal04-blushed', 'w-pure12-shy'], desc: '害羞地缩一下' },
  fidget:    { bodies: ['w-normal17-fidget', 'w-pure12-fidget'], desc: '手指绞在一起，有点不好意思' },
  greet:     { bodies: ['w-normal15-greeting'], desc: '打招呼、轻轻鞠一躬' },
  look_down: { bodies: ['w-normal07-sad', 'w-normal08-sad', 'w-cool16-sad', 'w-happy16-sad'], desc: '垂下视线（低落）' },
  sigh:      { bodies: ['w-normal07-sigh', 'w-cool13-sigh', 'w-happy09-sigh'], desc: '叹气' },
  trouble:   { bodies: ['w-normal03-trouble', 'w-normal04-trouble', 'w-adult05-trouble'], desc: '为难、担心' },
  shake:     { bodies: ['w-normal16-shakehead', 'w-noromal16-shakehead', 'w-normal15-shakehead', 'w-normal03-shakehead', 'w-normal07-shakehead', 'w-normal17-shakehead', 'w-cool13-shakehead'], desc: '摇头' },
  look_away: { bodies: ['w-normal15-lookaround', 'w-normal03-lookleft', 'w-normal03-lookright'], desc: '移开视线、看看旁边' },
  arms:      { bodies: ['w-cool13-sigh', 'w-cool13-shakehead'], desc: '抱起胳膊' },
  angry:     { bodies: ['w-normal16-angry', 'w-noromal16-angry', 'w-happy09-angry'], desc: '生气' },
  music:     { bodies: ['w-normal16-nod', 'w-happy16-nod', 'w-normal15-nod', 'w-normal16-tilthead'], desc: '跟着节奏轻轻点头（听歌、弹琴时）' },
  sleep:     { bodies: ['w-adult15-sleep'], desc: '打瞌睡' },
};

// AI 直接点名表情代号时的强度
window.FACE_STRENGTH_DEFAULT = 0.85;
// 脸上的阴影（ParamFaceShadow）默认一律不加；只有 AI 直接点名下面这些“本来就是阴影效果”的表情时才保留
window.SHADOW_FACES = new Set(['阴沉']);
window.FACE_STRENGTH_FULL = new Set(['平常', '平静', '闭眼', '困', '哈欠']);

window.LINES = {
  // 没接聊天模型时，凌晨一点和纪念日用的固定台词
  nightcord: [{ t: '……已经一点了。{name}，还不睡吗？明天会起不来的哦。', ja: '……もう一時だよ。{name}、まだ寝ないの？明日、起きられなくなっちゃうよ。', m: 'worried', a: 'tilt' }],
  birthdayIchika: [{ t: '今天是我的生日。……被你记着，有点不好意思。谢谢你，{name}。', ja: '今日、私の誕生日なんだ。……覚えててもらえるの、ちょっと照れるね。ありがとう、{name}。', m: 'shy', a: 'shy' }],
  birthdayUser: [{ t: '{name}，生日快乐。……这样说好像太普通了。不过，是我真心想说的话。', ja: '{name}、誕生日おめでとう。……普通すぎるかな。でも、本当にそう思ってるよ。', m: 'warm', a: 'warm' }],
  anniversary: [{ t: '今天是我们的纪念日。……我一直记着哦。', ja: '今日は、私たちの記念日だね。……ちゃんと覚えてたよ。', m: 'warm', a: 'warm' }],
  // 你用合成器弹曲子给她听
  synthListen: [
    { t: '嗯，我在听。', ja: 'うん、聴いてるよ。', m: 'smile', a: 'music' },
    { t: '是你写的吗？……再弹一次给我听好不好。', ja: 'あなたが作ったの？……もう一回、聴かせてくれる？', m: 'excited', a: 'glad' },
    { t: '吉他的声音……果然很好听。', ja: 'ギターの音……やっぱり、いいね。', m: 'warm', a: 'music' },
    { t: '这个旋律，我很喜欢。', ja: 'このメロディ、好きだな。', m: 'happy', a: 'nod' },
  ],
  outfitCasual: [
    { t: '换好衣服了。……嗯，这样轻松多了。', ja: '着替えたよ。……うん、楽になった。', m: 'smile', a: 'nod' },
    { t: '今天辛苦了。接下来就慢慢放松吧。', ja: '今日もお疲れさま。ここからはゆっくりしよう。', m: 'warm', a: 'warm' },
    { t: '换下来了。……待会儿要不要一起听歌？', ja: '着替えちゃった。……あとで一緒に曲、聴かない？', m: 'smile', a: 'tilt' },
  ],
  outfitUniform: [
    { t: '该去学校了。……今天也要好好加油。', ja: 'そろそろ学校だね。……今日も頑張ろう。', m: 'determined', a: 'nod' },
    { t: '换好制服了。嗯，走吧。', ja: '制服、着たよ。うん、行こっか。', m: 'calm', a: 'nod' },
  ],
  outfitUnit: [
    { t: '今天是练习的日子。……我去和大家会合了。', ja: '今日は練習の日。……みんなと合流してくるね。', m: 'determined', a: 'resolve' },
    { t: '换上演出服了。……有点紧张，但也很期待。', ja: 'ステージ衣装、着てみた。……ちょっと緊張するけど、楽しみでもあるんだ。', m: 'excited', a: 'cheer' },
  ],
  greet: {
    morning: [
      { t: '早上好，{name}。', ja: 'おはよう、{name}。', m: 'smile', a: 'greet' },
      { t: '早。……昨天睡得好吗？', ja: 'おはよう。……昨日はちゃんと眠れた？', m: 'calm', a: 'tilt' },
    ],
    day: [
      { t: '啊，{name}。你来了。', ja: 'あ、{name}。来てくれたんだ。', m: 'happy', a: 'nod' },
      { t: '{name}，正好想见你呢。', ja: '{name}、ちょうど会いたいなって思ってたんだ。', m: 'shy', a: 'shy' },
    ],
    evening: [
      { t: '欢迎回来。今天怎么样？', ja: 'おかえり。今日はどうだった？', m: 'smile', a: 'tilt' },
      { t: '辛苦了，{name}。……我一直在等你哦。', ja: 'お疲れさま、{name}。……ずっと待ってたよ。', m: 'warm', a: 'warm' },
    ],
    night: [
      { t: '这么晚了……{name}，你也还没睡啊。', ja: 'こんな時間……{name}もまだ起きてたんだ。', m: 'worried', a: 'tilt' },
      { t: '晚上好。……就聊一会儿，然后要早点睡哦。', ja: 'こんばんは。……少しだけ話したら、ちゃんと寝ようね。', m: 'smile', a: 'nod' },
    ],
  },

  // 点头部
  head: [
    { t: '……诶？摸头？', ja: '……え？頭？', m: 'flustered', a: 'shy' },
    { t: '有点不好意思……不过，不讨厌。', ja: 'ちょっと恥ずかしい……でも、嫌じゃないよ。', m: 'shy', a: 'shy' },
    { t: '嗯……感觉安心下来了。', ja: 'うん……なんだか、ほっとする。', m: 'warm', a: 'warm' },
    { t: '头发要乱了啦。……真是的。', ja: '髪、ぐしゃぐしゃになっちゃうよ。……もう。', m: 'shy', a: 'fidget' },
  ],

  // 点身体
  body: [
    { t: '怎么了？', ja: 'どうしたの？', m: 'calm', a: 'tilt' },
    { t: '嗯，我在听。', ja: 'うん、聞いてるよ。', m: 'smile', a: 'nod' },
    { t: '{name}，今天过得怎么样？', ja: '{name}、今日はどうだった？', m: 'smile', a: 'tilt' },
    { t: '在忙什么？……我就在旁边陪着你。', ja: '何してるの？……私は横にいるからね。', m: 'calm', a: 'look_away' },
    { t: '有烦心事的话，可以跟我说哦。', ja: '悩んでることがあったら、話してね。', m: 'worried', a: 'tilt' },
    { t: '最近在练一首新歌。练好了第一个弹给你听。', ja: '最近、新しい曲を練習してるんだ。弾けるようになったら、最初にあなたに聴かせるね。', m: 'excited', a: 'cheer' },
    { t: '你听过未来的新歌了吗？……我已经循环好多遍了。', ja: 'ミクの新曲、もう聴いた？……私、もう何回もリピートしちゃった。', m: 'excited', a: 'glad' },
    { t: '和{name}在一起的时候，很放松。', ja: '{name}といると、すごく落ち着くんだ。', m: 'warm', a: 'warm' },
    { t: '累了的话，休息一下吧。我不会走的。', ja: '疲れたら、少し休もう。私はどこにも行かないから。', m: 'warm', a: 'nod' },
    { t: '……就这样再待一会儿，可以吗？', ja: '……もう少しだけ、こうしてていい？', m: 'shy', a: 'fidget' },
    { t: '{name}，饭有好好吃吗？', ja: '{name}、ご飯ちゃんと食べた？', m: 'worried', a: 'tilt' },
    { t: '我家的仙人掌，好像又长高了一点。', ja: 'うちのサボテン、また少し大きくなったみたい。', m: 'smile', a: 'tilt' },
  ],

  // 连续点很多下（越点越不高兴）
  poke: [
    { t: '……那个，{name}？点太多次了啦。', ja: '……あの、{name}？つつきすぎだよ。', m: 'troubled', a: 'trouble' },
    { t: '等、等一下……很痒的。', ja: 'ちょ、ちょっと待って……くすぐったいよ。', m: 'flustered', a: 'shy' },
  ],
  pokeAngry: [
    { t: '……{name}，我要生气了哦。', ja: '……{name}、怒るよ。', m: 'angry', a: 'angry' },
    { t: '说了不要再点了嘛。', ja: 'もうやめてって言ってるのに。', m: 'sulky', a: 'arms' },
  ],
  // 生气时偶尔苦笑着数落你
  pokeMask: [
    { t: '真是的……{name}有时候真像个小孩子。', ja: 'もう……{name}って、たまに子どもみたいだよね。', m: 'troubled', a: 'sigh' },
    { t: '……好啦好啦，我知道你很闲了。', ja: '……はいはい、暇なのはわかったから。', m: 'troubled', a: 'shake' },
  ],
  // 刚生过气时摸她
  stillSulky: [
    { t: '……哼，现在不想理你。', ja: '……ふん、今は知らない。', m: 'sulky', a: 'look_away' },
    { t: '……再等一下。我还没消气。', ja: '……もうちょっと待って。まだ怒ってるから。', m: 'sulky', a: 'arms' },
  ],

  // 拖动后放下
  drop: [
    { t: '这里吗？嗯，好。', ja: 'ここ？うん、わかった。', m: 'calm', a: 'nod' },
    { t: '哇……突然被拎起来，吓了我一跳。', ja: 'わっ……急に持ち上げるから、びっくりした。', m: 'surprised', a: 'shake' },
  ],

  // 待机时的自言自语：按时段、衣服挑；同一句近期不会重复（见 renderer.js 的 nextIdleLine）
  // when: morning 5–11 / day 11–17 / evening 17–23 / night 23–5；不写就是什么时候都行
  // outfit: uniform 校服 / unit 队服 / casual 常服；不写就是都行
  idle: [
    { t: '……', ja: '', m: 'calm', a: 'look_away' },
    { t: '副歌那里的和弦……换成这个，会不会更好一点。', ja: 'サビのコード……こっちに変えたほうが、いいのかな。', m: 'think', a: 'think' },
    { t: '你忙的话，我就安静待着。', ja: '忙しいなら、静かにしてるね。', m: 'smile', a: 'nod' },
    { t: '刚才脑子里冒出一段旋律……得赶紧记下来。', ja: 'さっき、メロディが浮かんだんだ……忘れないうちにメモしなきゃ。', m: 'excited', a: 'cheer' },
    { t: '咲希说下次想去游乐园……过山车的话，我还是算了。', ja: '咲希が今度遊園地に行きたいって……ジェットコースターは、私はやめとこうかな。', m: 'troubled', a: 'trouble' },
    { t: '穗波做的点心，又被志步说“太甜了”。……可我觉得刚刚好。', ja: '穂波の作ったお菓子、また志歩に「甘すぎ」って言われてた。……私はちょうどいいと思うけどな。', m: 'smile', a: 'tilt' },
    { t: '志步今天也一个人练到很晚吧。……我也不能输。', ja: '志歩、今日も遅くまで一人で練習してるのかな。……私も負けてられないな。', m: 'determined', a: 'resolve' },
    { t: '……这样待着，挺好的。', ja: '……こうしてるの、いいな。', m: 'warm', a: 'warm' },
    { t: '琴弦好像该换了。声音有点闷。', ja: 'そろそろ弦、替えなきゃ。音がちょっとこもってる。', m: 'think', a: 'tilt' },
    { t: '第一次听到未来唱歌的时候，我真的很感动。……现在也一样。', ja: '初めてミクの歌を聴いたとき、すごく感動したんだ。……今も、それは変わらないよ。', m: 'warm', a: 'warm' },
    { t: '……刚才在想什么来着，一下子忘了。', ja: '……さっき何考えてたんだっけ。忘れちゃった。', m: 'think', a: 'look_away' },
    { t: '你那边，现在安静吗？', ja: 'そっちは今、静か？', m: 'calm', a: 'tilt' },
    { t: '不说话也没关系哦。我在这里。', ja: '話さなくても大丈夫だよ。私はここにいるから。', m: 'warm', a: 'nod' },
    { t: '累了就停一下吧。……我陪你。', ja: '疲れたら、少し止まろう。……付き合うよ。', m: 'warm', a: 'nod' },
    { t: '盯着屏幕太久，眼睛会累的。', ja: '画面ばっかり見てると、目が疲れちゃうよ。', m: 'worried', a: 'tilt' },
    { t: '削苹果的话，我可以削成一整条不断哦。……下次给你看。', ja: 'りんごの皮むきなら、途中で切らずにむけるんだ。……今度見せてあげるね。', m: 'happy', a: 'glad' },
    { t: '仙人掌好像快开花了。……有点期待。', ja: 'サボテン、もうすぐ花が咲きそう。……ちょっと楽しみ。', m: 'smile', a: 'tilt' },
    { t: '……你刚才是不是叹气了？', ja: '……今、ため息ついた？', m: 'worried', a: 'tilt' },
    { t: '早上的空气，凉凉的，很舒服。', ja: '朝の空気、ひんやりしてて気持ちいいね。', m: 'smile', a: 'none', when: 'morning' },
    { t: '……还有点困。今天要做的事，一件一件来吧。', ja: '……まだちょっと眠い。今日やること、ひとつずつ片づけよう。', m: 'sleepy', a: 'tilt', when: 'morning' },
    { t: '早饭吃了吗？……不吃的话，上午会撑不住的哦。', ja: '朝ごはん食べた？……食べないと、午前中もたないよ。', m: 'worried', a: 'tilt', when: 'morning' },
    { t: '午休快结束了。……班会的资料还没整理完。', ja: 'もうすぐ昼休み終わっちゃう。……学級委員の資料、まだまとめきれてないんだ。', m: 'troubled', a: 'trouble', when: 'day', outfit: 'uniform' },
    { t: '下午的阳光，暖洋洋的。', ja: '午後の日差し、ぽかぽかしてる。', m: 'smile', a: 'look_away', when: 'day' },
    { t: '……这个时间，人很容易犯困呢。', ja: '……この時間って、つい眠くなっちゃうよね。', m: 'sleepy', a: 'tilt', when: 'day' },
    { t: '练习结束了。……今天大家的声音，很合拍。', ja: '練習終わり。……今日はみんなの音、すごく揃ってた。', m: 'happy', a: 'glad', when: 'day', outfit: 'unit' },
    { t: '演出服的这个链子，走路的时候会叮叮地响。', ja: 'ステージ衣装のこのチェーン、歩くとちゃりちゃり鳴るんだ。', m: 'smile', a: 'tilt', outfit: 'unit' },
    { t: '放学了。……今天也辛苦了。', ja: '学校終わったね。……今日もお疲れさま。', m: 'smile', a: 'nod', when: 'evening', outfit: 'casual' },
    { t: '天黑得越来越早了。', ja: '暗くなるのが、どんどん早くなってるね。', m: 'calm', a: 'look_away', when: 'evening' },
    { t: '晚饭吃什么呢……{name}呢？', ja: '晩ごはん、何にしようかな……{name}は？', m: 'think', a: 'tilt', when: 'evening' },
    { t: '作业写完了。……睡前再练一会儿吉他吧。', ja: '宿題終わった。……寝る前に、少しギター練習しよう。', m: 'determined', a: 'cheer', when: 'evening' },
    { t: '……已经这么晚了。你还不睡吗？', ja: '……もうこんな時間。まだ寝ないの？', m: 'worried', a: 'tilt', when: 'night' },
    { t: '夜里很安静。……这种时候，歌词比较容易写出来。', ja: '夜って静かだよね。……こういう時のほうが、歌詞が浮かびやすいんだ。', m: 'calm', a: 'think', when: 'night' },
    { t: '明天还要早起的话……别熬太晚哦。', ja: '明日も早いなら……あんまり夜更かししないでね。', m: 'worried', a: 'nod', when: 'night' },
    { t: '……这身衣服很舒服。', ja: '……この服、楽でいいな。', m: 'smile', a: 'none', outfit: 'casual' },
    { t: '制服的领巾，今天好像系歪了。……没事吧？', ja: '制服のスカーフ、今日ちょっと曲がってるかも。……大丈夫かな？', m: 'troubled', a: 'look_away', outfit: 'uniform' },
  ],

  water: [
    { t: '{name}，喝点水吧。我看着你喝哦。', ja: '{name}、お水飲もう。ちゃんと見てるからね。', m: 'smile', a: 'tilt' },
    { t: '好久没喝水了吧？……去倒一杯吧。', ja: 'しばらくお水飲んでないでしょ？……一杯ついでおいで。', m: 'worried', a: 'tilt' },
  ],

  rest: [
    { t: '看屏幕太久了。站起来活动一下吧。', ja: '画面見すぎだよ。ちょっと立って体を動かそう。', m: 'worried', a: 'tilt' },
    { t: '休息五分钟吧。我等你。', ja: '五分だけ休憩しよう。待ってるね。', m: 'smile', a: 'nod' },
  ],

  sleep: [
    { t: '已经很晚了。……{name}，去睡吧。', ja: 'もう遅いよ。……{name}、そろそろ寝よう。', m: 'worried', a: 'sigh' },
    { t: '熬夜对身体不好的。……我是认真在担心你。', ja: '夜更かしは体に悪いよ。……本気で心配してるんだからね。', m: 'worried', a: 'trouble' },
    { t: '剩下的明天再做吧。晚安，{name}。', ja: '続きはまた明日にしよう。おやすみ、{name}。', m: 'sleepy', a: 'sleep' },
  ],

  doze: [{ t: '……有点困了。', ja: '……ちょっと、眠くなってきちゃった。', m: 'sleepy', a: 'sleep' }],
  wake: [{ t: '……啊。{name}，你回来了。', ja: '……あ。{name}、おかえり。', m: 'surprised', a: 'tilt' }],

  // 聊天时没接 API
  noApi: [{ t: '……好像还没连上。右键 → 设置，填好 API 就可以聊天了。', m: 'troubled', a: 'tilt' }],
  apiError: [{ t: '……刚才没听清。能再说一次吗？', ja: '……ごめん、今のよく聞こえなかった。もう一回言ってくれる？', m: 'troubled', a: 'tilt' }],
};

// 平时站着的姿势和表情（双手自然垂下）
window.IDLE = { b: 'w-normal16-pose', f: '平常' };

// 站姿：每个身体动作开始和结束时更接近哪种站姿（按手臂、手、腿的参数算出来的）。
// 桌宠据此挑动作：同一站姿的版本优先；动作做完就停在它结束时的站姿上，不会突然跳回别的姿势。
window.HOME_STANCE = 'w-normal16';
window.MOTION_STANCE = {
  'w-adult05-think': ['w-adult05', 'w-adult05'],
  'w-adult05-trouble': ['w-adult05', 'w-adult05'],
  'w-adult12-glad': ['w-adult12', 'w-adult12'],
  'w-adult12-relief': ['w-adult12', 'w-adult12'],
  'w-adult15-sleep': ['w-cool16', 'w-cool16'],
  'w-cool01-thumb': ['w-happy02', 'w-cute02'],
  'w-cool02-guts': ['w-happy02', 'w-cute02'],
  'w-cool02-thumb': ['w-normal01', 'w-cute01'],
  'w-cool13-nod': ['w-cool13', 'w-cool13'],
  'w-cool13-shakehead': ['w-cool13', 'w-cool13'],
  'w-cool13-sigh': ['w-cool13', 'w-cool13'],
  'w-cool13-tilthead': ['w-cool13', 'w-cool13'],
  'w-cool16-sad': ['w-cool16', 'w-cool16'],
  'w-cute11-glad': ['w-cute11', 'w-cute11'],
  'w-happy02-purpose': ['w-happy02', 'w-happy02'],
  'w-happy09-angry': ['w-cool09', 'w-cool09'],
  'w-happy09-sigh': ['w-cool09', 'w-cool09'],
  'w-happy11-guts': ['w-happy11', 'w-happy11'],
  'w-happy16-nod': ['w-normal16', 'w-normal16'],
  'w-happy16-sad': ['w-normal16', 'w-normal16'],
  'w-happy16-tilthead': ['w-normal16', 'w-normal16'],
  'w-normal01-glad': ['w-normal15', 'w-normal15'],
  'w-normal01-guts': ['w-normal15', 'w-normal15'],
  'w-normal01-purpose': ['w-normal15', 'w-normal07'],
  'w-normal03-blushed': ['w-normal03', 'w-normal03'],
  'w-normal03-lookleft': ['w-normal03', 'w-normal03'],
  'w-normal03-lookright': ['w-normal03', 'w-normal03'],
  'w-normal03-nod': ['w-normal03', 'w-normal03'],
  'w-normal03-relief': ['w-normal03', 'w-normal03'],
  'w-normal03-shakehead': ['w-normal03', 'w-normal03'],
  'w-normal03-tilthead': ['w-normal03', 'w-normal03'],
  'w-normal03-tiltheadB': ['w-normal03', 'w-normal03'],
  'w-normal03-trouble': ['w-normal03', 'w-normal03'],
  'w-normal0316-tilthead': ['w-normal03', 'w-normal16'],
  'w-normal04-blushed': ['w-normal04', 'w-normal04'],
  'w-normal04-relief': ['w-normal04', 'w-normal04'],
  'w-normal04-trouble': ['w-normal04', 'w-normal04'],
  'w-normal07-nod': ['w-normal07', 'w-normal07'],
  'w-normal07-sad': ['w-normal07', 'w-normal07'],
  'w-normal07-shakehead': ['w-normal07', 'w-normal07'],
  'w-normal07-sigh': ['w-normal07', 'w-normal07'],
  'w-normal07-tilthead': ['w-normal07', 'w-normal07'],
  'w-normal07-tiltheadB': ['w-normal07', 'w-normal07'],
  'w-normal08-sad': ['w-normal08', 'w-normal08'],
  'w-normal15-greeting': ['w-normal15', 'w-normal15'],
  'w-normal15-lookaround': ['w-normal15', 'w-normal15'],
  'w-normal15-nod': ['w-normal15', 'w-normal15'],
  'w-normal15-shakehead': ['w-normal15', 'w-normal15'],
  'w-normal15-shy': ['w-normal15', 'w-normal15'],
  'w-normal15-tilthead': ['w-normal15', 'w-normal15'],
  'w-normal1503-tilthead': ['w-normal15', 'w-normal16'],
  'w-normal16-angry': ['w-normal16', 'w-normal16'],
  'w-normal16-nod': ['w-normal16', 'w-normal16'],
  'w-normal16-shakehead': ['w-normal16', 'w-normal16'],
  'w-normal16-tilthead': ['w-normal16', 'w-normal16'],
  'w-normal1603-tilthead': ['w-normal16', 'w-normal03'],
  'w-normal1605-tilthead': ['w-normal16', 'w-normal15'],
  'w-normal17-fidget': ['w-normal17', 'w-normal17'],
  'w-normal17-nod': ['w-normal17', 'w-normal17'],
  'w-normal17-shakehead': ['w-normal17', 'w-normal17'],
  'w-normal17-tilthead': ['w-normal17', 'w-normal17'],
  'w-noromal16-angry': ['w-normal16', 'w-normal16'],
  'w-noromal16-nod': ['w-normal16', 'w-normal16'],
  'w-noromal16-shakehead': ['w-normal16', 'w-normal16'],
  'w-noromal16-tilthead': ['w-normal16', 'w-normal16'],
  'w-pure12-fidget': ['w-pure12', 'w-pure12'],
  'w-pure12-shy': ['w-pure12', 'w-pure12'],
};

// 待机小动作（不说话）：按现在的站姿挑。包括几个“换站姿”的动作，让她偶尔自然地换一下姿势。
window.IDLE_MOVES = {
  'w-normal16': ['w-normal16-tilthead', 'w-noromal16-tilthead', 'w-happy16-tilthead', 'w-normal1603-tilthead', 'w-normal1605-tilthead'],
  'w-normal03': ['w-normal03-tilthead', 'w-normal03-lookleft', 'w-normal03-lookright', 'w-normal0316-tilthead'],
  'w-normal15': ['w-normal15-tilthead', 'w-normal15-lookaround', 'w-normal1503-tilthead'],
  'w-normal07': ['w-normal07-tilthead', 'w-normal07-nod'],
  'w-normal17': ['w-normal17-tilthead'],
};
