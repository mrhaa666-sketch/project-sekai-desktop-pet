// 读取 .motion3.json 并按时间求值，用来自己控制「身体动作 + 表情」两层叠加
'use strict';

class Motion {
  constructor(json) {
    this.duration = json.Meta.Duration;
    this.loop = !!json.Meta.Loop;
    this.curves = [];
    for (const c of json.Curves) {
      if (c.Target !== 'Parameter') continue;
      this.curves.push({ id: c.Id, segs: Motion.parse(c.Segments) });
    }
  }

  static parse(s) {
    // 转成分段列表：{type, pts:[[t,v],...]}，第一个点是起点
    const segs = [];
    let p0 = [s[0], s[1]];
    let i = 2;
    while (i < s.length) {
      const type = s[i];
      if (type === 1) {
        const p1 = [s[i + 1], s[i + 2]], p2 = [s[i + 3], s[i + 4]], p3 = [s[i + 5], s[i + 6]];
        segs.push({ type, p0, p1, p2, p3, t0: p0[0], t1: p3[0] });
        p0 = p3; i += 7;
      } else {
        const p1 = [s[i + 1], s[i + 2]];
        segs.push({ type, p0, p1, t0: p0[0], t1: p1[0] });
        p0 = p1; i += 3;
      }
    }
    return { start: [s[0], s[1]], list: segs };
  }

  static evalCurve(c, t) {
    const L = c.segs.list;
    if (!L.length) return c.segs.start[1];
    if (t <= L[0].t0) return L[0].p0[1];
    for (const g of L) {
      if (t > g.t1) continue;
      const span = g.t1 - g.t0 || 1e-6;
      const r = (t - g.t0) / span;
      switch (g.type) {
        case 0: return g.p0[1] + (g.p1[1] - g.p0[1]) * r;
        case 1: {
          // 简化的三次贝塞尔（按时间比例取 t）
          const u = 1 - r;
          return u * u * u * g.p0[1] + 3 * u * u * r * g.p1[1] + 3 * u * r * r * g.p2[1] + r * r * r * g.p3[1];
        }
        case 2: return g.p0[1];
        case 3: return g.p1[1];
      }
    }
    const last = L[L.length - 1];
    return (last.p3 || last.p1)[1];
  }

  // 返回 {paramId: value}
  sample(t) {
    const out = {};
    for (const c of this.curves) out[c.id] = Motion.evalCurve(c, t);
    return out;
  }
}

// 手、手臂的画法切换参数（值只有 0 / 1 左右，用来换另一张手的图）
// 手臂参数控制连续网格变形；只有手型图层开关需要离散切换。
const SWITCH_PARAM = /^ParamHand[LR][A-Z]$/;

// 一个动作层：播放一个动作，切换时从上一帧姿态平滑过渡
class Layer {
  constructor(defaults) {
    this.defaults = defaults; // {id: defaultValue}
    this.motion = null;
    this.time = 0;
    this.loop = false;
    this.from = null;      // 过渡起点快照
    this.fade = 0;         // 过渡总时长
    this.fadeT = 0;
    this.last = {};        // 上一帧输出
    this.onEnd = null;
  }

  play(motion, { loop = false, fade = 0.5, onEnd = null } = {}) {
    // 还没输出过任何姿态时直接开始，不从默认的 T 字姿势过渡
    this.from = fade > 0 && Object.keys(this.last).length ? Object.assign({}, this.last) : null;
    this.motion = motion;
    this.time = 0;
    this.loop = loop;
    this.fade = fade;
    this.fadeT = 0;
    this.onEnd = onEnd;
    this.ended = false;
  }

  update(dt) {
    if (!this.motion) return this.last;
    let completed = null;
    this.time += dt;
    const d = this.motion.duration;
    let t = this.time;
    if (t >= d) {
      if (this.loop) {
        // 循环回到开头时，首尾姿态不一定一致，短暂混合一下避免跳帧
        this.time = t = t % d;
        if (!this.from) { this.from = Object.assign({}, this.last); this.fade = 0.35; this.fadeT = 0; }
      }
      else {
        t = d;
        if (!this.ended) {
          this.ended = true;
          completed = this.onEnd; this.onEnd = null;
        }
      }
    }
    const cur = this.motion.sample(t);
    let out = cur;
    if (this.from && this.fadeT < this.fade) {
      this.fadeT += dt;
      let w = Math.min(1, this.fadeT / this.fade);
      w = w * w * (3 - 2 * w); // smoothstep，让衔接不生硬
      out = {};
      const ids = new Set([...Object.keys(this.from), ...Object.keys(cur)]);
      for (const id of ids) {
        const a = id in this.from ? this.from[id] : (this.defaults[id] ?? 0);
        const b = id in cur ? cur[id] : (this.defaults[id] ?? 0);
        // 手的画法开关（只有 0/1）不能渐变：渐变时两只手会同时半透明地出现，看起来一闪一闪。过渡到一半时直接切换
        out[id] = SWITCH_PARAM.test(id) ? (w < 0.5 ? a : b) : a + (b - a) * w;
      }
      if (w >= 1) this.from = null;
    }
    this.last = out;
    // Finish the old frame first. A callback may synchronously play another
    // motion, which must start from this final pose with its own clock.
    if (completed) completed();
    return out;
  }
}

window.Motion = Motion;
window.MotionLayer = Layer;
