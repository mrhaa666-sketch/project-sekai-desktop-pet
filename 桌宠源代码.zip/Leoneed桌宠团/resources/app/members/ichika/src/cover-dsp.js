'use strict';
/* 翻唱的声音处理（全部在本机算）：
   1. 音高跟踪：从分离出来的原唱人声里，每 10 毫秒取一次音高（YIN 算法）和音量
   2. 切音符、切乐句：按有声 / 无声、音高跳变、音量起伏把人声切成一个个音符，停顿久一点算一个乐句
   3. 歌词切音节：日语按假名（拍），中文按字
   4. 对齐：把每个音节分到一个或几个连续的音符上（动态规划；歌词的换行尽量对上乐句的停顿）
   5. 合成：每个音节用她克隆后的音色念一遍（MiniMax），再用 PSOLA 把音高改成原唱的音高曲线、
      把长度拉到原唱的长度（共振峰不变，所以还是她的声音）；音量跟着原唱走
   6. 混音：她的人声 + 伴奏（原曲 − 原唱人声），加一点混响 */
(function (root) {
  const SR = 44100;

  /* ---------- 基本工具 ---------- */
  function fft(re, im, inverse = false) {
    const n = re.length;
    for (let i = 1, j = 0; i < n; i++) {
      let bit = n >> 1;
      for (; j & bit; bit >>= 1) j ^= bit;
      j ^= bit;
      if (i < j) { let t = re[i]; re[i] = re[j]; re[j] = t; t = im[i]; im[i] = im[j]; im[j] = t; }
    }
    for (let len = 2; len <= n; len <<= 1) {
      const ang = (inverse ? 2 : -2) * Math.PI / len, wr = Math.cos(ang), wi = Math.sin(ang), half = len >> 1;
      for (let i = 0; i < n; i += len) {
        let cr = 1, ci = 0;
        for (let j = 0; j < half; j++) {
          const a = i + j, b = a + half;
          const tr = re[b] * cr - im[b] * ci, ti = re[b] * ci + im[b] * cr;
          re[b] = re[a] - tr; im[b] = im[a] - ti; re[a] += tr; im[a] += ti;
          const ncr = cr * wr - ci * wi; ci = cr * wi + ci * wr; cr = ncr;
        }
      }
    }
    if (inverse) for (let i = 0; i < n; i++) { re[i] /= n; im[i] /= n; }
  }

  // 重采样（加窗 sinc；降采样时同时低通）
  function resample(x, srIn, srOut) {
    if (srIn === srOut) return Float32Array.from(x);
    const ratio = srIn / srOut, n = Math.floor(x.length / ratio);
    const out = new Float32Array(n);
    const fc = Math.min(1, srOut / srIn) * 0.97, A = 12;
    const half = Math.ceil(A / fc);
    for (let i = 0; i < n; i++) {
      const t = i * ratio, k0 = Math.floor(t);
      let s = 0, ws = 0;
      for (let k = k0 - half + 1; k <= k0 + half; k++) {
        if (k < 0 || k >= x.length) continue;
        const d = t - k, u = d * fc;
        const sinc = u === 0 ? 1 : Math.sin(Math.PI * u) / (Math.PI * u);
        const w = 0.5 + 0.5 * Math.cos(Math.PI * d / (half + 1));
        const c = sinc * w; s += x[k] * c; ws += c;
      }
      out[i] = ws ? s / ws : 0;
    }
    return out;
  }
  const median = (arr) => { const a = Array.from(arr).sort((p, q) => p - q); return a.length ? a[a.length >> 1] : 0; };
  const percentile = (arr, p) => { const a = Array.from(arr).sort((x, y) => x - y); return a.length ? a[Math.min(a.length - 1, Math.floor(a.length * p))] : 0; };
  const hz2midi = (f) => 69 + 12 * Math.log2(f / 440);
  const midi2hz = (m) => 440 * Math.pow(2, (m - 69) / 12);

  /* ---------- 1. 音高跟踪（YIN，用 FFT 算自相关） ---------- */
  // x：单声道；返回每帧 { f0（0 = 无声）, conf, db }
  function pitchTrack(x, sr, { hopSec = 0.01, fmin = 65, fmax = 1100, win = 1024 } = {}) {
    const hop = Math.round(hopSec * sr), W = win;
    const tauMin = Math.floor(sr / fmax), tauMax = Math.min(W - 2, Math.ceil(sr / fmin));
    const nF = Math.max(0, Math.floor((x.length - W) / hop) + 1);
    const f0 = new Float32Array(nF), conf = new Float32Array(nF), db = new Float32Array(nF);
    const M = 2 * W;
    const re = new Float64Array(M), im = new Float64Array(M);
    const d = new Float64Array(tauMax + 2), cm = new Float64Array(tauMax + 2);
    const sq = new Float64Array(W + 1);
    for (let f = 0; f < nF; f++) {
      const o = f * hop;
      re.fill(0); im.fill(0);
      let e = 0;
      sq[0] = 0;
      for (let i = 0; i < W; i++) { const v = x[o + i]; re[i] = v; e += v * v; sq[i + 1] = sq[i] + v * v; }
      db[f] = 10 * Math.log10(e / W + 1e-12);
      if (e < 1e-9) { f0[f] = 0; conf[f] = 0; continue; }
      fft(re, im);
      for (let i = 0; i < M; i++) { re[i] = re[i] * re[i] + im[i] * im[i]; im[i] = 0; }
      fft(re, im, true);
      // d(τ) = Σ(x_j − x_{j+τ})²  (j < W − τ)
      d[0] = 0;
      let run = 0;
      cm[0] = 1;
      for (let tau = 1; tau <= tauMax; tau++) {
        const e0 = sq[W - tau], e1 = sq[W] - sq[tau];
        d[tau] = Math.max(0, e0 + e1 - 2 * re[tau]);
        run += d[tau];
        cm[tau] = run > 0 ? d[tau] * tau / run : 1;
      }
      let best = -1;
      for (let tau = tauMin; tau <= tauMax; tau++) {
        if (cm[tau] < 0.15) { while (tau + 1 <= tauMax && cm[tau + 1] < cm[tau]) tau++; best = tau; break; }
      }
      if (best < 0) { let mv = 1e9; for (let tau = tauMin; tau <= tauMax; tau++) if (cm[tau] < mv) { mv = cm[tau]; best = tau; } }
      // 抛物线插值，取更准的周期
      let tb = best;
      if (best > tauMin && best < tauMax) {
        const a = cm[best - 1], b = cm[best], c = cm[best + 1], den = a - 2 * b + c;
        if (Math.abs(den) > 1e-12) tb = best + 0.5 * (a - c) / den;
      }
      f0[f] = sr / tb; conf[f] = Math.max(0, 1 - cm[best]);
    }
    return { f0, conf, db, hopSec: hop / sr, sr };
  }

  // 判断有声 / 无声，修正八度跳错，轻微平滑
  function cleanTrack(tr, { confMin = 0.72, gateBelowPeak = 38 } = {}) {
    const n = tr.f0.length;
    const loud = percentile(tr.db.filter((v) => v > -90), 0.95);
    const gate = Math.max(-62, loud - gateBelowPeak);
    const v = new Uint8Array(n), m = new Float32Array(n);
    for (let i = 0; i < n; i++) { v[i] = tr.conf[i] >= confMin && tr.db[i] >= gate && tr.f0[i] > 0 ? 1 : 0; m[i] = v[i] ? hz2midi(tr.f0[i]) : 0; }
    // 很短的有声 / 无声片段去掉（30ms 以内）
    for (let i = 0; i < n;) {
      let j = i; while (j < n && v[j] === v[i]) j++;
      if (j - i <= 3) { if (v[i] === 1) for (let k = i; k < j; k++) v[k] = 0; else if (i > 0 && j < n) for (let k = i; k < j; k++) { v[k] = 1; m[k] = (m[i - 1] + m[j]) / 2; } }
      i = j;
    }
    // 八度错误：和附近的中位数差 12 半音左右的，挪回来
    const out = new Float32Array(n);
    for (let i = 0; i < n; i++) {
      if (!v[i]) continue;
      const nb = []; for (let k = Math.max(0, i - 15); k <= Math.min(n - 1, i + 15); k++) if (v[k]) nb.push(m[k]);
      const md = median(nb);
      let x = m[i];
      while (x - md > 9) x -= 12;
      while (md - x > 9) x += 12;
      out[i] = x;
    }
    // 3 点中值 + 3 点平均（去掉抖动，保留颤音）
    const sm = new Float32Array(n);
    for (let i = 0; i < n; i++) {
      if (!v[i]) continue;
      const a = v[i - 1] ? out[i - 1] : out[i], c = v[i + 1] ? out[i + 1] : out[i];
      sm[i] = [a, out[i], c].sort((p, q) => p - q)[1];
    }
    const midi = new Float32Array(n);
    for (let i = 0; i < n; i++) {
      if (!v[i]) continue;
      let s = 0, c = 0; for (let k = i - 1; k <= i + 1; k++) if (k >= 0 && k < n && v[k]) { s += sm[k]; c++; }
      midi[i] = s / c;
    }
    return { voiced: v, midi, db: tr.db, hopSec: tr.hopSec, gate, loud };
  }

  /* ---------- 2. 切音符、切乐句 ---------- */
  function segment(ct, { gapBridge = 3, phraseGap = 0.25, splitSemi = 0.8, minNote = 0.07 } = {}) {
    const n = ct.voiced.length, hs = ct.hopSec;
    const runs = [];
    for (let i = 0; i < n;) {
      if (!ct.voiced[i]) { i++; continue; }
      let j = i; while (j < n && ct.voiced[j]) j++;
      // 很短的空隙连起来
      if (runs.length && i - runs[runs.length - 1].e <= gapBridge) runs[runs.length - 1].e = j;
      else runs.push({ s: i, e: j });
      i = j;
    }
    const notes = [];
    const minF = Math.max(2, Math.round(minNote / hs));
    const medAt = (a, b) => { const arr = []; for (let k = Math.max(a, 0); k < Math.min(b, n); k++) if (ct.voiced[k]) arr.push(ct.midi[k]); return arr.length ? median(arr) : null; };
    for (const r of runs) {
      if (r.e - r.s < minF) continue;
      const cuts = [r.s];
      for (let k = r.s + minF; k < r.e - minF; k++) {
        const before = medAt(k - 6, k), after = medAt(k, k + 6);
        const pitchJump = before !== null && after !== null && Math.abs(after - before) >= splitSemi;
        // 音量突然变大（新的一个字唱出来）
        const dip = Math.min(ct.db[k - 1], ct.db[k]), rise = Math.max(ct.db[k + 2] || -99, ct.db[k + 3] || -99);
        const onset = rise - dip >= 7 && dip < ct.loud - 14;
        if ((pitchJump || onset) && k - cuts[cuts.length - 1] >= minF) {
          // 跳变最陡的地方切
          if (pitchJump) {
            let bestK = k, bestD = 0;
            for (let q = k; q < Math.min(r.e - 1, k + 5); q++) { const dd = Math.abs((ct.midi[q + 1] || 0) - (ct.midi[q] || 0)); if (dd > bestD) { bestD = dd; bestK = q + 1; } }
            k = bestK;
          }
          if (k - cuts[cuts.length - 1] >= minF && r.e - k >= minF) cuts.push(k);
          k += minF - 1;
        }
      }
      cuts.push(r.e);
      for (let c = 0; c + 1 < cuts.length; c++) {
        const s = cuts[c], e = cuts[c + 1];
        notes.push({ s, e, t0: s * hs, t1: e * hs, midi: medAt(s, e) || 60 });
      }
    }
    // 乐句：停顿超过 phraseGap 就是新的一句
    const phrases = [];
    notes.forEach((nt, i) => {
      if (!i || nt.t0 - notes[i - 1].t1 > phraseGap) phrases.push({ first: i, last: i, t0: nt.t0, t1: nt.t1 });
      else { const p = phrases[phrases.length - 1]; p.last = i; p.t1 = nt.t1; }
      nt.phrase = phrases.length - 1;
    });
    return { notes, phrases };
  }

  /* ---------- 3. 歌词 → 音节 ---------- */
  const SMALL = 'ぁぃぅぇぉゃゅょゎゕゖ';
  const kata2hira = (s) => s.replace(/[ァ-ヶ]/g, (c) => String.fromCharCode(c.charCodeAt(0) - 0x60));
  function cleanLyricLine(l) {
    return l.replace(/\[[^\]]*\]|【[^】]*】|\([^)]*\)|（[^）]*）/g, ' ').replace(/^\s*(主歌|副歌|桥段|前奏|间奏|尾奏|verse|chorus|bridge|intro|outro)\s*\d*\s*[:：]?/i, '').trim();
  }
  // 返回 { lines: [[{ text, tts }]], needKana: 有没有汉字之类要先转成假名的, total }
  function syllabify(text, lang) {
    const lines = [];
    let needKana = false, total = 0;
    for (const raw of String(text || '').split(/\r?\n/)) {
      const l = cleanLyricLine(raw);
      if (!l) continue;
      const out = [];
      if (lang === 'ja') {
        const s = kata2hira(l);
        for (const ch of s) {
          if (/[ぁ-ゖ]/.test(ch)) {
            if (SMALL.includes(ch) && out.length) out[out.length - 1].text += ch;
            else if (ch === 'っ' || ch === 'ゝ') { if (out.length) out[out.length - 1].text += ch; else out.push({ text: ch }); }
            else out.push({ text: ch });
          } else if (/[ーｰ〜~]/.test(ch)) { if (out.length) out[out.length - 1].long = (out[out.length - 1].long || 0) + 1; }
          else if (/[\s\p{P}\p{S}]/u.test(ch)) continue;
          else needKana = true;
        }
        for (const o of out) o.tts = /っ$/.test(o.text) ? o.text : o.text + 'ー';
      } else {
        const toks = l.match(/[㐀-鿿豈-﫿]|[A-Za-z']+|[ぁ-ヿ]/g) || [];
        for (const t of toks) out.push({ text: t, tts: t });
        if (/\d/.test(l)) needKana = true;
      }
      if (out.length) { lines.push(out); total += out.length; }
    }
    return { lines, needKana, total };
  }

  /* ---------- 4. 对齐：音节 → 音符 ---------- */
  // 返回 [{ text, tts, line, first, last, t0, t1 }]
  function align(seg, lines) {
    let notes = seg.notes.map((n) => ({ ...n }));
    const syl = [];
    lines.forEach((ln, li) => ln.forEach((s, k) => syl.push({ ...s, line: li, lineStart: k === 0, lineEnd: k === ln.length - 1 })));
    const S = syl.length;
    if (!S || !notes.length) return [];
    // 音节比音符多：把最长的音符对半分开，直到够用
    while (notes.length < S) {
      let bi = 0; notes.forEach((nt, i) => { if (nt.t1 - nt.t0 > notes[bi].t1 - notes[bi].t0) bi = i; });
      const nt = notes[bi], mid = (nt.t0 + nt.t1) / 2;
      notes.splice(bi, 1, { ...nt, t1: mid, split: true }, { ...nt, t0: mid, split: true });
    }
    const N = notes.length, G = 8;
    const phraseStart = (j) => j === 0 || notes[j].phrase !== notes[j - 1].phrase;
    const phraseEnd = (j) => j === N - 1 || notes[j].phrase !== notes[j + 1].phrase;
    const INF = 1e18;
    // dp[i][j]：前 i 个音节用掉前 j 个音符的最小代价；允许跳过音符（不唱）
    const dp = Array.from({ length: S + 1 }, () => new Float64Array(N + 1).fill(INF));
    const bk = Array.from({ length: S + 1 }, () => new Int32Array(N + 1).fill(-1));
    dp[0][0] = 0;
    for (let j = 1; j <= N; j++) { dp[0][j] = dp[0][j - 1] + 1.2; bk[0][j] = -2; }
    for (let i = 1; i <= S; i++) {
      const s = syl[i - 1];
      for (let j = 1; j <= N; j++) {
        // 跳过音符 j-1（不唱，比如和声、拖腔的杂音）
        let best = dp[i][j - 1] + 1.6, from = -2;
        for (let g = 1; g <= G && j - g >= 0; g++) {
          const a = j - g, prev = dp[i - 1][a];
          if (prev >= INF) continue;
          let c = 0;
          // 一个音节占好几个音符（拖腔）：小代价；跨过乐句停顿：大代价
          c += 0.35 * (g - 1);
          for (let q = a + 1; q < j; q++) if (phraseStart(q)) c += 6;
          // 长音（ー）的音节更适合占多个音符
          if (s.long && g > 1) c -= 0.3 * Math.min(g - 1, s.long);
          // 换行尽量对上乐句
          if (s.lineStart && !phraseStart(a)) c += 1.4;
          if (s.lineEnd && !phraseEnd(j - 1)) c += 1.0;
          if (!s.lineStart && phraseStart(a)) c += 0.9;
          const dur = notes[j - 1].t1 - notes[a].t0;
          if (dur > 2.5) c += (dur - 2.5) * 0.5;
          const v = prev + c;
          if (v < best) { best = v; from = a; }
        }
        dp[i][j] = best; bk[i][j] = from;
      }
    }
    // 回溯
    const out = new Array(S);
    let i = S, j = N;
    while (i > 0 && j > 0) {
      const f = bk[i][j];
      if (f === -2) { j--; continue; }
      if (f < 0) break;
      const s = syl[i - 1];
      out[i - 1] = { text: s.text, tts: s.tts, line: s.line, first: f, last: j - 1, t0: notes[f].t0, t1: notes[j - 1].t1 };
      i--; j = f;
    }
    return out.filter(Boolean);
  }

  /* ---------- 5. 她的声音：每个音节的样本 ---------- */
  // x：MiniMax 念出来的一个音节（单声道，44.1k）。返回元音区间、音高标记
  function analyzeSample(x, sr = SR) {
    // 去掉前后的静音
    const frame = Math.round(0.005 * sr);
    const env = [];
    for (let i = 0; i + frame <= x.length; i += frame) { let e = 0; for (let k = 0; k < frame; k++) e += x[i + k] * x[i + k]; env.push(10 * Math.log10(e / frame + 1e-12)); }
    const peak = Math.max(...env);
    let a = env.findIndex((v) => v > peak - 40), b = env.length - 1 - [...env].reverse().findIndex((v) => v > peak - 40);
    if (a < 0) a = 0;
    const s0 = Math.max(0, a * frame - frame), s1 = Math.min(x.length, (b + 2) * frame);
    let y = Float32Array.from(x.subarray(s0, s1));
    // 音高（每 5ms）
    const tr = pitchTrack(y, sr, { hopSec: 0.005, fmin: 70, fmax: 700, win: 2048 });
    const nF = tr.f0.length, hop = Math.round(tr.hopSec * sr);
    const loud = Math.max(...tr.db);
    const voiced = Array.from({ length: nF }, (_, i) => tr.conf[i] > 0.7 && tr.db[i] > loud - 28);
    // 元音：最长的一段连续有声
    let bs = -1, be = -1;
    for (let i = 0; i < nF;) {
      if (!voiced[i]) { i++; continue; }
      let j = i; while (j < nF && (voiced[j] || (j + 2 < nF && voiced[j + 1] && voiced[j + 2]))) j++;
      if (j - i > be - bs) { bs = i; be = j; }
      i = j;
    }
    const f0s = [];
    if (bs >= 0) for (let i = bs; i < be; i++) if (voiced[i]) f0s.push(tr.f0[i]);
    const f0med = f0s.length ? median(f0s) : 220;
    if (bs < 0 || be - bs < 4) {
      // 几乎没有有声的部分：当成一段整体（只做拉伸，不改音高）
      return { x: y, sr, vowelStart: 0, vowelEnd: y.length, marks: new Int32Array(0), periods: new Float32Array(0), f0med, unvoiced: true };
    }
    const vs = Math.max(0, bs * hop), ve = Math.min(y.length - 1, be * hop + 1024);
    // 音高标记：每个周期一个，放在波形的峰上
    const f0At = (pos) => { const fi = Math.max(bs, Math.min(be - 1, Math.round((pos - 512) / hop))); const v = voiced[fi] ? tr.f0[fi] : f0med; return v > 50 ? v : f0med; };
    const marks = [], periods = [];
    let P = sr / f0At(vs);
    let m = vs; { let mv = -1; for (let k = vs; k < Math.min(ve, vs + P); k++) if (y[k] > mv) { mv = y[k]; m = k; } }
    while (m < ve) {
      marks.push(m); P = sr / f0At(m); periods.push(P);
      const c = Math.round(m + P), r = Math.round(P * 0.2);
      let best = c, mv = -Infinity;
      for (let k = c - r; k <= c + r; k++) if (k < y.length && y[k] > mv) { mv = y[k]; best = k; }
      if (best <= m) best = m + Math.round(P);
      m = best;
    }
    // 元音部分的响度统一
    let e = 0; for (let k = vs; k < ve; k++) e += y[k] * y[k];
    const rms = Math.sqrt(e / Math.max(1, ve - vs));
    if (rms > 0) { const g = 0.1 / rms; for (let k = 0; k < y.length; k++) y[k] *= g; }
    return { x: y, sr, vowelStart: marks[0], vowelEnd: marks[marks.length - 1], marks: Int32Array.from(marks), periods: Float32Array.from(periods), f0med };
  }

  /* ---------- 5. 合成人声 ---------- */
  // spans：align 的结果；ct：cleanTrack 的结果（原唱的音高、音量）；samples：tts 文本 → analyzeSample 的结果
  // octave：整体升降几个八度；返回 Float32Array（44.1k 单声道）
  function renderVocal({ spans, ct, samples, length, octave = 0, sr = SR }) {
    const out = new Float32Array(length);
    const hs = ct.hopSec, n = ct.voiced.length;
    // 原唱的音高（midi，逐帧），没有声音的帧用最近的有声帧补上
    const mid = new Float32Array(n);
    let fv = -1; for (let i = 0; i < n; i++) if (ct.voiced[i]) { fv = i; break; }
    let last = fv >= 0 ? ct.midi[fv] : 60;
    for (let i = 0; i < n; i++) { if (ct.voiced[i]) last = ct.midi[i]; mid[i] = last; }
    const midiAt = (t) => { const f = t / hs; const i = Math.max(0, Math.min(n - 2, Math.floor(f))); const r = Math.min(1, Math.max(0, f - i)); return mid[i] + (mid[i + 1] - mid[i]) * r + 12 * octave; };
    // 音量：跟着原唱（相对最响的地方），开 0.7 次方让起伏柔和一点
    const dbS = new Float32Array(n);
    for (let i = 0; i < n; i++) { let s = 0, c = 0; for (let k = i - 3; k <= i + 3; k++) if (k >= 0 && k < n) { s += ct.db[k]; c++; } dbS[i] = s / c; }
    const gainAt = (t) => { const i = Math.max(0, Math.min(n - 1, Math.round(t / hs))); const g = Math.pow(10, (dbS[i] - ct.loud) / 20 * 0.7); return Math.max(0.12, Math.min(1.3, g)); };

    for (let si = 0; si < spans.length; si++) {
      const sp = spans[si], smp = samples[sp.tts];
      if (!smp) continue;
      const next = spans[si + 1];
      const y = smp.x;
      const tStart = sp.t0;
      // 连唱：离下一个音节很近就一直唱到下一个音节的辅音前；否则在音符结束后 60ms 内收掉
      const nextCons = next && samples[next.tts] ? Math.min(0.12, samples[next.tts].vowelStart / sr) : 0;
      let tEnd = sp.t1 + 0.03;
      if (next && next.t0 - sp.t1 < 0.15) tEnd = Math.max(sp.t1, next.t0 - nextCons * 0.6 + 0.015);
      const oStart = Math.round(tStart * sr), oEnd = Math.min(length, Math.round(tEnd * sr));
      if (oEnd - oStart < 64) continue;
      // 辅音：原样贴在音符开始之前（最长 0.12 秒）
      const consLen = Math.min(smp.vowelStart, Math.round(0.12 * sr));
      if (consLen > 0) {
        const c0 = smp.vowelStart - consLen, at = oStart - consLen;
        const g = gainAt(tStart);
        for (let k = 0; k < consLen + Math.round(0.01 * sr); k++) {
          const p = at + k, q = c0 + k;
          if (p < 0 || p >= length || q >= y.length) continue;
          const fin = Math.min(1, k / (0.004 * sr));
          const fout = k > consLen ? Math.max(0, 1 - (k - consLen) / (0.01 * sr)) : 1;
          out[p] += y[q] * g * fin * fout;
        }
      }
      if (smp.unvoiced || !smp.marks.length) {
        // 没有元音（比如单独的辅音）：直接拉伸贴上
        const L = oEnd - oStart;
        for (let k = 0; k < L; k++) { const q = Math.floor(smp.vowelStart + (k / L) * (y.length - smp.vowelStart - 1)); out[oStart + k] += (y[q] || 0) * gainAt(tStart + k / sr) * 0.8; }
        continue;
      }
      // 元音：PSOLA。按原唱的音高放一个个周期，每个周期从样本里取最接近的那个周期的波形
      const marks = smp.marks, periods = smp.periods, M = marks.length;
      const Ls = marks[M - 1] - marks[0];
      const Lo = oEnd - oStart;
      const srcPos = (u) => {
        if (Lo <= Ls) return marks[0] + u * (Ls / Lo) * 0.92;
        // 先按原速唱到元音的 45%，之后在稳定的中段（30%–85%）来回取，不会唱到元音结尾的收尾音
        const direct = Ls * 0.45;
        if (u < direct) return marks[0] + u;
        const a = marks[0] + Ls * 0.3, b = marks[0] + Ls * 0.85, span = Math.max(1, b - a);
        const q = (Ls * 0.15 + (u - direct)) % (2 * span);
        return q < span ? a + q : b - (q - span);
      };
      const nearest = (pos) => { let lo = 0, hi = M - 1; while (lo < hi) { const md = (lo + hi) >> 1; if (marks[md] < pos) lo = md + 1; else hi = md; } if (lo > 0 && Math.abs(marks[lo - 1] - pos) < Math.abs(marks[lo] - pos)) lo--; return lo; };
      const fadeIn = Math.round((consLen > 0 ? 0.012 : 0.006) * sr), fadeOut = Math.round(0.03 * sr);
      let o = oStart - (consLen > 0 ? Math.round(0.006 * sr) : 0);
      while (o < oEnd) {
        const t = o / sr;
        const T = sr / midi2hz(midiAt(t));
        const j = nearest(srcPos(o - oStart));
        const m = marks[j], P = periods[j];
        const h = Math.round(P);
        const g = Math.min(1.6, T / P) * gainAt(t);
        for (let k = -h; k <= h; k++) {
          const p = Math.round(o) + k, q = m + k;
          if (p < 0 || p >= length || q < 0 || q >= y.length) continue;
          const w = 0.5 + 0.5 * Math.cos(Math.PI * k / (h + 1));
          let env = 1;
          const rel = p - oStart;
          if (rel < fadeIn) env *= Math.max(0, (rel + fadeIn) / (2 * fadeIn));
          if (oEnd - p < fadeOut) env *= Math.max(0, (oEnd - p) / fadeOut);
          out[p] += y[q] * w * g * env;
        }
        o += T;
      }
    }
    // 去掉 80Hz 以下的低频
    let prevX = 0, prevY = 0; const a = Math.exp(-2 * Math.PI * 80 / sr);
    for (let i = 0; i < length; i++) { const v = out[i]; const yv = a * (prevY + v - prevX); prevX = v; prevY = yv; out[i] = yv; }
    return out;
  }

  /* ---------- 6. 混音 ---------- */
  // 简单的 Freeverb（8 个梳状 + 4 个全通，左右稍微错开）
  function reverb(x, sr, { room = 0.78, damp = 0.35 } = {}) {
    const k = sr / 44100;
    const combT = [1116, 1188, 1277, 1356, 1422, 1491, 1557, 1617].map((v) => Math.round(v * k));
    const apT = [556, 441, 341, 225].map((v) => Math.round(v * k));
    const run = (spread) => {
      const y = new Float32Array(x.length);
      const combs = combT.map((t) => ({ b: new Float32Array(t + spread), i: 0, f: 0 }));
      const aps = apT.map((t) => ({ b: new Float32Array(t + spread), i: 0 }));
      for (let n = 0; n < x.length; n++) {
        const inp = x[n] * 0.015;
        let s = 0;
        for (const c of combs) { const o = c.b[c.i]; c.f = o * (1 - damp) + c.f * damp; c.b[c.i] = inp + c.f * room; if (++c.i >= c.b.length) c.i = 0; s += o; }
        for (const a of aps) { const o = a.b[a.i]; const v = -s + o; a.b[a.i] = s + o * 0.5; if (++a.i >= a.b.length) a.i = 0; s = v; }
        y[n] = s;
      }
      return y;
    };
    return [run(0), run(23)];
  }
  function rmsOf(x, step = 4) { let s = 0, c = 0; for (let i = 0; i < x.length; i += step) { s += x[i] * x[i]; c++; } return Math.sqrt(s / Math.max(1, c)); }
  // inst：伴奏（左右）；voc：她的人声；refVocal：原唱人声（用来对齐音量）
  function mixCover({ instL, instR, voc, refRms, vocalGain = 1, wet = 0.18, keepL = null, keepR = null, keep = 0, sr = SR }) {
    const n = Math.min(instL.length, voc.length);
    // 人声响度对齐到原唱
    const vr = rmsOf(voc);
    const g = vr > 0 ? (refRms / vr) * vocalGain : 0;
    const v = new Float32Array(n); for (let i = 0; i < n; i++) v[i] = voc[i] * g;
    const [rl, rr] = wet > 0 ? reverb(v, sr) : [null, null];
    const L = new Float32Array(n), R = new Float32Array(n);
    for (let i = 0; i < n; i++) {
      let l = instL[i] + v[i], r = instR[i] + v[i];
      if (rl) { l += rl[i] * wet * 6; r += rr[i] * wet * 6; }
      if (keep > 0 && keepL) { l += keepL[i] * keep; r += keepR[i] * keep; }
      L[i] = l; R[i] = r;
    }
    // 柔和限幅 + 统一到 -1dB
    let peak = 0; for (let i = 0; i < n; i++) peak = Math.max(peak, Math.abs(L[i]), Math.abs(R[i]));
    if (peak > 0) {
      const pre = 1 / peak * 1.25;
      for (let i = 0; i < n; i++) { L[i] = Math.tanh(L[i] * pre) * 0.89 / Math.tanh(1.25); R[i] = Math.tanh(R[i] * pre) * 0.89 / Math.tanh(1.25); }
    }
    return { L, R, vocal: v };
  }

  function toWav(chans, sr = SR) {
    const ch = chans.length, n = chans[0].length;
    const out = new DataView(new ArrayBuffer(44 + n * ch * 2));
    const w = (o, s) => { for (let k = 0; k < s.length; k++) out.setUint8(o + k, s.charCodeAt(k)); };
    w(0, 'RIFF'); out.setUint32(4, 36 + n * ch * 2, true); w(8, 'WAVE'); w(12, 'fmt ');
    out.setUint32(16, 16, true); out.setUint16(20, 1, true); out.setUint16(22, ch, true); out.setUint32(24, sr, true);
    out.setUint32(28, sr * ch * 2, true); out.setUint16(32, ch * 2, true); out.setUint16(34, 16, true); w(36, 'data'); out.setUint32(40, n * ch * 2, true);
    let o = 44;
    for (let k = 0; k < n; k++) for (let c = 0; c < ch; c++) { const v = Math.max(-1, Math.min(1, chans[c][k])); out.setInt16(o, v < 0 ? v * 0x8000 : v * 0x7fff, true); o += 2; }
    return new Uint8Array(out.buffer);
  }

  // 原唱的大致音高 vs 她念的音高：建议升降几个八度（-1 / 0 / +1）
  function suggestOctave(ct, sampleF0) {
    const arr = []; for (let i = 0; i < ct.voiced.length; i++) if (ct.voiced[i]) arr.push(ct.midi[i]);
    if (!arr.length) return 0;
    const orig = median(arr), target = hz2midi((sampleF0 || 240) * 1.45);   // 唱歌一般比说话高一些
    let best = 0, bd = 1e9;
    for (const o of [-1, 0, 1]) { const d = Math.abs(orig + 12 * o - target); if (d < bd) { bd = d; best = o; } }
    return best;
  }

  // 按乐句分组（给语音识别用）：每组 2.5–12 秒
  function asrChunks(seg, { minSec = 2.5, maxSec = 12 } = {}) {
    const out = [];
    for (const p of seg.phrases) {
      const last = out[out.length - 1];
      if (last && (p.t1 - last.t0 <= maxSec) && (last.t1 - last.t0 < minSec)) { last.t1 = p.t1; continue; }
      out.push({ t0: p.t0, t1: p.t1 });
    }
    return out.map((c) => ({ t0: Math.max(0, c.t0 - 0.15), t1: c.t1 + 0.25 }));
  }

  const api = { fft, resample, pitchTrack, cleanTrack, segment, syllabify, align, analyzeSample, renderVocal, mixCover, reverb, toWav, suggestOctave, asrChunks, hz2midi, midi2hz, median, rmsOf, SR };
  root.CoverDSP = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);
