'use strict';
/* 电吉他窗口：写简谱或六线谱 → 用电吉他的声音弹出来（简谱还可以配和弦伴奏）；
   可以保存、导出 WAV / MIDI；简谱能自动排指法转成六线谱；弹的时候告诉一歌 */
const $ = (id) => document.getElementById(id);
const api = window.synthAPI;
const msg = (t, cls = '') => { $('msg').textContent = t; $('msg').className = cls; };

let mineLoaded = false;   // 现在框里是她写的曲子
let mode = 'jianpu';      // 现在用哪种写法：jianpu 简谱 / tab 六线谱（决定提示和指板怎么写进去）
let ac = null, src = null, raf = 0, cache = { text: null, buf: null, score: null };
const ctx = () => (ac || (ac = new AudioContext()));

/* ---------- 预览：把每个音包成一个可以高亮的块 ---------- */
// items: [{ src:[a,b], t, dur }]；返回 spans（和 items 一一对应）
function buildPv(el, text, items) {
  el.textContent = '';
  const order = items.map((it, k) => ({ ...it, k })).filter((it) => it.src).sort((a, b) => a.src[0] - b.src[0]);
  const spans = new Array(items.length);
  let pos = 0;
  for (const it of order) {
    const [a, b] = it.src;
    if (a < pos) continue;
    if (a > pos) el.appendChild(document.createTextNode(text.slice(pos, a)));
    const sp = document.createElement('span');
    sp.className = 'n'; sp.textContent = text.slice(a, b);
    el.appendChild(sp); spans[it.k] = sp;
    pos = b;
  }
  if (pos < text.length) el.appendChild(document.createTextNode(text.slice(pos)));
  return spans;
}
let hl = [];   // [{ t, dur, span }]：播放时要高亮的块
function setMode(m, { quiet = false } = {}) {
  mode = m;
  $('modeJ').classList.toggle('on', m === 'jianpu'); $('modeT').classList.toggle('on', m === 'tab');
  $('hintJ').hidden = m !== 'jianpu'; $('hintT').hidden = m !== 'tab';
  $('tabTools').classList.toggle('show', m === 'tab');
  $('fbHint').textContent = m === 'tab' ? '点一下试音，同时把这个音写进最后一组六线谱' : '点一下试音，同时按当前的调把这个音写成简谱';
  $('toTab').disabled = m === 'tab';
  if (!quiet) check();
}

function check() {
  const text = $('score').value;
  const score = Jianpu.parse(text);
  hl = [];
  $('tabWrap').classList.remove('show');
  if (score.error) {
    msg(`第 ${text.slice(0, score.error.pos).split('\n').length} 行：${score.error.msg}`, 'err');
    buildPv($('preview'), '', []);
    return null;
  }
  // 自动跟着写法走：框里是六线谱就切到六线谱
  if (score.mode !== mode) setMode(score.mode, { quiet: true });
  if (TONE_NAME[score.tone] && $('tone').value !== TONE_NAME[score.tone]) $('tone').value = TONE_NAME[score.tone];
  if (!score.notes.length && !(score.chords && score.chords.length)) {
    msg(mode === 'tab' || /^\s*[eB]\s*\|/m.test(text) ? '六线谱还是空的：点下面的指板，或者直接在格子里写品位' : '还没有写音符');
    buildPv($('preview'), '', []);
    return null;
  }
  const sec = score.total * 60 / score.bpm;
  const len = sec < 60 ? Math.round(sec) + ' 秒' : Math.floor(sec / 60) + ' 分 ' + Math.round(sec % 60) + ' 秒';
  const count = score.mode === 'tab' ? score.events.filter((e) => !e.mute).length : score.notes.length;
  msg(`${score.mode === 'tab' ? '六线谱' : '简谱'} · ${count} 个音${score.chords.length ? ' · ' + score.chords.length + ' 个和弦' : ''} · ` +
    (score.mode === 'jianpu' ? `1=${score.key} · ` : '') + `♩=${score.bpm} · ${TONE_NAME[score.tone]} · 大约 ${len}`);
  if (score.mode === 'tab') {
    const spans = buildPv($('preview'), text, score.events);
    score.events.forEach((e, k) => spans[k] && hl.push({ t: e.t, dur: Math.max(0.2, Math.min(e.dur, 1)), span: spans[k] }));
  } else {
    const spans = buildPv($('preview'), text, score.notes);
    score.notes.forEach((n, k) => spans[k] && hl.push({ t: n.t, dur: n.dur, span: spans[k] }));
    // 同时给出自动排好指法的六线谱
    const tab = Jianpu.toTab(score);
    if (tab && tab.map.length) {
      $('tabWrap').classList.add('show');
      $('tabPv').hidden = !$('showTab').checked;
      if ($('showTab').checked) {
        const items = tab.map.map((m) => ({ src: [m.start, m.end] }));
        const spans2 = buildPv($('tabPv'), tab.text, items);
        tab.map.forEach((m, k) => { const n = tab.notes[m.idx]; if (spans2[k] && n) hl.push({ t: n.t, dur: n.dur, span: spans2[k] }); });
      }
    }
  }
  return score;
}
const TONE_NAME = Jianpu.TONES;
let checkTimer = 0;
$('score').addEventListener('input', () => { mineLoaded = false; clearTimeout(checkTimer); checkTimer = setTimeout(check, 250); });
$('showTab').addEventListener('change', check);

// 定位到出错的地方
$('msg').addEventListener('click', () => {
  const s = Jianpu.parse($('score').value);
  if (s.error) { $('score').focus(); $('score').setSelectionRange(s.error.pos, s.error.pos + 1); }
});

/* ---------- 写法、音色 ---------- */
$('modeJ').onclick = () => {
  const ta = $('score');
  const sc = Jianpu.parse(ta.value);
  if (sc.mode === 'tab' && sc.events.length) { msg('六线谱没法自动转回简谱。想写简谱的话，先保存这首，再清空编辑框（或者换一首）', 'err'); return; }
  if (sc.mode === 'tab' || !ta.value.trim()) ta.value = `1=C 4/4 ♩=100 音色=${$('tone').value}\n`;
  setMode('jianpu');
};
$('modeT').onclick = () => {
  const ta = $('score');
  const sc = Jianpu.parse(ta.value);
  if (sc.mode === 'jianpu' && !sc.error && sc.notes.some((n) => n.midi.length)) { $('toTab').click(); return; }   // 简谱：直接排好指法转过去
  if (sc.mode !== 'tab') ta.value = `♩=100 4/4 音色=${$('tone').value} 每格=1/4拍\n` + Jianpu.STRING_NAMES.map((n) => n + '|').join('\n');
  mineLoaded = false;
  setMode('tab');
};
// 改音色：改写谱子第一行里的“音色=…”（没有就加上）
$('tone').onchange = () => {
  const ta = $('score'), v = $('tone').value;
  let text = ta.value;
  if (/(音色|tone)\s*[=:：]\s*[一-龥A-Za-z]+/.test(text)) text = text.replace(/(音色|tone)\s*[=:：]\s*[一-龥A-Za-z]+/, '音色=' + v);
  else {
    const lines = text.split('\n');
    const k = lines.findIndex((l) => /1\s*=|♩|bpm|\d\s*\/\s*\d/.test(l) && !/^\s*[eEBGDA1-6]\s*\|/.test(l));
    if (k >= 0) lines[k] = lines[k].replace(/\s*(\/\/.*)?$/, (m, c) => ' 音色=' + v + (c ? '   ' + c : ''));
    else lines.unshift('音色=' + v);
    text = lines.join('\n');
  }
  ta.value = text; mineLoaded = false;
  check();
};

async function getBuffer() {
  const text = $('score').value;
  if (cache.text === text && cache.buf) return cache;
  const score = check();
  if (!score) return null;
  msg('合成中…');
  await new Promise((r) => setTimeout(r, 20));   // 让“合成中”先显示出来
  const buf = await Jianpu.render(score);
  cache = { text, buf, score };
  check();
  return cache;
}

/* ---------- 播放 ---------- */
function stop() {
  if (src) { try { src.stop(); } catch (e) {} src = null; }
  cancelAnimationFrame(raf);
  hl.forEach((h) => h.span.classList.remove('on'));
  $('play').disabled = false; $('stop').disabled = true;
}
$('stop').onclick = stop;
$('play').onclick = async () => {
  stop();
  $('play').disabled = true;
  const c = await getBuffer();
  if (!c) { $('play').disabled = false; return; }
  const a = ctx(); if (a.state === 'suspended') await a.resume();
  src = a.createBufferSource(); src.buffer = c.buf; src.connect(a.destination);
  const t0 = a.currentTime + 0.05;
  src.start(t0);
  src.onended = () => { if (src) stop(); };
  $('play').disabled = true; $('stop').disabled = false;
  if ($('share').checked || mineLoaded) api.played($('title').value.trim(), mineLoaded);
  const spb = 60 / c.score.bpm;
  const lit = new Set();
  let lastScroll = null;
  const tick = () => {
    const beat = (a.currentTime - t0 - 0.05) / spb;
    for (const h of hl) {
      const on = beat >= h.t && beat < h.t + h.dur;
      if (on && !lit.has(h)) {
        lit.add(h); h.span.classList.add('on');
        if (lastScroll !== h.span.parentNode) { lastScroll = h.span.parentNode; }
        h.span.scrollIntoView({ block: 'nearest', inline: 'nearest' });
      } else if (!on && lit.has(h)) { lit.delete(h); h.span.classList.remove('on'); }
    }
    raf = requestAnimationFrame(tick);
  };
  tick();
};

/* ---------- 导出 ---------- */
const fname = () => ($('title').value.trim() || '无题').replace(/[\\/:*?"<>|]/g, '_');
$('wav').onclick = async () => {
  const c = await getBuffer(); if (!c) return;
  const r = await api.exportFile({ name: fname() + '.wav', data: Jianpu.toWav(c.buf) });
  if (r && r.path) msg('已导出：' + r.path, 'ok');
};
$('midi').onclick = async () => {
  const score = check(); if (!score) return;
  const r = await api.exportFile({ name: fname() + '.mid', data: Jianpu.toMidi(score) });
  if (r && r.path) msg('已导出：' + r.path, 'ok');
};

/* ---------- 简谱 → 六线谱 ---------- */
$('toTab').onclick = () => {
  stop();
  const score = check();
  if (!score || score.mode !== 'jianpu') return;
  const tab = Jianpu.toTab(score);
  if (!tab) { msg('转不了：先把简谱写好', 'err'); return; }
  $('score').value = tab.text;
  mineLoaded = false;
  check();
  msg('已经排好指法，写成六线谱了（和弦伴奏也保留着；想留着原来的简谱，可以先另存一份）', 'ok');
};

/* ---------- 保存的曲子 ---------- */
let saved = {};
async function refreshSaved(select) {
  saved = await api.list();
  const sel = $('saved');
  sel.innerHTML = '<option value="">已保存的曲子…</option>';
  for (const name of Object.keys(saved).sort((a, b) => (saved[b].at || 0) - (saved[a].at || 0))) {
    const o = document.createElement('option'); o.value = name; o.textContent = name; sel.appendChild(o);
  }
  if (select) sel.value = select;
}
$('saved').onchange = () => {
  const name = $('saved').value; if (!name || !saved[name]) return;
  stop();
  $('title').value = name; $('score').value = saved[name].text; mineLoaded = saved[name].by === 'ichika'; check();
};
$('save').onclick = async () => {
  const name = $('title').value.trim();
  if (!name) { msg('先给曲子起个名字', 'err'); $('title').focus(); return; }
  await api.save({ title: name, text: $('score').value });
  await refreshSaved(name);
  msg('已保存', 'ok');
};
$('del').onclick = async () => {
  const name = $('saved').value;
  if (!name) { msg('先在右边选一首要删除的曲子', 'err'); return; }
  await api.remove(name);
  await refreshSaved('');
  msg(`已删除《${name}》`, 'ok');
};

/* ---------- 指板：6 根弦 × 0–15 品 ---------- */
const NAMES = ['1', '#1', '2', '#2', '3', '4', '#4', '5', '#5', '6', '#6', '7'];
const SUFFIX = { 0.25: '__', 0.5: '_', 1: '', 2: ' -' };
function tokenFor(midi) {
  const tonic = Jianpu.parse($('score').value).tonic || 60;
  const d = midi - tonic, oct = Math.floor(d / 12), r = ((d % 12) + 12) % 12;
  return NAMES[r] + (oct > 0 ? "'".repeat(oct) : ','.repeat(-oct));
}
// 找最后一组六线谱（e B G D A E 六行）的行号
function lastBlock(lines) {
  const lab = /^\s*([eEBGDA1-6])\s*\|/;
  for (let i = lines.length - 6; i >= 0; i--) {
    let ok = true;
    for (let k = 0; k < 6; k++) if (!lab.test(lines[i + k])) { ok = false; break; }
    if (ok) return i;
  }
  return -1;
}
function ensureBlock() {
  const ta = $('score');
  let lines = ta.value.replace(/\s+$/, '').split('\n');
  if (lastBlock(lines) < 0) {
    if (!ta.value.trim()) lines = [`♩=100 4/4 音色=${$('tone').value} 每格=1/4拍`];
    lines.push(...Jianpu.STRING_NAMES.map((n) => n + '|'));
  }
  return lines;
}
// 往最后一组六线谱的末尾加一列：cells[弦] 是这根弦要写的字（空 = 只补 -）
function appendTab(cells, beats) {
  const ta = $('score');
  const lines = ensureBlock();
  const b = lastBlock(lines);
  const sc = Jianpu.parse(lines.join('\n'));
  const perChar = (sc.mode === 'tab' && sc.unit) || 0.25;
  const need = Math.max(...cells.map((c) => (c || '').length)) + 1;
  const w = Math.max(need, Math.round(beats / perChar));
  for (let s = 0; s < 6; s++) lines[b + s] = lines[b + s].replace(/\s+$/, '') + (cells[s] || '').padEnd(w, '-');
  ta.value = lines.join('\n');
  ta.scrollTop = ta.scrollHeight; ta.scrollLeft = ta.scrollWidth;
  mineLoaded = false;
  check();
}
$('addBar').onclick = () => {
  const ta = $('score'); const lines = ensureBlock(); const b = lastBlock(lines);
  for (let s = 0; s < 6; s++) lines[b + s] = lines[b + s].replace(/\s+$/, '').replace(/\|?$/, '|');
  ta.value = lines.join('\n'); check();
};
$('addRest').onclick = () => appendTab(['', '', '', '', '', ''], +$('len').value);
$('newBlock').onclick = () => {
  const ta = $('score');
  ta.value = ta.value.replace(/\s+$/, '') + '\n\n' + Jianpu.STRING_NAMES.map((n) => n + '|').join('\n');
  check();
};
const tapCache = new Map();
async function tap(s, fret, el) {
  el.classList.add('down'); setTimeout(() => el.classList.remove('down'), 180);
  const midi = Jianpu.TUNING[s] + fret;
  const len = +$('len').value;
  if (mode === 'tab') {
    const cells = ['', '', '', '', '', '']; cells[s] = String(fret);
    appendTab(cells, len);
  } else {
    // 写进光标的位置
    const ta = $('score'), p = ta.selectionStart, q = ta.selectionEnd, v = ta.value;
    const before = v.slice(0, p), sep = before && !/[\s|[]$/.test(before) ? ' ' : '';
    const tok = sep + tokenFor(midi) + (SUFFIX[len] ?? '');
    ta.value = before + tok + v.slice(q);
    ta.setSelectionRange(p + tok.length, p + tok.length);
    mineLoaded = false;
    check();
  }
  const tone = (Jianpu.parse($('score').value).tone) || 'crunch';
  const key = midi + '|' + tone;
  if (!tapCache.has(key)) tapCache.set(key, Jianpu.render({ bpm: 60, total: 1, tone, notes: [{ t: 0, dur: 0.9, midi: [midi] }] }));
  const buf = await tapCache.get(key);
  const a = ctx(); if (a.state === 'suspended') await a.resume();
  const sn = a.createBufferSource(); sn.buffer = buf; sn.connect(a.destination); sn.start();
}
(function buildFretboard() {
  const fb = $('fb'), FR = 15;
  const dots = document.createElement('div'); dots.className = 'dots';
  for (let f = 0; f <= FR; f++) { const d = document.createElement('div'); if (f === 0) d.className = 'f0'; else if (f === 12) d.className = 'dd'; else if ([3, 5, 7, 9, 15].includes(f)) d.className = 'd'; dots.appendChild(d); }
  fb.appendChild(dots);
  const thick = [1, 1.3, 1.6, 2, 2.4, 2.9];
  for (let s = 0; s < 6; s++) {
    const row = document.createElement('div'); row.className = 'str'; row.style.setProperty('--th', thick[s] + 'px');
    const nm = document.createElement('div'); nm.className = 'nm'; nm.textContent = Jianpu.STRING_NAMES[s]; row.appendChild(nm);
    for (let f = 0; f <= FR; f++) {
      const el = document.createElement('div'); el.className = 'fr' + (f === 0 ? ' f0' : '');
      const sp = document.createElement('span'); sp.textContent = f; el.appendChild(sp);
      el.title = `${s + 1} 弦 ${f} 品`;
      el.onmousedown = (e) => { e.preventDefault(); tap(s, f, el); };
      row.appendChild(el);
    }
    fb.appendChild(row);
  }
  const num = $('fnum');
  for (let f = 0; f <= FR; f++) { const d = document.createElement('div'); if (f === 0) d.className = 'f0'; d.textContent = [0, 3, 5, 7, 9, 12, 15].includes(f) ? f : ''; num.appendChild(d); }
})();

/* ---------- 让她写一首 ---------- */
$('compose').onclick = async () => { stop(); await api.compose(''); };
api.onStatus(({ busy, text, err }) => {
  $('compose').disabled = !!busy;
  msg(text, err ? 'err' : busy ? '' : 'ok');
});
api.onLoad(async ({ title, text, play, mine }) => {
  stop();
  await refreshSaved(title);
  $('title').value = title; $('score').value = text; mineLoaded = !!mine;
  check();
  if (play) $('play').click();
});

/* ---------- 开始 ---------- */
(async () => {
  await refreshSaved('');
  const names = Object.keys(saved);
  if (!names.length) {
    $('title').value = '明天也一起（示例）';
    $('score').value = "1=D 4/4 ♩=116 音色=过载   // 示例：可以直接点“播放”\n3 5 6 1'_ 6_ | 5~ - 3 2_ 3_ | 1 2 3 5 | 2 - - 0 |\n3 5 6 1'_ 2'_ | 3'~ - 2' 1'_ 6_ | 5 6 1' 2'_ 1'_ | 1'~ - - 0 |\n和弦：| D | A | Bm | G A | D | A | G A | D |";
  }
  check();
})();

/* ---------- 写词：把当前作品直接交给写词窗口（不用先导出文件） ---------- */
function currentPiece() {
  const text = $('score').value, title = $('title').value.trim();
  if (!text.trim()) return { error: '合成器里还没有曲子：先写一段，或者从“已保存的曲子”里选一首，再点“为这首写歌词”。' };
  const p = Jianpu.parse(text);
  if (p.error) return { error: '这首谱子有错误，先改好再写歌词：' + p.error.msg };
  if (!p.notes.some((n) => n.midi.length)) return { error: '这首谱子里还没有音符（只有休止、和弦或空白）。' };
  return { kind: 'synth', title, text, mine: mineLoaded };
}
$('toLyrics').onclick = async () => {
  clearTimeout(checkTimer);   // 不让输入检查的提示盖掉这里的提示
  const c = currentPiece();
  if (c.error) { msg(c.error, 'err'); return; }
  const r = await api.toLyrics(c);
  if (r && r.error) msg(r.error, 'err');
  else msg(`已经把${c.title ? '《' + c.title + '》' : '当前这首'}交给写词窗口（编辑框里的内容没有改动）。`, 'ok');
};
api.onGetCurrent && api.onGetCurrent((reqId) => api.currentReply(reqId, currentPiece()));
