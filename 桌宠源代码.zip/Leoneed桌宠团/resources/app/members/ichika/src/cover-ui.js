'use strict';
/* 翻唱窗口 */
const $ = (id) => document.getElementById(id);
const api = window.coverAPI;
const D = window.CoverDSP;
const SR = D.SR;
const st = { name: '', mixL: null, mixR: null, vocL: null, vocR: null, instL: null, instR: null, ct: null, seg: null, her: null, cover: null, herMix: null, spans: null, rawVoc: null, refRms: 0, busy: false };
let cfg = {};
let revision = 0, activeRevision = null;
const ac = new AudioContext({ sampleRate: SR });
const setMsg = (id, t, cls = '') => { $(id).textContent = t; $(id).className = 'msg' + (cls ? ' ' + cls : ''); };
const yieldUI = () => new Promise((r) => setTimeout(r, 30));
const fmtSec = (s) => `${Math.floor(s / 60)}:${String(Math.round(s % 60)).padStart(2, '0')}`;

/* ---------- 进度 ---------- */
function prog(on, text = '', frac = null, eta = '') {
  $('prog').classList.toggle('on', on);
  $('bar').classList.toggle('indef', frac === null);
  $('bar').firstElementChild.style.width = frac === null ? '' : Math.round(frac * 100) + '%';
  $('progText').textContent = text; $('progEta').textContent = eta;
  $('cancelBtn').disabled = !on;
}
api.onProgress((p) => {
  if (activeRevision !== revision) return;
  const f = p.total ? p.done / p.total : null;
  if (p.stage === 'load') prog(true, '载入人声分离模型…', null);
  else if (p.stage === 'separate') prog(true, `分离人声 ${p.done}/${p.total} 段`, f, p.eta ? `还要大约 ${fmtSec(p.eta)}` : '');
  else if (p.stage === 'asr') prog(true, `识别歌词 ${p.done}/${p.total} 句`, f);
  else if (p.stage === 'tts') prog(true, `她在念每个音 ${p.done}/${p.total}`, f, p.cached ? '（念过的直接用）' : '');
});
$('cancelBtn').onclick = () => { revision++; api.cancel(); prog(false); setMsg('genMsg', '已取消', 'warn'); };

/* ---------- 设置检查 ---------- */
async function refreshCfg() {
  cfg = await api.config();
  const pill = $('voicePill');
  pill.className = 'pill ' + (cfg.hasVoice ? 'ok' : 'bad');
  pill.textContent = cfg.hasVoice ? '她的声音：已设置（MiniMax 音色）' : '她的声音：还没设置';
  const w = [];
  if (!cfg.hasVoice) w.push('翻唱要用她克隆后的音色：右键 → 设置 → “语音”，填好 MiniMax 密钥和音色 ID（不用勾“开启语音”也行）。');
  if (!cfg.hasModel) w.push('缺少人声分离模型文件（resources\\app\\models\\Kim_Vocal_2.onnx），请重新解压完整的程序包。');
  $('warn').innerHTML = w.map((x) => '· ' + x).join('<br>');
  $('warn').classList.toggle('on', w.length > 0);
  $('kanaBtn').disabled = !cfg.hasChat || st.busy || st.loading;
  $('kanaBtn').title = cfg.hasChat ? '用聊天模型把汉字、片假名、英文转成平假名（日语歌必须是假名）' : '需要先在设置里填聊天模型的 API';
}
$('openSet').onclick = () => api.openSettings();
window.addEventListener('focus', refreshCfg);

/* ---------- 1. 选歌 ---------- */
$('pick').onclick = () => $('file').click();
$('file').onchange = (e) => { const f = e.target.files[0]; e.target.value = ''; if (f) loadFile(f); };
const drop = $('drop');
drop.addEventListener('dragover', (e) => { e.preventDefault(); drop.classList.add('over'); });
drop.addEventListener('dragleave', () => drop.classList.remove('over'));
drop.addEventListener('drop', (e) => { e.preventDefault(); drop.classList.remove('over'); const f = [...e.dataTransfer.files][0]; if (f) loadFile(f); });

async function loadFile(f) {
  if (st.busy) return;
  const mine = ++revision;
  st.loading = true; setPlayers();
  stopPlay();
  try {
    setMsg('genMsg', '');
    $('fileInfo').textContent = '读取中…';
    const bytes = await f.arrayBuffer();
    if (mine !== revision) return;
    const hashBuf = await crypto.subtle.digest('SHA-1', bytes);
    if (mine !== revision) return;
    const hash = [...new Uint8Array(hashBuf)].map((b) => b.toString(16).padStart(2, '0')).join('');
    const buf = await ac.decodeAudioData(bytes.slice(0));
    if (mine !== revision) return;
    if (buf.duration < 6) throw new Error('太短了（少于 6 秒）');
    if (buf.duration > 8 * 60) throw new Error('太长了（超过 8 分钟），可以先剪短一点');
    // 统一成 44.1k 双声道
    const oc = new OfflineAudioContext(2, Math.ceil(buf.duration * SR), SR);
    const s = oc.createBufferSource(); s.buffer = buf; s.connect(oc.destination); s.start();
    const r = await oc.startRendering();
    if (mine !== revision) return;
    st.hash = hash;
    st.mixL = r.getChannelData(0).slice(); st.mixR = r.getChannelData(1).slice();
    st.name = f.name.replace(/\.[^.]+$/, '');
    Object.assign(st, { vocL: null, vocR: null, instL: null, instR: null, ct: null, seg: null, her: null, cover: null, spans: null, rawVoc: null });
    $('title').value = st.name;
    $('fileInfo').textContent = '';
    drop.innerHTML = `<b>${esc(f.name)}</b><div class="hint">${fmtSec(buf.duration)} · 点“开始分离”。想换一首就再拖一个文件进来，或 <button id="pick2" class="small">重新选择…</button></div>`;
    $('pick2').onclick = () => $('file').click();
    $('sepBtn').disabled = false;
    setPlayers();
    $('sepInfo').textContent = ''; $('anaInfo').textContent = '';
  } catch (e) {
    if (mine !== revision) return;
    $('fileInfo').textContent = '';
    setMsg('genMsg', '这个文件读不了：' + e.message, 'err');
  } finally { if (mine === revision) { st.loading = false; setPlayers(); } }
}
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

/* ---------- 2. 分离人声 + 分析原唱 ---------- */
$('sepBtn').onclick = async () => {
  if (!st.mixL || st.busy || st.loading) return;
  const mine = revision; activeRevision = mine;
  st.busy = true; $('sepBtn').disabled = true; stopPlay();
  prog(true, '准备中…', null);
  const t0 = Date.now();
  try {
  const r = await api.separate({ L: st.mixL, R: st.mixR, hash: st.hash });
  if (mine !== revision || r.canceled) return;
  if (r.error) { prog(false); setMsg('genMsg', r.error, r.canceled ? 'warn' : 'err'); return; }
  st.vocL = r.L instanceof Float32Array ? r.L : new Float32Array(r.L); st.vocR = r.R instanceof Float32Array ? r.R : new Float32Array(r.R);
  const n = st.mixL.length;
  st.instL = new Float32Array(n); st.instR = new Float32Array(n);
  for (let i = 0; i < n; i++) { st.instL[i] = st.mixL[i] - st.vocL[i]; st.instR[i] = st.mixR[i] - st.vocR[i]; }
  $('sepInfo').textContent = r.cached ? '用了上次的分离结果' : `用了 ${fmtSec((Date.now() - t0) / 1000)}`;
  prog(true, '分析原唱的旋律…', null);
  await yieldUI();
  if (mine !== revision) return;
  analyze();
  prog(false);
  setPlayers();
  } catch (e) { if (mine === revision) setMsg('genMsg', '分离失败：' + e.message, 'err'); }
  finally { st.busy = false; activeRevision = null; prog(false); setPlayers(); }
};
function analyze() {
  const n = st.vocL.length, mono = new Float32Array(n);
  for (let i = 0; i < n; i++) mono[i] = (st.vocL[i] + st.vocR[i]) / 2;
  st.vocMono = mono;
  st.refRms = D.rmsOf(mono);
  const v16 = D.resample(mono, SR, 16000);
  st.ct = D.cleanTrack(D.pitchTrack(v16, 16000));
  st.seg = D.segment(st.ct);
  const sung = st.seg.notes.reduce((s, x) => s + (x.t1 - x.t0), 0);
  $('anaInfo').textContent = st.seg.notes.length
    ? `原唱：${st.seg.phrases.length} 句、${st.seg.notes.length} 个音，唱的部分共 ${fmtSec(sung)}`
    : '没在这首歌里找到人声（可能是纯音乐）';
  $('asrBtn').disabled = !st.seg.notes.length;
  updateSyl();
}

/* ---------- 3. 歌词 ---------- */
$('asrBtn').onclick = async () => {
  if (!st.seg || st.busy || st.loading) return;
  if (!cfg.hasAsr) { setMsg('lyrMsg', '还没填语音识别的密钥：右键 → 设置 → “语音通话（语音识别）”', 'err'); return; }
  st.busy = true; $('asrBtn').disabled = true;
  const mine = revision; activeRevision = mine;
  try {
  const chunks = D.asrChunks(st.seg).map((c) => wav16(st.vocMono.subarray(Math.floor(c.t0 * SR), Math.min(st.vocMono.length, Math.ceil(c.t1 * SR)))));
  prog(true, `识别歌词 0/${chunks.length} 句`, 0);
  const r = await api.asr(chunks);
  if (mine !== revision || r.canceled) return;
  if (r.error && !(r.lines && r.lines.length)) { setMsg('lyrMsg', r.error, 'err'); return; }
  const lines = (r.lines || []).map((x) => x.trim()).filter(Boolean);
  $('lyr').value = lines.join('\n');
  const lang = /[぀-ヿ]/.test($('lyr').value) ? 'ja' : /[一-鿿]/.test($('lyr').value) ? $('lang').value : $('lang').value;
  $('lang').value = lang;
  setMsg('lyrMsg', (r.error ? r.error + '；' : '') + `识别出 ${lines.length} 行。唱歌的识别常有错字，最好对照原词改一改` + (lang === 'ja' && /[一-鿿]/.test($('lyr').value) ? '；里面有汉字，点“转成假名”' : ''), r.error ? 'warn' : 'ok');
  updateSyl();
  } catch (e) { if (mine === revision) setMsg('lyrMsg', '识别失败：' + e.message, 'err'); }
  finally { st.busy = false; activeRevision = null; prog(false); setPlayers(); }
};
function wav16(x) {
  const y = D.resample(x, SR, 16000);
  return D.toWav([y], 16000).buffer;
}
$('kanaBtn').onclick = async () => {
  if (st.busy || st.loading) return;
  const lines = $('lyr').value.split('\n').map((x) => x.trim()).filter(Boolean);
  if (!lines.length) { setMsg('lyrMsg', '先填歌词', 'err'); return; }
  const mine = revision; activeRevision = mine; st.busy = true;
  $('kanaBtn').disabled = true; setMsg('lyrMsg', '转换中…');
  prog(true, '转换假名中…');
  try {
  const r = await api.kana(lines, $('lang').value);
  if (mine !== revision || r.canceled) return;
  if (r.error) { setMsg('lyrMsg', r.error, 'err'); return; }
  $('lyr').value = r.lines.join('\n');
  setMsg('lyrMsg', $('lang').value === 'ja' ? '已转成假名，看看读音对不对（尤其是汉字的读法）' : '已整理好', 'ok');
  updateSyl();
  } catch (e) { if (mine === revision) setMsg('lyrMsg', '转换失败：' + e.message, 'err'); }
  finally { st.busy = false; activeRevision = null; prog(false); setPlayers(); }
};
let sylTimer = 0;
$('lyr').addEventListener('input', () => { clearTimeout(sylTimer); sylTimer = setTimeout(updateSyl, 300); });
$('lang').addEventListener('change', updateSyl);
function updateSyl() {
  const sy = D.syllabify($('lyr').value, $('lang').value);
  const notes = st.seg ? st.seg.notes.length : 0;
  $('sylInfo').textContent = sy.total ? `${sy.lines.length} 行 · ${sy.total} 个音节${notes ? ' / 原唱 ' + notes + ' 个音' : ''}` : '';
  const warning = '歌词里有汉字或字母：日语歌要写成假名，点“转成假名”';
  if (sy.needKana && $('lang').value === 'ja') setMsg('lyrMsg', warning, 'warn');
  else if ($('lyrMsg').textContent === warning) setMsg('lyrMsg', '');
  $('genBtn').disabled = !!(st.busy || st.loading) || !(st.seg && st.seg.notes.length && sy.total && cfg.hasVoice);
  return sy;
}

/* ---------- 4. 生成 ---------- */
async function decodeSample(b64) {
  const bin = atob(b64), bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  const buf = await ac.decodeAudioData(bytes.buffer);
  const oc = new OfflineAudioContext(1, Math.ceil(buf.duration * SR), SR);
  const s = oc.createBufferSource(); s.buffer = buf; s.connect(oc.destination); s.start();
  const r = await oc.startRendering();
  return r.getChannelData(0).slice();
}
$('genBtn').onclick = async () => {
  if (st.busy || st.loading) return;
  const mine = revision; activeRevision = mine;
  const lang = $('lang').value;
  const sy = updateSyl();
  if (!sy.total) return;
  if (sy.needKana && lang === 'ja') { setMsg('genMsg', '歌词里还有汉字或字母，先点右边的“转成假名”', 'err'); return; }
  st.busy = true; $('genBtn').disabled = true; stopPlay();
  try {
    setMsg('genMsg', '把歌词对到旋律上…');
    await yieldUI();
    if (mine !== revision) return;
    st.spans = D.align(st.seg, sy.lines);
    if (!st.spans.length) throw new Error('歌词对不上旋律');
    const texts = [...new Set(st.spans.map((s) => s.tts))];
    setMsg('genMsg', `一共 ${st.spans.length} 个音节，${texts.length} 种读音，让她一个个念出来…`);
    prog(true, `她在念每个音 0/${texts.length}`, 0);
    const r = await api.tts(texts, lang);
    if (mine !== revision || r.canceled) return;
    if (r.error && !(r.audio && Object.keys(r.audio).length)) throw new Error(r.error);
    prog(true, '准备她的声音…', null);
    const samples = {};
    for (const t of texts) {
      if (mine !== revision) return;
      if (!r.audio || !r.audio[t]) continue;
      try { samples[t] = D.analyzeSample(await decodeSample(r.audio[t]), SR); } catch (e) {}
      if (mine !== revision) return;
    }
    const missing = texts.filter((t) => !samples[t]);
    prog(true, '按原唱的旋律唱出来…', null);
    await yieldUI();
    if (mine !== revision) return;
    const f0s = Object.values(samples).map((s) => s.f0med);
    const oct = $('octave').value === 'auto' ? D.suggestOctave(st.ct, D.median(f0s)) : +$('octave').value;
    st.octUsed = oct;
    st.rawVoc = D.renderVocal({ spans: st.spans, ct: st.ct, samples, length: st.mixL.length, octave: oct });
    remix();
    prog(false);
    const octTxt = oct > 0 ? '（升了一个八度）' : oct < 0 ? '（降了一个八度）' : '';
    setMsg('genMsg', `唱好了${octTxt}。` + (missing.length ? `有 ${missing.length} 个音没念出来（${r.error || '合成失败'}），那几处会空着。` : '') + '不满意的话：改改歌词的换行、换个音高，再生成一次（念过的音不会再花钱）。', missing.length ? 'warn' : 'ok');
    api.done($('title').value.trim() || st.name);
  } catch (e) {
    prog(false);
    if (mine === revision) setMsg('genMsg', '没唱成：' + e.message, 'err');
  } finally {
    st.busy = false; activeRevision = null; prog(false);
    setPlayers();
  }
};
function remix() {
  if (!st.rawVoc) return;
  const m = D.mixCover({ instL: st.instL, instR: st.instR, voc: st.rawVoc, refRms: st.refRms, vocalGain: +$('vol').value / 100, wet: +$('wet').value / 100, keepL: st.vocL, keepR: st.vocR, keep: +$('keep').value / 100 });
  st.cover = [m.L, m.R];
  // 单独的人声：统一到 -1dB
  let pk = 0; for (const v of m.vocal) pk = Math.max(pk, Math.abs(v));
  const g = pk > 0 ? 0.89 / pk : 0; st.her = m.vocal.map((v) => v * g);
}
let remixTimer = 0;
for (const id of ['vol', 'wet', 'keep']) {
  $(id).addEventListener('input', () => {
    $(id + 'V').textContent = $(id).value + '%';
    clearTimeout(remixTimer);
    remixTimer = setTimeout(() => { if (st.rawVoc && !st.busy) { const was = playing; stopPlay(); remix(); if (was === 'cover') play('cover'); } }, 250);
  });
}

/* ---------- 试听 ---------- */
let src = null, playing = '';
function stopPlay() {
  if (src) { try { src.onended = null; src.stop(); } catch (e) {} src = null; }
  playing = '';
  document.querySelectorAll('[data-play]').forEach((b) => b.classList.remove('on'));
}
function play(kind) {
  stopPlay();
  const ch = kind === 'mix' ? [st.mixL, st.mixR] : kind === 'inst' ? [st.instL, st.instR] : kind === 'vocal' ? [st.vocL, st.vocR] : kind === 'cover' ? st.cover : kind === 'her' ? [st.her] : null;
  if (!ch || !ch[0]) return;
  const b = ac.createBuffer(ch.length, ch[0].length, SR);
  ch.forEach((c, i) => b.copyToChannel(c, i));
  if (ac.state === 'suspended') ac.resume();
  src = ac.createBufferSource(); src.buffer = b; src.connect(ac.destination); src.start();
  src.onended = () => stopPlay();
  playing = kind;
  const btn = document.querySelector(`[data-play="${kind}"]`); if (btn) btn.classList.add('on');
}
document.querySelectorAll('[data-play]').forEach((b) => { b.onclick = () => (b.dataset.play === 'stop' || playing === b.dataset.play ? stopPlay() : play(b.dataset.play)); });
function setPlayers() {
  $('sepBtn').disabled = !!(st.busy || st.loading) || !st.mixL;
  $('asrBtn').disabled = !!(st.busy || st.loading) || !st.seg || !st.seg.notes.length;
  $('kanaBtn').disabled = !!(st.busy || st.loading) || !cfg.hasChat;
  const has = { mix: !!st.mixL, inst: !!st.instL, vocal: !!st.vocL, cover: !!st.cover, her: !!st.her, stop: true };
  document.querySelectorAll('[data-play]').forEach((b) => { b.disabled = !has[b.dataset.play]; });
  $('saveCover').disabled = !st.cover; $('saveVocal').disabled = !st.her;
  updateSyl();
}

/* ---------- 导出 ---------- */
const outName = () => ($('title').value.trim() || st.name || '翻唱');
$('saveCover').onclick = async () => { if (!st.cover) return; const r = await api.save({ name: `${outName()}（一歌翻唱）`, data: D.toWav(st.cover) }); if (r.ok) setMsg('genMsg', '已导出：' + r.path, 'ok'); };
$('saveVocal').onclick = async () => { if (!st.her) return; const r = await api.save({ name: `${outName()}（一歌的人声）`, data: D.toWav([st.her]) }); if (r.ok) setMsg('genMsg', '已导出：' + r.path, 'ok'); };

refreshCfg().then(updateSyl);
