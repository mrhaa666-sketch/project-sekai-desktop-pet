// 台词、心情、动作。对你的她：直率、话少、不太会说软话，但很在乎你；被说中心事会别扭地移开视线。
// t = 台词，ja = 配音用的日语（空 = 不配音），m = 心情（决定表情），a = 动作（决定身体动作）。
// {name} 会替换成设置里的称呼（日语里换成「日语称呼」）。
'use strict';

// 表情代号表：代号 → [文件名, 说明]。文件在 model/faces/文件名.motion3.json（三套衣服都有）。
// 文件名保持英文，是为了解压时不会因为中文文件名出乱码；平时只用中文代号。
// 想加新表情：把文件放进三套衣服的 faces/，再在这里加一行。
window.FACES = {
  '平常': ['face_normal_01', '平常的脸，平静、有点冷淡（默认）'],
  '平常2': ['face_normal_02', '平常，稍微柔和一点'],
  '平静': ['face_smallmouth_01', '平静，嘴很小'],
  '淡笑': ['face_smile_01', '嘴角轻轻扬起'],
  '微笑': ['face_smile_07', '难得的微笑'],
  '温柔笑': ['face_smile_06', '温柔地笑'],
  '安心笑': ['face_smile_05', '放下心来，淡淡地笑'],
  '脸红微笑': ['face_smile_02', '脸红红地笑'],
  '害羞笑': ['face_smile_08', '有点害羞地笑，脸红'],
  '开心': ['face_smile_09', '开心，脸红'],
  '温和脸红': ['face_smile_11', '温和地笑，脸有点红'],
  '闭眼笑': ['face_smile_04', '闭着一只眼笑'],
  '无奈笑': ['face_smile_03', '无奈地笑，冒汗'],
  '苦笑': ['face_smile_10', '苦笑'],
  '得意': ['face_smile_12', '露出牙齿，得意地笑'],
  '咧嘴笑': ['face_e_01', '露出牙齿的笑'],
  '坏笑1': ['face_play_01', '带点调侃的笑'],
  '坏笑2': ['face_play_02', '调侃你'],
  '陶醉': ['face_spoony_01', '脸红，看得入神'],
  '眨眼': ['face_wink_01', '眨一只眼'],
  '害羞1': ['face_shy_01', '害羞'],
  '害羞2': ['face_shy_02', '害羞，脸红'],
  '慌乱': ['face_hawawa_01', '慌了，脸红'],
  '别扭1': ['face_lookaway_01', '别过眼去'],
  '别扭左': ['face_lookaway_01l', '眼睛看向一边'],
  '别扭右': ['face_lookaway_01r', '眼睛看向另一边'],
  '嘴硬脸红': ['face_lookaway_02', '别过脸去，脸红（嘴硬）'],
  '别扭2': ['face_lookaway_03', '不太情愿地移开视线'],
  '脸红别扭': ['face_lookaway_04', '脸红着移开视线'],
  '移开视线': ['face_lookaway_05', '默默地移开视线'],
  '尴尬1': ['face_ossmile_02', '尴尬地笑，冒汗'],
  '尴尬2': ['face_ossmile_05', '尴尬，冒汗'],
  '尴尬3': ['face_ossmile_07', '有点尴尬地笑'],
  '慌张': ['face_ossurprise_01', '吓了一跳，冒汗'],
  '闭眼': ['face_closeeye_01', '闭着眼'],
  '闭眼放松': ['face_closeeye_02', '闭眼，很放松'],
  '闭眼微笑': ['face_closeeye_03', '闭着眼微笑'],
  '困': ['face_sleepy_01', '困了'],
  '认真': ['face_sharp_01', '认真、眼神锐利'],
  '认真冒汗': ['face_sharp_02', '认真，有点紧张'],
  '较劲': ['face_bright_01', '不服输地盯着'],
  '惊讶1': ['face_surprise_01', '惊讶'],
  '惊讶2': ['face_surprise_02', '惊讶，脸有点红'],
  '惊讶3': ['face_surprise_03', '有点意外'],
  '张嘴': ['face_eat_01', '“啊”地张开嘴'],
  '嚼': ['face_eat_02', '嘴里在吃东西'],
  '困扰1': ['face_trouble_01', '困扰'],
  '困扰2': ['face_trouble_02', '困扰，为难'],
  '低头': ['face_lookdown_01', '眼睛往下看'],
  '难过1': ['face_sad_01', '难过'],
  '难过闭眼': ['face_sad_02', '难过地闭上一只眼'],
  '难过2': ['face_sad_03', '难过，垂着眉'],
  '难过3': ['face_sad_04', '低落'],
  '难过4': ['face_sad_05', '难过，忍着'],
  '难过5': ['face_sad_06', '很难过'],
  '失落': ['face_sad_07', '失落'],
  '眼眶湿': ['face_cry_01', '眼眶湿了'],
  '含泪': ['face_cry_02', '含着泪，脸红'],
  '快哭了': ['face_cry_03', '快要哭了'],
  '不满': ['face_angry_01', '不满，皱眉'],
  '生气': ['face_angry_02', '生气'],
  '脸红生气': ['face_angry_03', '红着脸生气'],
  '皱眉': ['face_angry_04', '皱着眉（不高兴或担心）'],
  '嫌弃1': ['face_disgust_01', '嫌弃、受不了'],
  '嫌弃2': ['face_disgust_02', '很嫌弃'],
};

// 心情 → 表情 + 动作。
// faces：[表情代号, 强度]，强度 0~1（1 是完整的表情，小一点会更接近「平常」）。
// rare：偶尔才出现的表情，chance 是出现概率。
// actions：这个心情常用的身体动作；AI 没选动作时从这里挑。
window.MOODS = {
  calm:       { faces: [['平常', 1], ['平静', 1]], rare: { chance: 0.2, faces: [['淡笑', 0.7], ['平常2', 1]] }, actions: ['none', 'nod', 'arms'], desc: '平常、平静的样子（默认）' },
  smile:      { faces: [['淡笑', 0.9], ['微笑', 0.85], ['安心笑', 0.85]], actions: ['nod', 'tilt'], desc: '心情不错，淡淡地笑' },
  happy:      { faces: [['开心', 0.85], ['温柔笑', 0.9], ['温和脸红', 0.85]], actions: ['nod', 'thumb'], desc: '开心（她表现得很克制）' },
  excited:    { faces: [['认真', 0.8], ['得意', 0.85], ['咧嘴笑', 0.85]], actions: ['cheer', 'thumb'], desc: '有干劲、兴奋（聊到贝斯、乐队、好的演出时）' },
  proud:      { faces: [['得意', 0.9], ['坏笑1', 0.85]], actions: ['hip', 'thumb'], desc: '得意（“……还行吧”）' },
  teasing:    { faces: [['坏笑1', 0.9], ['坏笑2', 0.9]], actions: ['hip', 'tilt'], desc: '调侃你、逗你' },
  warm:       { faces: [['温柔笑', 0.85], ['闭眼微笑', 0.85], ['安心笑', 0.9]], actions: ['warm', 'nod'], desc: '被打动、心里暖暖的、放下心来' },
  shy:        { faces: [['嘴硬脸红', 0.9], ['脸红别扭', 0.9], ['害羞2', 0.85], ['害羞笑', 0.8]], actions: ['look_away', 'shy'], desc: '害羞（会别过脸去，嘴硬）' },
  flustered:  { faces: [['慌乱', 0.9], ['慌张', 0.85], ['尴尬1', 0.85]], actions: ['look_away', 'shake'], desc: '被说中、慌了' },
  awkward:    { faces: [['尴尬2', 0.85], ['尴尬3', 0.85], ['无奈笑', 0.85]], actions: ['look_away', 'sigh'], desc: '尴尬、不知道说什么好' },
  think:      { faces: [['平静', 1], ['认真', 0.6], ['别扭左', 0.6]], actions: ['think', 'arms'], desc: '在想事情' },
  determined: { faces: [['认真', 0.95], ['较劲', 0.85], ['认真冒汗', 0.8]], actions: ['resolve', 'cheer'], desc: '下定决心、不服输' },
  sad:        { faces: [['难过1', 0.75], ['难过3', 0.75], ['失落', 0.75]], actions: ['look_down', 'sigh'], desc: '低落、难过' },
  hurt:       { faces: [['眼眶湿', 0.8], ['难过5', 0.75], ['快哭了', 0.7]], actions: ['look_down', 'sigh'], desc: '受伤、很难受（她很少表现出来）' },
  worried:    { faces: [['皱眉', 0.85], ['困扰1', 0.8], ['认真冒汗', 0.75]], actions: ['arms', 'trouble'], desc: '担心你（会说得很直接）' },
  troubled:   { faces: [['困扰1', 0.8], ['困扰2', 0.8], ['无奈笑', 0.8], ['苦笑', 0.8]], actions: ['sigh', 'shake'], desc: '困扰、拿你没办法' },
  annoyed:    { faces: [['嫌弃1', 0.8], ['不满', 0.75], ['皱眉', 0.8]], actions: ['arms', 'sigh', 'hip'], desc: '嫌麻烦、受不了（“……你啊”）' },
  surprised:  { faces: [['惊讶1', 0.85], ['惊讶3', 0.9], ['惊讶2', 0.8]], actions: ['tilt', 'nod'], desc: '吃惊、意外' },
  sleepy:     { faces: [['困', 1], ['闭眼', 1]], actions: ['sleep'], desc: '困了' },
  sulky:      { faces: [['不满', 0.7], ['别扭2', 0.85], ['嫌弃1', 0.65]], actions: ['arms', 'look_away', 'shake'], desc: '闹别扭、不高兴' },
  angry:      { faces: [['生气', 0.9], ['不满', 1], ['脸红生气', 0.85]], actions: ['angry', 'arms', 'shake'], desc: '生气' },
};

// 动作 → 身体动作（随机挑一个）。和一歌、穗波是同一套官方动作；按志步在原作里常用的类型挑：
// 多用 cool 系（抱臂、叹气、摇头）、叉腰和 normal 系；少用 cute 系（捧脸、眨眼这类卖萌的动作）。
// 同一个动作准备了几种站姿下的版本：桌宠会优先挑和她现在站姿一样的那个，衔接不会突然换手、换姿势。
// 张开双臂、跳起来、身体大幅前倾的动作都不用（会伸出窗口或上下移动）。
window.ACTIONS = {
  none:      { bodies: [], desc: '不做动作' },
  nod:       { bodies: ['w-normal16-nod', 'w-noromal16-nod', 'w-normal15-nod', 'w-normal03-nod', 'w-normal07-nod', 'w-normal17-nod', 'w-cool13-nod'], desc: '点头' },
  tilt:      { bodies: ['w-normal16-tilthead', 'w-noromal16-tilthead', 'w-normal15-tilthead', 'w-normal03-tilthead', 'w-normal07-tilthead', 'w-normal17-tilthead'], desc: '歪头' },
  think:     { bodies: ['w-adult05-think', 'w-cool13-tilthead', 'w-normal03-tiltheadB', 'w-normal07-tiltheadB'], desc: '想事情（手托下巴、抱臂歪头）' },
  glad:      { bodies: ['w-normal01-glad', 'w-adult12-glad'], desc: '开心（很克制）' },
  cheer:     { bodies: ['w-normal01-guts', 'w-cool02-guts'], desc: '握拳（“好，上吧”）' },
  thumb:     { bodies: ['w-cool01-thumb', 'w-cool02-thumb'], desc: '竖大拇指（“不错”）' },
  resolve:   { bodies: ['w-normal01-purpose', 'w-happy02-purpose'], desc: '握住手、下定决心' },
  warm:      { bodies: ['w-normal03-relief', 'w-normal04-relief', 'w-adult12-relief'], desc: '手按在胸口（安心、被打动）' },
  shy:       { bodies: ['w-normal03-blushed', 'w-normal04-blushed', 'w-normal15-shy'], desc: '不好意思地缩一下' },
  fidget:    { bodies: ['w-normal17-fidget'], desc: '手指动来动去，有点不自在' },
  greet:     { bodies: ['w-normal15-greeting'], desc: '打招呼、轻轻点一下头' },
  look_down: { bodies: ['w-normal07-sad', 'w-normal08-sad', 'w-cool16-sad', 'w-happy16-sad'], desc: '垂下视线（低落）' },
  sigh:      { bodies: ['w-cool13-sigh', 'w-normal07-sigh', 'w-happy09-sigh'], desc: '叹气' },
  trouble:   { bodies: ['w-normal03-trouble', 'w-normal04-trouble', 'w-adult05-trouble'], desc: '为难、担心' },
  shake:     { bodies: ['w-cool13-shakehead', 'w-normal16-shakehead', 'w-noromal16-shakehead', 'w-normal15-shakehead', 'w-normal03-shakehead', 'w-normal07-shakehead', 'w-normal17-shakehead'], desc: '摇头' },
  look_away: { bodies: ['w-normal15-lookaround', 'w-normal03-lookleft', 'w-normal03-lookright'], desc: '移开视线、别过脸去' },
  arms:      { bodies: ['w-cool13-sigh', 'w-cool13-shakehead', 'w-cool13-nod'], desc: '抱起胳膊' },
  hip:       { bodies: ['w-happy14-nod', 'w-happy14-tilthead', 'w-happy14-shakehead'], desc: '叉着腰（“真拿你没办法”“……还行吧”）' },
  angry:     { bodies: ['w-normal16-angry', 'w-noromal16-angry', 'w-happy09-angry'], desc: '生气' },
  music:     { bodies: ['w-normal16-nod', 'w-happy16-nod', 'w-normal15-nod', 'w-cool13-nod'], desc: '跟着节奏轻轻点头（听歌、弹琴时）' },
  sleep:     { bodies: ['w-adult15-sleep'], desc: '打瞌睡' },
};

// AI 直接点名表情代号时的强度
window.FACE_STRENGTH_DEFAULT = 0.85;
// 脸上的阴影一律不加
window.SHADOW_FACES = new Set([]);
window.FACE_STRENGTH_FULL = new Set(['平常', '平常2', '平静', '闭眼', '困', '眨眼']);

window.LINES = {
  // 没接聊天模型时，凌晨一点和纪念日用的固定台词
  nightcord: [{ t: '……已经一点了。{name}，还不睡？明天起不来我可不管。', ja: '……もう一時だよ。{name}、まだ寝ないの？明日起きられなくても知らないから。', m: 'worried', a: 'arms' }],
  birthdayShiho: [{ t: '……今天是我生日。你记得啊。……嗯，谢了。', ja: '……今日、私の誕生日。覚えてたんだ。……ん、ありがと。', m: 'shy', a: 'look_away' }],
  birthdayUser: [{ t: '{name}，生日快乐。……就这样。没什么好害羞的吧。', ja: '{name}、誕生日おめでとう。……それだけ。別に照れることじゃないでしょ。', m: 'shy', a: 'look_away' }],
  anniversary: [{ t: '今天是纪念日。……我没忘，别那样看我。', ja: '今日、記念日でしょ。……忘れてないよ。そんな顔で見ないで。', m: 'shy', a: 'arms' }],
  // 你用合成器弹贝斯给她听
  synthListen: [
    { t: '……嗯，在听。', ja: '……ん、聴いてる。', m: 'calm', a: 'music' },
    { t: '节奏还算稳。……这里的经过音，挺好的。', ja: 'リズムは安定してる。……ここの経過音、悪くないね。', m: 'smile', a: 'nod' },
    { t: '第三小节有点赶拍。……再来一遍。', ja: '三小節目、ちょっと走ってる。……もう一回。', m: 'determined', a: 'arms' },
    { t: '是你写的？……不错。', ja: 'あんたが作ったの？……悪くないじゃん。', m: 'proud', a: 'thumb' },
  ],
  outfitCasual: [
    { t: '换好了。……这样轻松多了。', ja: '着替えた。……こっちのほうが楽。', m: 'calm', a: 'nod' },
    { t: '今天辛苦了。……你也早点休息。', ja: '今日もお疲れ。……あんたも早めに休みなよ。', m: 'smile', a: 'arms' },
    { t: '回来了。……先练一会儿琴。', ja: 'ただいま。……まずはちょっと練習。', m: 'determined', a: 'resolve' },
  ],
  outfitUniform: [
    { t: '该去学校了。……走吧。', ja: 'そろそろ学校。……行こ。', m: 'calm', a: 'nod' },
    { t: '制服换好了。……别迟到。', ja: '制服、着た。……遅刻しないでよ。', m: 'calm', a: 'arms' },
  ],
  outfitUnit: [
    { t: '今天练习。……我去和大家会合了。', ja: '今日は練習。……みんなと合流してくる。', m: 'determined', a: 'resolve' },
    { t: '换上演出服了。……今天也不会出错。', ja: 'ステージ衣装、着た。……今日もミスはしない。', m: 'determined', a: 'cheer' },
  ],
  greet: {
    morning: [
      { t: '早。……睡得还行？', ja: 'おはよ。……ちゃんと寝た？', m: 'calm', a: 'greet' },
      { t: '早上好。……早饭吃了没？', ja: 'おはよう。……朝ごはん食べた？', m: 'calm', a: 'tilt' },
    ],
    day: [
      { t: '……来了啊，{name}。', ja: '……来たんだ、{name}。', m: 'smile', a: 'nod' },
      { t: '{name}。……正好，有点想见你。', ja: '{name}。……ちょうど、会いたいと思ってた。', m: 'shy', a: 'look_away' },
    ],
    evening: [
      { t: '回来了。今天怎么样？', ja: 'おかえり。今日はどうだった？', m: 'calm', a: 'tilt' },
      { t: '辛苦了，{name}。……我等你半天了。', ja: 'お疲れ、{name}。……結構待ってたんだけど。', m: 'shy', a: 'arms' },
    ],
    night: [
      { t: '这么晚了。……{name}也还没睡？', ja: 'こんな時間。……{name}もまだ起きてたの？', m: 'worried', a: 'tilt' },
      { t: '晚上好。……聊一会儿就去睡。', ja: 'こんばんは。……少し話したら、寝なよ。', m: 'calm', a: 'nod' },
    ],
  },

  // 点头部
  head: [
    { t: '……干什么。别摸头。', ja: '……何。頭、撫でないで。', m: 'shy', a: 'look_away' },
    { t: '……不、不讨厌就是了。', ja: '……べ、別に嫌じゃないけど。', m: 'flustered', a: 'shy' },
    { t: '……嗯。就一会儿。', ja: '……ん。少しだけなら。', m: 'warm', a: 'warm' },
    { t: '把我当小孩子吗。……真是的。', ja: '子ども扱いしないで。……まったく。', m: 'sulky', a: 'arms' },
  ],

  // 点身体
  body: [
    { t: '……什么事？', ja: '……何？', m: 'calm', a: 'tilt' },
    { t: '嗯，在听。', ja: 'ん、聞いてる。', m: 'calm', a: 'nod' },
    { t: '{name}，今天怎么样。', ja: '{name}、今日はどうだった？', m: 'calm', a: 'tilt' },
    { t: '在忙的话，我不吵你。', ja: '忙しいなら、邪魔しない。', m: 'calm', a: 'arms' },
    { t: '有烦心事就说。……我听着。', ja: '悩んでるなら言いなよ。……聞くから。', m: 'worried', a: 'arms' },
    { t: '最近在练一段新的贝斯线。……练好了给你听。', ja: '最近、新しいベースライン練習してる。……弾けるようになったら聴かせる。', m: 'determined', a: 'resolve' },
    { t: '琴弦该换了。……这周末去乐器店吧。', ja: 'そろそろ弦、替えなきゃ。……今週末、楽器屋行こうかな。', m: 'think', a: 'think' },
    { t: '和{name}在一起的时候……不用想太多。挺好的。', ja: '{name}といると……あんまり考えすぎなくていい。悪くない。', m: 'warm', a: 'look_away' },
    { t: '累了就休息。别逞强。', ja: '疲れたら休みなよ。無理しないで。', m: 'worried', a: 'nod' },
    { t: '……再待一会儿也行。我又没说要走。', ja: '……もう少しいてもいいよ。別に、帰るなんて言ってないし。', m: 'shy', a: 'look_away' },
    { t: '{name}，饭吃了没？……别糊弄我。', ja: '{name}、ご飯食べた？……ごまかさないでよ。', m: 'worried', a: 'hip' },
    { t: '姐姐又在节目上出糗了……算了，她开心就好。', ja: 'お姉ちゃん、また番組でやらかしてた……まあ、楽しそうならいいけど。', m: 'troubled', a: 'sigh' },
  ],

  // 连续点很多下（越点越不高兴）
  poke: [
    { t: '……你在干什么？', ja: '……何してんの？', m: 'annoyed', a: 'arms' },
    { t: '别戳了。……很痒。', ja: 'つつかないで。……くすぐったい。', m: 'flustered', a: 'shake' },
  ],
  pokeAngry: [
    { t: '……{name}。我说了别戳了。', ja: '……{name}。やめてって言ってるでしょ。', m: 'angry', a: 'angry' },
    { t: '再戳我就真的生气了。', ja: 'これ以上やったら、本気で怒るから。', m: 'angry', a: 'arms' },
  ],
  // 生气时偶尔苦笑着数落你
  pokeMask: [
    { t: '……你是小学生吗。', ja: '……小学生なの？', m: 'annoyed', a: 'sigh' },
    { t: '……好了好了，知道你闲了。', ja: '……はいはい、暇なのはわかったから。', m: 'troubled', a: 'hip' },
  ],
  // 刚生过气时摸她
  stillSulky: [
    { t: '……现在不想理你。', ja: '……今は知らない。', m: 'sulky', a: 'look_away' },
    { t: '……等会儿再说。', ja: '……あとにして。', m: 'sulky', a: 'arms' },
  ],

  // 拖动后放下
  drop: [
    { t: '这里？……行。', ja: 'ここ？……いいけど。', m: 'calm', a: 'nod' },
    { t: '……别突然拎起来。吓一跳。', ja: '……急に持ち上げないで。びっくりする。', m: 'surprised', a: 'shake' },
  ],

  // 待机时的自言自语：按时段、衣服挑；同一句近期不会重复（见 renderer.js 的 nextIdleLine）
  // when: morning 5–11 / day 11–17 / evening 17–23 / night 23–5；不写就是什么时候都行
  // outfit: uniform 校服 / unit 队服 / casual 常服；不写就是都行
  idle: [
    { t: '……', ja: '', m: 'calm', a: 'look_away' },
    { t: '副歌那里的贝斯线……再动一点会不会更好。', ja: 'サビのベースライン……もう少し動かしたほうがいいかな。', m: 'think', a: 'think' },
    { t: '你忙你的。我在这儿。', ja: 'あんたはあんたのことしてて。私はここにいるから。', m: 'calm', a: 'arms' },
    { t: '一歌又练到很晚了吧。……我也不能输。', ja: '一歌、また遅くまで練習してるんだろうな。……私も負けてられない。', m: 'determined', a: 'resolve' },
    { t: '咲希说想去游乐园……我陪着就是了。', ja: '咲希が遊園地行きたいって……まあ、付き合ってあげてもいいけど。', m: 'troubled', a: 'sigh' },
    { t: '穗波的点心……太甜了。……不过还是吃完了。', ja: '穂波のお菓子……甘すぎ。……まあ、全部食べたけど。', m: 'shy', a: 'look_away' },
    { t: '……这样安静地待着，不坏。', ja: '……こうして静かにしてるの、悪くない。', m: 'warm', a: 'none' },
    { t: '节拍器开到 180……还差一点。', ja: 'メトロノーム180……あと少し。', m: 'determined', a: 'cheer' },
    { t: '姐姐又发消息问我吃没吃饭。……我又不是小孩。', ja: 'お姉ちゃん、またご飯食べたかってメッセージ送ってきた。……子どもじゃないんだけど。', m: 'annoyed', a: 'sigh' },
    { t: '……刚才在想什么来着。', ja: '……さっき何考えてたんだっけ。', m: 'think', a: 'look_away' },
    { t: '不说话也没关系。……我也不太爱说话。', ja: '話さなくてもいいよ。……私もあんまり喋るほうじゃないし。', m: 'calm', a: 'nod' },
    { t: '一直盯着屏幕，眼睛会坏的。', ja: '画面ばっかり見てると、目、悪くするよ。', m: 'worried', a: 'arms' },
    { t: '……你刚才叹气了吧。', ja: '……今、ため息ついたでしょ。', m: 'worried', a: 'tilt' },
    { t: '早上……还有点困。', ja: '朝は……まだちょっと眠い。', m: 'sleepy', a: 'tilt', when: 'morning' },
    { t: '早饭吃了没？……别不吃。', ja: '朝ごはん食べた？……抜くのはやめなよ。', m: 'worried', a: 'hip', when: 'morning' },
    { t: '午休了。……去天台吹吹风吧。', ja: '昼休み。……屋上で風にでも当たろうかな。', m: 'calm', a: 'look_away', when: 'day', outfit: 'uniform' },
    { t: '下午的课……好困。', ja: '午後の授業……眠い。', m: 'sleepy', a: 'sigh', when: 'day' },
    { t: '练习结束。……今天的节奏，大家都对上了。', ja: '練習終わり。……今日はみんなのリズム、ちゃんと合ってた。', m: 'smile', a: 'thumb', when: 'day', outfit: 'unit' },
    { t: '演出服……还是有点不习惯。', ja: 'ステージ衣装……まだちょっと慣れない。', m: 'awkward', a: 'look_away', outfit: 'unit' },
    { t: '放学了。……回去练琴。', ja: '放課後。……帰って練習。', m: 'determined', a: 'nod', when: 'evening', outfit: 'casual' },
    { t: '天黑得真早。', ja: '暗くなるの、早くなったね。', m: 'calm', a: 'look_away', when: 'evening' },
    { t: '晚饭……{name}吃什么？', ja: '晩ごはん……{name}は何食べるの？', m: 'calm', a: 'tilt', when: 'evening' },
    { t: '……已经这么晚了。还不睡？', ja: '……もうこんな時間。まだ寝ないの？', m: 'worried', a: 'arms', when: 'night' },
    { t: '夜里安静。……戴着耳机练，正好。', ja: '夜は静か。……ヘッドホンで練習するには、ちょうどいい。', m: 'calm', a: 'think', when: 'night' },
    { t: '明天还要早起吧。……别熬了。', ja: '明日も早いんでしょ。……夜更かしやめなよ。', m: 'worried', a: 'nod', when: 'night' },
    { t: '……这身衣服，挺舒服。', ja: '……この服、楽でいい。', m: 'calm', a: 'none', outfit: 'casual' },
    { t: '制服的领巾……歪了吗？……没有吧。', ja: '制服のスカーフ……曲がってる？……ないよね。', m: 'awkward', a: 'look_away', outfit: 'uniform' },
  ],

  water: [
    { t: '{name}，喝水。……现在就去。', ja: '{name}、水飲んで。……今すぐ。', m: 'calm', a: 'arms' },
    { t: '好久没喝水了吧。……去倒一杯。', ja: 'しばらく水飲んでないでしょ。……一杯ついできなよ。', m: 'worried', a: 'hip' },
  ],

  rest: [
    { t: '看屏幕太久了。站起来活动一下。', ja: '画面見すぎ。立って体動かしなよ。', m: 'worried', a: 'arms' },
    { t: '休息五分钟。……我等你。', ja: '五分休憩。……待ってるから。', m: 'calm', a: 'nod' },
  ],

  sleep: [
    { t: '很晚了。……{name}，去睡。', ja: 'もう遅い。……{name}、寝なよ。', m: 'worried', a: 'sigh' },
    { t: '熬夜伤身体。……我是认真的。', ja: '夜更かしは体に悪い。……本気で言ってるから。', m: 'worried', a: 'arms' },
    { t: '剩下的明天再说。……晚安，{name}。', ja: '続きはまた明日。……おやすみ、{name}。', m: 'sleepy', a: 'sleep' },
  ],

  doze: [{ t: '……有点困。', ja: '……ちょっと、眠い。', m: 'sleepy', a: 'sleep' }],
  wake: [{ t: '……啊。{name}，回来了啊。', ja: '……あ。{name}、おかえり。', m: 'surprised', a: 'tilt' }],

  // 聊天时没接 API
  noApi: [{ t: '……还没连上。右键 → 设置，把 API 填好。', m: 'calm', a: 'tilt' }],
  apiError: [{ t: '……没听清。再说一遍。', ja: '……聞こえなかった。もう一回言って。', m: 'calm', a: 'tilt' }],
};

// 平时站着的姿势和表情（双手自然垂下）
window.IDLE = { b: 'w-normal16-pose', f: '平常' };

// 站姿：每个身体动作开始和结束时更接近哪种站姿（按手臂、手、腿的参数算出来的）。
// 桌宠据此挑动作：同一站姿的版本优先；动作做完就停在它结束时的站姿上，不会突然跳回别的姿势。
window.HOME_STANCE = 'w-normal16';
window.MOTION_STANCE = {
  'w-adult05-think': ['w-adult05', 'w-adult05'],
  'w-adult05-trouble': ['w-adult05', 'w-adult05'],
  'w-adult12-glad': ['w-adult12', 'w-adult12'],
  'w-adult12-relief': ['w-adult12', 'w-adult12'],
  'w-adult15-sleep': ['w-cool16', 'w-cool16'],
  'w-cool01-thumb': ['w-happy02', 'w-cute02'],
  'w-cool02-guts': ['w-happy02', 'w-cute02'],
  'w-cool02-thumb': ['w-normal01', 'w-cute01'],
  'w-cool13-nod': ['w-cool13', 'w-cool13'],
  'w-cool13-shakehead': ['w-cool13', 'w-cool13'],
  'w-cool13-sigh': ['w-cool13', 'w-cool13'],
  'w-cool13-tilthead': ['w-cool13', 'w-cool13'],
  'w-cool16-sad': ['w-cool16', 'w-cool16'],
  'w-cute11-glad': ['w-cute11', 'w-cute11'],
  'w-happy02-purpose': ['w-happy02', 'w-happy02'],
  'w-happy09-angry': ['w-cool09', 'w-cool09'],
  'w-happy09-sigh': ['w-cool09', 'w-cool09'],
  'w-happy11-guts': ['w-happy11', 'w-happy11'],
  'w-happy16-nod': ['w-normal16', 'w-normal16'],
  'w-happy16-sad': ['w-normal16', 'w-normal16'],
  'w-happy16-tilthead': ['w-normal16', 'w-normal16'],
  'w-normal01-glad': ['w-normal15', 'w-normal15'],
  'w-normal01-guts': ['w-normal15', 'w-normal15'],
  'w-normal01-purpose': ['w-normal15', 'w-normal07'],
  'w-normal03-blushed': ['w-normal03', 'w-normal03'],
  'w-normal03-lookleft': ['w-normal03', 'w-normal03'],
  'w-normal03-lookright': ['w-normal03', 'w-normal03'],
  'w-normal03-nod': ['w-normal03', 'w-normal03'],
  'w-normal03-relief': ['w-normal03', 'w-normal03'],
  'w-normal03-shakehead': ['w-normal03', 'w-normal03'],
  'w-normal03-tilthead': ['w-normal03', 'w-normal03'],
  'w-normal03-tiltheadB': ['w-normal03', 'w-normal03'],
  'w-normal03-trouble': ['w-normal03', 'w-normal03'],
  'w-normal0316-tilthead': ['w-normal03', 'w-normal16'],
  'w-normal04-blushed': ['w-normal04', 'w-normal04'],
  'w-normal04-relief': ['w-normal04', 'w-normal04'],
  'w-normal04-trouble': ['w-normal04', 'w-normal04'],
  'w-normal07-nod': ['w-normal07', 'w-normal07'],
  'w-normal07-sad': ['w-normal07', 'w-normal07'],
  'w-normal07-shakehead': ['w-normal07', 'w-normal07'],
  'w-normal07-sigh': ['w-normal07', 'w-normal07'],
  'w-normal07-tilthead': ['w-normal07', 'w-normal07'],
  'w-normal07-tiltheadB': ['w-normal07', 'w-normal07'],
  'w-normal08-sad': ['w-normal08', 'w-normal08'],
  'w-normal15-greeting': ['w-normal15', 'w-normal15'],
  'w-normal15-lookaround': ['w-normal15', 'w-normal15'],
  'w-normal15-nod': ['w-normal15', 'w-normal15'],
  'w-normal15-shakehead': ['w-normal15', 'w-normal15'],
  'w-normal15-shy': ['w-normal15', 'w-normal15'],
  'w-normal15-tilthead': ['w-normal15', 'w-normal15'],
  'w-normal1503-tilthead': ['w-normal15', 'w-normal16'],
  'w-normal16-angry': ['w-normal16', 'w-normal16'],
  'w-normal16-nod': ['w-normal16', 'w-normal16'],
  'w-normal16-shakehead': ['w-normal16', 'w-normal16'],
  'w-normal16-tilthead': ['w-normal16', 'w-normal16'],
  'w-normal1603-tilthead': ['w-normal16', 'w-normal03'],
  'w-normal1605-tilthead': ['w-normal16', 'w-normal15'],
  'w-normal17-fidget': ['w-normal17', 'w-normal17'],
  'w-normal17-nod': ['w-normal17', 'w-normal17'],
  'w-normal17-shakehead': ['w-normal17', 'w-normal17'],
  'w-normal17-tilthead': ['w-normal17', 'w-normal17'],
  'w-noromal16-angry': ['w-normal16', 'w-normal16'],
  'w-noromal16-nod': ['w-normal16', 'w-normal16'],
  'w-noromal16-shakehead': ['w-normal16', 'w-normal16'],
  'w-noromal16-tilthead': ['w-normal16', 'w-normal16'],
  'w-pure12-fidget': ['w-pure12', 'w-pure12'],
  'w-pure12-shy': ['w-pure12', 'w-pure12'],
};

// 待机小动作（不说话）：按现在的站姿挑。包括几个“换站姿”的动作，让她偶尔自然地换一下姿势。
window.IDLE_MOVES = {
  'w-normal16': ['w-normal16-tilthead', 'w-noromal16-tilthead', 'w-happy16-tilthead', 'w-normal1603-tilthead', 'w-normal1605-tilthead'],
  'w-normal03': ['w-normal03-tilthead', 'w-normal03-lookleft', 'w-normal03-lookright', 'w-normal0316-tilthead'],
  'w-normal15': ['w-normal15-tilthead', 'w-normal15-lookaround', 'w-normal1503-tilthead'],
  'w-normal07': ['w-normal07-tilthead', 'w-normal07-nod'],
  'w-normal17': ['w-normal17-tilthead'],
  'w-cool13': ['w-cool13-nod', 'w-cool13-sigh'],   // 抱着胳膊站着（志步常有的样子）
};
