'use strict';
/* 简谱 / 四线谱解析 + 贝斯音色合成（“和弦：”那一行用干净的电吉他伴奏）
   简谱写法：
     1–7 音，0 休止，- 把前一个音延长一拍
     后面加 ' 高八度（可以叠加 1''），加 , 低八度（5,,）
     前面加 # 升半音，b 降半音
     后面加 _ 时值减半（1_ 半拍，1__ 四分之一拍），加 . 附点（×1.5）
     后面加 ~ 揉弦，加 ^ 推弦（从低一个全音推到这个音）
     简谱的 1 是这个调在贝斯上最低的那个主音：1=E 时是空弦 E1，1=C 时是 C2，1=G 时是 G1
     [15] 几根弦一起弹（双音），后面同样可以加 _ . -
     | 小节线（只是看着方便，不影响播放）
     开头写 1=C、1=bE、1=F#、4/4、♩=90（也可以写 速度=90 或 bpm=90）、音色=指弹 / 拨片 / 击弦 / 过载
     另起一行写「和弦：| C | G | Am F |」：按小节配和弦，自动加一把干净的电吉他伴奏（分解 / 扫弦）
     // 后面是注释
   四线谱写法（标准 ASCII 贝斯谱，四行一组，从上到下是 1 弦（G）到 4 弦（低音 E））：
     G|---------|
     D|-----2---|
     A|---3-----|
     E|-0-------|
     每一格（一个字符）默认是 1/4 拍，可以在开头写 每格=1/2拍；| 是小节线
     数字是品位，x 闷音；技巧：5h7 击弦、7p5 勾弦、5b7 推弦、7r5 放弦、5/7 7\5 滑音、7~ 揉弦
     开头也可以写 ♩=120、4/4、音色=拨片
*/
(function (root) {
  const KEYS = { C: 0, D: 2, E: 4, F: 5, G: 7, A: 9, B: 11 };
  const DEG = [0, 0, 2, 4, 5, 7, 9, 11];   // 1–7 在大调里离主音几个半音
  const TUNING = [43, 38, 33, 28];          // 贝斯：1 弦（G）… 4 弦（低音 E）
  const STRING_NAMES = ['G', 'D', 'A', 'E'];
  const NS = 4;                             // 弦数
  const GTR = [64, 59, 55, 50, 45, 40];     // 伴奏的电吉他：1 弦（高音 e）… 6 弦（低音 E）
  const LOW = 28, HIGH = 67;                // 贝斯（24 品）能弹的范围：E1–G4
  const TONES = { finger: '指弹', pick: '拨片', slap: '击弦', drive: '过载' };
  const TONE_ALIAS = { 指弹: 'finger', 手指: 'finger', finger: 'finger', 拨片: 'pick', 匹克: 'pick', pick: 'pick', 击弦: 'slap', 击勾: 'slap', slap: 'slap', 过载: 'drive', 失真: 'drive', drive: 'drive', overdrive: 'drive' };

  // 全角符号、中文标点换成半角（一个字符换一个字符，位置不变，方便高亮）
  function normalize(s) {
    return String(s).replace(/[’‘＇′`´]/g, "'").replace(/[，、]/g, ',').replace(/[｜]/g, '|')
      .replace(/[—－–]/g, '-').replace(/[＿]/g, '_').replace(/[＃♯]/g, '#').replace(/[♭]/g, 'b')
      .replace(/[．·•]/g, '.').replace(/[［【]/g, '[').replace(/[］】]/g, ']').replace(/＝/g, '=')
      .replace(/[～〜]/g, '~').replace(/[＾]/g, '^').replace(/[／]/g, '/').replace(/[＼]/g, '\\')
      .replace(/[０-９]/g, (c) => String.fromCharCode(c.charCodeAt(0) - 0xfee0));
  }
  const blank = (m) => m.replace(/[^\n]/g, ' ');

  /* ---------- 头部信息：速度、拍号、调、音色 ---------- */
  function readHeader(body, o) {
    body = body.replace(/\/\/[^\n]*/g, blank);
    body = body.replace(/(?:音色|tone)\s*[=:：]\s*([一-龥A-Za-z]+)/g, (m, v) => { if (TONE_ALIAS[v]) o.tone = TONE_ALIAS[v]; else o.badTone = v; return blank(m); });
    body = body.replace(/(?:变调夹|capo)\s*[=:：]\s*(\d{1,2})/gi, (m, v) => { o.capo = Math.max(0, Math.min(12, +v)); return blank(m); });
    body = body.replace(/(?:每格|grid)\s*[=:：]\s*(\d+(?:\.\d+)?)(?:\s*\/\s*(\d+))?\s*拍?/g, (m, a, b) => { const v = b ? +a / +b : +a; if (v > 0 && v <= 2) o.unit = v; return blank(m); });
    body = body.replace(/1\s*=\s*([#b]?)([A-Ga-g])([#b]?)/g, (m, a1, k, a2) => {
      const acc = (a1 || a2) === '#' ? 1 : (a1 || a2) === 'b' ? -1 : 0;
      o.tonic = 24 + KEYS[k.toUpperCase()] + acc;
      while (o.tonic < 28) o.tonic += 12;              // 1 是这个调在贝斯上最低的那个主音（1=E 是空弦 E1，1=C 是 C2）
      o.key = (acc === 1 ? '#' : acc === -1 ? 'b' : '') + k.toUpperCase();
      return blank(m);
    });
    body = body.replace(/(?:♩|bpm|BPM|速度|拍速)\s*[=:：]?\s*(\d{2,3})/g, (m, n) => { o.bpm = Math.max(30, Math.min(240, +n)); return blank(m); });
    body = body.replace(/(\d)\s*\/\s*(\d)(?!\s*拍)/g, (m, a) => { o.beats = +a || 4; return blank(m); });
    return body;
  }

  /* ---------- 和弦 ---------- */
  const QUALITY = {
    '': [0, 4, 7], m: [0, 3, 7], '7': [0, 4, 7, 10], maj7: [0, 4, 7, 11], M7: [0, 4, 7, 11], m7: [0, 3, 7, 10],
    sus4: [0, 5, 7], sus2: [0, 2, 7], add9: [0, 4, 7, 14], '5': [0, 7, 12], dim: [0, 3, 6], aug: [0, 4, 8],
    '6': [0, 4, 7, 9], m6: [0, 3, 7, 9], '9': [0, 4, 7, 10, 14], madd9: [0, 3, 7, 14], '7sus4': [0, 5, 7, 10],
  };
  // 按把位的指型（6 弦 → 1 弦，null 是不弹）：E 型（根音在 6 弦）、A 型（根音在 5 弦）
  const SHAPE_E = { '': [0, 2, 2, 1, 0, 0], m: [0, 2, 2, 0, 0, 0], '7': [0, 2, 0, 1, 0, 0], maj7: [0, 2, 1, 1, 0, 0], m7: [0, 2, 0, 0, 0, 0],
    sus4: [0, 2, 2, 2, 0, 0], sus2: [0, 2, 4, 4, 0, 0], add9: [0, 2, 2, 1, 0, 2], '5': [0, 2, 2, null, null, null], '7sus4': [0, 2, 0, 2, 0, 0], m6: [0, 2, 2, 0, 2, 0], '6': [0, 2, 2, 1, 2, 0] };
  const SHAPE_A = { '': [null, 0, 2, 2, 2, 0], m: [null, 0, 2, 2, 1, 0], '7': [null, 0, 2, 0, 2, 0], maj7: [null, 0, 2, 1, 2, 0], m7: [null, 0, 2, 0, 1, 0],
    sus4: [null, 0, 2, 2, 3, 0], sus2: [null, 0, 2, 2, 0, 0], add9: [null, 0, 2, 4, 2, 0], '5': [null, 0, 2, 2, null, null], '7sus4': [null, 0, 2, 0, 3, 0], m6: [null, 0, 2, 2, 1, 2], '6': [null, 0, 2, 2, 2, 2], madd9: [null, 0, 2, 4, 1, 0] };
  // 常用的开放和弦（听起来更像吉他）
  const OPEN = { C: [null, 3, 2, 0, 1, 0], Cmaj7: [null, 3, 2, 0, 0, 0], Cadd9: [null, 3, 2, 0, 3, 0], C7: [null, 3, 2, 3, 1, 0], D: [null, null, 0, 2, 3, 2], Dm: [null, null, 0, 2, 3, 1],
    D7: [null, null, 0, 2, 1, 2], Dsus4: [null, null, 0, 2, 3, 3], Dsus2: [null, null, 0, 2, 3, 0], Dmaj7: [null, null, 0, 2, 2, 2], Dm7: [null, null, 0, 2, 1, 1],
    G: [3, 2, 0, 0, 0, 3], G7: [3, 2, 0, 0, 0, 1], Gadd9: [3, 0, 0, 0, 0, 3], Fmaj7: [null, null, 3, 2, 1, 0] };

  function parseChord(name) {
    const m = /^([A-G])([#b]?)(maj7|M7|madd9|m7|m6|m|7sus4|7|sus4|sus2|add9|dim|aug|5|6|9)?(?:\/([A-G])([#b]?))?$/.exec(name);
    if (!m) return null;
    const pc = (KEYS[m[1]] + (m[2] === '#' ? 1 : m[2] === 'b' ? -1 : 0) + 12) % 12;
    const q = m[3] || '';
    const bass = m[4] ? (KEYS[m[4]] + (m[5] === '#' ? 1 : m[5] === 'b' ? -1 : 0) + 12) % 12 : null;
    return { name, pc, q: q === 'M7' ? 'maj7' : q, bass };
  }
  // 一个和弦 → 每根弦弹第几品（6 弦 → 1 弦）
  function voicing(ch, power) {
    if (power) {
      const f6 = (ch.pc - 4 + 12) % 12, f5 = (ch.pc - 9 + 12) % 12;
      return f6 <= f5 ? [f6, f6 + 2, f6 + 2, null, null, null] : [null, f5, f5 + 2, f5 + 2, null, null];
    }
    const flat = ch.name.replace(/\/.*$/, '');
    let v = OPEN[flat] ? OPEN[flat].slice() : null;
    if (!v) {
      const f6 = (ch.pc - 4 + 12) % 12, f5 = (ch.pc - 9 + 12) % 12;
      const useE = SHAPE_E[ch.q] && (!SHAPE_A[ch.q] || f6 <= f5);
      const shape = useE ? SHAPE_E[ch.q] : SHAPE_A[ch.q];
      if (shape) v = shape.map((x) => (x === null ? null : x + (useE ? f6 : f5)));
      else {
        // 不常见的和弦：根音放在 6 弦 / 5 弦，其他弦在附近找和弦里的音
        const base = Math.min(f6, f5), rs = f6 <= f5 ? 0 : 1;
        const pcs = new Set((QUALITY[ch.q] || QUALITY['']).map((x) => (ch.pc + x) % 12));
        v = [null, null, null, null, null, null];
        v[rs] = base;
        for (let s = rs + 1; s < 6; s++) {
          const open = GTR[5 - s];
          for (let f = Math.max(0, base - 1); f <= base + 3; f++) if (pcs.has((open + f) % 12)) { v[s] = f; break; }
        }
      }
    }
    if (ch.bass !== null) {
      // 转位：最低的弦换成指定的低音
      const f6 = (ch.bass - 4 + 12) % 12, f5 = (ch.bass - 9 + 12) % 12;
      if (f6 <= 5) { v[0] = f6; } else { v[0] = null; v[1] = f5; }
    }
    return v;
  }
  const voicingMidi = (v, capo = 0) => v.map((f, i) => (f === null ? null : GTR[5 - i] + f + capo)).filter((x) => x !== null);

  // 「和弦：| C | G | Am F |」→ [{t, dur, name, chord}]
  function parseChordLine(line, beats, startPos) {
    const out = [];
    let err = null;
    const parts = line.split('|');
    let bar = 0, pos = startPos;
    let prev = null;
    for (let k = 0; k < parts.length; k++) {
      const seg = parts[k];
      const toks = seg.trim().split(/\s+/).filter(Boolean);
      if (!toks.length) { pos += seg.length + 1; continue; }
      const each = beats / toks.length;
      toks.forEach((tk, j) => {
        let ch;
        if (tk === '%' || tk === '-') ch = prev;
        else if (/^(N\.?C\.?|0|x)$/i.test(tk)) ch = null;
        else { ch = parseChord(tk); if (!ch && !err) err = `看不懂和弦“${tk}”（可以写 C、Am、G7、Fmaj7、Dsus4、E5、C/G 这样的）`; }
        if (ch) out.push({ t: bar * beats + j * each, dur: each, name: ch.name, chord: ch });
        prev = ch || prev;
      });
      bar++;
      pos += seg.length + 1;
    }
    // 连续同一个和弦合并
    const merged = [];
    for (const c of out) {
      const last = merged[merged.length - 1];
      if (last && last.name === c.name && Math.abs(last.t + last.dur - c.t) < 1e-6) last.dur += c.dur;
      else merged.push({ ...c });
    }
    return { chords: merged, bars: bar, error: err };
  }

  /* ---------- 简谱 ---------- */
  function parseJianpu(raw) {
    const o = { bpm: 90, tonic: 36, key: 'C', beats: 4, tone: 'finger', capo: 0, unit: 0.25 };
    let body = raw;
    // 和弦行先拿出来（位置换成空格）
    const chordLines = [];
    body = body.replace(/^[ \t]*(?:和弦|chords?)\s*[:：]([^\n]*)/gim, (m, rest, offset) => { chordLines.push({ text: rest, pos: offset + m.length - rest.length }); return blank(m); });
    body = readHeader(body, o);
    const notes = [];
    let t = 0, last = null;
    const bars = [];
    const done = (error) => {
      const sc = { mode: 'jianpu', notes, bpm: o.bpm, key: o.key, tonic: o.tonic, beats: o.beats, bars, total: t, tone: o.tone, capo: 0, chords: [], error: error || null };
      return sc;
    };
    const err = (msg, pos) => done({ msg, pos });
    if (o.badTone) return err(`音色只能写 指弹、拨片、击弦 或 过载（写的是“${o.badTone}”）`, raw.indexOf(o.badTone));

    let i = 0;
    const n = body.length;
    while (i < n) {
      const c = body[i];
      if (c === '|') { if (!bars.length || bars[bars.length - 1] !== t) bars.push(t); i++; continue; }
      if (/\s/.test(c)) { i++; continue; }
      if (c === '-') {                           // 延长前一个音
        if (!last) return err('“-” 前面没有音可以延长', i);
        last.dur += 1; t += 1; i++; continue;
      }
      const start = i;
      const pitches = [];
      const readOne = () => {
        let acc = 0;
        while (body[i] === '#' || body[i] === 'b') { acc += body[i] === '#' ? 1 : -1; i++; }
        const d = body[i];
        if (!/[0-7]/.test(d)) return null;
        i++;
        let oct = 0;
        while (body[i] === "'" || body[i] === ',') { oct += body[i] === "'" ? 1 : -1; i++; }
        return d === '0' ? 'rest' : o.tonic + DEG[+d] + acc + oct * 12;
      };
      if (c === '[') {
        i++;
        while (i < n && body[i] !== ']') {
          if (/\s/.test(body[i])) { i++; continue; }
          const p = readOne();
          if (p === null) return err(`和弦里有看不懂的字符“${body[i] || '（结尾）'}”`, i);
          if (p !== 'rest') pitches.push(p);
        }
        if (body[i] !== ']') return err('和弦的 [ 没有配对的 ]', start);
        i++;
      } else {
        const p = readOne();
        if (p === null) return err(`看不懂“${c}”。音只能写 0–7，可以带 # b ' , _ . - ~ ^`, start);
        if (p !== 'rest') pitches.push(p);
      }
      let dur = 1, vib = false, bend = false;
      while ('_.~^'.includes(body[i]) && i < n) {
        const s = body[i];
        if (s === '_') dur *= 0.5; else if (s === '.') dur *= 1.5; else if (s === '~') vib = true; else bend = true;
        i++;
      }
      for (const m of pitches) if (m < LOW || m > HIGH) return err('这个音太高或太低了，贝斯弹不出来（能弹的范围是低音 E1 到 G4，1=E 时是 1 到 3\'\'，1=C 时是 3, 到 5\'\'）', start);
      const note = { t, dur, midi: pitches, src: [start, i] };
      if (vib) note.vib = true;
      if (bend && pitches.length) note.bend = true;
      notes.push(note);
      last = note; t += dur;
    }
    const sc = done(null);
    // 和弦伴奏
    for (const cl of chordLines) {
      const r = parseChordLine(cl.text, o.beats, cl.pos);
      if (r.error) { sc.chordError = r.error; sc.error = { msg: r.error, pos: cl.pos }; break; }
      sc.chords.push(...r.chords);
    }
    if (sc.chords.length) sc.total = Math.max(sc.total, ...sc.chords.map((c) => c.t + c.dur));
    return sc;
  }

  /* ---------- 四线谱 ---------- */
  const TAB_LINE = /^([ \t]*)([GDAEgdae1-4](?:\s*弦)?)[ \t]*\|/;
  const TAB_BODY = /^[-0-9xXhpbr\/\\~|.*()<> \t]*$/;
  function tabLinesOf(raw) {
    const lines = raw.split('\n');
    const info = [];
    let pos = 0;
    for (const l of lines) {
      const m = TAB_LINE.exec(l);
      const bar = m ? l.indexOf('|', m[0].length - 1) : -1;
      const content = m ? l.slice(bar + 1) : '';
      // 四线谱的行几乎全是 -（简谱的行里空格和数字多），这样不会把简谱误认成四线谱
      const dashes = (content.match(/-/g) || []).length, solid = content.replace(/\s/g, '').length;
      info.push({ text: l, pos, tab: !!m && TAB_BODY.test(content) && (!solid || (dashes >= 3 && dashes >= solid * 0.3)), bar, content });
      pos += l.length + 1;
    }
    return info;
  }
  function isTab(text) {
    const info = tabLinesOf(normalize(String(text || '')));
    let run = 0;
    for (const x of info) { run = x.tab ? run + 1 : 0; if (run >= NS) return true; }
    return false;
  }

  function parseTab(raw) {
    const o = { bpm: 90, tonic: 36, key: 'C', beats: 4, tone: 'finger', capo: 0, unit: 0.25 };
    const info = tabLinesOf(raw);
    // 不是四线谱的行当成头部信息读；其中「和弦：」那一行是伴奏
    const chordLines = [];
    for (const x of info) {
      if (x.tab) continue;
      const m = /^[ \t]*(?:和弦|chords?)\s*[:：]([^\n]*)/i.exec(x.text);
      if (m) { chordLines.push({ text: m[1], pos: x.pos + m[0].length - m[1].length }); x.text = ''; }
    }
    readHeader(info.filter((x) => !x.tab).map((x) => x.text).join('\n'), o);
    const events = [], bars = [];
    let t0 = 0;
    const err = (msg, pos) => ({ mode: 'tab', notes: [], events: [], bpm: o.bpm, key: o.key, tonic: o.tonic, beats: o.beats, bars, total: 0, tone: o.tone, capo: o.capo, chords: [], error: { msg, pos } });
    if (o.badTone) return err(`音色只能写 指弹、拨片、击弦 或 过载（写的是“${o.badTone}”）`, raw.indexOf(o.badTone));
    let k = 0;
    let blocks = 0;
    while (k < info.length) {
      if (!info[k].tab) { k++; continue; }
      let e = k;
      while (e < info.length && info[e].tab) e++;
      const n = e - k;
      if (n < NS) { k = e; continue; }
      // 连着超过 4 行时，每 4 行一组
      for (let b = k; b + NS <= e; b += NS) {
        const rows = info.slice(b, b + NS);
        blocks++;
        const width = Math.max(...rows.map((r) => r.content.length));
        // 小节线：这一列大多数弦都是 |
        const isBar = (c) => rows.filter((r) => r.content[c] === '|').length >= 3;
        const timeOf = [];
        let tc = 0;
        for (let c = 0; c < width; c++) { timeOf.push(tc); if (!isBar(c)) tc++; }
        const blockLen = tc * o.unit;
        for (let c = 0; c < width; c++) if (isBar(c) && c > 0) { const bt = t0 + timeOf[c] * o.unit; if (!bars.length || Math.abs(bars[bars.length - 1] - bt) > 1e-6) bars.push(bt); }
        for (let s = 0; s < NS; s++) {
          const r = rows[s], str = r.content, base = r.pos + r.bar + 1;
          let c = 0;
          while (c < str.length) {
            const ch = str[c];
            if (/[0-9]/.test(ch)) {
              let j = c; while (j < str.length && /[0-9]/.test(str[j]) && j - c < 2) j++;
              const fret = +str.slice(c, j);
              if (fret > 24) return err(`${STRING_NAMES[s]} 弦第 ${fret} 品太高了`, base + c);
              const prevCh = str[c - 1];
              const ev = { t: t0 + timeOf[c] * o.unit, midi: TUNING[s] + fret + o.capo, string: s, fret, src: [base + c, base + j] };
              if (prevCh === 'h' || prevCh === 'p') ev.legato = true;
              if (prevCh === '/' || prevCh === '\\') ev.slide = true;
              if (prevCh === 'r') ev.release = true;
              // 推弦：5b7（弹 5 品推到 7 品的音高）
              if (str[j] === 'b' && /[0-9]/.test(str[j + 1] || '')) {
                let q = j + 1; while (q < str.length && /[0-9]/.test(str[q]) && q - j - 1 < 2) q++;
                const to = +str.slice(j + 1, q);
                ev.midi = TUNING[s] + to + o.capo; ev.bendFrom = fret - to; ev.src = [base + c, base + q];
                j = q;
                // 放弦：5b7r5
                if (str[j] === 'r' && /[0-9]/.test(str[j + 1] || '')) {
                  let q2 = j + 1; while (q2 < str.length && /[0-9]/.test(str[q2]) && q2 - j - 1 < 2) q2++;
                  ev.releaseTo = +str.slice(j + 1, q2) - to; ev.src = [base + c, base + q2]; j = q2;
                }
              }
              let v = j; while (str[v] === '~') { ev.vib = true; v++; }
              events.push(ev);
              c = Math.max(j, c + 1);
              continue;
            }
            if (ch === 'x' || ch === 'X') events.push({ t: t0 + timeOf[c] * o.unit, midi: TUNING[s] + o.capo, string: s, fret: 0, mute: true, src: [base + c, base + c + 1] });
            c++;
          }
        }
        t0 += blockLen;
        if (!bars.length || Math.abs(bars[bars.length - 1] - t0) > 1e-6) bars.push(t0);
      }
      k = e;
    }
    if (!blocks) return err('没找到四线谱：四线谱要连着写 4 行，每行以 G| D| A| E| 开头', 0);
    // 时值：一直响到同一根弦上的下一个音（最长 4 拍）；最后一个音响到这一组结束后再多一点
    events.sort((a, b) => a.t - b.t || b.string - a.string);
    for (let s = 0; s < NS; s++) {
      const list = events.filter((x) => x.string === s);
      list.forEach((x, idx) => {
        const next = list[idx + 1];
        x.dur = x.mute ? Math.min(0.25, next ? next.t - x.t : 0.25) : Math.min(4, next ? next.t - x.t : Math.max(o.unit * 2, t0 - x.t + 0.5));
        if (next && (next.legato || next.slide || next.release)) { x.into = true; next.fromMidi = x.midi; }
      });
    }
    // 给“写词”和高亮用：同一时刻的音合成一组
    const notes = [];
    for (const ev of events) {
      if (ev.mute) continue;
      const last = notes[notes.length - 1];
      if (last && Math.abs(last.t - ev.t) < 1e-6) { last.midi.push(ev.midi); last.dur = Math.max(last.dur, ev.dur); }
      else notes.push({ t: ev.t, dur: ev.dur, midi: [ev.midi], src: ev.src });
    }
    // 旋律视角：每组之间不重叠
    for (let i = 0; i < notes.length; i++) if (notes[i + 1]) notes[i].dur = Math.min(notes[i].dur, notes[i + 1].t - notes[i].t);
    const sc = { mode: 'tab', notes, events, bpm: o.bpm, key: o.key, tonic: o.tonic, beats: o.beats, bars, total: t0, tone: o.tone, capo: o.capo, unit: o.unit, chords: [], error: null };
    for (const cl of chordLines) {
      const r = parseChordLine(cl.text, o.beats, cl.pos);
      if (r.error) { sc.chordError = r.error; sc.error = { msg: r.error, pos: cl.pos }; break; }
      sc.chords.push(...r.chords);
    }
    if (sc.chords.length) sc.total = Math.max(sc.total, ...sc.chords.map((c) => c.t + c.dur));
    return sc;
  }

  // 返回 { mode, notes: [{t, dur, midi:[...], src:[start,end]}], events, chords, bpm, key, tonic, beats, bars, total, tone, error }
  // t 和 dur 的单位是拍；src 是这个音在原文里的位置（播放时高亮用）
  function parse(text) {
    const raw = normalize(String(text || ''));
    return isTab(raw) ? parseTab(raw) : parseJianpu(raw);
  }

  /* ---------- 演奏：把谱子变成每根弦上的一个个音（主旋律 + 伴奏） ---------- */
  function performance(score) {
    const lead = [], rhythm = [];
    const spb = 60 / score.bpm;
    const jitter = (ms) => (Math.random() * 2 - 1) * ms / 1000;
    if (score.events && score.events.length) {
      // 四线谱：同一时刻按下的几根弦，稍微错开一点
      const groups = new Map();
      for (const ev of score.events) { const k = ev.t.toFixed(4); if (!groups.has(k)) groups.set(k, []); groups.get(k).push(ev); }
      for (const g of groups.values()) {
        g.sort((a, b) => b.string - a.string);
        g.forEach((ev, idx) => lead.push({ ...ev, sec: ev.t * spb + idx * (g.length > 2 ? 0.009 : 0.004), len: ev.dur * spb, vel: ev.mute ? 0.5 : g.length > 2 ? 0.62 : 0.8, pm: false }));
      }
    } else {
      for (const nt of score.notes) {
        if (!nt.midi.length) continue;
        const many = nt.midi.length > 1;
        nt.midi.slice().sort((a, b) => a - b).forEach((m, idx) => lead.push({
          midi: m, sec: nt.t * spb + (many ? idx * 0.01 : 0) + jitter(3), len: nt.dur * spb, vel: many ? 0.6 : 0.8 + (Math.random() - 0.5) * 0.06,
          vib: !!nt.vib, bendFrom: nt.bend ? -2 : 0,
        }));
      }
    }
    // 和弦伴奏：干净的电吉他。拨片 / 过载的贝斯配扫弦，指弹 / 击弦配分解和弦
    const tone = score.tone || 'finger';
    for (const c of score.chords || []) {
      const v = voicing(c.chord, false);
      const strs = v.map((f, i) => (f === null ? null : { s: 5 - i, midi: GTR[5 - i] + f })).filter(Boolean);   // 低音 → 高音
      const end = c.t + c.dur;
      if (tone === 'finger' || tone === 'slap') {
        const order = [0, 2, 3, 4, 2, 3, 1, 3].map((x) => strs[Math.min(strs.length - 1, x)]);
        for (let b = c.t, k = 0; b < end - 1e-6; b += 0.5, k++) {
          const st = order[k % order.length];
          rhythm.push({ midi: st.midi, sec: b * spb + jitter(4), len: Math.min(2, end - b) * spb, vel: (k % 4 === 0 ? 0.42 : 0.32) + (Math.random() - 0.5) * 0.05, string: st.s });
        }
      } else {
        const beats = score.beats || 4;
        const PAT = beats === 4 ? ['D', '', 'D', 'U', '', 'U', 'D', 'U'] : beats === 3 ? ['D', '', 'D', 'U', 'D', 'U'] : beats === 2 ? ['D', '', 'D', 'U'] : null;
        for (let b = c.t; b < end - 1e-6; b += 0.5) {
          const slot = Math.round((((b % beats) + beats) % beats) * 2);
          const pat = PAT ? PAT[slot % PAT.length] : (slot % 2 ? 'U' : 'D');
          const dir = b === c.t ? 'D' : pat;
          if (!dir) continue;
          const take = dir === 'D' ? strs : strs.slice(-4).reverse();
          const vel = dir === 'D' ? (slot === 0 || b === c.t ? 0.5 : 0.4) : 0.28;
          const nextOn = Math.min(end, b + (dir === 'D' ? 1 : 0.5));
          take.forEach((st, idx) => rhythm.push({ midi: st.midi, sec: b * spb + idx * (dir === 'D' ? 0.011 : 0.008) + jitter(4), len: (nextOn - b) * spb - idx * 0.01, vel: vel + (Math.random() - 0.5) * 0.06, string: st.s }));
        }
      }
    }
    return { lead, rhythm };
  }

  /* ---------- 弦的声音：Karplus-Strong 拨弦模型（可变音高：推弦、揉弦、滑音） ---------- */
  const freq = (m) => 440 * Math.pow(2, (m - 69) / 12);
  function pluck(out, sr, ev, tone, kind = 'bass') {
    const bass = kind === 'bass';
    const f0 = freq(ev.midi);
    const minF = freq(Math.min(ev.midi, ev.fromMidi ?? ev.midi) + Math.min(0, ev.bendFrom || 0) + Math.min(0, ev.releaseTo || 0)) * 0.97;
    const N = Math.ceil(sr / minF) + 8;
    const buf = new Float32Array(N);
    const i0 = Math.max(0, Math.floor(ev.sec * sr));
    const held = Math.max(0.03, ev.len);
    const iEnd = i0 + Math.floor(held * sr);
    const release = ev.pm ? 0.05 : 0.09;
    const iStop = Math.min(out.length, iEnd + Math.floor(release * 6 * sr));
    if (i0 >= out.length) return;
    // 衰减：低音延音长；闷音（palm mute）很短
    // 衰减：贝斯的弦粗，延音长；击弦短一点、有力；吉他伴奏用干净音色的延音
    const t60 = ev.mute ? 0.05 : ev.pm ? 0.22 : bass ? (tone === 'slap' ? 2.2 : tone === 'drive' ? 6 : 4.5) * Math.pow(55 / f0, 0.15) : Math.max(3.5, Math.min(10, 8 * Math.pow(110 / f0, 0.25)));
    const rho = Math.pow(10, -3 / (t60 * f0));
    const rhoRel = Math.pow(10, -3 / (release * f0));
    // 拨弦：带一点低通的噪声；力度越大越亮。击弦 / 勾弦 / 滑音时只轻轻激励
    const soft = ev.legato || ev.slide || ev.release;
    const amp = (soft ? 0.28 : 1) * ev.vel * (ev.mute ? 0.6 : 1);
    // 亮度：指弹最柔，拨片亮一点，击弦最亮（拇指砸弦）
    const bright = ev.mute ? 0.25 : ev.pm ? 0.35 : bass ? ({ finger: 0.28, pick: 0.6, slap: 0.92, drive: 0.55 }[tone] ?? 0.3) * (0.7 + 0.4 * ev.vel) : Math.min(0.95, 0.45 + 0.5 * ev.vel) * 0.85;
    const P0 = sr / f0;
    const pickPos = bass ? (tone === 'finger' ? 0.22 : tone === 'slap' ? 0.06 : 0.12) : 0.13;   // 拨弦的位置（离琴桥的比例）
    let lp = 0;
    const tmp = new Float32Array(Math.ceil(P0) + 2);
    for (let k = 0; k < tmp.length; k++) { lp += (Math.random() * 2 - 1 - lp) * bright; tmp[k] = lp; }
    const d = Math.max(1, Math.round(pickPos * P0));
    for (let k = tmp.length - 1; k >= d; k--) tmp[k] -= tmp[k - d];
    for (let k = 0; k < tmp.length; k++) buf[k % N] += tmp[k] * amp;
    // 音高随时间变化
    const fromSemi = ev.fromMidi !== undefined && ev.slide ? ev.fromMidi - ev.midi : ev.release && ev.fromMidi !== undefined ? ev.fromMidi - ev.midi : 0;
    const bendFrom = ev.bendFrom || 0, releaseTo = ev.releaseTo || 0;
    const vib = !!ev.vib;
    const bendTime = Math.min(0.16, held * 0.35), slideTime = Math.min(0.07, held * 0.5);
    const loopGain = bass ? (tone === 'slap' ? 0.18 : tone === 'finger' ? 0.42 : 0.3) : Math.max(0.12, Math.min(0.5, 0.5 * Math.sqrt(150 / f0)));   // 两点平均的比例：越大高泛音掉得越快
    let w = Math.ceil(P0) % N;   // 写指针
    let prevOut = 0;
    const pickup = bass ? 0.25 : 0.18;   // 拾音器位置
    const atk = Math.floor(0.002 * sr);
    for (let i = i0, j = 0; i < iStop; i++, j++) {
      const t = j / sr;
      let semi = 0;
      if (fromSemi) semi += t < slideTime ? fromSemi * (1 - t / slideTime) : 0;
      if (bendFrom) semi += t < bendTime ? bendFrom * (1 - smooth(t / bendTime)) : 0;
      if (releaseTo && t > held * 0.6) semi += releaseTo * Math.min(1, (t - held * 0.6) / 0.12);
      if (vib && t > 0.18) semi += 0.32 * Math.min(1, (t - 0.18) / 0.3) * Math.sin(2 * Math.PI * 5.6 * (t - 0.18));
      const P = semi ? P0 * Math.pow(2, -semi / 12) : P0;
      // 读延迟线（线性插值）；两点平均本身会多出 loopGain 个采样的延迟，这里扣掉，音才准
      const rp = w - (P - loopGain);
      const r0 = Math.floor(rp), fr = rp - r0;
      const a = buf[((r0 % N) + N) % N], b = buf[(((r0 + 1) % N) + N) % N];
      const x = a + (b - a) * fr;
      const cur = i < iEnd ? rho : rho * rhoRel;
      // 两点平均：高泛音衰减更快
      const y = (x * (1 - loopGain) + prevOut * loopGain) * cur + 0;
      prevOut = x;
      buf[w] = y;
      w = (w + 1) % N;
      // 拾音器：在延迟线上取两点相减（梳状），模拟拾音器的位置
      const pr = rp + pickup * P;
      const p0 = Math.floor(pr), pf = pr - p0;
      const c0 = buf[((p0 % N) + N) % N], c1 = buf[(((p0 + 1) % N) + N) % N];
      let v = y - (c0 + (c1 - c0) * pf) * 0.55;
      if (j < atk) v *= j / atk;
      out[i] += v;
      if (i > iEnd && Math.abs(y) < 1e-5 && Math.abs(v) < 1e-5) break;
    }
  }
  function smooth(x) { x = Math.max(0, Math.min(1, x)); return x * x * (3 - 2 * x); }

  /* ---------- 音箱：失真 + 箱体 + 空间（OfflineAudioContext） ---------- */
  const AMP = {
    // 贝斯音箱
    finger: { pre: 1.4, k: 1.1, asym: 1.0, low: 4, mid: [700, -1, 0.9], high: -3, lpf: 2600, hpf: 32, post: 0.95, chorus: false, delay: 0, rev: 0.05 },
    pick: { pre: 1.8, k: 1.5, asym: 0.95, low: 3, mid: [900, 3, 0.9], high: 2, lpf: 4200, hpf: 35, post: 0.85, chorus: false, delay: 0, rev: 0.05 },
    slap: { pre: 1.6, k: 1.3, asym: 1.0, low: 6, mid: [650, -7, 0.7], high: 7, lpf: 7500, hpf: 30, post: 0.8, chorus: false, delay: 0, rev: 0.06 },
    drive: { pre: 7, k: 3, asym: 0.85, low: 4, mid: [800, 2, 0.8], high: 1, lpf: 3400, hpf: 40, post: 0.42, chorus: false, delay: 0, rev: 0.06 },
    // 伴奏的电吉他（干净音色）
    gtr: { pre: 1.6, k: 1.4, asym: 1.0, low: 0, mid: [700, 0, 1], high: 2, lpf: 6800, hpf: 110, post: 0.75, chorus: true, delay: 0.12, rev: 0.2 },
  };
  function shaperCurve(k, asym) {
    const n = 2048, c = new Float32Array(n), norm = Math.tanh(k);
    for (let i = 0; i < n; i++) { const x = i * 2 / (n - 1) - 1; c[i] = x >= 0 ? Math.tanh(k * x) / norm : Math.tanh(k * asym * x) / Math.tanh(k * asym); }
    return c;
  }
  function ampChain(ctx, input, tone, dest) {
    const a = AMP[tone] || AMP.finger;
    const pre = ctx.createGain(); pre.gain.value = a.pre;
    const hp0 = ctx.createBiquadFilter(); hp0.type = 'highpass'; hp0.frequency.value = tone === 'drive' ? 50 : a.hpf;   // 切掉听不到的超低频，不会糊
    const sh = ctx.createWaveShaper(); sh.curve = shaperCurve(a.k, a.asym); sh.oversample = '4x';
    const low = ctx.createBiquadFilter(); low.type = 'lowshelf'; low.frequency.value = tone === 'gtr' ? 160 : 90; low.gain.value = a.low;
    const mid = ctx.createBiquadFilter(); mid.type = 'peaking'; mid.frequency.value = a.mid[0]; mid.gain.value = a.mid[1]; mid.Q.value = a.mid[2];
    const high = ctx.createBiquadFilter(); high.type = 'highshelf'; high.frequency.value = 2600; high.gain.value = a.high;
    const hp = ctx.createBiquadFilter(); hp.type = 'highpass'; hp.frequency.value = a.hpf; hp.Q.value = 0.7;
    const lp1 = ctx.createBiquadFilter(); lp1.type = 'lowpass'; lp1.frequency.value = a.lpf; lp1.Q.value = 0.8;
    const lp2 = ctx.createBiquadFilter(); lp2.type = 'lowpass'; lp2.frequency.value = a.lpf * 1.25; lp2.Q.value = 0.6;
    const notch = ctx.createBiquadFilter(); notch.type = 'peaking'; notch.frequency.value = 3200; notch.gain.value = -2; notch.Q.value = 1.4;
    const post = ctx.createGain(); post.gain.value = a.post;
    input.connect(pre); pre.connect(hp0); hp0.connect(sh); sh.connect(low); low.connect(mid); mid.connect(high); high.connect(hp); hp.connect(lp1); lp1.connect(lp2); lp2.connect(notch); notch.connect(post);
    if (a.chorus) {
      const dl = ctx.createDelay(0.05); dl.delayTime.value = 0.014;
      const lfo = ctx.createOscillator(); lfo.frequency.value = 0.8; const lg = ctx.createGain(); lg.gain.value = 0.0025;
      lfo.connect(lg); lg.connect(dl.delayTime); lfo.start(0);
      const wet = ctx.createGain(); wet.gain.value = 0.35;
      post.connect(dl); dl.connect(wet); wet.connect(dest);
    }
    post.connect(dest);
    return post;
  }

  async function render(score, { sampleRate = 44100, volume = 1.0 } = {}) {   // volume：相对响度，1 是默认
    const sr = sampleRate;
    const tone = TONES[score.tone] ? score.tone : 'finger';
    const perf = performance({ bpm: 90, beats: 4, chords: [], ...score });
    const all = [...perf.lead, ...perf.rhythm];
    const endSec = all.reduce((m, e) => Math.max(m, e.sec + e.len), 0);
    const len = Math.max(0.6, endSec + 2.2);
    const n = Math.ceil(len * sr);
    const offset = 0.05;
    const leadDI = new Float32Array(n), rhyL = new Float32Array(n), rhyR = new Float32Array(n);
    for (const e of perf.lead) pluck(leadDI, sr, { ...e, sec: e.sec + offset }, tone, 'bass');
    // 伴奏录两遍，左右各一遍（像录音棚里的双轨），会更宽
    for (const e of perf.rhythm) {
      pluck(rhyL, sr, { ...e, sec: e.sec + offset }, 'gtr', 'gtr');
      pluck(rhyR, sr, { ...e, sec: e.sec + offset + 0.012 + Math.random() * 0.006, vel: e.vel * (0.94 + Math.random() * 0.08) }, 'gtr', 'gtr');
    }
    const ctx = new OfflineAudioContext(2, n, sr);
    const master = ctx.createGain(); master.gain.value = volume;
    const comp = ctx.createDynamicsCompressor();
    comp.threshold.value = -12; comp.ratio.value = 3; comp.attack.value = 0.004; comp.release.value = 0.2;
    master.connect(comp); comp.connect(ctx.destination);
    // 空间：短的板式混响 + 主旋律的延迟
    const rev = ctx.createConvolver();
    const irLen = Math.floor(sr * 1.6), ir = ctx.createBuffer(2, irLen, sr);
    for (let ch = 0; ch < 2; ch++) {
      const dd = ir.getChannelData(ch);
      let seed = 4321 + ch * 999;
      for (let k = 0; k < irLen; k++) { seed = (seed * 16807) % 2147483647; dd[k] = ((seed / 2147483647) * 2 - 1) * Math.pow(1 - k / irLen, 3.6); }
    }
    rev.buffer = ir;
    const revWet = ctx.createGain(); revWet.gain.value = AMP[tone].rev;
    rev.connect(revWet); revWet.connect(master);
    const bus = (data, pan, gain, withDelay, ampTone = tone) => {
      const b = ctx.createBuffer(1, n, sr); b.copyToChannel(data, 0);
      const src = ctx.createBufferSource(); src.buffer = b;
      const sum = ctx.createGain(); sum.gain.value = 1;
      ampChain(ctx, src, ampTone, sum);
      const g = ctx.createGain(); g.gain.value = gain;
      const p = ctx.createStereoPanner(); p.pan.value = pan;
      sum.connect(g); g.connect(p); p.connect(master); p.connect(rev);
      if (withDelay) {
        const dl = ctx.createDelay(1); dl.delayTime.value = Math.min(0.5, 60 / (score.bpm || 90) * 0.75);
        const fb = ctx.createGain(); fb.gain.value = 0.28;
        const dw = ctx.createGain(); dw.gain.value = AMP[ampTone].delay;
        const df = ctx.createBiquadFilter(); df.type = 'lowpass'; df.frequency.value = 3000;
        g.connect(dl); dl.connect(df); df.connect(fb); fb.connect(dl); df.connect(dw); dw.connect(master);
      }
      src.start(0);
    };
    const hasRhythm = perf.rhythm.length > 0;
    bus(leadDI, 0, hasRhythm ? 1.0 : 1.1, false);
    if (hasRhythm) { bus(rhyL, -0.7, 0.32, true, 'gtr'); bus(rhyR, 0.7, 0.32, true, 'gtr'); }
    const out = await ctx.startRendering();
    // 响度统一：不同音色、不同曲子听起来差不多响，也不会爆音
    let peak = 0, ss = 0, cnt = 0;
    for (let ch = 0; ch < out.numberOfChannels; ch++) { const d = out.getChannelData(ch); for (let i = 0; i < d.length; i++) { const v = d[i]; if (Math.abs(v) > peak) peak = Math.abs(v); ss += v * v; cnt++; } }
    const rms = Math.sqrt(ss / Math.max(1, cnt));
    if (peak > 0) {
      const g = Math.min(0.92 / peak, (0.15 * volume) / Math.max(1e-4, rms));
      for (let ch = 0; ch < out.numberOfChannels; ch++) { const d = out.getChannelData(ch); for (let i = 0; i < d.length; i++) d[i] *= g; }
    }
    return out;
  }

  // AudioBuffer → WAV 文件（16 位）
  function toWav(buf) {
    const ch = buf.numberOfChannels, sr = buf.sampleRate, n = buf.length;
    const out = new DataView(new ArrayBuffer(44 + n * ch * 2));
    const w = (o, s) => { for (let k = 0; k < s.length; k++) out.setUint8(o + k, s.charCodeAt(k)); };
    w(0, 'RIFF'); out.setUint32(4, 36 + n * ch * 2, true); w(8, 'WAVE'); w(12, 'fmt ');
    out.setUint32(16, 16, true); out.setUint16(20, 1, true); out.setUint16(22, ch, true); out.setUint32(24, sr, true);
    out.setUint32(28, sr * ch * 2, true); out.setUint16(32, ch * 2, true); out.setUint16(34, 16, true); w(36, 'data'); out.setUint32(40, n * ch * 2, true);
    const data = []; for (let c = 0; c < ch; c++) data.push(buf.getChannelData(c));
    let o = 44;
    for (let k = 0; k < n; k++) for (let c = 0; c < ch; c++) { const v = Math.max(-1, Math.min(1, data[c][k])); out.setInt16(o, v < 0 ? v * 0x8000 : v * 0x7fff, true); o += 2; }
    return new Uint8Array(out.buffer);
  }

  // 谱子 → MIDI 文件：1 声道贝斯，2 声道吉他伴奏；贝斯的音色按“音色”选指弹 / 拨片 / 击弦 / 过载
  function toMidi(score) {
    const tpq = 480, ev = [];
    const program = { finger: 33, pick: 34, slap: 36, drive: 34 }[score.tone] ?? 33;
    const spb = 60 / score.bpm;
    const perf = performance(score);
    const add = (list, chn) => {
      for (const e of list) {
        const t = Math.max(0, Math.round(e.sec / spb * tpq)), d = Math.max(30, Math.round(e.len / spb * tpq));
        const vel = Math.max(20, Math.min(127, Math.round(e.vel * 120)));
        ev.push({ t, on: 1, m: e.midi, chn, vel }); ev.push({ t: t + d, on: 0, m: e.midi, chn, vel: 0 });
      }
    };
    add(perf.lead.filter((e) => !e.mute), 0); add(perf.rhythm, 1);
    ev.sort((a, b) => a.t - b.t || a.on - b.on);
    const bytes = [];
    const vlq = (v) => { const s = [v & 0x7f]; while ((v >>= 7)) s.unshift((v & 0x7f) | 0x80); bytes.push(...s); };
    const us = Math.round(60000000 / score.bpm);
    vlq(0); bytes.push(0xff, 0x51, 0x03, (us >> 16) & 255, (us >> 8) & 255, us & 255);
    vlq(0); bytes.push(0xc0, program);
    vlq(0); bytes.push(0xc1, 27);
    let prev = 0;
    for (const e of ev) { vlq(e.t - prev); prev = e.t; bytes.push((e.on ? 0x90 : 0x80) | e.chn, e.m, e.vel); }
    vlq(0); bytes.push(0xff, 0x2f, 0x00);
    const head = [0x4d, 0x54, 0x68, 0x64, 0, 0, 0, 6, 0, 0, 0, 1, (tpq >> 8) & 255, tpq & 255];
    const L = bytes.length;
    return new Uint8Array([...head, 0x4d, 0x54, 0x72, 0x6b, (L >>> 24) & 255, (L >> 16) & 255, (L >> 8) & 255, L & 255, ...bytes]);
  }

  // 检查每小节的拍数是不是对的：返回不对的小节 [{bar: 第几小节, got: 实际拍数}]
  function checkBars(score) {
    const bad = [];
    const ends = score.bars.slice();
    const melodyEnd = score.notes.length ? Math.max(...score.notes.map((x) => x.t + x.dur)) : score.total;
    const total = score.mode === 'jianpu' ? Math.max(melodyEnd, ends[ends.length - 1] || 0) : score.total;
    if (!ends.length || ends[ends.length - 1] < total) ends.push(total);
    let prev = 0;
    ends.forEach((e, k) => {
      const got = Math.round((e - prev) * 1000) / 1000;
      const last = k === ends.length - 1;
      if (got > 0 && Math.abs(got - score.beats) > 1e-6 && !(last && got < score.beats)) bad.push({ bar: k + 1, got });
      prev = e;
    });
    return bad;
  }

  /* ---------- 简谱 → 四线谱（自动排指法） ---------- */
  // 用动态规划挑每个音的把位：整首曲子手的移动最少，尽量在低把位、能用空弦就用空弦；同时按下的音分到不同的弦上
  function placeGroup(pitches, p, capo) {
    // 手在第 p 品（食指），能按到 p-1 … p+4 品，空弦随时能弹
    const res = [], used = new Set();
    let cost = 0;
    for (const m of pitches.slice().sort((x, y) => y - x)) {
      let best = null;
      for (let s = 0; s < NS; s++) {
        if (used.has(s)) continue;
        const f = m - TUNING[s] - capo;
        if (f < 0 || f > 20) continue;
        let c;
        if (f === 0) c = 0.6;
        else if (f >= p && f <= p + 3) c = 0;
        else if (f === p - 1 || f === p + 4) c = 0.8;
        else continue;
        c += s * 0.02;
        if (!best || c < best.c) best = { s, f, c };
      }
      if (!best) return null;
      used.add(best.s); res.push({ midi: m, string: best.s, fret: best.f }); cost += best.c;
    }
    return { res, cost };
  }
  function fingering(groups, capo = 0) {
    const P = 16;
    let prev = new Array(P).fill(0).map((_, p) => ({ cost: p * 0.15, from: -1 }));
    const table = [];
    for (const g of groups) {
      const cur = [], opts = [];
      for (let p = 1; p < P; p++) {
        const pl = placeGroup(g, p, capo);
        opts[p] = pl;
        if (!pl) { cur[p] = { cost: Infinity, from: -1 }; continue; }
        let best = { cost: Infinity, from: -1 };
        for (let q = 1; q < P; q++) {
          if (!isFinite(prev[q] ? prev[q].cost : Infinity)) continue;
          const c = prev[q].cost + Math.abs(p - q) * 1.0 + (p !== q ? 0.5 : 0) + pl.cost + p * 0.1;
          if (c < best.cost) best = { cost: c, from: q };
        }
        cur[p] = best;
      }
      table.push({ cur, opts });
      if (cur.every((x) => !x || !isFinite(x.cost))) {
        // 这一组按不下（比如同一根弦上的音太多）：单独找最近的位置
        cur.forEach((x, p) => { if (opts[p]) cur[p] = { cost: 0, from: -1 }; });
      }
      prev = cur;
    }
    // 回溯
    const out = new Array(groups.length);
    let p = -1, bestC = Infinity;
    if (table.length) prev.forEach((x, q) => { if (x && x.cost < bestC) { bestC = x.cost; p = q; } });
    for (let i = table.length - 1; i >= 0; i--) {
      const opt = p > 0 && table[i].opts[p];
      if (opt) out[i] = opt.res;
      else {
        // 实在放不下：每个音各找一个能弹的位置
        out[i] = groups[i].map((m) => { for (let s = 0; s < NS; s++) { const f = m - TUNING[s] - capo; if (f >= 0 && f <= 22) return { midi: m, string: s, fret: f }; } return null; }).filter(Boolean);
      }
      p = p > 0 && table[i].cur[p] ? table[i].cur[p].from : -1;
      if (p < 0 && i > 0) { let bc = Infinity; table[i - 1].cur.forEach((x, q) => { if (x && x.cost < bc) { bc = x.cost; p = q; } }); }
    }
    return out;
  }
  function toTab(score) {
    if (!score || score.error) return null;
    if (score.mode === 'tab') return null;
    const notes = score.notes.filter((n) => n.midi.length);
    // 一个字符代表多长：谱里都是半拍的倍数就 1/4 拍一格，否则 1/8 拍一格（每个音之间至少留出两格，写得下两位数的品）
    let unit = 0.5;
    for (const n of score.notes) for (const v of [n.t, n.dur]) if (Math.abs(v * 2 - Math.round(v * 2)) > 1e-6) unit = 0.25;
    const perChar = unit / 2;
    const fing = fingering(notes.map((n) => n.midi));
    const beats = score.beats || 4;
    const total = Math.max(score.total, notes.length ? notes[notes.length - 1].t + notes[notes.length - 1].dur : 0);
    const barsN = Math.max(1, Math.ceil(total / beats - 1e-6));
    const charsPerBar = Math.round(beats / perChar);
    const perLine = Math.max(1, Math.min(4, Math.floor(76 / (charsPerBar + 1))));
    const head = `1=${score.key} ♩=${score.bpm} ${beats}/4 音色=${TONES[score.tone] || '指弹'} 每格=${perChar === 0.25 ? '1/4' : '1/8'}拍   // 由简谱自动排的指法`;
    const srcMap = [];   // [{ idx, start, end }]（在四线谱文本里的位置）
    let text = head + '\n';
    for (let b0 = 0; b0 < barsN; b0 += perLine) {
      const b1 = Math.min(barsN, b0 + perLine);
      const rows = STRING_NAMES.map(() => []);
      const marks = [];
      // 先铺好 - 和小节线
      for (let s = 0; s < NS; s++) {
        for (let bar = b0; bar < b1; bar++) { for (let c = 0; c < charsPerBar; c++) rows[s].push('-'); rows[s].push('|'); }
      }
      const colOf = (t) => { const bar = Math.floor(t / beats + 1e-9) - b0; return bar * (charsPerBar + 1) + Math.round((t - (bar + b0) * beats) / perChar); };
      notes.forEach((n, idx) => {
        const bar = Math.floor(n.t / beats + 1e-9);
        if (bar < b0 || bar >= b1) return;
        for (const hit of fing[idx]) {
          let cell = String(hit.fret);
          if (n.bend && hit.fret >= 2) cell = `${hit.fret - 2}b${hit.fret}`;
          if (n.vib) cell += '~';
          let col = colOf(n.t);
          const row = rows[hit.string];
          // 前面一个长记号还没写完：往后挪到空的地方（只影响这一根弦）
          while (col < row.length && row[col] !== '-') col++;
          for (let k = 0; k < cell.length && col + k < row.length; k++) if (row[col + k] === '-') row[col + k] = cell[k];
          marks.push({ s: hit.string, col: col + 2, len: cell.length, idx });
        }
      });
      const lines = rows.map((r, s) => STRING_NAMES[s] + '|' + r.join(''));
      const offs = []; let acc = text.length;
      for (let s = 0; s < NS; s++) { offs.push(acc); acc += lines[s].length + 1; }
      for (const m of marks) srcMap.push({ idx: m.idx, start: offs[m.s] + m.col, end: offs[m.s] + m.col + m.len });
      text += lines.join('\n') + '\n\n';
    }
    // 和弦伴奏照样保留：按小节写成「和弦：」一行
    if (score.chords && score.chords.length) {
      const at = (t) => { const c = score.chords.find((x) => t >= x.t - 1e-6 && t < x.t + x.dur - 1e-6); return c ? c.name : 'N.C.'; };
      const cbars = Math.max(barsN, Math.ceil(Math.max(...score.chords.map((c) => c.t + c.dur)) / beats - 1e-6));
      const parts = [];
      for (let b = 0; b < cbars; b++) { const a1 = at(b * beats), a2 = at(b * beats + beats / 2); parts.push(a1 === a2 ? a1 : a1 + ' ' + a2); }
      text += '和弦：| ' + parts.join(' | ') + ' |\n';
    }
    return { text: text.replace(/\n+$/, '\n'), map: srcMap, notes };
  }

  const api = { parse, checkBars, render, toWav, toMidi, toTab, isTab, freq, normalize, TUNING, STRING_NAMES, TONES, parseChord, voicing, voicingMidi, performance };
  root.Jianpu = api;
  root.Bass = api;
})(typeof window !== 'undefined' ? window : globalThis);
