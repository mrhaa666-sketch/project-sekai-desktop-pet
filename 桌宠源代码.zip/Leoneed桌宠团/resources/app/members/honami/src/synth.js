'use strict';
/* 架子鼓窗口：鼓谱网格 + 鼓谱文字（两边同步）→ 用架子鼓的声音打出来；节拍器（可以单独练习，也可以和鼓谱一起响）；
   可以保存、导出 WAV / MIDI；打的时候告诉穗波 */
const $ = (id) => document.getElementById(id);
const api = window.synthAPI;
const msg = (t, cls = '') => { $('msg').textContent = t; $('msg').className = cls; };
const D = window.Drums;

let mineLoaded = false;      // 现在框里是她编的节奏
let sc = null;               // 现在的鼓谱（解析结果）
let ac = null;
const ctx = () => (ac || (ac = new AudioContext()));

/* ---------- 解析、检查 ---------- */
function check() {
  const text = $('score').value;
  const s = D.parse(text);
  if (s.error) {
    msg(`第 ${text.slice(0, s.error.pos).split('\n').length} 行：${s.error.msg}`, 'err');
    sc = null; drawGrid(null);
    return null;
  }
  sc = s;
  syncControls();
  const bad = D.checkBars(s);
  const sec = s.total * 60 / s.bpm;
  const bars = Math.max(1, Math.ceil(s.cells / (s.per * s.beats)));
  msg(s.events.length ? `${bars} 小节 · ${s.events.length} 下 · ${s.used.map((id) => D.INST[id][0]).join('、')} · ♩=${s.bpm} · ${s.beats}/${s.beatUnit} · ${D.KITS[s.kit]}鼓组 · 大约 ${Math.round(sec)} 秒` +
    (bad.length ? `　（第 ${bad.slice(0, 3).map((b) => b.bar).join('、')} 小节的格数不对：应该是 ${bad[0].want} 格）` : '')
    : '还是空的：在网格里点几下，或者从“套用节奏”里选一个');
  drawGrid(s);
  return s;
}
let checkTimer = 0;
$('score').addEventListener('input', () => { mineLoaded = false; stop(); clearTimeout(checkTimer); checkTimer = setTimeout(check, 250); });
$('msg').addEventListener('click', () => {
  const s = D.parse($('score').value);
  if (s.error) { $('score').focus(); $('score').setSelectionRange(s.error.pos, s.error.pos + 1); }
});
// 网格或控件改了：把鼓谱重新写成文字
function commit() {
  $('score').value = D.serialize(sc);
  mineLoaded = false;
  stop();
  check();
}

/* ---------- 速度、拍号、每格、鼓组、摇摆 ---------- */
function syncControls() {
  $('bpm').value = sc.bpm;
  $('sig').value = `${sc.beats}/${sc.beatUnit}`;
  if (![...$('sig').options].some((o) => o.value === $('sig').value)) { const o = document.createElement('option'); o.textContent = $('sig').value; $('sig').appendChild(o); $('sig').value = o.textContent; }
  $('unit').value = String(sc.unitDen);
  $('kit').value = D.KITS[sc.kit];
  $('swing').value = sc.swing; $('swingV').textContent = sc.swing + '%';
  if ($('metFollow').checked) setMetBpm(sc.bpm, false);
}
const needScore = () => { if (!sc) { msg('鼓谱文字里有错误，先改好再用这里', 'err'); return false; } return true; };
$('bpm').onchange = () => { if (!needScore()) return; sc.bpm = Math.max(30, Math.min(260, +$('bpm').value || 100)); commit(); };
$('kit').onchange = () => { if (!needScore()) return; sc.kit = D.KIT_ALIAS[$('kit').value]; commit(); };
$('swing').oninput = () => { $('swingV').textContent = $('swing').value + '%'; };
$('swing').onchange = () => { if (!needScore()) return; sc.swing = +$('swing').value; commit(); };
// 改拍号、每格：按时间重新排格子（落不到新格子上的音就放到最近的格子）
function regrid(beats, beatUnit, den) {
  const oldPer = sc.per, per = Math.max(1, Math.round(den / beatUnit));
  const total = sc.cells / oldPer;
  const bars = Math.max(1, Math.ceil(total / beats - 1e-9));
  const cells = bars * beats * per;
  const rows = {};
  for (const id in sc.rows) {
    rows[id] = new Array(cells).fill(0);
    sc.rows[id].forEach((v, k) => { if (!v) return; const c = Math.round(k / oldPer * per); if (c < cells) rows[id][c] = Math.max(rows[id][c], v); });
  }
  Object.assign(sc, { beats, beatUnit, unitDen: den, per, rows, cells });
}
$('sig').onchange = () => { if (!needScore()) return; const [a, b] = $('sig').value.split('/').map(Number); let den = +$('unit').value; if (den % b) den = b * Math.ceil(den / b); regrid(a, b, den); commit(); };
$('unit').onchange = () => {
  if (!needScore()) return;
  const den = +$('unit').value;
  if (den % sc.beatUnit) { msg(`每格=1/${den} 和拍号 ${sc.beats}/${sc.beatUnit} 对不上`, 'err'); $('unit').value = String(sc.unitDen); return; }
  regrid(sc.beats, sc.beatUnit, den); commit();
};
for (const name of Object.keys(D.PRESETS)) { const o = document.createElement('option'); o.value = name; o.textContent = name; $('preset').appendChild(o); }
$('preset').onchange = () => {
  const name = $('preset').value; if (!name) return;
  stop();
  $('score').value = D.PRESETS[name]; $('title').value = name; mineLoaded = false;
  $('preset').value = '';
  check();
};

/* ---------- 网格 ---------- */
let cellEls = [];   // cellEls[格] = 这一列的所有 td（播放时高亮）
function drawGrid(s) {
  const g = $('grid');
  g.innerHTML = '';
  cellEls = [];
  if (!s) { g.innerHTML = '<tr><td style="border:0;width:auto;cursor:default;color:#b0475a;padding:6px">鼓谱文字有错误，改好后这里会显示网格</td></tr>'; return; }
  const per = s.per, cpb = per * s.beats;
  const bars = Math.max(1, Math.ceil(s.cells / cpb));
  const n = bars * cpb;
  // 小节号
  const head = document.createElement('tr'); head.className = 'num';
  head.appendChild(document.createElement('th'));
  for (let k = 0; k < n; k++) { const td = document.createElement('td'); if (k % cpb === 0) { td.textContent = k / cpb + 1; td.className = 'barl'; } head.appendChild(td); }
  g.appendChild(head);
  for (const id of D.ORDER) {
    const tr = document.createElement('tr');
    const th = document.createElement('th'); th.textContent = D.INST[id][0]; th.title = '点一下试音';
    if (s.rows[id] && s.rows[id].some((v) => v)) th.className = 'used';
    th.onmousedown = (e) => { e.preventDefault(); audition(id, 0.85); };
    tr.appendChild(th);
    for (let k = 0; k < n; k++) {
      const td = document.createElement('td');
      const cls = [];
      if (k % cpb === 0) cls.push('barl'); else if (k % per === 0) cls.push('beat');
      if (Math.floor(k / per) % 2) cls.push('alt');
      const v = (s.rows[id] || [])[k] || 0;
      if (v) cls.push(v >= 0.95 ? 'v2' : v <= 0.4 ? 'v3' : 'v1');
      td.className = cls.join(' ');
      td.appendChild(document.createElement('i'));
      td.title = `${D.INST[id][0]} · 第 ${Math.floor(k / cpb) + 1} 小节第 ${Math.floor((k % cpb) / per) + 1} 拍`;
      td.onmousedown = (e) => {
        e.preventDefault();
        if (!sc) return;
        sc.rows[id] = sc.rows[id] || new Array(n).fill(0);
        while (sc.rows[id].length < n) sc.rows[id].push(0);
        for (const r in sc.rows) while (sc.rows[r].length < n) sc.rows[r].push(0);
        sc.cells = Math.max(sc.cells, n);
        const cur = sc.rows[id][k];
        const want = e.shiftKey ? 1 : e.altKey ? 0.3 : 0.78;
        sc.rows[id][k] = cur && Math.abs(cur - want) < 0.05 ? 0 : want;
        if (sc.rows[id][k]) audition(id, sc.rows[id][k]);
        commit();
      };
      tr.appendChild(td);
      (cellEls[k] = cellEls[k] || []).push(td);
    }
    g.appendChild(tr);
  }
}
const barOps = (fn) => () => { if (!needScore()) return; const cpb = sc.per * sc.beats; const bars = Math.max(1, Math.ceil(sc.cells / cpb)); fn(cpb, bars); commit(); };
$('addBar').onclick = barOps((cpb, bars) => { for (const id in sc.rows) { sc.rows[id].length = bars * cpb; sc.rows[id] = Array.from(sc.rows[id], (v) => v || 0).concat(new Array(cpb).fill(0)); } if (!Object.keys(sc.rows).length) sc.rows.hihat = new Array((bars + 1) * cpb).fill(0); sc.cells = (bars + 1) * cpb; });
$('dupBar').onclick = barOps((cpb, bars) => { for (const id in sc.rows) { const r = Array.from({ length: bars * cpb }, (_, k) => sc.rows[id][k] || 0); sc.rows[id] = r.concat(r.slice((bars - 1) * cpb)); } sc.cells = (bars + 1) * cpb; });
$('delBar').onclick = barOps((cpb, bars) => { if (bars <= 1) return; for (const id in sc.rows) sc.rows[id] = sc.rows[id].slice(0, (bars - 1) * cpb); sc.cells = (bars - 1) * cpb; });
$('clear').onclick = barOps((cpb) => { for (const id in sc.rows) sc.rows[id] = new Array(cpb * 2).fill(0); sc.cells = cpb * 2; });

/* ---------- 试音 ---------- */
const hitCache = new Map();
async function audition(id, vel) {
  const kit = sc ? sc.kit : 'acoustic';
  const key = id + kit + (vel >= 0.95 ? 'A' : vel <= 0.4 ? 'G' : 'N');
  if (!hitCache.has(key)) hitCache.set(key, D.renderHit(id, kit, vel));
  const buf = await hitCache.get(key);
  const a = ctx(); if (a.state === 'suspended') await a.resume();
  const s = a.createBufferSource(); s.buffer = buf; s.connect(a.destination); s.start();
}

/* ---------- 播放 ---------- */
let src = null, raf = 0, cache = { key: null, buf: null };
const metOpts = () => ({ on: $('withMet').checked, vol: +$('metVol').value, sub: $('metSub').value });
async function getBuffer() {
  const s = check(); if (!s) return null;
  if (!s.events.length) { msg('还没有敲任何一下', 'err'); return null; }
  const loop = $('loop').checked, countIn = $('countIn').checked ? 1 : 0, m = metOpts();
  const key = JSON.stringify([$('score').value, loop, countIn, m.on && m]);
  if (cache.key === key) return cache;
  msg('合成中…');
  await new Promise((r) => setTimeout(r, 20));
  const buf = await D.render(s, { metronome: m, countIn, loops: loop ? 2 : 1 });
  cache = { key, buf, sc: s, loop };
  check();
  return cache;
}
function stop() {
  if (src) { try { src.stop(); } catch (e) {} src = null; }
  cancelAnimationFrame(raf);
  cellEls.forEach((col) => col && col.forEach((td) => td.classList.remove('play')));
  $('play').disabled = false; $('stop').disabled = true;
}
$('stop').onclick = stop;
$('play').onclick = async () => {
  stop();
  $('play').disabled = true;
  const c = await getBuffer();
  if (!c) { $('play').disabled = false; return; }
  const a = ctx(); if (a.state === 'suspended') await a.resume();
  src = a.createBufferSource(); src.buffer = c.buf; src.connect(a.destination);
  const pre = c.buf.__pre, song = c.buf.__songLen;
  if (c.loop) { src.loop = true; src.loopStart = pre + song; src.loopEnd = pre + 2 * song; }
  const t0 = a.currentTime + 0.05;
  src.start(t0);
  src.onended = () => { if (src) stop(); };
  $('stop').disabled = false;
  if ($('share').checked || mineLoaded) api.played($('title').value.trim(), mineLoaded);
  const s = c.sc, spb = 60 / s.bpm;
  let lit = -1;
  const tick = () => {
    let t = a.currentTime - t0 - pre;
    if (c.loop && t > song) t = song + ((t - song) % song);
    if (t >= song) t -= song;
    const cell = t < 0 ? -1 : Math.floor(t / spb * s.per + 1e-6);
    if (cell !== lit) {
      if (cellEls[lit]) cellEls[lit].forEach((td) => td.classList.remove('play'));
      if (cellEls[cell]) { cellEls[cell].forEach((td) => td.classList.add('play')); const td = cellEls[cell][0]; const box = $('gridBox'); if (td.offsetLeft < box.scrollLeft + 60 || td.offsetLeft > box.scrollLeft + box.clientWidth - 40) box.scrollLeft = td.offsetLeft - 80; }
      lit = cell;
    }
    raf = requestAnimationFrame(tick);
  };
  tick();
};
for (const id of ['loop', 'countIn', 'withMet']) $(id).addEventListener('change', () => { if (src) $('play').click(); });

/* ---------- 导出 ---------- */
const fname = () => ($('title').value.trim() || '无题').replace(/[\\/:*?"<>|]/g, '_');
$('wav').onclick = async () => {
  const s = check(); if (!s || !s.events.length) return;
  msg('合成中…');
  const buf = await D.render(s, { metronome: metOpts(), countIn: $('countIn').checked ? 1 : 0, loops: 1 });
  const r = await api.exportFile({ name: fname() + '.wav', data: D.toWav(buf) });
  if (r && r.path) msg('已导出：' + r.path, 'ok'); else check();
};
$('midi').onclick = async () => {
  const s = check(); if (!s || !s.events.length) return;
  const r = await api.exportFile({ name: fname() + '.mid', data: D.toMidi(s) });
  if (r && r.path) msg('已导出：' + r.path + '（第 10 声道，GM 鼓的音符号）', 'ok');
};

/* ---------- 保存的鼓谱 ---------- */
let saved = {};
async function refreshSaved(select) {
  saved = await api.list();
  const sel = $('saved');
  sel.innerHTML = '<option value="">已保存的鼓谱…</option>';
  for (const name of Object.keys(saved).sort((a, b) => (saved[b].at || 0) - (saved[a].at || 0))) {
    const o = document.createElement('option'); o.value = name; o.textContent = name; sel.appendChild(o);
  }
  if (select) sel.value = select;
}
$('saved').onchange = () => {
  const name = $('saved').value; if (!name || !saved[name]) return;
  stop();
  $('title').value = name; $('score').value = saved[name].text; mineLoaded = saved[name].by === 'honami'; check();
};
$('save').onclick = async () => {
  const name = $('title').value.trim();
  if (!name) { msg('先起个名字', 'err'); $('title').focus(); return; }
  await api.save({ title: name, text: $('score').value });
  await refreshSaved(name);
  msg('已保存', 'ok');
};
$('del').onclick = async () => {
  const name = $('saved').value;
  if (!name) { msg('先在右边选一个要删除的鼓谱', 'err'); return; }
  await api.remove(name);
  await refreshSaved('');
  msg(`已删除《${name}》`, 'ok');
};

/* ---------- 节拍器（实时，提前排好接下来的“嘀”） ---------- */
const met = { on: false, bpm: 100, next: 0, beat: 0, sub: 0, timer: 0, taps: [] };
function setMetBpm(v, manual = true) {
  met.bpm = Math.max(30, Math.min(260, Math.round(v)));
  $('metBpm').textContent = met.bpm; $('metSlider').value = met.bpm;
  if (manual) $('metFollow').checked = false;
}
function buildDots() {
  const n = +$('metBeats').value, box = $('dots');
  box.innerHTML = '';
  for (let k = 0; k < n; k++) { const s = document.createElement('span'); if (k === 0) s.className = 'first'; box.appendChild(s); }
}
function scheduleClick(time, kind, beatIdx) {
  const a = ctx();
  const o = a.createOscillator(), g = a.createGain();
  o.frequency.value = kind === 'accent' ? 1760 : kind === 'beat' ? 1180 : 900;
  const vol = +$('metVol').value * (kind === 'accent' ? 0.55 : kind === 'beat' ? 0.4 : 0.18);
  g.gain.setValueAtTime(0.0001, time); g.gain.exponentialRampToValueAtTime(Math.max(0.0002, vol), time + 0.001); g.gain.exponentialRampToValueAtTime(0.0001, time + 0.05);
  o.connect(g); g.connect(a.destination); o.start(time); o.stop(time + 0.06);
  if (beatIdx !== null) {
    const delay = Math.max(0, (time - a.currentTime) * 1000);
    setTimeout(() => {
      if (!met.on) return;
      const dots = $('dots').children;
      [...dots].forEach((d, k) => d.classList.toggle('on', k === beatIdx));
      setTimeout(() => dots[beatIdx] && dots[beatIdx].classList.remove('on'), 110);
    }, delay);
  }
}
function metTick() {
  const a = ctx();
  const subN = { '8th': 2, triplet: 3, '16th': 4 }[$('metSub').value] || 1;
  const beats = +$('metBeats').value;
  while (met.next < a.currentTime + 0.12) {
    const spb = 60 / met.bpm;
    if (met.sub === 0) scheduleClick(met.next, met.beat === 0 && $('metAccent').checked ? 'accent' : 'beat', met.beat);
    else scheduleClick(met.next, 'sub', null);
    met.next += spb / subN;
    met.sub++;
    if (met.sub >= subN) { met.sub = 0; met.beat = (met.beat + 1) % beats; }
  }
}
$('metGo').onclick = async () => {
  if (met.on) { met.on = false; clearInterval(met.timer); $('metGo').textContent = '▶ 开始'; [...$('dots').children].forEach((d) => d.classList.remove('on')); return; }
  const a = ctx(); if (a.state === 'suspended') await a.resume();
  met.on = true; met.beat = 0; met.sub = 0; met.next = a.currentTime + 0.08;
  $('metGo').textContent = '■ 停止';
  metTick(); met.timer = setInterval(metTick, 25);
};
$('metUp').onclick = () => setMetBpm(met.bpm + 1);
$('metDown').onclick = () => setMetBpm(met.bpm - 1);
$('metSlider').oninput = () => setMetBpm(+$('metSlider').value);
$('metBeats').onchange = () => { buildDots(); met.beat = 0; met.sub = 0; };
$('metSub').onchange = () => { met.sub = 0; };
$('metFollow').onchange = () => { if ($('metFollow').checked && sc) setMetBpm(sc.bpm, false); };
$('tap').onclick = () => {
  const now = performance.now();
  met.taps = met.taps.filter((t) => now - t < 2500); met.taps.push(now);
  if (met.taps.length >= 3) {
    const gaps = met.taps.slice(1).map((t, k) => t - met.taps[k]);
    setMetBpm(60000 / (gaps.reduce((a, b) => a + b, 0) / gaps.length));
    msg(`测出来大约是 ♩=${met.bpm}`, 'ok');
  } else msg('继续跟着节奏点…（至少点 3 下）');
};
buildDots();

/* ---------- 让她打一段 ---------- */
$('compose').onclick = async () => { stop(); await api.compose(''); };
api.onStatus(({ busy, text, err }) => {
  $('compose').disabled = !!busy;
  msg(text, err ? 'err' : busy ? '' : 'ok');
});
api.onLoad(async ({ title, text, play, mine }) => {
  stop();
  await refreshSaved(title);
  $('title').value = title; $('score').value = text; mineLoaded = !!mine;
  check();
  if (play) $('play').click();
});

/* ---------- 开始 ---------- */
(async () => {
  await refreshSaved('');
  if (!Object.keys(saved).length) {
    $('title').value = '一起出发的节奏（示例）';
    $('score').value = '♩=120 4/4 每格=1/16 鼓组=原声   // 示例：可以直接点“播放”\n\n吊镲|O---------------|----------------|\n踩镲|--x-x-x-x-x-x-x-|x-x-x-x-x-x-x---|\n军鼓|----O-------O---|----O--g----OoOo|\n底鼓|o-------o-o-----|o-------o-o-----|';
  } else $('score').value = '♩=100 4/4 每格=1/16 鼓组=原声\n\n踩镲|----------------|----------------|\n军鼓|----------------|----------------|\n底鼓|----------------|----------------|';
  setMetBpm(100, false);
  check();
})();

/* ---------- 写词窗口来要“当前作品”：鼓谱没有旋律，写不了歌词 ---------- */
api.onGetCurrent && api.onGetCurrent((reqId) => api.currentReply(reqId, { error: '架子鼓的鼓谱只有节奏、没有旋律，没法按它写歌词。可以在写词窗口里导入一首歌的音频来写。' }));
