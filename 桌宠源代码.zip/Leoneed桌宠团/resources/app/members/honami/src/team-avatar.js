'use strict';
/* 桌宠团：头像模式（不显示 Live2D 模型，只显示一个圆形头像）
 * 这个文件在 renderer.js 之后加载，和它共用同一个全局作用域：可以读到 app、model、settings、voicePlaying，
 * 合奏时还会收到 team-perform：跟着节奏做动作，主唱按人声对口型；
 * 也可以替换 layout / hitTest 这些顶层函数（renderer.js 里对它们的调用会走到新的版本）。 */
(function () {
  const team = window.teamAPI;
  if (!team) return;
  const SIZE = 150, BOTTOM = 14;
  const css = document.createElement('style');
  css.textContent = `
#teamAvatar{position:fixed;left:50%;bottom:${BOTTOM}px;width:${SIZE}px;height:${SIZE}px;margin-left:-${SIZE / 2}px;border-radius:50%;
  object-fit:cover;background:#2b2a33;box-shadow:0 4px 14px rgba(0,0,0,.35),0 0 0 3px rgba(255,255,255,.85);display:none;cursor:pointer;
  transition:transform .12s ease-out;user-select:none;-webkit-user-drag:none}
#teamAvatarName{position:fixed;left:50%;bottom:${BOTTOM - 10}px;transform:translateX(-50%);display:none;padding:1px 9px;border-radius:9px;
  background:rgba(32,30,40,.82);color:#fff;font:12px "Microsoft YaHei UI",sans-serif;pointer-events:none;white-space:nowrap}
body.team-avatar #teamAvatar,body.team-avatar #teamAvatarName{display:block}
body.team-avatar #teamAvatar.talk{transform:translateY(-3px) scale(1.03)}
#teamAvatarFallback{display:none}`;
  document.head.appendChild(css);
  const img = document.createElement('img');
  img.id = 'teamAvatar'; img.alt = ''; img.draggable = false;
  const tag = document.createElement('div');
  tag.id = 'teamAvatarName';
  document.body.appendChild(img); document.body.appendChild(tag);

  let on = false, info = null;

  async function refreshImage() {
    try { info = await team.avatar(); } catch (e) { info = null; }
    if (info && info.src) img.src = info.src;
    tag.textContent = (info && info.name) || '';
  }
  function setMode(v) {
    v = !!v;
    if (v === on) return;
    on = v;
    document.body.classList.toggle('team-avatar', on);
    if (typeof model !== 'undefined' && model) model.visible = !on;   // 模型照常更新动作，只是不画出来
    if (on) refreshImage();
    if (typeof layout === 'function') layout();
    try { if (app) app.render(); } catch (e) {}
  }

  // 排版：头像模式时，把“头顶”换成头像的上沿，气泡贴在头像上方
  const baseLayout = window.layout;
  window.layout = function () {
    baseLayout.apply(this, arguments);
    if (!on || !window.__layout) return;
    window.__layout.headTop = window.innerHeight - BOTTOM - SIZE;
    if (typeof placeBubble === 'function') placeBubble();
  };
  // 命中测试：头像模式时，模型不画，所以只看头像和原来的那些按钮、气泡
  const baseHit = window.hitTest;
  window.hitTest = function (x, y) {
    if (on) {
      const r = img.getBoundingClientRect();
      const cx = r.left + r.width / 2, cy = r.top + r.height / 2;
      if ((x - cx) ** 2 + (y - cy) ** 2 <= (r.width / 2 + 2) ** 2) return true;
    }
    return baseHit.apply(this, arguments);
  };
  // 头像模式下“摸头”判断：点在头像上半部分算头
  if (typeof window.isHead === 'function') {
    const baseIsHead = window.isHead;
    window.isHead = function (y) {
      if (!on) return baseIsHead.apply(this, arguments);
      const r = img.getBoundingClientRect();
      return y < r.top + r.height * 0.45;
    };
  }

  // 说话时头像轻轻跳一下
  setInterval(() => {
    if (!on) return;
    const talking = typeof voicePlaying !== 'undefined' && voicePlaying;
    img.classList.toggle('talk', !!talking && Math.floor(Date.now() / 140) % 2 === 0);
  }, 70);

  // 第一次显示模型时截一张头像存起来（之后头像模式、群聊窗口都用它）
  async function capture() {
    if (on || typeof model === 'undefined' || !model || !app || !window.__layout) return;
    const H = typeof HEAD !== 'undefined' ? HEAD : (typeof head === 'function' ? head() : null);   // eslint-disable-line no-undef
    if (!H) return;
    const s = window.__layout.s, res = app.renderer.resolution || 1;
    const cx = (model.x + H.x * s) * res, cy = (model.y + (H.y + (H.bottom - H.y) * 0.15) * s) * res;
    const r = Math.max(20, (H.bottom - H.y) * s * 1.55 * res);
    app.render();
    const c = document.createElement('canvas'); c.width = c.height = 256;
    const g = c.getContext('2d');
    g.drawImage(app.view, cx - r, cy - r, r * 2, r * 2, 0, 0, 256, 256);
    // 太空（模型还没淡入）就不存
    const d = g.getImageData(0, 0, 256, 256).data;
    let solid = 0; for (let i = 3; i < d.length; i += 64) if (d[i] > 200) solid++;
    if (solid < 300) return;
    const out = document.createElement('canvas'); out.width = out.height = 256;
    const o = out.getContext('2d');
    const bg = o.createLinearGradient(0, 0, 0, 256); bg.addColorStop(0, info && info.color ? info.color : '#3b3550'); bg.addColorStop(1, '#1d1b26');
    o.fillStyle = bg; o.fillRect(0, 0, 256, 256);
    o.drawImage(c, 0, 0);
    team.saveAvatar({ png: out.toDataURL('image/png'), outfit: typeof outfit !== 'undefined' ? outfit : '' });
  }

  async function start() {
    await refreshImage();
    let s = {};
    try { s = await window.petAPI.getSettings(); } catch (e) {}
    setMode(!!s.avatarMode);
    if (window.petAPI.onSettings) window.petAPI.onSettings((v) => { if (v && 'avatarMode' in v) setMode(!!v.avatarMode); });
    if (team.onAvatarChanged) team.onAvatarChanged(() => refreshImage());
    if (info && info.needCapture) {
      const tryCap = (n) => setTimeout(async () => { await capture(); refreshImage().then(() => { if (info && info.needCapture && n < 6) tryCap(n + 1); }); }, 2500 + n * 1500);
      tryCap(0);
    }
  }

  // 合奏：演奏时跟着节奏做动作；主唱（一歌）按人声的响度对口型
  let perf = null;
  function stopPerf() {
    if (!perf) return;
    clearInterval(perf.timer); cancelAnimationFrame(perf.raf);
    try { if (window.__pet) window.__pet.holdMouth(null); } catch (e) {}
    perf = null;
  }
  function perform(p) {
    stopPerf();
    if (!p || p.kind !== 'start') return;
    const P = window.__pet; if (!P) return;
    const my = perf = { timer: 0, raf: 0 };
    const t0 = Number(p.at) || Date.now(), dur = Math.max(1, Number(p.duration) || 0) * 1000;
    const move = () => { try { P.react({ t: '', m: p.mood || 'happy', a: 'music' }, { silent: true, hold: 4200 }); } catch (e) {} };
    setTimeout(() => { if (perf === my) move(); }, Math.max(0, t0 - Date.now()));
    my.timer = setInterval(() => { if (perf !== my) return; if (Date.now() - t0 > dur) { stopPerf(); return; } move(); }, 5200);
    const env = Array.isArray(p.env) && p.env.length ? p.env : null, rate = Number(p.envRate) || 50;
    if (env) {
      const tick = () => {
        if (perf !== my) return;
        const k = Math.floor((Date.now() - t0) / 1000 * rate);
        try { P.holdMouth(k >= 0 && k < env.length ? Math.min(1, env[k] * 1.1) : 0); } catch (e) {}
        if (k < env.length) my.raf = requestAnimationFrame(tick); else stopPerf();
      };
      my.raf = requestAnimationFrame(tick);
    }
  }
  if (team.onPerform) team.onPerform((p) => perform(p));
  window.__teamAvatar = { setMode, capture, perform, get on() { return on; } };
  window.addEventListener('load', () => setTimeout(start, 300));
})();
