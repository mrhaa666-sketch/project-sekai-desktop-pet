// 台词、心情、动作。对你的她：温柔、体贴、很会照顾人，说话轻轻的；偶尔有点慌张，也有自己坚持的地方。
// t = 台词，ja = 配音用的日语（空 = 不配音），m = 心情（决定表情），a = 动作（决定身体动作）。
// {name} 会替换成设置里的称呼（日语里换成「日语称呼」）。
'use strict';

// 表情代号表：代号 → [文件名, 说明]。文件在 model/faces/文件名.motion3.json（三套衣服都有）。
// 文件名保持英文，是为了解压时不会因为中文文件名出乱码；平时只用中文代号。
// 想加新表情：把文件放进三套衣服的 faces/，再在这里加一行。
window.FACES = {
  '平常': ['face_normal_01', '平常的脸，温和（默认）'],
  '平常2': ['face_normal_02', '平常，更柔和一点'],
  '平静': ['face_smallmouth_01', '平静，嘴很小'],
  '微笑1': ['face_smile_01', '浅浅的微笑'],
  '微笑2': ['face_smile_04', '温和的微笑'],
  '微笑3': ['face_smile_05', '轻松的微笑'],
  '温柔笑': ['face_ncsmile_01', '温柔地看着你笑'],
  '甜笑': ['face_smile_07', '甜甜地笑，脸有点红'],
  '温柔脸红': ['face_smile_06', '温柔地笑，脸红'],
  '脸红微笑': ['face_smile_08', '脸红红地笑'],
  '开心': ['face_smile_09', '很开心，脸红'],
  '笑眼': ['face_smile_03', '笑得眼睛弯弯的'],
  '眯眼笑': ['face_smile_02', '闭着眼笑，脸红'],
  '安心笑': ['face_nccloseeye_02', '闭着眼、放下心来的笑'],
  '咧嘴笑': ['face_e_01', '露出牙齿的笑'],
  '调皮1': ['face_play_01', '有点调皮'],
  '调皮2': ['face_play_02', '调皮地笑，脸红'],
  '闪亮': ['face_sparkling_01', '眼睛发亮（聊到喜欢的东西）'],
  '害羞1': ['face_shy_01', '害羞，脸红'],
  '害羞2': ['face_shy_02', '害羞，眉毛为难'],
  '害羞闭眼': ['face_shy_03', '害羞地闭上眼'],
  '苦笑': ['face_ossmile_05', '冒汗的苦笑'],
  '苦笑2': ['face_ossmile_04', '有点为难地笑，冒汗'],
  '尴尬笑': ['face_osncsmile_01', '尴尬地笑，冒汗'],
  '窘迫': ['face_ossad_01', '难为情，冒汗'],
  '窘迫2': ['face_ossad_02', '难为情，很没办法'],
  '窘迫闭眼': ['face_oscloseeye_04', '难为情地闭紧眼睛'],
  '慌张': ['face_ossurprise_01', '慌了，冒汗'],
  '冒汗生气': ['face_osangry_02', '又急又气，冒汗'],
  '闭眼': ['face_closeeye_01', '静静地闭着眼'],
  '闭眼微笑': ['face_closeeye_02', '闭着眼微笑，脸红'],
  '闭眼放松': ['face_closeeye_03', '闭眼，很放松'],
  '闭眼开心': ['face_closeeye_04', '闭着眼开心地笑'],
  '闭眼害羞': ['face_closeeye_05', '闭着眼，脸红'],
  '闭眼为难': ['face_closeeye_06', '闭着眼，有点为难'],
  '闭眼温柔': ['face_closeeye_07', '闭着眼温柔地笑'],
  '深呼吸': ['face_breath_01', '闭眼“哈——”地呼一口气'],
  '困': ['face_sleepy_01', '困了，眼睛快闭上'],
  '认真1': ['face_serious_01', '认真起来'],
  '认真2': ['face_serious_02', '认真，有点担心'],
  '惊讶1': ['face_surprise_01', '惊讶，眼睛睁圆'],
  '惊讶2': ['face_surprise_02', '惊讶，脸有点红'],
  '惊讶3': ['face_surprise_03', '有点意外'],
  '察觉': ['face_notice_01', '“啊”地注意到什么'],
  '张嘴': ['face_eat_01', '“啊——”地张开嘴'],
  '嚼': ['face_eat_02', '嘴里在吃东西'],
  '迷糊': ['face_baffling_01', '没弄明白，愣住'],
  '害怕1': ['face_scared_01', '害怕'],
  '害怕2': ['face_scared_02', '很害怕'],
  '吓一跳': ['face_scream_01', '吓得闭紧眼睛'],
  '困扰1': ['face_trouble_01', '困扰'],
  '困扰2': ['face_trouble_02', '困扰，有点慌'],
  '懊恼': ['face_chagrined_01', '懊恼、自责'],
  '担心': ['face_angry_04', '皱着眉担心你'],
  '难过1': ['face_sad_01', '难过'],
  '难过2': ['face_sad_02', '难过，脸红'],
  '难过3': ['face_sad_03', '难过，垂着眉'],
  '低头': ['face_lookdown_01', '眼睛往下看'],
  '移开视线': ['face_lookaway_01', '眼睛看向旁边'],
  '眼眶湿': ['face_cry_01', '眼眶湿了'],
  '含泪': ['face_cry_02', '含着泪'],
  '感动': ['face_cry_03', '感动得眼眶发红，脸红'],
  '快哭了': ['face_cry_04', '快要哭了'],
  '含泪笑': ['face_cry_05', '含着泪笑'],
  '哭': ['face_cry_06', '哭了，脸红'],
  '闭眼流泪': ['face_cry_07', '闭着眼掉眼泪'],
  '哭2': ['face_cry_08', '哭得很伤心'],
  '大哭1': ['face_ecry_01', '忍不住哭出来'],
  '大哭2': ['face_ecry_03', '哭得说不出话'],
  '不满': ['face_angry_01', '不满，皱眉'],
  '生气': ['face_angry_02', '生气'],
  '生气2': ['face_angry_03', '很生气'],
  '不快': ['face_disgust_01', '不快，皱眉'],
};

// 心情 → 表情 + 动作。
// faces：[表情代号, 强度]，强度 0~1（1 是完整的表情，小一点会更接近「平常」）。
// rare：偶尔才出现的表情，chance 是出现概率。
// actions：这个心情常用的身体动作；AI 没选动作时从这里挑。
window.MOODS = {
  calm:       { faces: [['平常', 1], ['平常2', 1]], rare: { chance: 0.3, faces: [['温柔笑', 0.7], ['微笑1', 0.6]] }, actions: ['none', 'nod', 'tilt'], desc: '平常、温和的样子（默认）' },
  smile:      { faces: [['微笑1', 0.9], ['微笑2', 0.9], ['温柔笑', 0.9], ['微笑3', 0.85]], actions: ['nod', 'tilt'], desc: '心情不错，温柔地笑' },
  happy:      { faces: [['开心', 0.9], ['笑眼', 0.9], ['眯眼笑', 0.85], ['闭眼开心', 0.85]], actions: ['glad', 'nod'], desc: '开心' },
  excited:    { faces: [['闪亮', 0.95], ['咧嘴笑', 0.85], ['开心', 0.9]], actions: ['glad', 'cheer'], desc: '兴奋、眼睛发亮（聊到做点心、Leo/need、打鼓时常有）' },
  warm:       { faces: [['温柔脸红', 0.9], ['安心笑', 0.9], ['闭眼温柔', 0.85], ['甜笑', 0.85]], actions: ['warm', 'nod'], desc: '被打动、心里暖暖的、放下心来' },
  moved:      { faces: [['感动', 0.9], ['含泪笑', 0.85]], actions: ['warm', 'look_down'], desc: '感动得快哭了（但是开心的）' },
  playful:    { faces: [['调皮1', 0.9], ['调皮2', 0.85]], actions: ['tilt', 'thumb'], desc: '小小地开个玩笑、逗你' },
  shy:        { faces: [['害羞1', 0.85], ['害羞2', 0.85], ['脸红微笑', 0.8], ['闭眼害羞', 0.85]], actions: ['shy', 'fidget'], desc: '害羞、不好意思' },
  flustered:  { faces: [['窘迫', 0.85], ['慌张', 0.85], ['窘迫闭眼', 0.85], ['尴尬笑', 0.85]], actions: ['shy', 'look_away'], desc: '被说中、慌了、很难为情' },
  think:      { faces: [['平静', 1], ['认真1', 0.6], ['移开视线', 0.6]], actions: ['think', 'tilt'], desc: '在想事情' },
  determined: { faces: [['认真1', 0.9], ['认真2', 0.8], ['微笑2', 0.8]], actions: ['resolve', 'cheer'], desc: '下定决心、有干劲（“我也会加油的”）' },
  yummy:      { faces: [['嚼', 0.9], ['眯眼笑', 0.85], ['甜笑', 0.85]], actions: ['glad', 'nod'], desc: '吃到好吃的、做点心很顺利，很幸福' },
  sad:        { faces: [['难过1', 0.75], ['难过3', 0.75], ['低头', 0.7]], actions: ['look_down', 'sigh'], desc: '低落、难过' },
  hurt:       { faces: [['眼眶湿', 0.8], ['快哭了', 0.75], ['含泪', 0.75]], actions: ['look_down', 'sigh'], desc: '受伤、很难受' },
  guilty:     { faces: [['懊恼', 0.85], ['闭眼为难', 0.8]], actions: ['look_down', 'trouble'], desc: '自责、觉得是自己不好' },
  worried:    { faces: [['担心', 0.85], ['认真2', 0.85], ['困扰1', 0.8]], actions: ['trouble', 'tilt'], desc: '担心你（她很容易担心别人）' },
  troubled:   { faces: [['困扰1', 0.8], ['困扰2', 0.8], ['苦笑', 0.85], ['苦笑2', 0.8]], actions: ['trouble', 'shake'], desc: '困扰、为难' },
  surprised:  { faces: [['惊讶1', 0.85], ['惊讶2', 0.9], ['惊讶3', 0.9], ['察觉', 0.85]], actions: ['tilt', 'nod'], desc: '吃惊、意外' },
  scared:     { faces: [['害怕1', 0.85], ['害怕2', 0.8], ['吓一跳', 0.85]], actions: ['shy', 'trouble'], desc: '害怕、被吓到（比如鬼故事）' },
  sleepy:     { faces: [['困', 1], ['闭眼', 1]], actions: ['sleep'], desc: '困了' },
  sulky:      { faces: [['不满', 0.7], ['不快', 0.65], ['冒汗生气', 0.7]], actions: ['shake', 'sigh', 'look_away'], desc: '有点不高兴（“真是的……”）' },
  angry:      { faces: [['生气', 0.9], ['生气2', 0.85], ['不满', 1]], actions: ['angry', 'arms', 'shake'], desc: '生气（她很少生气，真生气时会很认真地说你）' },
};

// 动作 → 身体动作（随机挑一个）。
// 同一个动作准备了几种站姿下的版本：桌宠会优先挑和她现在站姿一样的那个，衔接不会突然换手、换姿势。
// 张开双臂、跳起来、身体大幅前倾的动作都不用（会伸出窗口或上下移动）。
window.ACTIONS = {
  none:      { bodies: [], desc: '不做动作' },
  nod:       { bodies: ['w-normal16-nod', 'w-noromal16-nod', 'w-normal15-nod', 'w-normal03-nod', 'w-normal07-nod', 'w-normal17-nod', 'w-cool13-nod'], desc: '点头' },
  tilt:      { bodies: ['w-normal16-tilthead', 'w-noromal16-tilthead', 'w-normal15-tilthead', 'w-normal03-tilthead', 'w-normal07-tilthead', 'w-normal17-tilthead'], desc: '歪头' },
  think:     { bodies: ['w-adult05-think', 'w-cool13-tilthead', 'w-normal03-tiltheadB', 'w-normal07-tiltheadB'], desc: '想事情（手托下巴、抱臂歪头）' },
  glad:      { bodies: ['w-normal01-glad', 'w-adult12-glad', 'w-cute11-glad'], desc: '开心地双手合在胸前' },
  cheer:     { bodies: ['w-normal01-guts', 'w-happy11-guts', 'w-cool02-guts'], desc: '握拳打气（“一起加油吧”）' },
  thumb:     { bodies: ['w-cool01-thumb', 'w-cool02-thumb'], desc: '竖大拇指（“很棒”）' },
  resolve:   { bodies: ['w-normal01-purpose', 'w-happy02-purpose'], desc: '握住手、下定决心' },
  warm:      { bodies: ['w-normal03-relief', 'w-normal04-relief', 'w-adult12-relief'], desc: '手按在胸口（安心、被打动）' },
  shy:       { bodies: ['w-normal15-shy', 'w-normal03-blushed', 'w-normal04-blushed', 'w-pure12-shy'], desc: '害羞地缩一下' },
  fidget:    { bodies: ['w-normal17-fidget', 'w-pure12-fidget'], desc: '手指绞在一起，有点不好意思' },
  greet:     { bodies: ['w-normal15-greeting'], desc: '打招呼、轻轻鞠一躬' },
  look_down: { bodies: ['w-normal07-sad', 'w-normal08-sad', 'w-cool16-sad', 'w-happy16-sad'], desc: '垂下视线（低落）' },
  sigh:      { bodies: ['w-normal07-sigh', 'w-cool13-sigh', 'w-happy09-sigh'], desc: '叹气' },
  trouble:   { bodies: ['w-normal03-trouble', 'w-normal04-trouble', 'w-adult05-trouble'], desc: '为难、担心' },
  shake:     { bodies: ['w-normal16-shakehead', 'w-noromal16-shakehead', 'w-normal15-shakehead', 'w-normal03-shakehead', 'w-normal07-shakehead', 'w-normal17-shakehead', 'w-cool13-shakehead'], desc: '摇头' },
  look_away: { bodies: ['w-normal15-lookaround', 'w-normal03-lookleft', 'w-normal03-lookright'], desc: '移开视线、看看旁边' },
  arms:      { bodies: ['w-cool13-sigh', 'w-cool13-shakehead'], desc: '抱起胳膊' },
  angry:     { bodies: ['w-normal16-angry', 'w-noromal16-angry', 'w-happy09-angry'], desc: '生气' },
  music:     { bodies: ['w-normal16-nod', 'w-happy16-nod', 'w-normal15-nod', 'w-normal16-tilthead'], desc: '跟着节奏轻轻点头（听歌、打鼓时）' },
  sleep:     { bodies: ['w-adult15-sleep'], desc: '打瞌睡' },
};


// AI 直接点名表情代号时的强度
window.FACE_STRENGTH_DEFAULT = 0.85;
// 脸上的阴影（ParamFaceShadow）一律不加
window.SHADOW_FACES = new Set([]);
window.FACE_STRENGTH_FULL = new Set(['平常', '平常2', '平静', '闭眼', '困', '深呼吸']);

window.LINES = {
  // 没接聊天模型时，凌晨一点和纪念日用的固定台词
  nightcord: [{ t: '{name}，已经一点了哦。再不睡的话，明天会没精神的。', ja: '{name}、もう一時だよ。そろそろ寝ないと、明日元気出ないよ。', m: 'worried', a: 'tilt' }],
  birthdayHonami: [{ t: '今天是我的生日。……{name}还记得，我真的很开心。谢谢你。', ja: '今日、私の誕生日なんだ。……{name}が覚えててくれて、すごく嬉しい。ありがとう。', m: 'warm', a: 'warm' }],
  birthdayUser: [{ t: '{name}，生日快乐。我烤了蛋糕哦……虽然只能在心里给你了。', ja: '{name}、お誕生日おめでとう。ケーキ焼いたんだよ……心の中でだけど、ね。', m: 'happy', a: 'glad' }],
  anniversary: [{ t: '今天是我们的纪念日呢。……能和{name}在一起，真好。', ja: '今日は私たちの記念日だね。……{name}と一緒にいられて、よかった。', m: 'warm', a: 'warm' }],
  // 你用合成器打鼓给她听
  synthListen: [
    { t: '嗯，我在听哦。节奏很稳呢。', ja: 'うん、聴いてるよ。リズム、すごく安定してるね。', m: 'smile', a: 'music' },
    { t: '是{name}编的节奏吗？……这里的加花好帅气。', ja: '{name}が作ったリズム？……ここのフィル、かっこいいね。', m: 'excited', a: 'glad' },
    { t: '听着听着，手也想跟着动起来了。', ja: '聴いてたら、手が動きたくなっちゃった。', m: 'happy', a: 'music' },
    { t: '军鼓的位置放得刚刚好，很舒服的律动。', ja: 'スネアの位置がちょうどよくて、気持ちいいグルーヴだね。', m: 'smile', a: 'nod' },
  ],
  outfitCasual: [
    { t: '换好衣服了。……嗯，这样放松多了。', ja: '着替えたよ。……うん、楽になった。', m: 'smile', a: 'nod' },
    { t: '今天辛苦了。要不要喝杯热茶，休息一下？', ja: '今日もお疲れさま。温かいお茶でも飲んで、ひと休みしない？', m: 'warm', a: 'warm' },
    { t: '换下来了。……待会儿想做点小点心呢。', ja: '着替えちゃった。……あとで、ちょっとお菓子作りたいな。', m: 'smile', a: 'tilt' },
  ],
  outfitUniform: [
    { t: '该去学校了。……今天也要好好加油。', ja: 'そろそろ学校だね。……今日も頑張ろう。', m: 'determined', a: 'nod' },
    { t: '制服换好了。手帕和便当也带上了。', ja: '制服着たよ。ハンカチとお弁当も持ったし。', m: 'smile', a: 'nod' },
  ],
  outfitUnit: [
    { t: '今天是练习的日子。……我去和大家会合了。', ja: '今日は練習の日。……みんなと合流してくるね。', m: 'determined', a: 'resolve' },
    { t: '换上演出服了。今天也要好好地把节奏稳住。', ja: 'ステージ衣装、着たよ。今日もしっかりリズムを支えなきゃ。', m: 'determined', a: 'cheer' },
  ],
  greet: {
    morning: [
      { t: '早上好，{name}。昨晚睡得好吗？', ja: 'おはよう、{name}。昨日はよく眠れた？', m: 'smile', a: 'greet' },
      { t: '早。……早饭有好好吃吗？', ja: 'おはよう。……朝ごはん、ちゃんと食べた？', m: 'calm', a: 'tilt' },
    ],
    day: [
      { t: '啊，{name}。你来了呀。', ja: 'あ、{name}。来てくれたんだ。', m: 'happy', a: 'nod' },
      { t: '{name}……正好在想你呢。', ja: '{name}……ちょうど会いたいなって思ってたんだ。', m: 'shy', a: 'shy' },
    ],
    evening: [
      { t: '欢迎回来。今天怎么样？', ja: 'おかえりなさい。今日はどうだった？', m: 'smile', a: 'tilt' },
      { t: '辛苦了，{name}。……我一直在等你哦。', ja: 'お疲れさま、{name}。……ずっと待ってたよ。', m: 'warm', a: 'warm' },
    ],
    night: [
      { t: '这么晚了……{name}也还没睡呀。', ja: 'こんな時間……{name}もまだ起きてたんだね。', m: 'worried', a: 'tilt' },
      { t: '晚上好。就聊一会儿，然后要早点睡哦。', ja: 'こんばんは。少しだけお話ししたら、ちゃんと寝ようね。', m: 'smile', a: 'nod' },
    ],
  },

  // 点头部
  head: [
    { t: '……诶？摸、摸头吗？', ja: '……え？な、なでなで？', m: 'flustered', a: 'shy' },
    { t: '有点不好意思……不过，很安心。', ja: 'ちょっと恥ずかしいけど……でも、安心する。', m: 'shy', a: 'shy' },
    { t: '平时都是我照顾别人……被这样摸摸头，感觉好新鲜。', ja: 'いつもは私がお世話する側だから……なでてもらうの、なんだか新鮮。', m: 'warm', a: 'warm' },
    { t: '头发会乱掉的啦……真是的。', ja: '髪、くしゃくしゃになっちゃうよ……もう。', m: 'shy', a: 'fidget' },
  ],

  // 点身体
  body: [
    { t: '怎么了？', ja: 'どうしたの？', m: 'calm', a: 'tilt' },
    { t: '嗯，我在听哦。', ja: 'うん、聞いてるよ。', m: 'smile', a: 'nod' },
    { t: '{name}，今天过得怎么样？', ja: '{name}、今日はどうだった？', m: 'smile', a: 'tilt' },
    { t: '在忙吗？那我在旁边安安静静地陪着你。', ja: '忙しい？じゃあ、横で静かにしてるね。', m: 'calm', a: 'nod' },
    { t: '有什么烦恼的话，跟我说说看吧。', ja: '何か悩んでることがあったら、話してみて。', m: 'worried', a: 'tilt' },
    { t: '最近在练一段新的加花。练好了给你听。', ja: '最近、新しいフィルを練習してるんだ。叩けるようになったら聴かせるね。', m: 'excited', a: 'cheer' },
    { t: '这周末想烤苹果派……{name}要不要尝尝？', ja: '今週末、アップルパイ焼こうかなって……{name}も食べる？', m: 'excited', a: 'glad' },
    { t: '和{name}在一起的时候，心里很平静。', ja: '{name}といると、心が落ち着くんだ。', m: 'warm', a: 'warm' },
    { t: '累了的话，休息一下吧。我不会走的。', ja: '疲れたら、少し休もう。私はどこにも行かないから。', m: 'warm', a: 'nod' },
    { t: '……再这样待一会儿，可以吗？', ja: '……もう少しだけ、こうしてていい？', m: 'shy', a: 'fidget' },
    { t: '{name}，饭有好好吃吗？不可以只吃零食哦。', ja: '{name}、ご飯ちゃんと食べた？お菓子だけじゃだめだよ。', m: 'worried', a: 'tilt' },
    { t: '房间整理好了吗？……要不要我帮你一起收拾？', ja: 'お部屋、片付いてる？……一緒に片付けよっか？', m: 'smile', a: 'tilt' },
  ],

  // 连续点很多下（越点越不高兴）
  poke: [
    { t: '那、那个，{name}？戳太多下了啦。', ja: 'あ、あの、{name}？つつきすぎだよ。', m: 'troubled', a: 'trouble' },
    { t: '等、等一下……好痒。', ja: 'ちょ、ちょっと待って……くすぐったいよ。', m: 'flustered', a: 'shy' },
  ],
  pokeAngry: [
    { t: '{name}。……我真的要生气了哦。', ja: '{name}。……本当に怒るよ。', m: 'angry', a: 'angry' },
    { t: '说了不可以了吧？', ja: 'だめって言ったよね？', m: 'sulky', a: 'arms' },
  ],
  // 生气时偶尔苦笑着数落你
  pokeMask: [
    { t: '真是的……{name}有时候真像小孩子。', ja: 'もう……{name}って、たまに子どもみたいだね。', m: 'troubled', a: 'sigh' },
    { t: '好啦好啦，陪你玩就是了。', ja: 'はいはい、遊んであげるから。', m: 'troubled', a: 'shake' },
  ],
  // 刚生过气时摸她
  stillSulky: [
    { t: '……现在先不理你。', ja: '……今はちょっと、知らない。', m: 'sulky', a: 'look_away' },
    { t: '……再等一下。我还没消气呢。', ja: '……もうちょっと待って。まだ怒ってるんだから。', m: 'sulky', a: 'arms' },
  ],

  // 拖动后放下
  drop: [
    { t: '这里吗？嗯，好。', ja: 'ここ？うん、わかった。', m: 'calm', a: 'nod' },
    { t: '哇……突然拎起来，吓了我一跳。', ja: 'わっ……急に持ち上げるから、びっくりした。', m: 'surprised', a: 'shake' },
  ],

  // 待机时的自言自语：按时段、衣服挑；同一句近期不会重复（见 renderer.js 的 nextIdleLine）
  // when: morning 5–11 / day 11–17 / evening 17–23 / night 23–5；不写就是什么时候都行
  // outfit: uniform 校服 / unit 队服 / casual 常服；不写就是都行
  idle: [
    { t: '……', ja: '', m: 'calm', a: 'look_away' },
    { t: '副歌前的加花……再简单一点，会不会更好。', ja: 'サビ前のフィル……もう少しシンプルにしたほうがいいかな。', m: 'think', a: 'think' },
    { t: '你忙的话，我就安静地待着。', ja: '忙しいなら、静かにしてるね。', m: 'smile', a: 'nod' },
    { t: '下次练习带什么点心好呢……曲奇？还是玛芬？', ja: '次の練習、何のお菓子持っていこうかな……クッキー？マフィン？', m: 'think', a: 'tilt' },
    { t: '咲希又说想吃我做的点心了。……嗯，下次多做一点吧。', ja: '咲希ちゃん、また私のお菓子食べたいって。……うん、今度は多めに作ろう。', m: 'smile', a: 'tilt' },
    { t: '志步说“太甜了”，可还是全部吃完了。……嘻嘻。', ja: '志歩ちゃん、「甘すぎ」って言いながら、全部食べてくれたんだ。……ふふっ。', m: 'happy', a: 'glad' },
    { t: '一歌又练到很晚了吧。……要提醒她早点休息才行。', ja: '一歌ちゃん、また遅くまで練習してるのかな。……早く休むように言わなきゃ。', m: 'worried', a: 'trouble' },
    { t: '……这样待着，很舒服呢。', ja: '……こうしてるの、いいな。', m: 'warm', a: 'warm' },
    { t: '鼓棒好像该换新的了。尖端有点磨平了。', ja: 'そろそろスティック、新しいのにしなきゃ。先がちょっとすり減ってる。', m: 'think', a: 'tilt' },
    { t: '打鼓的时候，看着大家的背影，会觉得很安心。', ja: 'ドラムを叩いてるとき、みんなの背中が見えると安心するんだ。', m: 'warm', a: 'warm' },
    { t: '……刚才想到哪了来着，一下子忘了。', ja: '……さっき何考えてたんだっけ。忘れちゃった。', m: 'think', a: 'look_away' },
    { t: '不说话也没关系哦。我在这里。', ja: '話さなくても大丈夫だよ。私はここにいるから。', m: 'warm', a: 'nod' },
    { t: '盯着屏幕太久，眼睛会累的。', ja: '画面ばっかり見てると、目が疲れちゃうよ。', m: 'worried', a: 'tilt' },
    { t: '……你刚才是不是叹气了？', ja: '……今、ため息ついた？', m: 'worried', a: 'tilt' },
    { t: '早上的空气凉凉的，很舒服。', ja: '朝の空気、ひんやりして気持ちいいね。', m: 'smile', a: 'none', when: 'morning' },
    { t: '便当做好了……今天的煎蛋卷，做得很漂亮。', ja: 'お弁当できた……今日の卵焼き、上手に巻けたんだ。', m: 'happy', a: 'glad', when: 'morning' },
    { t: '早饭吃了吗？……不吃的话，上午会撑不住的哦。', ja: '朝ごはん食べた？……食べないと、午前中もたないよ。', m: 'worried', a: 'tilt', when: 'morning' },
    { t: '午休了。……大家的便当，今天会是什么呢。', ja: 'お昼休み。……みんなのお弁当、今日は何かな。', m: 'smile', a: 'tilt', when: 'day', outfit: 'uniform' },
    { t: '下午的阳光，暖洋洋的。', ja: '午後の日差し、ぽかぽかしてるね。', m: 'smile', a: 'look_away', when: 'day' },
    { t: '……这个时间，人很容易犯困呢。', ja: '……この時間って、つい眠くなっちゃうよね。', m: 'sleepy', a: 'tilt', when: 'day' },
    { t: '练习结束了。……今天大家的节奏，很整齐。', ja: '練習終わり。……今日はみんなのリズム、すごく揃ってた。', m: 'happy', a: 'glad', when: 'day', outfit: 'unit' },
    { t: '打完鼓手腕有点酸……回去要好好拉伸。', ja: 'ドラム叩いたら手首がちょっと疲れちゃった……帰ったらストレッチしなきゃ。', m: 'troubled', a: 'trouble', outfit: 'unit' },
    { t: '放学了。……今天也辛苦了。', ja: '学校終わったね。……今日もお疲れさま。', m: 'smile', a: 'nod', when: 'evening', outfit: 'casual' },
    { t: '天黑得越来越早了。', ja: '暗くなるのが、どんどん早くなってるね。', m: 'calm', a: 'look_away', when: 'evening' },
    { t: '晚饭吃什么好呢……{name}想吃什么？', ja: '晩ごはん、何にしようかな……{name}は何が食べたい？', m: 'think', a: 'tilt', when: 'evening' },
    { t: '作业写完了。……睡前再用练习垫敲一会儿吧。', ja: '宿題終わった。……寝る前に、少しだけ練習パッド叩こう。', m: 'determined', a: 'cheer', when: 'evening' },
    { t: '……已经这么晚了。你还不睡吗？', ja: '……もうこんな時間。まだ寝ないの？', m: 'worried', a: 'tilt', when: 'night' },
    { t: '夜里很安静。……这种时候，节拍器的声音听得特别清楚。', ja: '夜って静かだよね。……メトロノームの音が、よく聞こえるんだ。', m: 'calm', a: 'think', when: 'night' },
    { t: '明天还要早起的话……别熬太晚哦。', ja: '明日も早いなら……あんまり夜更かししないでね。', m: 'worried', a: 'nod', when: 'night' },
    { t: '……这身衣服很舒服。', ja: '……この服、楽でいいな。', m: 'smile', a: 'none', outfit: 'casual' },
    { t: '制服的领巾，今天好像系歪了。……没事吧？', ja: '制服のスカーフ、今日ちょっと曲がってるかも。……大丈夫かな？', m: 'troubled', a: 'look_away', outfit: 'uniform' },
  ],

  water: [
    { t: '{name}，喝点水吧。我看着你喝哦。', ja: '{name}、お水飲もう。ちゃんと見てるからね。', m: 'smile', a: 'tilt' },
    { t: '好久没喝水了吧？……去倒一杯吧。', ja: 'しばらくお水飲んでないでしょ？……一杯ついでおいで。', m: 'worried', a: 'tilt' },
  ],

  rest: [
    { t: '看屏幕太久了。站起来活动一下吧。', ja: '画面見すぎだよ。ちょっと立って体を動かそう。', m: 'worried', a: 'tilt' },
    { t: '休息五分钟吧。我泡好茶等你。', ja: '五分だけ休憩しよう。お茶いれて待ってるね。', m: 'smile', a: 'nod' },
  ],

  sleep: [
    { t: '已经很晚了。……{name}，去睡吧。', ja: 'もう遅いよ。……{name}、そろそろ寝よう。', m: 'worried', a: 'sigh' },
    { t: '熬夜对身体不好的。……我是认真在担心你哦。', ja: '夜更かしは体に悪いよ。……本気で心配してるんだからね。', m: 'worried', a: 'trouble' },
    { t: '剩下的明天再做吧。晚安，{name}。', ja: '続きはまた明日にしよう。おやすみ、{name}。', m: 'sleepy', a: 'sleep' },
  ],

  doze: [{ t: '……有点困了。', ja: '……ちょっと、眠くなってきちゃった。', m: 'sleepy', a: 'sleep' }],
  wake: [{ t: '……啊。{name}，你回来了。', ja: '……あ。{name}、おかえり。', m: 'surprised', a: 'tilt' }],

  // 聊天时没接 API
  noApi: [{ t: '……好像还没连上呢。右键 → 设置，填好 API 就可以聊天了。', m: 'troubled', a: 'tilt' }],
  apiError: [{ t: '……刚才没听清。能再说一次吗？', ja: '……ごめんね、今のよく聞こえなかった。もう一回言ってくれる？', m: 'troubled', a: 'tilt' }],
};

// 平时站着的姿势和表情（双手自然垂下）
window.IDLE = { b: 'w-normal16-pose', f: '平常' };

// 站姿：每个身体动作开始和结束时更接近哪种站姿（按手臂、手、腿的参数算出来的）。
// 桌宠据此挑动作：同一站姿的版本优先；动作做完就停在它结束时的站姿上，不会突然跳回别的姿势。
window.HOME_STANCE = 'w-normal16';
window.MOTION_STANCE = {
  'w-adult05-think': ['w-adult05', 'w-adult05'],
  'w-adult05-trouble': ['w-adult05', 'w-adult05'],
  'w-adult12-glad': ['w-adult12', 'w-adult12'],
  'w-adult12-relief': ['w-adult12', 'w-adult12'],
  'w-adult15-sleep': ['w-cool16', 'w-cool16'],
  'w-cool01-thumb': ['w-happy02', 'w-cute02'],
  'w-cool02-guts': ['w-happy02', 'w-cute02'],
  'w-cool02-thumb': ['w-normal01', 'w-cute01'],
  'w-cool13-nod': ['w-cool13', 'w-cool13'],
  'w-cool13-shakehead': ['w-cool13', 'w-cool13'],
  'w-cool13-sigh': ['w-cool13', 'w-cool13'],
  'w-cool13-tilthead': ['w-cool13', 'w-cool13'],
  'w-cool16-sad': ['w-cool16', 'w-cool16'],
  'w-cute11-glad': ['w-cute11', 'w-cute11'],
  'w-happy02-purpose': ['w-happy02', 'w-happy02'],
  'w-happy09-angry': ['w-cool09', 'w-cool09'],
  'w-happy09-sigh': ['w-cool09', 'w-cool09'],
  'w-happy11-guts': ['w-happy11', 'w-happy11'],
  'w-happy16-nod': ['w-normal16', 'w-normal16'],
  'w-happy16-sad': ['w-normal16', 'w-normal16'],
  'w-happy16-tilthead': ['w-normal16', 'w-normal16'],
  'w-normal01-glad': ['w-normal15', 'w-normal15'],
  'w-normal01-guts': ['w-normal15', 'w-normal15'],
  'w-normal01-purpose': ['w-normal15', 'w-normal07'],
  'w-normal03-blushed': ['w-normal03', 'w-normal03'],
  'w-normal03-lookleft': ['w-normal03', 'w-normal03'],
  'w-normal03-lookright': ['w-normal03', 'w-normal03'],
  'w-normal03-nod': ['w-normal03', 'w-normal03'],
  'w-normal03-relief': ['w-normal03', 'w-normal03'],
  'w-normal03-shakehead': ['w-normal03', 'w-normal03'],
  'w-normal03-tilthead': ['w-normal03', 'w-normal03'],
  'w-normal03-tiltheadB': ['w-normal03', 'w-normal03'],
  'w-normal03-trouble': ['w-normal03', 'w-normal03'],
  'w-normal0316-tilthead': ['w-normal03', 'w-normal16'],
  'w-normal04-blushed': ['w-normal04', 'w-normal04'],
  'w-normal04-relief': ['w-normal04', 'w-normal04'],
  'w-normal04-trouble': ['w-normal04', 'w-normal04'],
  'w-normal07-nod': ['w-normal07', 'w-normal07'],
  'w-normal07-sad': ['w-normal07', 'w-normal07'],
  'w-normal07-shakehead': ['w-normal07', 'w-normal07'],
  'w-normal07-sigh': ['w-normal07', 'w-normal07'],
  'w-normal07-tilthead': ['w-normal07', 'w-normal07'],
  'w-normal07-tiltheadB': ['w-normal07', 'w-normal07'],
  'w-normal08-sad': ['w-normal08', 'w-normal08'],
  'w-normal15-greeting': ['w-normal15', 'w-normal15'],
  'w-normal15-lookaround': ['w-normal15', 'w-normal15'],
  'w-normal15-nod': ['w-normal15', 'w-normal15'],
  'w-normal15-shakehead': ['w-normal15', 'w-normal15'],
  'w-normal15-shy': ['w-normal15', 'w-normal15'],
  'w-normal15-tilthead': ['w-normal15', 'w-normal15'],
  'w-normal1503-tilthead': ['w-normal15', 'w-normal16'],
  'w-normal16-angry': ['w-normal16', 'w-normal16'],
  'w-normal16-nod': ['w-normal16', 'w-normal16'],
  'w-normal16-shakehead': ['w-normal16', 'w-normal16'],
  'w-normal16-tilthead': ['w-normal16', 'w-normal16'],
  'w-normal1603-tilthead': ['w-normal16', 'w-normal03'],
  'w-normal1605-tilthead': ['w-normal16', 'w-normal15'],
  'w-normal17-fidget': ['w-normal17', 'w-normal17'],
  'w-normal17-nod': ['w-normal17', 'w-normal17'],
  'w-normal17-shakehead': ['w-normal17', 'w-normal17'],
  'w-normal17-tilthead': ['w-normal17', 'w-normal17'],
  'w-noromal16-angry': ['w-normal16', 'w-normal16'],
  'w-noromal16-nod': ['w-normal16', 'w-normal16'],
  'w-noromal16-shakehead': ['w-normal16', 'w-normal16'],
  'w-noromal16-tilthead': ['w-normal16', 'w-normal16'],
  'w-pure12-fidget': ['w-pure12', 'w-pure12'],
  'w-pure12-shy': ['w-pure12', 'w-pure12'],
};

// 待机小动作（不说话）：按现在的站姿挑。包括几个“换站姿”的动作，让她偶尔自然地换一下姿势。
window.IDLE_MOVES = {
  'w-normal16': ['w-normal16-tilthead', 'w-noromal16-tilthead', 'w-happy16-tilthead', 'w-normal1603-tilthead', 'w-normal1605-tilthead'],
  'w-normal03': ['w-normal03-tilthead', 'w-normal03-lookleft', 'w-normal03-lookright', 'w-normal0316-tilthead'],
  'w-normal15': ['w-normal15-tilthead', 'w-normal15-lookaround', 'w-normal1503-tilthead'],
  'w-normal07': ['w-normal07-tilthead', 'w-normal07-nod'],
  'w-normal17': ['w-normal17-tilthead'],
};
