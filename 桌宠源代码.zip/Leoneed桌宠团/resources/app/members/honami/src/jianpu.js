'use strict';
/* 简谱解析 + 电子琴音色合成 + 五线谱
   简谱写法：
     1–7 音，0 休止，- 把前一个音延长一拍
     后面加 ' 高八度（可以叠加 1''），加 , 低八度（5,,）
     前面加 # 升半音，b 降半音
     后面加 _ 时值减半（1_ 半拍，1__ 四分之一拍），加 . 附点（×1.5）
     [1 3 5] 几个音一起按，后面同样可以加 _ . -
     | 小节线
     开头写 1=C、1=bE、1=F#、4/4、♩=90（也可以写 速度=90 或 bpm=90）、音色=电子琴 / 电钢琴 / 风琴 / 合成器、伴奏=流行 / 分解 / 柱式 / 长音
     另起一行写「和弦：| C | G | Am F |」：按小节配和弦，自动加电子琴伴奏（左手低音 + 右手和弦）
     // 后面是注释
   五线谱的音名写法（会看五线谱的话可以直接这样写，和简谱可以混着用）：
     C4 是中央 C，D#4 / Eb4 带升降号，数字是第几个八度；时值写法和简谱一样（C4_ 半拍，G4 - 两拍）
   五线谱：toStaff() 把谱子排成小节、音符（全/二分/四分/八分/十六分、附点、连音线、临时记号），合成器窗口画出来；
     toMusicXML() 导出 MusicXML，可以用 MuseScore 等打谱软件打开
*/
(function (root) {
  const KEYS = { C: 0, D: 2, E: 4, F: 5, G: 7, A: 9, B: 11 };
  const DEG = [0, 0, 2, 4, 5, 7, 9, 11];   // 1–7 在大调里离主音几个半音
  const LETTER_PC = [0, 2, 4, 5, 7, 9, 11]; // C D E F G A B
  const LETTERS = 'CDEFGAB';
  const LOW = 21, HIGH = 108;               // 88 键：A0–C8
  const TONES = { keys: '电子琴', epiano: '电钢琴', organ: '风琴', synth: '合成器' };
  const TONE_ALIAS = { 电子琴: 'keys', 键盘: 'keys', keys: 'keys', keyboard: 'keys', 电钢琴: 'epiano', 电钢: 'epiano', epiano: 'epiano', 风琴: 'organ', 管风琴: 'organ', organ: 'organ', 合成器: 'synth', 合成: 'synth', synth: 'synth' };
  const STYLES = { pop: '流行', arp: '分解', block: '柱式', pad: '长音' };
  const STYLE_ALIAS = { 流行: 'pop', pop: 'pop', 分解: 'arp', 琶音: 'arp', arp: 'arp', 柱式: 'block', block: 'block', 长音: 'pad', 铺底: 'pad', pad: 'pad' };
  const DEFAULT_STYLE = { keys: 'pop', epiano: 'arp', organ: 'pad', synth: 'pop' };

  // 全角符号、中文标点换成半角（一个字符换一个字符，位置不变，方便高亮）
  function normalize(s) {
    return String(s).replace(/[’‘＇′`´]/g, "'").replace(/[，、]/g, ',').replace(/[｜]/g, '|')
      .replace(/[—－–]/g, '-').replace(/[＿]/g, '_').replace(/[＃♯]/g, '#').replace(/[♭]/g, 'b')
      .replace(/[．·•]/g, '.').replace(/[［【]/g, '[').replace(/[］】]/g, ']').replace(/＝/g, '=')
      .replace(/[０-９]/g, (c) => String.fromCharCode(c.charCodeAt(0) - 0xfee0))
      .replace(/[Ａ-Ｇ]/g, (c) => String.fromCharCode(c.charCodeAt(0) - 0xfee0));
  }
  const blank = (m) => m.replace(/[^\n]/g, ' ');

  /* ---------- 调号：每个调的升降号个数（五线谱用） ---------- */
  // 主音的音级 → [调号（正数是升号个数，负数是降号个数）, 主音字母]
  function keyInfo(tonicPc, preferSharp) {
    const T = { 0: [0, 'C'], 7: [1, 'G'], 2: [2, 'D'], 9: [3, 'A'], 4: [4, 'E'], 11: [5, 'B'], 5: [-1, 'F'], 10: [-2, 'B'], 3: [-3, 'E'], 8: [-4, 'A'], 1: [-5, 'D'] };
    if (tonicPc === 6) return preferSharp ? { fifths: 6, letter: 'F' } : { fifths: -6, letter: 'G' };
    if (tonicPc === 1 && preferSharp) return { fifths: 7, letter: 'C' };
    const [fifths, letter] = T[tonicPc];
    return { fifths, letter };
  }
  const SHARP_ORDER = 'FCGDAEB', FLAT_ORDER = 'BEADGCF';
  // 调号里每个字母默认升 / 降多少
  function keyAlters(fifths) {
    const a = { C: 0, D: 0, E: 0, F: 0, G: 0, A: 0, B: 0 };
    if (fifths > 0) for (let i = 0; i < fifths; i++) a[SHARP_ORDER[i]] = 1;
    if (fifths < 0) for (let i = 0; i < -fifths; i++) a[FLAT_ORDER[i]] = -1;
    return a;
  }

  /* ---------- 头部信息：速度、拍号、调、音色、伴奏 ---------- */
  function readHeader(body, o) {
    body = body.replace(/\/\/[^\n]*/g, blank);
    body = body.replace(/(?:音色|tone)\s*[=:：]\s*([一-龥A-Za-z]+)/g, (m, v) => { if (TONE_ALIAS[v]) o.tone = TONE_ALIAS[v]; else o.badTone = v; return blank(m); });
    body = body.replace(/(?:伴奏|style)\s*[=:：]\s*([一-龥A-Za-z]+)/g, (m, v) => { if (STYLE_ALIAS[v]) o.style = STYLE_ALIAS[v]; else o.badStyle = v; return blank(m); });
    body = body.replace(/1\s*=\s*([#b]?)([A-Ga-g])([#b]?)/g, (m, a1, k, a2) => {
      const acc = (a1 || a2) === '#' ? 1 : (a1 || a2) === 'b' ? -1 : 0;
      o.tonic = 60 + KEYS[k.toUpperCase()] + acc;
      if (o.tonic > 66) o.tonic -= 12;                 // 主音放在中央 C 附近
      o.key = (acc === 1 ? '#' : acc === -1 ? 'b' : '') + k.toUpperCase();
      o.keySharp = acc === 1;
      return blank(m);
    });
    body = body.replace(/(?:♩|bpm|BPM|速度|拍速)\s*[=:：]?\s*(\d{2,3})/g, (m, n) => { o.bpm = Math.max(30, Math.min(240, +n)); return blank(m); });
    body = body.replace(/(\d)\s*\/\s*(\d)(?!\s*拍)/g, (m, a, b) => { o.beats = Math.max(1, Math.min(12, +a || 4)); o.beatUnit = +b || 4; return blank(m); });
    return body;
  }

  /* ---------- 和弦 ---------- */
  const QUALITY = {
    '': [0, 4, 7], m: [0, 3, 7], '7': [0, 4, 7, 10], maj7: [0, 4, 7, 11], M7: [0, 4, 7, 11], m7: [0, 3, 7, 10],
    sus4: [0, 5, 7], sus2: [0, 2, 7], add9: [0, 4, 7, 14], '5': [0, 7], dim: [0, 3, 6], aug: [0, 4, 8],
    '6': [0, 4, 7, 9], m6: [0, 3, 7, 9], '9': [0, 4, 7, 10, 14], madd9: [0, 3, 7, 14], '7sus4': [0, 5, 7, 10], dim7: [0, 3, 6, 9], m7b5: [0, 3, 6, 10],
  };
  function parseChord(name) {
    const m = /^([A-G])([#b]?)(maj7|M7|madd9|m7b5|m7|m6|m|7sus4|7|sus4|sus2|add9|dim7|dim|aug|5|6|9)?(?:\/([A-G])([#b]?))?$/.exec(name);
    if (!m) return null;
    const pc = (KEYS[m[1]] + (m[2] === '#' ? 1 : m[2] === 'b' ? -1 : 0) + 12) % 12;
    const q = m[3] === 'M7' ? 'maj7' : (m[3] || '');
    const bass = m[4] ? (KEYS[m[4]] + (m[5] === '#' ? 1 : m[5] === 'b' ? -1 : 0) + 12) % 12 : null;
    return { name, pc, q, bass, tones: QUALITY[q].map((x) => (pc + x) % 12) };
  }
  // 「和弦：| C | G | Am F |」→ [{t, dur, name, chord}]
  function parseChordLine(line, beats) {
    const out = [];
    let err = null;
    const parts = line.split('|');
    let bar = 0, prev = null;
    for (let k = 0; k < parts.length; k++) {
      const toks = parts[k].trim().split(/\s+/).filter(Boolean);
      if (!toks.length) continue;
      const each = beats / toks.length;
      toks.forEach((tk, j) => {
        let ch;
        if (tk === '%' || tk === '-') ch = prev;
        else if (/^(N\.?C\.?|0|x)$/i.test(tk)) ch = null;
        else { ch = parseChord(tk); if (!ch && !err) err = `看不懂和弦“${tk}”（可以写 C、Am、G7、Fmaj7、Dsus4、C/G 这样的）`; }
        if (ch) out.push({ t: bar * beats + j * each, dur: each, name: ch.name, chord: ch });
        prev = ch || prev;
      });
      bar++;
    }
    const merged = [];
    for (const c of out) {
      const last = merged[merged.length - 1];
      if (last && last.name === c.name && Math.abs(last.t + last.dur - c.t) < 1e-6) last.dur += c.dur;
      else merged.push({ ...c });
    }
    return { chords: merged, bars: bar, error: err };
  }

  /* ---------- 拼写：一个音在五线谱上写成哪个字母、升降多少 ---------- */
  // step：从 C0 开始数的白键序号（C4 = 28），alter：-2…2
  function spellWithLetter(midi, letterIdx) {
    const pc = LETTER_PC[letterIdx];
    let oct = Math.round((midi - pc) / 12) - 1;
    let alter = midi - (12 * (oct + 1) + pc);
    if (alter > 6) { oct++; alter -= 12; } else if (alter < -6) { oct--; alter += 12; }
    return { step: oct * 7 + letterIdx, alter, midi };
  }
  function spellDefault(midi, fifths) {
    const pc = ((midi % 12) + 12) % 12;
    const ka = keyAlters(fifths);
    // 先找调号里就有的写法
    for (let L = 0; L < 7; L++) if ((LETTER_PC[L] + ka[LETTERS[L]] + 12) % 12 === pc) return spellWithLetter(midi, L);
    // 调外音：升号调写成升号，降号调（和 C 调里的 b3 b6 b7）写成降号
    const sharp = fifths > 0 || (fifths === 0 && ![3, 8, 10].includes(pc));
    for (let L = 0; L < 7; L++) if ((LETTER_PC[L] + (sharp ? 1 : -1) + 12) % 12 === pc) return spellWithLetter(midi, L);
    for (let L = 0; L < 7; L++) if (LETTER_PC[L] === pc) return spellWithLetter(midi, L);
    return spellWithLetter(midi, 0);
  }

  /* ---------- 简谱 / 音名 ---------- */
  // 返回 { notes: [{t, dur, midi:[...], spell:[...], src:[start,end]}], chords, bpm, key, tonic, beats, bars, total, tone, style, error }
  // t 和 dur 的单位是拍；src 是这个音在原文里的位置（播放时高亮用）
  function parse(text) {
    const raw = normalize(String(text || ''));
    const o = { bpm: 90, tonic: 60, key: 'C', keySharp: false, beats: 4, beatUnit: 4, tone: 'keys', style: null };
    let body = raw;
    const chordLines = [];
    body = body.replace(/^[ \t]*(?:和弦|chords?)\s*[:：]([^\n]*)/gim, (m, rest, offset) => { chordLines.push({ text: rest, pos: offset + m.length - rest.length }); return blank(m); });
    body = readHeader(body, o);
    const tonicPc = ((o.tonic % 12) + 12) % 12;
    const ki = keyInfo(tonicPc, o.keySharp);
    const keyLetter = LETTERS.indexOf(ki.letter);
    const notes = [];
    let t = 0, last = null;
    const bars = [];
    const done = (error) => ({ mode: 'jianpu', notes, bpm: o.bpm, key: o.key, tonic: o.tonic, fifths: ki.fifths, beats: o.beats, beatUnit: o.beatUnit, bars, total: t,
      tone: o.tone, style: o.style || DEFAULT_STYLE[o.tone], chords: [], error: error || null });
    const err = (msg, pos) => done({ msg, pos });
    if (o.badTone) return err(`音色只能写 电子琴、电钢琴、风琴 或 合成器（写的是“${o.badTone}”）`, raw.indexOf(o.badTone));
    if (o.badStyle) return err(`伴奏只能写 流行、分解、柱式 或 长音（写的是“${o.badStyle}”）`, raw.indexOf(o.badStyle));

    let i = 0;
    const n = body.length;
    // 读一个音：简谱（#4、5'）或音名（C4、Eb5）；返回 'rest'、{midi, spell} 或 null
    const readOne = () => {
      if (/[A-G]/.test(body[i])) {
        const m = /^([A-G])(##|bb|#|b)?(-?\d)/.exec(body.slice(i, i + 5));
        if (!m) return null;
        i += m[0].length;
        const L = LETTERS.indexOf(m[1]);
        const alter = m[2] === '#' ? 1 : m[2] === '##' ? 2 : m[2] === 'b' ? -1 : m[2] === 'bb' ? -2 : 0;
        const oct = +m[3];
        const midi = 12 * (oct + 1) + LETTER_PC[L] + alter;
        return { midi, spell: { step: oct * 7 + L, alter, midi } };
      }
      let acc = 0;
      while (body[i] === '#' || body[i] === 'b') { acc += body[i] === '#' ? 1 : -1; i++; }
      const d = body[i];
      if (!/[0-7]/.test(d)) return null;
      i++;
      let oct = 0;
      while (body[i] === "'" || body[i] === ',') { oct += body[i] === "'" ? 1 : -1; i++; }
      if (d === '0') return 'rest';
      const midi = o.tonic + DEG[+d] + acc + oct * 12;
      return { midi, spell: spellWithLetter(midi, (keyLetter + (+d) - 1) % 7) };
    };
    while (i < n) {
      const c = body[i];
      if (c === '|') { if (!bars.length || bars[bars.length - 1] !== t) bars.push(t); i++; continue; }
      if (/\s/.test(c)) { i++; continue; }
      if (c === '-') {
        if (!last) return err('“-” 前面没有音可以延长', i);
        last.dur += 1; t += 1; i++; continue;
      }
      const start = i;
      const pitches = [], spell = [];
      const push = (p) => { if (p !== 'rest') { pitches.push(p.midi); spell.push(p.spell); } };
      if (c === '[') {
        i++;
        while (i < n && body[i] !== ']') {
          if (/\s/.test(body[i])) { i++; continue; }
          const p = readOne();
          if (p === null) return err(`几个音一起按的 [ ] 里有看不懂的字符“${body[i] || '（结尾）'}”`, i);
          push(p);
        }
        if (body[i] !== ']') return err('[ 没有配对的 ]', start);
        i++;
      } else {
        const p = readOne();
        if (p === null) return err(/[A-G]/.test(c) ? `音名要写成字母加八度，比如 C4、F#4、Bb3（写的是“${body.slice(i, i + 3).trim()}”）`
          : `看不懂“${c}”。简谱的音只能写 0–7，可以带 # b ' , _ . -；音名写成 C4、F#4 这样`, start);
        push(p);
      }
      let dur = 1;
      while ((body[i] === '_' || body[i] === '.') && i < n) { dur *= body[i] === '_' ? 0.5 : 1.5; i++; }
      for (const m of pitches) if (m < LOW || m > HIGH) return err('这个音太高或太低了，电子琴上没有（88 个键的范围是 A0 到 C8）', start);
      const note = { t, dur, midi: pitches, spell, src: [start, i] };
      notes.push(note);
      last = note; t += dur;
    }
    const sc = done(null);
    for (const cl of chordLines) {
      const r = parseChordLine(cl.text, o.beats);
      if (r.error) { sc.chordError = r.error; sc.error = { msg: r.error, pos: cl.pos }; break; }
      sc.chords.push(...r.chords);
    }
    if (sc.chords.length) sc.total = Math.max(sc.total, ...sc.chords.map((c) => c.t + c.dur));
    return sc;
  }

  /* ---------- 演奏：主旋律 + 伴奏（左手低音、右手和弦） ---------- */
  function performance(score) {
    const lead = [], acc = [];
    const spb = 60 / score.bpm;
    const jitter = (ms) => (Math.random() * 2 - 1) * ms / 1000;
    for (const nt of score.notes) {
      if (!nt.midi.length) continue;
      const many = nt.midi.length > 1;
      nt.midi.slice().sort((a, b) => a - b).forEach((m, idx) => lead.push({
        midi: m, sec: nt.t * spb + (many ? idx * 0.006 : 0) + jitter(2), len: nt.dur * spb * 0.96, vel: (many ? 0.62 : 0.8) + (Math.random() - 0.5) * 0.05,
      }));
    }
    // 伴奏：右手和弦放在旋律下面，和上一个和弦的音尽量接近（手不乱跳）
    const melodyLow = (t0, t1) => {
      let lo = 99;
      for (const nt of score.notes) if (nt.t < t1 && nt.t + nt.dur > t0) for (const m of nt.midi) lo = Math.min(lo, m);
      return lo;
    };
    let prev = null;
    const style = score.style || DEFAULT_STYLE[score.tone] || 'pop';
    for (const c of score.chords || []) {
      const ch = c.chord;
      const top = Math.min(72, Math.max(60, melodyLow(c.t, c.t + c.dur) - 1));
      const pcs = ch.tones.slice(0, 4);
      // 列出所有在 [top-14, top] 里的转位，挑和上一个和弦最接近的
      let best = null;
      for (let inv = 0; inv < pcs.length; inv++) {
        const order = pcs.slice(inv).concat(pcs.slice(0, inv));
        for (let base = top - 16; base <= top; base++) {
          if ((base % 12 + 12) % 12 !== order[0]) continue;
          const v = [base];
          for (let k = 1; k < order.length; k++) { let m = v[k - 1] + 1; while ((m % 12 + 12) % 12 !== order[k]) m++; v.push(m); }
          if (v[v.length - 1] > top) continue;
          const center = v.reduce((a, b) => a + b, 0) / v.length;
          const cost = prev ? Math.abs(center - prev) : Math.abs(center - (top - 6));
          if (!best || cost < best.cost) best = { v, cost, center };
        }
      }
      if (!best) continue;
      prev = best.center;
      const right = best.v;
      let bass = (ch.bass ?? ch.pc) + 36;
      while (bass < 40) bass += 12;
      while (bass > 52) bass -= 12;
      const end = c.t + c.dur;
      const hit = (midis, t, d, vel) => { if (t >= end - 1e-6) return; for (const m of midis) acc.push({ midi: m, sec: t * spb + jitter(4), len: Math.min(d, end - t) * spb * 0.95, vel, acc: true }); };
      if (style === 'pad') {
        hit([bass], c.t, c.dur, 0.5); hit(right, c.t, c.dur, 0.36);
      } else if (style === 'block') {
        for (let b = c.t; b < end - 1e-6; b += 1) { hit([bass], b, 1, b === c.t ? 0.55 : 0.45); hit(right, b, 0.9, b === c.t ? 0.44 : 0.36); }
      } else if (style === 'arp') {
        const seq = [bass, bass + 7, ...right, right[0] + 12].filter((m, k, a) => a.indexOf(m) === k);
        const path = seq.concat(seq.slice(1, -1).reverse());
        let k = 0;
        for (let b = c.t; b < end - 1e-6; b += 0.5, k++) hit([path[k % path.length]], b, k === 0 ? 2 : 1.2, k === 0 ? 0.5 : 0.38);
      } else {
        // 流行：低音在 1、3 拍，右手和弦在每拍的后半拍轻轻按一下，第一拍按住
        for (let b = c.t, k = 0; b < end - 1e-6; b += 1, k++) {
          if (k % 2 === 0) hit([k % 4 === 2 ? bass + 7 > 55 ? bass - 5 : bass + 7 : bass], b, 1.8, 0.52);
          if (k === 0) hit(right, b, 0.9, 0.38);
          hit(right, b + 0.5, 0.42, 0.32);
        }
      }
    }
    return { lead, acc };
  }

  /* ---------- 电子琴音色 ---------- */
  // 每种音色是几层波形（用谐波表叠出来），各自有包络。波形表按“最多到第几个谐波”分开缓存，高音不会出现刺耳的折叠音
  const VOICES = {
    // 电子琴：空心一点的方波 + 正弦，按下去很快响起，按住时慢慢变弱一点，有一点延迟出现的颤音（像家用电子琴）
    keys: { layers: [{ h: { 1: 1, 2: 0.32, 3: 0.42, 4: 0.1, 5: 0.24, 6: 0.05, 7: 0.13, 9: 0.07, 11: 0.04 }, gain: 0.5 }],
      a: 0.006, d: 0.35, s: 0.62, decay: 3.5, r: 0.13, vib: [5.4, 0.0028, 0.28], detune: 0, click: 0.006 },
    // 电钢琴：柔和的基音长长地响，加一个很快消失的“叮”（音叉的声音）
    epiano: { layers: [{ h: { 1: 1, 2: 0.18, 3: 0.05 }, gain: 0.42 }, { h: { 1: 0.2, 4: 0.3, 7: 0.25, 14: 0.5 }, gain: 0.22, decayOnly: 0.12 }],
      a: 0.003, d: 1.2, s: 0.0, decay: 2.2, r: 0.25, vib: null, trem: [4.6, 0.12], detune: 0, click: 0.004, decayByPitch: true },
    // 风琴：几根拉杆的谐波，一直响着不衰减，有轻微的颤动
    organ: { layers: [{ h: { 1: 1, 2: 0.85, 3: 0.55, 4: 0.45, 6: 0.22, 8: 0.2 }, gain: 0.34 }],
      a: 0.012, d: 0.05, s: 1, decay: 0, r: 0.07, vib: [6.6, 0.0018, 0], trem: [6.6, 0.08], detune: 0, click: 0.012 },
    // 合成器：两根稍微走音的锯齿波，明亮
    synth: { layers: [{ saw: 22, gain: 0.26 }, { saw: 22, gain: 0.26, cents: 9 }],
      a: 0.008, d: 0.3, s: 0.7, decay: 6, r: 0.18, vib: [5.2, 0.002, 0.35], detune: 0, click: 0 },
  };
  const TABLE = 2048;
  const tableCache = new Map();
  function waveTable(layer, maxH) {
    const key = JSON.stringify(layer.h || { saw: layer.saw }) + '|' + maxH;
    if (tableCache.has(key)) return tableCache.get(key);
    const tb = new Float32Array(TABLE + 1);
    const parts = layer.h ? Object.entries(layer.h).map(([k, v]) => [+k, v]) : Array.from({ length: layer.saw }, (_, k) => [k + 1, 1 / (k + 1)]);
    let peak = 0;
    for (let j = 0; j < TABLE; j++) {
      let v = 0;
      for (const [k, a] of parts) if (k <= maxH) v += a * Math.sin(2 * Math.PI * k * j / TABLE);
      tb[j] = v; peak = Math.max(peak, Math.abs(v));
    }
    for (let j = 0; j < TABLE; j++) tb[j] /= peak || 1;
    tb[TABLE] = tb[0];
    tableCache.set(key, tb);
    return tb;
  }
  const freq = (m) => 440 * Math.pow(2, (m - 69) / 12);

  function synthNote(L, R, sr, ev, tone, pan) {
    const V = VOICES[tone] || VOICES.keys;
    const f0 = freq(ev.midi);
    const i0 = Math.max(0, Math.floor(ev.sec * sr));
    const held = Math.max(0.06, ev.len);
    const decay = V.decayByPitch ? V.decay * Math.pow(261.6 / f0, 0.5) : V.decay;
    const iOff = i0 + Math.floor(held * sr);
    const iEnd = Math.min(L.length, iOff + Math.floor(V.r * 5 * sr));
    const gl = Math.cos((pan + 1) * Math.PI / 4), gr = Math.sin((pan + 1) * Math.PI / 4);
    const vel = ev.vel;
    for (const layer of V.layers) {
      const fl = f0 * Math.pow(2, (layer.cents || 0) / 1200);
      const maxH = Math.max(1, Math.floor(sr * 0.45 / fl));
      const tb = waveTable(layer, maxH);
      const inc = fl * TABLE / sr;
      let ph = Math.random() * TABLE;
      const aN = V.a * sr, dN = V.d * sr;
      const decK = decay > 0 ? Math.exp(-1 / (decay * sr)) : 1;
      const relK = Math.exp(-1 / (V.r / 4 * sr));
      const lDec = layer.decayOnly ? Math.exp(-1 / (layer.decayOnly * sr)) : 1;
      let slow = 1, rel = 1, lenv = 1;
      // 音的亮度随力度变化：轻按的高音层小一点
      const g = layer.gain * vel * (layer.decayOnly ? 0.6 + vel * 0.6 : 1);
      for (let i = i0, j = 0; i < iEnd; i++, j++) {
        let env;
        if (j < aN) env = j / aN;
        else if (j < aN + dN) { const x = (j - aN) / dN; env = 1 - (1 - V.s) * (1 - Math.pow(1 - x, 2)); }
        else env = V.s;
        if (V.s === 0 && j >= aN) env = Math.exp(-(j - aN) / (decay * sr * 0.6)) * 0.85 + 0.15 * Math.exp(-(j - aN) / (decay * sr * 2));
        env *= slow; slow *= decK;
        if (i >= iOff) { rel *= relK; if (rel < 1e-4) break; }
        env *= rel * lenv; lenv *= lDec;
        let pinc = inc;
        if (V.vib) { const tt = j / sr; const onset = V.vib[2] ? Math.min(1, Math.max(0, (tt - V.vib[2]) / 0.4)) : 1; pinc *= 1 + V.vib[1] * onset * Math.sin(2 * Math.PI * V.vib[0] * tt); }
        if (V.trem) env *= 1 - V.trem[1] * (0.5 + 0.5 * Math.sin(2 * Math.PI * V.trem[0] * j / sr));
        ph += pinc; if (ph >= TABLE) ph -= TABLE;
        const k = ph | 0, fr = ph - k;
        const v = (tb[k] + (tb[k + 1] - tb[k]) * fr) * env * g;
        L[i] += v * gl; R[i] += v * gr;
      }
    }
    // 按键的“咔”一声（很短）
    if (V.click) {
      const nLen = Math.floor(V.click * sr);
      for (let j = 0; j < nLen && i0 + j < L.length; j++) {
        const v = (Math.random() * 2 - 1) * 0.03 * vel * Math.pow(1 - j / nLen, 2);
        L[i0 + j] += v * gl; R[i0 + j] += v * gr;
      }
    }
  }

  // 轻微的立体声合唱效果（电子琴、电钢琴、合成器用），让声音更宽
  function chorus(L, R, sr, depthMs, mix) {
    const n = L.length, base = Math.floor(0.012 * sr), dep = depthMs / 1000 * sr;
    const outL = new Float32Array(n), outR = new Float32Array(n);
    for (let i = 0; i < n; i++) {
      const t = i / sr;
      const dl = base + dep * (0.5 + 0.5 * Math.sin(2 * Math.PI * 0.8 * t));
      const dr = base + dep * (0.5 + 0.5 * Math.sin(2 * Math.PI * 0.8 * t + Math.PI / 2));
      const read = (buf, d) => { const p = i - d; if (p < 1) return 0; const k = p | 0, f = p - k; return buf[k] + (buf[k + 1] - buf[k]) * f; };
      const m = (L[i] + R[i]) * 0.5;
      outL[i] = L[i] + mix * read(R, dl) - mix * 0.2 * m;
      outR[i] = R[i] + mix * read(L, dr) - mix * 0.2 * m;
    }
    L.set(outL); R.set(outR);
  }

  // 把整首曲子合成成一段声音（AudioBuffer）
  async function render(score, { sampleRate = 44100, volume = 1.6 } = {}) {
    const spb = 60 / score.bpm;
    const tone = score.tone || 'keys';
    const perf = performance({ bpm: 90, beats: 4, chords: [], ...score });
    const all = perf.lead.concat(perf.acc);
    const len = Math.max(0.6, (all.length ? Math.max(...all.map((e) => e.sec + e.len)) : score.total * spb) + 2.2);
    const n = Math.ceil(len * sampleRate);
    const L = new Float32Array(n), R = new Float32Array(n);
    for (const ev of perf.lead) synthNote(L, R, sampleRate, ev, tone, Math.max(-0.25, Math.min(0.25, (ev.midi - 66) / 40)));
    for (const ev of perf.acc) synthNote(L, R, sampleRate, ev, tone, Math.max(-0.5, Math.min(0.5, (ev.midi - 58) / 24)));
    if (tone !== 'organ') chorus(L, R, sampleRate, tone === 'synth' ? 3 : 2, tone === 'keys' ? 0.25 : 0.32);
    const ctx = new OfflineAudioContext(2, n, sampleRate);
    const dryBuf = ctx.createBuffer(2, n, sampleRate);
    dryBuf.copyToChannel(L, 0); dryBuf.copyToChannel(R, 1);
    const srcN = ctx.createBufferSource(); srcN.buffer = dryBuf;
    const master = ctx.createGain(); master.gain.value = volume;
    const comp = ctx.createDynamicsCompressor();
    comp.threshold.value = -14; comp.ratio.value = 3; comp.attack.value = 0.004; comp.release.value = 0.22;
    master.connect(comp); comp.connect(ctx.destination);
    const rev = ctx.createConvolver();
    const irLen = Math.floor(sampleRate * 1.6), ir = ctx.createBuffer(2, irLen, sampleRate);
    for (let ch = 0; ch < 2; ch++) {
      const d = ir.getChannelData(ch);
      let seed = 4321 + ch * 777;
      for (let k = 0; k < irLen; k++) { seed = (seed * 16807) % 2147483647; d[k] = ((seed / 2147483647) * 2 - 1) * Math.pow(1 - k / irLen, 3.4); }
    }
    rev.buffer = ir;
    const wet = ctx.createGain(); wet.gain.value = tone === 'organ' ? 0.2 : 0.14;
    srcN.connect(master);
    srcN.connect(rev); rev.connect(wet); wet.connect(master);
    srcN.start(0);
    const out = await ctx.startRendering();
    // 最后把峰值压到 0.95 以下，导出的 WAV 不会爆音
    let peak = 0;
    for (let c = 0; c < out.numberOfChannels; c++) { const d = out.getChannelData(c); for (let i = 0; i < d.length; i++) { const v = d[i] < 0 ? -d[i] : d[i]; if (v > peak) peak = v; } }
    if (peak > 0.95) for (let c = 0; c < out.numberOfChannels; c++) { const d = out.getChannelData(c), k = 0.95 / peak; for (let i = 0; i < d.length; i++) d[i] *= k; }
    return out;
  }

  // AudioBuffer → WAV 文件（16 位）
  function toWav(buf) {
    const ch = buf.numberOfChannels, sr = buf.sampleRate, n = buf.length;
    const out = new DataView(new ArrayBuffer(44 + n * ch * 2));
    const w = (o, s) => { for (let k = 0; k < s.length; k++) out.setUint8(o + k, s.charCodeAt(k)); };
    w(0, 'RIFF'); out.setUint32(4, 36 + n * ch * 2, true); w(8, 'WAVE'); w(12, 'fmt ');
    out.setUint32(16, 16, true); out.setUint16(20, 1, true); out.setUint16(22, ch, true); out.setUint32(24, sr, true);
    out.setUint32(28, sr * ch * 2, true); out.setUint16(32, ch * 2, true); out.setUint16(34, 16, true); w(36, 'data'); out.setUint32(40, n * ch * 2, true);
    const data = []; for (let c = 0; c < ch; c++) data.push(buf.getChannelData(c));
    let o = 44;
    for (let k = 0; k < n; k++) for (let c = 0; c < ch; c++) { const v = Math.max(-1, Math.min(1, data[c][k])); out.setInt16(o, v < 0 ? v * 0x8000 : v * 0x7fff, true); o += 2; }
    return new Uint8Array(out.buffer);
  }

  // 谱子 → MIDI 文件：1 声道主旋律，2 声道伴奏
  const MIDI_PROGRAM = { keys: 4, epiano: 5, organ: 16, synth: 81 };
  function toMidi(score) {
    const tpq = 480, ev = [];
    const program = MIDI_PROGRAM[score.tone] ?? 4;
    const spb = 60 / score.bpm;
    const perf = performance(score);
    const add = (list, chn) => {
      for (const e of list) {
        const t = Math.max(0, Math.round(e.sec / spb * tpq)), d = Math.max(30, Math.round(e.len / spb * tpq));
        const vel = Math.max(20, Math.min(127, Math.round(e.vel * 120)));
        ev.push({ t, on: 1, m: e.midi, chn, vel }); ev.push({ t: t + d, on: 0, m: e.midi, chn, vel: 0 });
      }
    };
    add(perf.lead, 0); add(perf.acc, 1);
    ev.sort((a, b) => a.t - b.t || a.on - b.on);
    const bytes = [];
    const vlq = (v) => { const s = [v & 0x7f]; while ((v >>= 7)) s.unshift((v & 0x7f) | 0x80); bytes.push(...s); };
    const us = Math.round(60000000 / score.bpm);
    vlq(0); bytes.push(0xff, 0x51, 0x03, (us >> 16) & 255, (us >> 8) & 255, us & 255);
    vlq(0); bytes.push(0xff, 0x58, 0x04, score.beats || 4, Math.round(Math.log2(score.beatUnit || 4)), 24, 8);
    vlq(0); bytes.push(0xff, 0x59, 0x02, ((score.fifths || 0) + 256) & 255, 0);
    vlq(0); bytes.push(0xc0, program);
    vlq(0); bytes.push(0xc1, program);
    let prev = 0;
    for (const e of ev) { vlq(e.t - prev); prev = e.t; bytes.push((e.on ? 0x90 : 0x80) | e.chn, e.m, e.vel); }
    vlq(0); bytes.push(0xff, 0x2f, 0x00);
    const head = [0x4d, 0x54, 0x68, 0x64, 0, 0, 0, 6, 0, 0, 0, 1, (tpq >> 8) & 255, tpq & 255];
    const Ln = bytes.length;
    return new Uint8Array([...head, 0x4d, 0x54, 0x72, 0x6b, (Ln >>> 24) & 255, (Ln >> 16) & 255, (Ln >> 8) & 255, Ln & 255, ...bytes]);
  }

  // 检查每小节的拍数是不是对的：返回不对的小节 [{bar: 第几小节, got: 实际拍数}]
  function checkBars(score) {
    const bad = [];
    const ends = score.bars.slice();
    const melodyEnd = score.notes.length ? Math.max(...score.notes.map((x) => x.t + x.dur)) : score.total;
    const total = Math.max(melodyEnd, ends[ends.length - 1] || 0);
    if (!ends.length || ends[ends.length - 1] < total) ends.push(total);
    let prev = 0;
    ends.forEach((e, k) => {
      const got = Math.round((e - prev) * 1000) / 1000;
      const last = k === ends.length - 1;
      if (got > 0 && Math.abs(got - score.beats) > 1e-6 && !(last && got < score.beats)) bad.push({ bar: k + 1, got });
      prev = e;
    });
    return bad;
  }

  /* ---------- 五线谱 ---------- */
  // 能直接写出来的时值（拍）：全音符 4、附点二分 3、二分 2、附点四分 1.5、四分 1、附点八分 0.75、八分 0.5、附点十六分 0.375、十六分 0.25、三十二分 0.125
  const VALUES = [[4, 'whole', 0], [3, 'half', 1], [2, 'half', 0], [1.5, 'quarter', 1], [1, 'quarter', 0], [0.75, 'eighth', 1], [0.5, 'eighth', 0], [0.375, '16th', 1], [0.25, '16th', 0], [0.125, '32nd', 0]];
  // 把一段时值拆成能写出来的几个音（用连音线连起来）：先按拍子对齐，避免奇怪的切分
  function splitDur(start, dur) {
    const out = [];
    let t = start, left = dur;
    let guard = 0;
    while (left > 1e-6 && guard++ < 64) {
      let pick = null;
      for (const v of VALUES) {
        if (v[0] > left + 1e-6) continue;
        // 超过一拍的时值，要从拍子上开始（二分音符从 1、3 拍或任意整拍开始都可以）
        if (v[0] >= 1 && Math.abs(t - Math.round(t)) > 1e-6) continue;
        // 不到一拍的时值，不能跨过拍子
        if (v[0] < 1 && Math.floor(t + 1e-6) !== Math.floor(t + v[0] - 1e-6)) continue;
        pick = v; break;
      }
      if (!pick) pick = VALUES[VALUES.length - 1];
      out.push({ t, dur: pick[0], type: pick[1], dots: pick[2] });
      t += pick[0]; left -= pick[0];
    }
    return out;
  }
  // 返回 { fifths, beats, beatUnit, clef: 'treble' | 'grand', measures: [{ items, chords }] }
  // item：{ kind: 'note' | 'rest', t（小节内第几拍）, dur, type, dots, pitches:[{step, alter, midi, acc(要写的临时记号或 null)}], tieStart, tieStop, idx（原来第几个音）}
  function toStaff(score) {
    const beats = score.beats || 4;
    const fifths = score.fifths || 0;
    const ka = keyAlters(fifths);
    const total = Math.max(score.total || 0, ...score.notes.map((n) => n.t + n.dur), beats);
    const nBars = Math.max(1, Math.ceil(total / beats - 1e-6));
    const measures = Array.from({ length: nBars }, () => ({ items: [], chords: [] }));
    let low = 99;
    // 音符（和中间空着的地方补上休止）
    const events = score.notes.slice().sort((a, b) => a.t - b.t);
    let cursor = 0;
    const place = (t0, dur, pitches, idx) => {
      let t = t0, left = dur, first = true;
      while (left > 1e-6) {
        const bar = Math.floor(t / beats + 1e-6);
        if (bar >= nBars) break;
        const barEnd = (bar + 1) * beats;
        const seg = Math.min(left, barEnd - t);
        const parts = splitDur(t - bar * beats, seg);
        parts.forEach((p, k) => {
          const lastPart = k === parts.length - 1 && seg >= left - 1e-6;
          measures[bar].items.push({ kind: pitches.length ? 'note' : 'rest', t: p.t, dur: p.dur, type: p.type, dots: p.dots, idx,
            pitches: pitches.map((s) => ({ ...s })), tieStop: pitches.length > 0 && !first, tieStart: pitches.length > 0 && !lastPart });
          first = false;
        });
        t += seg; left -= seg;
      }
    };
    events.forEach((nt, idx) => {
      if (nt.t > cursor + 1e-6) place(cursor, nt.t - cursor, [], -1);
      const sp = (nt.spell && nt.spell.length === nt.midi.length) ? nt.spell : nt.midi.map((m) => spellDefault(m, fifths));
      for (const s of sp) low = Math.min(low, s.midi);
      place(nt.t, nt.dur, sp.slice().sort((a, b) => a.step - b.step), score.notes.indexOf(nt));
      cursor = Math.max(cursor, nt.t + nt.dur);
    });
    if (cursor < nBars * beats - 1e-6) place(cursor, nBars * beats - cursor, [], -1);
    // 一整小节都是休止：写成全休止符
    for (const m of measures) {
      if (m.items.length && m.items.every((it) => it.kind === 'rest')) m.items = [{ kind: 'rest', t: 0, dur: beats, type: 'whole', dots: 0, whole: true, pitches: [], idx: -1 }];
    }
    // 临时记号：同一小节里同一个位置的音，升降和调号 / 前面一样就不再写
    for (const m of measures) {
      const state = {};
      for (const it of m.items) {
        for (const p of it.pitches) {
          const letter = LETTERS[((p.step % 7) + 7) % 7];
          const cur = p.step in state ? state[p.step] : ka[letter];
          p.acc = it.tieStop ? null : (p.alter !== cur ? p.alter : null);
          state[p.step] = p.alter;
        }
      }
    }
    for (const c of score.chords || []) {
      const bar = Math.floor(c.t / beats + 1e-6);
      if (bar < nBars) measures[bar].chords.push({ t: c.t - bar * beats, name: c.name });
    }
    return { fifths, beats, beatUnit: score.beatUnit || 4, clef: low < 53 ? 'grand' : 'treble', measures, bpm: score.bpm };
  }

  // 五线谱 → MusicXML（可以用 MuseScore、Finale、Sibelius 等打开）
  function toMusicXML(score, title = '') {
    const st = toStaff(score);
    const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    const div = 24;   // 每拍 24 份（能写到三十二分音符和附点）
    const grand = st.clef === 'grand';
    const kindOf = { '': 'major', m: 'minor', '7': 'dominant', maj7: 'major-seventh', m7: 'minor-seventh', sus4: 'suspended-fourth', sus2: 'suspended-second',
      add9: 'major', '5': 'power', dim: 'diminished', aug: 'augmented', '6': 'major-sixth', m6: 'minor-sixth', '9': 'dominant-ninth', madd9: 'minor', '7sus4': 'dominant', dim7: 'diminished-seventh', m7b5: 'half-diminished' };
    const rootXml = (name) => { const m = /^([A-G])([#b]?)/.exec(name); return `<root-step>${m[1]}</root-step>${m[2] ? `<root-alter>${m[2] === '#' ? 1 : -1}</root-alter>` : ''}`; };
    let xml = `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE score-partwise PUBLIC "-//Recordare//DTD MusicXML 3.1 Partwise//EN" "http://www.musicxml.org/dtds/partwise.dtd">
<score-partwise version="3.1">
  <work><work-title>${esc(title || '无题')}</work-title></work>
  <part-list><score-part id="P1"><part-name>${esc(TONES[score.tone] || '电子琴')}</part-name></score-part></part-list>
  <part id="P1">
`;
    st.measures.forEach((m, k) => {
      xml += `    <measure number="${k + 1}">\n`;
      if (k === 0) {
        xml += `      <attributes><divisions>${div}</divisions><key><fifths>${st.fifths}</fifths></key><time><beats>${st.beats}</beats><beat-type>${st.beatUnit}</beat-type></time>`;
        xml += grand ? '<staves>2</staves><clef number="1"><sign>G</sign><line>2</line></clef><clef number="2"><sign>F</sign><line>4</line></clef>' : '<clef><sign>G</sign><line>2</line></clef>';
        xml += '</attributes>\n';
        xml += `      <direction placement="above"><direction-type><metronome><beat-unit>quarter</beat-unit><per-minute>${st.bpm}</per-minute></metronome></direction-type><sound tempo="${st.bpm}"/></direction>\n`;
      }
      const chords = m.chords.slice();
      for (const it of m.items) {
        while (chords.length && chords[0].t <= it.t + 1e-6) {
          const c = chords.shift(); const ch = parseChord(c.name);
          if (ch) xml += `      <harmony><root>${rootXml(c.name)}</root><kind text="${esc(c.name.replace(/^[A-G][#b]?/, '').replace(/\/.*$/, ''))}">${kindOf[ch.q] || 'major'}</kind></harmony>\n`;
        }
        const d = Math.round(it.dur * div);
        if (it.kind === 'rest') {
          xml += `      <note><rest${it.whole ? ' measure="yes"' : ''}/><duration>${d}</duration>${it.whole ? '' : `<type>${it.type}</type>${'<dot/>'.repeat(it.dots)}`}${grand ? '<staff>1</staff>' : ''}</note>\n`;
          continue;
        }
        it.pitches.forEach((p, j) => {
          const letter = LETTERS[((p.step % 7) + 7) % 7], oct = Math.floor(p.step / 7);
          const staff = grand ? (p.midi < 60 ? 2 : 1) : 0;
          const acc = p.acc === null || p.acc === undefined ? '' : `<accidental>${{ '-2': 'flat-flat', '-1': 'flat', 0: 'natural', 1: 'sharp', 2: 'double-sharp' }[p.acc]}</accidental>`;
          const ties = (it.tieStop ? '<tie type="stop"/>' : '') + (it.tieStart ? '<tie type="start"/>' : '');
          const tied = (it.tieStop ? '<tied type="stop"/>' : '') + (it.tieStart ? '<tied type="start"/>' : '');
          xml += `      <note>${j ? '<chord/>' : ''}<pitch><step>${letter}</step>${p.alter ? `<alter>${p.alter}</alter>` : ''}<octave>${oct}</octave></pitch><duration>${d}</duration>${ties}<type>${it.type}</type>${'<dot/>'.repeat(it.dots)}${acc}${staff ? `<staff>${staff}</staff>` : ''}${tied ? `<notations>${tied}</notations>` : ''}</note>\n`;
        });
      }
      xml += '    </measure>\n';
    });
    xml += '  </part>\n</score-partwise>\n';
    return new TextEncoder().encode(xml);
  }

  root.Jianpu = { parse, checkBars, render, toWav, toMidi, toStaff, toMusicXML, freq, normalize, parseChord, keyAlters, spellDefault, performance,
    TONES, TONE_ALIAS, STYLES, STYLE_ALIAS, DEFAULT_STYLE, LETTERS, LETTER_PC };
})(typeof window !== 'undefined' ? window : globalThis);
