'use strict';
/* 鼓谱解析 + 架子鼓音色合成 + 节拍器
   鼓谱写法（和常见的吉他谱网站上的鼓谱一样，一行一个鼓，竖着对齐的是同一时刻）：
     ♩=100 4/4 每格=1/16 鼓组=原声 摇摆=0
     踩镲|x-x-x-x-x-x-x-x-|x-x-x-x-x-x-x-x-|
     军鼓|----o-------o---|----o-------o---|
     底鼓|o-------o-o-----|o-------o-o-----|
   - 行首是鼓的名字（中文或缩写），后面跟 |；| 是小节线
   - 每个字符是一格：- 或 . 是空，o / x 是打一下，O / X 是重音，g 是很轻的“鬼音”
   - 开头写速度、拍号、每格多长（1/8、1/16、1/12（三连音）、1/24），鼓组（原声 / 电子），摇摆（0–60，让八分 / 十六分音符往后拖一点）
   - 一组写完空一行可以接着写下一组，时间接在后面
   - // 后面是注释
   鼓的名字：底鼓(BD)、军鼓(SD)、边击(RS)、拍手(CP)、踩镲(HH)、开镲(OH)、踏镲(PH)、高嗵(T1)、中嗵(T2)、落地嗵(FT)、吊镲(CR)、叮叮镲(RD)、镲帽(RB)
*/
(function (root) {
  // 鼓：id → [显示名, GM 打击乐音符号, 声像（-1 左 … 1 右）]
  const INST = {
    crash: ['吊镲', 49, -0.45], ride: ['叮叮镲', 51, 0.5], bell: ['镲帽', 53, 0.5],
    hihat: ['踩镲', 42, 0.32], openhat: ['开镲', 46, 0.32], pedal: ['踏镲', 44, 0.32],
    tom1: ['高嗵', 50, -0.18], tom2: ['中嗵', 47, 0.08], tom3: ['落地嗵', 43, 0.38],
    snare: ['军鼓', 38, 0.04], rim: ['边击', 37, 0.04], clap: ['拍手', 39, 0],
    kick: ['底鼓', 36, 0],
  };
  const ORDER = ['crash', 'ride', 'bell', 'openhat', 'hihat', 'pedal', 'tom1', 'tom2', 'tom3', 'snare', 'rim', 'clap', 'kick'];
  const ALIAS = {
    底鼓: 'kick', 大鼓: 'kick', 低音鼓: 'kick', bd: 'kick', kick: 'kick', k: 'kick', b: 'kick',
    军鼓: 'snare', 小鼓: 'snare', sd: 'snare', snare: 'snare', s: 'snare',
    边击: 'rim', 鼓边: 'rim', rs: 'rim', rim: 'rim', ss: 'rim',
    拍手: 'clap', cp: 'clap', clap: 'clap',
    踩镲: 'hihat', 闭镲: 'hihat', 合镲: 'hihat', hh: 'hihat', hihat: 'hihat', h: 'hihat',
    开镲: 'openhat', oh: 'openhat',
    踏镲: 'pedal', 脚镲: 'pedal', ph: 'pedal', hf: 'pedal',
    高嗵: 'tom1', 嗵1: 'tom1', 一嗵: 'tom1', t1: 'tom1', ht: 'tom1', t: 'tom1',
    中嗵: 'tom2', 嗵2: 'tom2', 二嗵: 'tom2', t2: 'tom2', mt: 'tom2',
    落地嗵: 'tom3', 地嗵: 'tom3', 嗵3: 'tom3', 三嗵: 'tom3', ft: 'tom3', lt: 'tom3', t3: 'tom3',
    吊镲: 'crash', 强音镲: 'crash', 碎音镲: 'crash', cr: 'crash', cc: 'crash', c: 'crash', crash: 'crash',
    叮叮镲: 'ride', 节奏镲: 'ride', rd: 'ride', ride: 'ride', r: 'ride',
    镲帽: 'bell', 镲铃: 'bell', rb: 'bell', bell: 'bell',
  };
  const KITS = { acoustic: '原声', electronic: '电子' };
  const KIT_ALIAS = { 原声: 'acoustic', 原声鼓: 'acoustic', 架子鼓: 'acoustic', acoustic: 'acoustic', 电子: 'electronic', 电子鼓: 'electronic', electronic: 'electronic', '808': 'electronic' };
  const VEL = { o: 0.78, x: 0.78, O: 1, X: 1, g: 0.3, '@': 1 };

  function normalize(s) {
    return String(s).replace(/[｜]/g, '|').replace(/　/g, ' ').replace(/[—－–]/g, '-').replace(/＝/g, '=').replace(/[：]/g, ':').replace(/[／]/g, '/')
      .replace(/[０-９]/g, (c) => String.fromCharCode(c.charCodeAt(0) - 0xfee0)).replace(/[ｏ○]/g, 'o').replace(/[Ｏ●]/g, 'O').replace(/[ｘ×]/g, 'x');
  }
  const blank = (m) => m.replace(/[^\n]/g, ' ');
  const LINE = /^([ \t]*)([一-龥A-Za-z0-9]{1,4})[ \t]*\|/;

  // 返回 { bpm, beats, beatUnit, per（每拍几格）, kit, swing, rows: {id: [vel 或 0 ...]}, used, cells（总格数）, total（拍）, bars（每个小节线在第几格）, events:[{t, inst, vel, src}], error }
  function parse(text) {
    const raw = normalize(text || '');
    const o = { bpm: 100, beats: 4, beatUnit: 4, per: 4, kit: 'acoustic', swing: 0 };
    let body = raw.replace(/\/\/[^\n]*/g, blank);
    const err = (msg, pos) => ({ ...o, rows: {}, used: [], cells: 0, total: 0, bars: [], events: [], error: { msg, pos } });
    let bad = null;
    // 头部信息只在不是鼓谱行的地方读
    const lines = [];
    let pos = 0;
    for (const L of body.split('\n')) { lines.push({ text: L, pos }); pos += L.length + 1; }
    const tabLines = [];
    for (const l of lines) {
      const m = LINE.exec(l.text);
      const name = m && m[2].toLowerCase();
      if (m && ALIAS[name]) { tabLines.push({ ...l, inst: ALIAS[name], cellsAt: l.pos + m[0].length, cellsText: l.text.slice(m[0].length) }); continue; }
      if (m && /^[A-Za-z一-龥]/.test(m[2]) && /^[-.oxOXg@| \t]*$/.test(l.text.slice(m[0].length)) && !bad) bad = { msg: `不认识“${m[2]}”这个鼓。可以写：底鼓、军鼓、边击、拍手、踩镲、开镲、踏镲、高嗵、中嗵、落地嗵、吊镲、叮叮镲、镲帽（或 BD、SD、HH、CR 这样的缩写）`, pos: l.pos + m[1].length };
      let t = l.text;
      t = t.replace(/(?:♩|bpm|速度|拍速)\s*[=:]?\s*(\d{2,3})/gi, (mm, n) => { o.bpm = Math.max(30, Math.min(260, +n)); return blank(mm); });
      t = t.replace(/(?:每格|grid)\s*[=:]\s*1\s*\/\s*(\d{1,2})/g, (mm, n) => { const d = +n; if ([4, 8, 12, 16, 24, 32].includes(d)) o.unitDen = d; else bad = bad || { msg: '每格只能写 1/4、1/8、1/12（三连音）、1/16、1/24、1/32', pos: l.pos }; return blank(mm); });
      t = t.replace(/(?:鼓组|kit)\s*[=:]\s*([一-龥A-Za-z0-9]+)/g, (mm, v) => { if (KIT_ALIAS[v]) o.kit = KIT_ALIAS[v]; else bad = bad || { msg: `鼓组只能写 原声 或 电子（写的是“${v}”）`, pos: l.pos }; return blank(mm); });
      t = t.replace(/(?:摇摆|swing)\s*[=:]\s*(\d{1,2})%?/g, (mm, v) => { o.swing = Math.max(0, Math.min(60, +v)); return blank(mm); });
      t = t.replace(/(\d{1,2})\s*\/\s*(\d{1,2})/g, (mm, a, b) => { o.beats = Math.max(1, Math.min(12, +a)); o.beatUnit = +b || 4; return blank(mm); });
      if (t.trim() && !bad) bad = { msg: `这一行看不懂：“${t.trim().slice(0, 16)}”。鼓谱的每一行要以鼓的名字和 | 开头，比如 军鼓|----o-------o---|`, pos: l.pos };
    }
    if (bad) return err(bad.msg, bad.pos);
    // 拍号的单位是四分音符：每格 = 1/16 → 一拍 4 格；6/8 这种按八分音符算一拍
    const den = o.unitDen || 16;
    o.per = Math.max(1, Math.round(den / o.beatUnit));
    if (den / o.beatUnit !== o.per) return err(`每格=1/${den} 和拍号 ${o.beats}/${o.beatUnit} 对不上（每拍要正好是整数格）`, 0);
    // 连在一起的鼓谱行是一组；组和组之间空行隔开
    const groups = [];
    let cur = null, lastIdx = -2;
    tabLines.forEach((l) => {
      const idx = lines.findIndex((x) => x.pos === l.pos);
      if (!cur || idx !== lastIdx + 1) { cur = []; groups.push(cur); }
      cur.push(l); lastIdx = idx;
    });
    const rows = {};
    const bars = [];
    const events = [];
    let offset = 0;
    for (const g of groups) {
      let width = 0;
      const seen = new Set();
      const parsed = [];
      for (const l of g) {
        if (seen.has(l.inst)) return err(`同一组里写了两行${INST[l.inst][0]}`, l.pos);
        seen.add(l.inst);
        const cells = [], barAt = [];
        const txt = l.cellsText.replace(/\s+$/, '');
        for (let k = 0; k < txt.length; k++) {
          const c = txt[k];
          if (c === '|') { barAt.push(cells.length); continue; }
          if (c === ' ' || c === '\t') continue;
          if (c === '-' || c === '.') { cells.push(null); continue; }
          if (VEL[c] !== undefined) { cells.push({ v: VEL[c], src: l.cellsAt + k }); continue; }
          return err(`${INST[l.inst][0]}那一行有看不懂的“${c}”：只能写 - o x O X g 和 |`, l.cellsAt + k);
        }
        parsed.push({ l, cells, barAt });
        width = Math.max(width, cells.length);
      }
      // 同一组的每一行要一样长、小节线对齐
      const ref = parsed.reduce((a, b) => (b.barAt.length > a.barAt.length ? b : a), parsed[0]);
      for (const p of parsed) {
        if (p.cells.length !== width) return err(`这一组里各行长度不一样：${INST[p.l.inst][0]}有 ${p.cells.length} 格，最长的有 ${width} 格`, p.l.pos);
        if (p.barAt.length && ref.barAt.length && p.barAt.join() !== ref.barAt.join()) return err(`${INST[p.l.inst][0]}那一行的小节线和其他行没对齐`, p.l.pos);
      }
      for (const b of ref.barAt) if (b > 0 && (!bars.length || bars[bars.length - 1] !== offset + b)) bars.push(offset + b);
      for (const p of parsed) {
        rows[p.l.inst] = rows[p.l.inst] || [];
        p.cells.forEach((c, k) => {
          rows[p.l.inst][offset + k] = c ? c.v : 0;
          if (c) events.push({ cell: offset + k, inst: p.l.inst, vel: c.v, src: [c.src, c.src + 1] });
        });
      }
      offset += width;
    }
    for (const id in rows) for (let k = 0; k < offset; k++) rows[id][k] = rows[id][k] || 0;
    if (!bars.length || bars[bars.length - 1] !== offset) if (offset) bars.push(offset);
    events.sort((a, b) => a.cell - b.cell);
    for (const e of events) e.t = e.cell / o.per;
    const used = ORDER.filter((id) => rows[id]);
    return { ...o, unitDen: den, rows, used, cells: offset, total: offset / o.per, bars, events, error: null };
  }

  // 每小节的格数对不对：返回 [{bar, got, want}]
  function checkBars(sc) {
    const want = sc.beats * sc.per, bad = [];
    let prev = 0;
    sc.bars.forEach((b, k) => { const got = b - prev; if (got !== want && !(k === sc.bars.length - 1 && got < want)) bad.push({ bar: k + 1, got, want }); prev = b; });
    return bad;
  }

  // 把格子写回成鼓谱文字（网格编辑用）：每两小节一组
  function serialize(sc, { barsPerLine = 2, header } = {}) {
    const per = sc.per, beats = sc.beats, cellsPerBar = per * beats;
    const nBars = Math.max(1, Math.ceil(sc.cells / cellsPerBar));
    const used = ORDER.filter((id) => sc.rows[id] && sc.rows[id].some((v) => v > 0));
    const ids = used.length ? used : ['hihat', 'snare', 'kick'];
    const ch = (v) => (!v ? '-' : v >= 0.95 ? 'O' : v <= 0.4 ? 'g' : 'o');
    const head = header || `♩=${sc.bpm} ${beats}/${sc.beatUnit} 每格=1/${sc.unitDen} 鼓组=${KITS[sc.kit]}${sc.swing ? ' 摇摆=' + sc.swing : ''}`;
    const nameW = Math.max(...ids.map((id) => INST[id][0].length));
    const out = [head];
    for (let b0 = 0; b0 < nBars; b0 += barsPerLine) {
      out.push('');
      for (const id of ids) {
        const nm = INST[id][0];
        let line = nm + '　'.repeat(nameW - nm.length) + '|';
        for (let b = b0; b < Math.min(nBars, b0 + barsPerLine); b++) {
          for (let k = 0; k < cellsPerBar; k++) {
            const v = (sc.rows[id] || [])[b * cellsPerBar + k];
            line += ch(v);
          }
          line += '|';
        }
        out.push(line);
      }
    }
    return out.join('\n');
  }

  /* ---------- 声音 ---------- */
  // 简单的二阶滤波器（RBJ）
  function biquad(type, f, q, sr) {
    const w = 2 * Math.PI * f / sr, c = Math.cos(w), s = Math.sin(w), a = s / (2 * q);
    let b0, b1, b2, a0, a1, a2;
    if (type === 'hp') { b0 = (1 + c) / 2; b1 = -(1 + c); b2 = (1 + c) / 2; }
    else if (type === 'lp') { b0 = (1 - c) / 2; b1 = 1 - c; b2 = (1 - c) / 2; }
    else { b0 = a; b1 = 0; b2 = -a; }   // bp
    a0 = 1 + a; a1 = -2 * c; a2 = 1 - a;
    const B0 = b0 / a0, B1 = b1 / a0, B2 = b2 / a0, A1 = a1 / a0, A2 = a2 / a0;
    let x1 = 0, x2 = 0, y1 = 0, y2 = 0;
    return (x) => { const y = B0 * x + B1 * x1 + B2 * x2 - A1 * y1 - A2 * y2; x2 = x1; x1 = x; y2 = y1; y1 = y; return y; };
  }
  let seed = 22222;
  const noise = () => { seed = (seed * 16807) % 2147483647; return seed / 1073741823.5 - 1; };
  // 镲片：六个互相不成整数比的方波叠在一起（像 808 的做法），再过高通，听起来是金属声
  const METAL = [205.3, 304.4, 369.6, 522.7, 540, 800];
  function metal(t, k = 1) { let v = 0; for (const f of METAL) v += ((f * k * t) % 1) < 0.5 ? 1 : -1; return v / 6; }

  // 一个鼓的声音写进 out（单声道），从第 i0 个采样开始；返回写到哪
  function hit(out, sr, i0, inst, vel, kit, chokeAt) {
    const E = kit === 'electronic';
    const len = (s) => Math.min(out.length - i0, Math.floor(s * sr));
    const v = vel;
    switch (inst) {
      case 'kick': {
        const n = len(E ? 0.9 : 0.5); let ph = 0;
        const f0 = E ? 120 : 140, f1 = E ? 45 : 52, dec = E ? 0.55 : 0.28;
        const lp = biquad('lp', 3000, 0.7, sr);
        for (let j = 0; j < n; j++) {
          const t = j / sr;
          const f = f1 + (f0 - f1) * Math.exp(-t / (E ? 0.05 : 0.035));
          ph += f / sr;
          let s = Math.sin(2 * Math.PI * ph) * Math.exp(-t / dec);
          if (!E) s = Math.tanh(s * 1.6) * 0.85;
          if (j < sr * 0.004) s += lp(noise()) * 0.5 * (1 - j / (sr * 0.004));   // 鼓槌敲到鼓皮的“哒”
          out[i0 + j] += s * v * 0.95;
        }
        return;
      }
      case 'snare': case 'rim': case 'clap': {
        if (inst === 'rim') {
          const n = len(0.07), bp = biquad('bp', 1750, 6, sr);
          for (let j = 0; j < n; j++) { const t = j / sr; out[i0 + j] += (bp(noise()) * 3 + Math.sin(2 * Math.PI * 820 * t) * 0.6) * Math.exp(-t / 0.012) * v * 0.6; }
          return;
        }
        if (inst === 'clap') {
          const n = len(0.35), bp = biquad('bp', 1100, 1.2, sr);
          for (let j = 0; j < n; j++) {
            const t = j / sr;
            const env = (t < 0.03 ? Math.exp(-((t % 0.01)) / 0.0025) : 0) + Math.exp(-t / 0.11) * 0.7;
            out[i0 + j] += bp(noise()) * env * v * 0.9;
          }
          return;
        }
        const n = len(E ? 0.3 : 0.38);
        const hp = biquad('hp', E ? 1500 : 1800, 0.7, sr), lp = biquad('lp', E ? 7000 : 9500, 0.7, sr);
        let p1 = 0, p2 = 0;
        for (let j = 0; j < n; j++) {
          const t = j / sr;
          p1 += (E ? 190 : 185) * (1 + 0.6 * Math.exp(-t / 0.01)) / sr; p2 += 330 / sr;
          const body = (Math.sin(2 * Math.PI * p1) * 0.7 + Math.sin(2 * Math.PI * p2) * 0.35) * Math.exp(-t / (E ? 0.05 : 0.07));
          const wires = lp(hp(noise())) * Math.exp(-t / (E ? 0.09 : 0.14)) * (0.9 + 0.4 * v);
          out[i0 + j] += (body * 0.8 + wires * 1.1) * v * 0.75;
        }
        return;
      }
      case 'tom1': case 'tom2': case 'tom3': {
        const f = { tom1: E ? 190 : 210, tom2: E ? 140 : 155, tom3: E ? 95 : 105 }[inst];
        const n = len(E ? 0.7 : 0.6); let ph = 0;
        const bp = biquad('bp', f * 3, 1.5, sr);
        for (let j = 0; j < n; j++) {
          const t = j / sr;
          ph += f * (1 + 0.5 * Math.exp(-t / 0.03)) / sr;
          const s = Math.sin(2 * Math.PI * ph) * Math.exp(-t / (E ? 0.3 : 0.22)) + bp(noise()) * Math.exp(-t / 0.02) * 0.6;
          out[i0 + j] += (E ? s : Math.tanh(s * 1.3)) * v * 0.8;
        }
        return;
      }
      case 'hihat': case 'openhat': case 'pedal': {
        const open = inst === 'openhat';
        const dec = open ? 0.45 : inst === 'pedal' ? 0.03 : 0.045;
        let n = len(open ? 1.0 : 0.15);
        if (open && chokeAt) n = Math.min(n, chokeAt - i0 + Math.floor(0.01 * sr));   // 下一下闭镲会把开镲按住
        const hp = biquad('hp', E ? 7000 : 6500, 0.8, sr), hp2 = biquad('hp', 8000, 0.7, sr);
        for (let j = 0; j < n; j++) {
          const t = j / sr;
          let env = Math.exp(-t / dec);
          if (open && chokeAt && i0 + j > chokeAt) env *= Math.exp(-(i0 + j - chokeAt) / (0.004 * sr));
          const s = hp2(hp(metal(t, E ? 1.6 : 2.2) * 0.6 + noise() * 0.5));
          out[i0 + j] += s * env * v * (inst === 'pedal' ? 0.35 : 0.55);
        }
        return;
      }
      case 'crash': case 'ride': case 'bell': {
        const dec = inst === 'crash' ? 1.6 : inst === 'ride' ? 0.9 : 0.6;
        const n = len(dec * 2.6);
        const hp = biquad('hp', inst === 'crash' ? 3500 : 4500, 0.7, sr), lp = biquad('lp', inst === 'crash' ? 12000 : 9000, 0.7, sr);
        for (let j = 0; j < n; j++) {
          const t = j / sr;
          const env = Math.exp(-t / dec) * (inst === 'crash' ? Math.min(1, t / 0.002) : 1);
          let s = lp(hp(metal(t, 3.1) * 0.7 + noise() * (inst === 'crash' ? 0.9 : 0.35)));
          if (inst !== 'crash') s += (Math.sin(2 * Math.PI * 2350 * t) + 0.6 * Math.sin(2 * Math.PI * 3510 * t)) * (inst === 'bell' ? 0.5 : 0.12) * Math.exp(-t / (dec * 0.6));
          out[i0 + j] += s * env * v * (inst === 'crash' ? 0.5 : 0.42);
        }
        return;
      }
    }
  }

  // 节拍器的“嘀”：第一拍高一点、响一点；细分的拍很轻
  function click(L, R, sr, i0, kind, vol) {
    const f = kind === 'accent' ? 1760 : kind === 'beat' ? 1180 : 900;
    const a = (kind === 'accent' ? 0.55 : kind === 'beat' ? 0.4 : 0.18) * vol;
    const n = Math.min(L.length - i0, Math.floor(0.035 * sr));
    for (let j = 0; j < n; j++) { const t = j / sr; const s = Math.sin(2 * Math.PI * f * t) * Math.exp(-t / 0.008) * a; L[i0 + j] += s; R[i0 + j] += s; }
  }

  // 演奏时间：摇摆把每一对格子里的后一格往后拖一点；稍微有一点人的误差
  function timeOf(sc, cell) {
    const spb = 60 / sc.bpm;
    let t = cell / sc.per;
    if (sc.swing && sc.per % 2 === 0 && cell % 2 === 1) t += (sc.swing / 100) / sc.per;
    return t * spb;
  }

  // opts：{ metronome: {on, vol, sub:'none'|'8th'|'16th'|'triplet'}, countIn: 小节数, loops: 次数 }
  async function render(sc, { sampleRate = 44100, metronome = null, countIn = 0, loops = 1, humanize = true } = {}) {
    const sr = sampleRate, spb = 60 / sc.bpm;
    const pre = countIn * sc.beats * spb;
    const songLen = Math.max(sc.total, sc.bars.length ? sc.bars[sc.bars.length - 1] / sc.per : 0) * spb;
    const tail = 1.8;
    const n = Math.ceil((pre + songLen * loops + tail) * sr);
    const L = new Float32Array(n), R = new Float32Array(n);
    const tmp = new Float32Array(Math.ceil(3.2 * sr));
    let hs = 777;
    const jit = () => { hs = (hs * 16807) % 2147483647; return hs / 2147483647 - 0.5; };
    for (let lp = 0; lp < loops; lp++) {
      const base = pre + lp * songLen;
      const evs = sc.events;
      for (let k = 0; k < evs.length; k++) {
        const e = evs[k];
        const t = base + timeOf(sc, e.cell) + (humanize ? jit() * 0.004 : 0);
        const i0 = Math.max(0, Math.floor(t * sr));
        if (i0 >= n) continue;
        let chokeAt = null;
        if (e.inst === 'openhat') {
          const nx = evs.find((x) => x.cell > e.cell && (x.inst === 'hihat' || x.inst === 'pedal'));
          if (nx) chokeAt = Math.floor((base + timeOf(sc, nx.cell)) * sr);
        }
        const vel = Math.max(0.05, Math.min(1, e.vel * (humanize ? 1 + jit() * 0.1 : 1)));
        tmp.fill(0);
        const sub = tmp.subarray(0, Math.min(tmp.length, n - i0));
        hit(sub, sr, 0, e.inst, vel, sc.kit, chokeAt === null ? null : chokeAt - i0);
        const pan = INST[e.inst][2], gl = Math.cos((pan + 1) * Math.PI / 4), gr = Math.sin((pan + 1) * Math.PI / 4);
        for (let j = 0; j < sub.length; j++) { const s = sub[j]; if (s) { L[i0 + j] += s * gl; R[i0 + j] += s * gr; } }
      }
    }
    // 节拍器（和预备拍）
    const totalBeats = countIn * sc.beats + (songLen / spb) * loops;
    const mOn = metronome && metronome.on;
    for (let b = 0; b < totalBeats - 1e-6; b++) {
      const inCount = b < countIn * sc.beats;
      if (!mOn && !inCount) continue;
      const vol = mOn ? metronome.vol ?? 0.8 : 0.8;
      const inBar = b % sc.beats;
      click(L, R, sr, Math.floor(b * spb * sr), inBar === 0 ? 'accent' : 'beat', vol);
      const subN = mOn ? { '8th': 2, '16th': 4, triplet: 3 }[metronome.sub] || 1 : 1;
      for (let s = 1; s < subN; s++) click(L, R, sr, Math.floor((b + s / subN) * spb * sr), 'sub', vol);
    }
    // 房间混响 + 压缩，最后限幅
    const ctx = new OfflineAudioContext(2, n, sr);
    const dry = ctx.createBuffer(2, n, sr); dry.copyToChannel(L, 0); dry.copyToChannel(R, 1);
    const src = ctx.createBufferSource(); src.buffer = dry;
    const master = ctx.createGain(); master.gain.value = 1.15;
    const comp = ctx.createDynamicsCompressor(); comp.threshold.value = -12; comp.ratio.value = 3; comp.attack.value = 0.003; comp.release.value = 0.15;
    master.connect(comp); comp.connect(ctx.destination);
    const rev = ctx.createConvolver();
    const irLen = Math.floor(sr * (sc.kit === 'electronic' ? 0.6 : 0.9)), ir = ctx.createBuffer(2, irLen, sr);
    for (let c = 0; c < 2; c++) { const d = ir.getChannelData(c); let sd = 99 + c * 31; for (let k = 0; k < irLen; k++) { sd = (sd * 16807) % 2147483647; d[k] = ((sd / 2147483647) * 2 - 1) * Math.pow(1 - k / irLen, 4); } }
    rev.buffer = ir;
    const wet = ctx.createGain(); wet.gain.value = 0.12;
    src.connect(master); src.connect(rev); rev.connect(wet); wet.connect(master);
    src.start(0);
    const out = await ctx.startRendering();
    let peak = 0;
    for (let c = 0; c < 2; c++) { const d = out.getChannelData(c); for (let i = 0; i < d.length; i++) { const a = d[i] < 0 ? -d[i] : d[i]; if (a > peak) peak = a; } }
    if (peak > 0.95) for (let c = 0; c < 2; c++) { const d = out.getChannelData(c), k = 0.95 / peak; for (let i = 0; i < d.length; i++) d[i] *= k; }
    out.__pre = pre; out.__songLen = songLen;
    return out;
  }

  // 只敲一下（点格子、试音用）
  function renderHit(inst, kit, vel = 0.85) {
    return render({ bpm: 120, beats: 4, beatUnit: 4, per: 4, kit, swing: 0, total: 0.5, bars: [], events: [{ cell: 0, t: 0, inst, vel }] }, { humanize: false });
  }

  function toWav(buf) {
    const ch = buf.numberOfChannels, sr = buf.sampleRate, n = buf.length;
    const out = new DataView(new ArrayBuffer(44 + n * ch * 2));
    const w = (o, s) => { for (let k = 0; k < s.length; k++) out.setUint8(o + k, s.charCodeAt(k)); };
    w(0, 'RIFF'); out.setUint32(4, 36 + n * ch * 2, true); w(8, 'WAVE'); w(12, 'fmt ');
    out.setUint32(16, 16, true); out.setUint16(20, 1, true); out.setUint16(22, ch, true); out.setUint32(24, sr, true);
    out.setUint32(28, sr * ch * 2, true); out.setUint16(32, ch * 2, true); out.setUint16(34, 16, true); w(36, 'data'); out.setUint32(40, n * ch * 2, true);
    const data = []; for (let c = 0; c < ch; c++) data.push(buf.getChannelData(c));
    let o = 44;
    for (let k = 0; k < n; k++) for (let c = 0; c < ch; c++) { const v = Math.max(-1, Math.min(1, data[c][k])); out.setInt16(o, v < 0 ? v * 0x8000 : v * 0x7fff, true); o += 2; }
    return new Uint8Array(out.buffer);
  }

  // 鼓谱 → MIDI：第 10 声道（打击乐），按 GM 鼓的音符号
  function toMidi(sc) {
    const tpq = 480, ev = [];
    const spb = 60 / sc.bpm;
    for (const e of sc.events) {
      const t = Math.round(timeOf(sc, e.cell) / spb * tpq), d = Math.round(tpq / sc.per * 0.9);
      const vel = Math.max(20, Math.min(127, Math.round(e.vel * 120)));
      ev.push({ t, on: 1, m: INST[e.inst][1], vel }); ev.push({ t: t + d, on: 0, m: INST[e.inst][1], vel: 0 });
    }
    ev.sort((a, b) => a.t - b.t || a.on - b.on);
    const bytes = [];
    const vlq = (v) => { const s = [v & 0x7f]; while ((v >>= 7)) s.unshift((v & 0x7f) | 0x80); bytes.push(...s); };
    const us = Math.round(60000000 / sc.bpm);
    vlq(0); bytes.push(0xff, 0x51, 0x03, (us >> 16) & 255, (us >> 8) & 255, us & 255);
    vlq(0); bytes.push(0xff, 0x58, 0x04, sc.beats, Math.round(Math.log2(sc.beatUnit || 4)), 24, 8);
    let prev = 0;
    for (const e of ev) { vlq(e.t - prev); prev = e.t; bytes.push((e.on ? 0x99 : 0x89), e.m, e.vel); }
    vlq(0); bytes.push(0xff, 0x2f, 0x00);
    const head = [0x4d, 0x54, 0x68, 0x64, 0, 0, 0, 6, 0, 0, 0, 1, (tpq >> 8) & 255, tpq & 255];
    const Ln = bytes.length;
    return new Uint8Array([...head, 0x4d, 0x54, 0x72, 0x6b, (Ln >>> 24) & 255, (Ln >> 16) & 255, (Ln >> 8) & 255, Ln & 255, ...bytes]);
  }

  // 常用的节奏（网格里可以直接套用）
  const PRESETS = {
    '八拍基本节奏': '♩=100 4/4 每格=1/16 鼓组=原声\n\n踩镲|x-x-x-x-x-x-x-x-|x-x-x-x-x-x-x-x-|\n军鼓|----o-------o---|----o-------o---|\n底鼓|o-------o-o-----|o-------o-o-----|',
    '十六拍流行': '♩=92 4/4 每格=1/16 鼓组=原声\n\n踩镲|xxxxxxxxxxxxxxxx|xxxxxxxxxxxxxxxx|\n军鼓|----O-------O---|----O--g----O---|\n底鼓|o-----o---o-----|o-----o---o-o---|',
    '乐队摇滚（加花收尾）': '♩=150 4/4 每格=1/8 鼓组=原声\n\n吊镲|O-------|--------|--------|--------|\n踩镲|--x-x-x-|x-x-x-x-|x-x-x-x-|x-------|\n军鼓|--O---O-|--O---O-|--O---O-|--OOoooo|\n高嗵|--------|--------|--------|----oo--|\n底鼓|o---o---|o---o---|o---o---|o-------|',
    '四踩舞曲': '♩=124 4/4 每格=1/16 鼓组=电子\n\n开镲|--o---o---o---o-|--o---o---o---o-|\n拍手|----o-------o---|----o-------o---|\n底鼓|o---o---o---o---|o---o---o---o---|',
    '抒情慢歌': '♩=72 4/4 每格=1/16 鼓组=原声\n\n叮叮镲|o-o-o-o-o-o-o-o-|o-o-o-o-o-o-o-o-|\n边击　|--------o-------|--------o-------|\n底鼓　|o-------o--o----|o-------o-------|',
    '三拍子华尔兹': '♩=96 3/4 每格=1/8 鼓组=原声\n\n踩镲|x-x-x-|x-x-x-|\n军鼓|--o-o-|--o-o-|\n底鼓|o-----|o-----|',
    '摇摆爵士': '♩=120 4/4 每格=1/8 鼓组=原声 摇摆=60\n\n叮叮镲|o-oxo-ox|o-oxo-ox|\n踏镲　|--o---o-|--o---o-|\n底鼓　|o-------|o-------|',
  };

  root.Drums = { parse, checkBars, serialize, render, renderHit, toWav, toMidi, INST, ORDER, ALIAS, KITS, KIT_ALIAS, PRESETS, timeOf };
})(typeof window !== 'undefined' ? window : globalThis);
