'use strict';
/* 一起合奏（主进程部分）
 * 按乐队分工：一歌 电吉他 + 主唱、咲希 电子琴、穗波 架子鼓、志步 贝斯。
 *  - 让大家写：聊天模型按段落写出四个声部 + 主唱的旋律和歌词（合奏谱，格式见 ui/w/band-core.js）
 *  - 拆解谱子：MIDI / MusicXML 在合奏窗口里本地拆成四个声部；简谱、六线谱、和弦谱这类文字和谱子的图片交给模型来拆
 *  - 各声部用各自桌宠原来的乐器合成（窗口里算），一歌用她复刻的音色唱（和白葱桌宠一样：每个音念一遍，再变调对齐到旋律上）
 * 这里负责：调用模型、检查谱子、一歌的逐音合成、保存文件、让桌面上的四个人跟着演。 */
const path = require('path');
const fs = require('fs');
const vm = require('vm');
const crypto = require('crypto');
const { ipcMain, app, shell, dialog } = require('electron');

const W = path.join(__dirname, 'ui', 'w');
const Core = require(path.join(W, 'band-core.js'));
const SingDSP = require(path.join(W, 'sing-dsp.js'));
// 四个成员的谱子解析各自放在一个独立的环境里（它们都叫 Jianpu，放在一起会互相覆盖）
function loadEngine(file, name) {
  const ctx = { console };
  ctx.globalThis = ctx;
  vm.createContext(ctx);
  vm.runInContext(fs.readFileSync(path.join(W, file), 'utf8'), ctx, { filename: file });
  return ctx[name];
}
const E = { guitar: loadEngine('guitar-jianpu.js', 'Guitar'), keys: loadEngine('keys-jianpu.js', 'Jianpu'), bass: loadEngine('bass-jianpu.js', 'Bass'), drums: loadEngine('drums.js', 'Drums') };

class BandError extends Error { constructor(m, extra = {}) { super(m); Object.assign(this, extra); } }

/* ---------- 写合奏谱的说明（给聊天模型） ---------- */
const LEN = { short: [12, 20], mid: [24, 36], long: [36, 52] };
function writingRules({ beats, grid }) {
  const cells = beats * (grid / 4);
  return `【写法】
吉他（一歌）、电子琴（咲希）、贝斯（志步）都写简谱正文，不要写开头的“1=… ♩=… 音色=…”那一行，也不要写“和弦：”行（这些会自动加）：
- 1–7 是音，0 是休止；默认一拍；- 延长一拍（前面空格）；_ 半拍，__ 四分之一拍，. 附点（2_. 是 3/4 拍）
- 高八度在后面加 '，低八度加 ,；升降号写在前面：#4 b7
- [1 3 5] 是几个音一起弹；| 是小节线
- 每一段里，每个声部的总拍数必须正好是 小节数 × ${beats}
- 吉他和电子琴的 1 在中央 C 附近；贝斯的 1 是这个调在贝斯上最低的主音（1=E 时是空弦 E，1=C 时是 C2），低八度 , 最低只能到空弦 E
- 吉他：前奏、间奏、尾声弹主音 riff 或旋律，有人唱的时候以休止为主，偶尔加一点小 fill（伴奏的扫弦会按和弦自动加上）；可以用 ~ 揉弦、^ 推弦（写在音后面）
- 电子琴：写对位旋律、点缀或长音（左右手伴奏会按和弦自动加），副歌可以亮一点
- 贝斯：跟着和弦走根音，八分音符或四分音符为主，副歌更有推动感；不要写和弦 [ ]

鼓（穗波）写鼓谱行：每行“鼓名|格子|”，一小节 ${cells} 格（每格=1/${grid}），每小节后面写 |；同一段里每一行一样长
- 格子：- 空，o 敲，O 重音，g 很轻的鬼音
- 鼓名只能用：底鼓、军鼓、边击、拍手、踩镲、开镲、踏镲、高嗵、中嗵、落地嗵、吊镲、叮叮镲
- 主歌稳一点（踩镲 + 底鼓 + 军鼓），副歌更满，段落开头可以敲吊镲，段落最后一小节可以加花（嗵鼓、军鼓连打）

和弦：每段写 "| C | G | Am | F |"，一小节一格，一格最多两个和弦（"| C G |"）；和弦只用：大三（C）、m、7、maj7、m7、sus4、sus2、add9、dim、aug、6、m6、9

主唱（一歌唱）：每段的 vocal 是这一段要唱的句子
- {"bar": 这一段里的第几小节（从 0 开始）, "beat": 这一小节里的第几拍开始（从 0 开始，可以是 0.5）, "text": "这一句的歌词", "units": ["每个音唱的字"], "notes": [[半音, 拍数], ...]}
- 半音以 1（do）为 0：1=0、2=2、3=4、4=5、5=7、6=9、7=11、高音 1=12、低音 6=-3、低音 5=-5；音域 -5 到 14 之间
- 拍数只能是 0.25、0.5、0.75、1、1.5、2、3、4；句中的休止写 [null, 拍数]，休止不占字
- units 的个数必须等于 notes 里不是 null 的音的个数；一句不超过 14 个音
- 句子不能互相重叠，不能超出这一段；旋律要和这一段的和弦配合，好唱、有记忆点，副歌是全曲最高潮
- 中文歌词一个字一个音；日语歌词 units 用假名，一个拍（mora）一个音（拗音“きょ”算一个，促音“っ”、长音“ー”单独算一个）`;
}
const SHAPE = `只输出一个 JSON 对象：
{"title":"曲名","bpm":120,"key":"D","beats":4,
 "tones":{"guitar":"清音|过载|失真","keys":"电子琴|电钢琴|风琴|合成器","keysStyle":"流行|分解|柱式|长音","bass":"指弹|拨片|击弦|过载","kit":"原声|电子","grid":16},
 "sections":[{"name":"前奏","bars":4,"chords":"| D | A | Bm | G |","guitar":"…","keys":"…","bass":"…","drums":"踩镲|…|\\n军鼓|…|\\n底鼓|…|","vocal":[]},
   {"name":"主歌2","same":"主歌1","vocal":[…]}],
 "comment":{"ichika":"…","saki":"…","honami":"…","shiho":"…"}}
- key 是 1= 后面的音（只能是 C Db D Eb E F F# G Ab A Bb B）；小调的歌按它的关系大调写（A 小调写 key "C"，主音是 6）
- 和前面某一段的伴奏完全一样时，用 "same":"那一段的名字" 代替 chords、guitar、keys、bass、drums（可以只写新的 vocal），能省很多字
- comment 是四个人各自对自己声部的一句话（中文，像她们平时说话），不超过 30 字`;

module.exports = function createBand({ team, members, online, shared, state, llm, group, getWin, userData, appDir }) {
  const send = (ch, v) => { const w = getWin(); if (w && !w.isDestroyed()) w.webContents.send(ch, v); };
  const fromWin = (e) => { const w = getWin(); return w && !w.isDestroyed() && e.sender === w.webContents; };
  const jobs = new Map();
  let project = null;           // { dir, title }
  const sOf = (id) => (team[id] ? team[id].settings() : shared.get());
  const chatCfg = (t = 0.85) => { const s = sOf('ichika'); return { apiType: s.apiType || '', apiBase: s.apiBase, apiKey: s.apiKey, model: String(s.model || '').trim(), temperature: t, keyLabel: '聊天模型的 API 密钥' }; };

  async function job(id, fn) {
    const ctl = new AbortController();
    jobs.set(String(id), ctl);
    try { return await fn(ctl.signal); }
    catch (e) { return { error: ctl.signal.aborted ? '已取消' : String(e && e.message || e), canceled: ctl.signal.aborted, noConfig: !!(e && e.noConfig) }; }
    finally { jobs.delete(String(id)); }
  }
  const handle = (ch, fn) => ipcMain.handle(ch, async (e, p = {}) => {
    if (!fromWin(e)) return { error: '只能在合奏窗口里使用' };
    try { return await fn(p || {}, e); } catch (err) { return { error: String(err && err.message || err) }; }
  });
  async function chatJSON(system, user, signal, maxTokens = 8000) {
    const cfg = chatCfg();
    if (!llm.hasChatApi(cfg) || !cfg.model) throw new BandError('还没有设置聊天模型（群聊窗口 → 团队设置）', { noConfig: true });
    const r = await llm.request(cfg, { system, messages: [{ role: 'user', content: user }], stream: false, json: true, maxTokens, signal });
    if (r.error) throw new BandError('聊天模型出错：' + r.error);
    const t = String(r.data.choices[0].message.content || ''), a = t.indexOf('{'), b = t.lastIndexOf('}');
    if (a < 0 || b <= a) throw new BandError('模型没有按格式回答（可能是曲子太长、回答被截断了，试试短一点）');
    try { return JSON.parse(t.slice(a, b + 1)); } catch (e) { throw new BandError('模型回答的格式不对（可能被截断了，试试短一点）'); }
  }
  const progress = (id, stage, extra = {}) => send('band-progress', { id, stage, ...extra });

  // 检查一份合奏谱；有段落写错了，就把错误告诉模型、只让它重写那几段的那几个声部（最多一次）
  async function checkAndRepair(raw, { id, signal, context }) {
    let r = Core.assemble(raw, E, { syllabify: SingDSP.syllabify });
    if (!r.bad.length) return { raw, r };
    progress(id, 'repair', { count: r.bad.length });
    const list = r.bad.slice(0, 12).map((b) => `- 「${b.section}」的${Core.PART_LABEL[b.part]}（${b.part}）：${b.error}${b.near ? `（在“${b.near}”附近）` : ''}`).join('\n');
    const sys = `你是 Leo/need 的编曲搭档，刚才写的合奏谱有几处写法不对，只重写出错的那几段的那几个声部。\n${writingRules({ beats: r.song.beats, grid: r.song.tones.grid })}\n\n只输出 JSON：{"sections":[{"name":"段落名","声部（guitar/keys/bass/drums）":"重写的内容"}]}`;
    const want = r.bad.map((b) => { const s = r.song.sections.find((x) => x.name === b.section); return `「${b.section}」${s ? s.bars : '?'} 小节，和弦 ${s ? s.chords : ''}`; });
    try {
      const fix = await chatJSON(sys, `${context ? context + '\n\n' : ''}出错的地方：\n${list}\n\n这些段的长度和和弦：\n${[...new Set(want)].join('\n')}\n调 1=${r.song.key}，${r.song.beats}/4 拍，♩=${r.song.bpm}`, signal, 4000);
      for (const s of Array.isArray(fix.sections) ? fix.sections : []) {
        const tgt = (raw.sections || []).find((x) => x && String(x.name).trim() === String(s && s.name || '').trim());
        if (!tgt) continue;
        for (const p of Core.PARTS) if (s[p] != null && r.bad.some((b) => b.section === tgt.name && b.part === p)) tgt[p] = String(s[p]);
      }
      r = Core.assemble(raw, E, { syllabify: SingDSP.syllabify });
    } catch (e) { if (signal.aborted) throw e; }
    return { raw, r };
  }
  const result = (raw, r, extra = {}) => ({ ok: true, raw: r.song, bad: r.bad, warnings: r.warnings, comment: raw.comment && typeof raw.comment === 'object' ? raw.comment : null, ...extra });

  /* ---------- 准备情况 ---------- */
  handle('band-config', () => {
    const cfg = chatCfg(), ic = sOf('ichika');
    let vision = null; try { vision = team.ichika && team.ichika.visionCfg ? team.ichika.visionCfg() : null; } catch (e) {}
    return {
      chatReady: llm.hasChatApi(cfg) && !!cfg.model, chatModel: cfg.model,
      voiceReady: !!(llm.cleanKey(ic.ttsKey) && String(ic.ttsVoiceId || '').trim()),
      visionReady: !!(vision && vision.apiKey),
      online: members.map((m) => ({ id: m.id, online: online(m.id) })),
      project: project ? project.dir : '',
    };
  });

  /* ---------- 1. 让大家写 / 按上传的谱子编 ---------- */
  handle('band-compose', (p) => job(p.id, async (signal) => {
    const beats = [3, 4].includes(+p.beats) ? +p.beats : 4;
    const grid = +p.grid === 8 ? 8 : 16;
    const [lo, hi] = LEN[p.length] || LEN.mid;
    const lang = p.language === 'ja' ? 'ja' : 'zh';
    const vocal = p.vocal !== false;
    const src = String(p.source || '').trim().slice(0, 6000);
    const sys = `你是 Leo/need 的编曲搭档，替四人乐队写一首合奏曲的总谱：一歌（电吉他 + 主唱）、咲希（电子琴）、穗波（架子鼓）、志步（贝斯）。
Leo/need 的风格：青春感的流行摇滚，真挚、有力量，也有温柔安静的歌；四个声部各有分工，互相留出空间。不要抄现有歌曲的旋律、歌词或编曲。

${writingRules({ beats, grid })}

${SHAPE}`;
    const ask = [];
    if (src) {
      ask.push(`【原谱】下面是要拆解的谱子（可能是简谱、六线谱、和弦谱、五线谱的文字转写或描述）。按它来编：调、速度、拍号、段落、和弦进行尽量保持原样；有旋律就把旋律交给一歌唱（原谱有歌词就用原来的歌词，units 按原来的字分），没有歌词但有旋律时，让一歌的吉他弹这段旋律；原谱里有哪个乐器的谱子，就把它转写到对应的声部；原谱没有的声部按乐队分工补上。总长度按原谱来（最多 60 小节，太长就只取开头）。\n${src}`);
    } else {
      ask.push(`总长度 ${lo}–${hi} 小节；${beats}/4 拍；鼓谱每格=1/${grid}。`);
    }
    if (p.theme) ask.push(`主题 / 想表达的：${String(p.theme).slice(0, 300)}`);
    if (p.style) ask.push(`曲风 / 气氛：${String(p.style).slice(0, 120)}`);
    if (+p.bpm) ask.push(`速度：♩=${Math.max(50, Math.min(220, +p.bpm))}`);
    if (Core.keyPc(p.key) != null && !src) ask.push(`调：1=${Core.keyName(Core.keyPc(p.key))}`);
    if (vocal) {
      ask.push(`主唱：要有一歌唱的部分，歌词用${lang === 'ja' ? '日语' : '中文'}。`);
      if (p.lyrics) ask.push(`用这些歌词（可以按旋律分句，不要改字）：\n${String(p.lyrics).slice(0, 1200)}`);
    } else ask.push('这一首是纯器乐，不要主唱：每段的 vocal 都是空数组。');
    if (p.extra) ask.push(`另外：${String(p.extra).slice(0, 300)}`);
    progress(p.id, 'writing');
    const raw = await chatJSON(sys, ask.join('\n'), signal, 8000);
    if (lang === 'ja') raw.vocalLang = 'ja';
    raw.beats = raw.beats || beats;
    raw.tones = { ...(raw.tones || {}), grid: raw.tones && +raw.tones.grid === 8 ? 8 : grid };
    if (!Array.isArray(raw.sections) || !raw.sections.length) throw new BandError('模型没有写出段落');
    progress(p.id, 'checking');
    const { r } = await checkAndRepair(raw, { id: p.id, signal });
    return result(raw, r, { by: chatCfg().model });
  }));

  /* ---------- 2. 只重写某个声部（或主唱），其他声部不动 ---------- */
  handle('band-revise', (p) => job(p.id, async (signal) => {
    const raw = p.raw && typeof p.raw === 'object' ? JSON.parse(JSON.stringify(p.raw)) : null;
    if (!raw || !Array.isArray(raw.sections)) throw new BandError('还没有合奏谱');
    const part = ['guitar', 'keys', 'bass', 'drums', 'vocal'].includes(p.part) ? p.part : 'drums';
    const who = { guitar: '一歌的电吉他', keys: '咲希的电子琴', bass: '志步的贝斯', drums: '穗波的架子鼓', vocal: '一歌唱的旋律和歌词' }[part];
    const lang = raw.vocalLang === 'ja' ? '日语' : '中文';
    const overview = raw.sections.map((s) => {
      const o = { name: s.name, bars: s.bars, chords: s.chords };
      for (const k of Core.PARTS) if (k !== part) o[k] = String(s[k] || '').slice(0, 600);
      if (part !== 'vocal') o.vocal = (s.vocal || []).map((l) => ({ bar: l.bar, beat: l.beat, text: l.text, notes: l.notes }));
      return o;
    });
    const sys = `你是 Leo/need 的编曲搭档。这首合奏曲的其他声部已经写好了，现在只重写${who}，要和其他声部配合好。
${writingRules({ beats: raw.beats || 4, grid: (raw.tones && raw.tones.grid) || 16 })}

只输出 JSON：{"sections":[{"name":"段落名","${part}":${part === 'vocal' ? '[ 这一段的句子 ]' : '"这一段的内容"'}}],"comment":"${who.slice(0, 2)}对这次修改说的一句话"}
- 每一段都要写（段落名、顺序和原来一样），长度必须和原来的小节数一致${part === 'vocal' ? `\n- 歌词用${lang}；不想唱的段落写空数组` : ''}`;
    const user = `调 1=${raw.key}，${raw.beats || 4}/4 拍，♩=${raw.bpm}\n要求：${String(p.instruction || '').slice(0, 300) || '换一种更好的写法'}\n\n现在的合奏谱：\n${JSON.stringify(overview).slice(0, 14000)}`;
    progress(p.id, 'writing');
    const fix = await chatJSON(sys, user, signal, 6000);
    for (const s of Array.isArray(fix.sections) ? fix.sections : []) {
      const tgt = raw.sections.find((x) => String(x.name).trim() === String(s && s.name || '').trim());
      if (!tgt || s[part] == null) continue;
      if (tgt.same) { for (const k of ['chords', ...Core.PARTS]) if (!tgt[k]) { const o = raw.sections.find((x) => x.name === tgt.same); if (o) tgt[k] = o[k]; } delete tgt.same; }
      tgt[part] = part === 'vocal' ? (Array.isArray(s.vocal) ? s.vocal : []) : String(s[part]);
    }
    progress(p.id, 'checking');
    const { r } = await checkAndRepair(raw, { id: p.id, signal });
    const comment = typeof fix.comment === 'string' ? { [{ guitar: 'ichika', keys: 'saki', bass: 'shiho', drums: 'honami', vocal: 'ichika' }[part]]: fix.comment.slice(0, 60) } : null;
    return { ...result(raw, r), comment };
  }));

  /* ---------- 3. 导入的旋律：按乐句的字数写歌词 ---------- */
  handle('band-lyrics', (p) => job(p.id, async (signal) => {
    const phrases = (Array.isArray(p.phrases) ? p.phrases : []).slice(0, 48).map((x) => Math.max(1, Math.min(24, +x.count || 1)));
    if (!phrases.length) throw new BandError('没有要填词的乐句');
    const lang = p.language === 'ja' ? 'ja' : 'zh';
    const sys = `你是 Leo/need 的作词搭档，要为一段已经写好的旋律填词，由一歌来唱。只输出 JSON：{"lines":[{"text":"这一句歌词","units":["每个音唱的字"]}],"comment":"一歌对这首词说的一句话"}
- lines 的个数正好是 ${phrases.length}，第 i 句的 units 个数必须正好等于给出的音数
- ${lang === 'ja' ? '日语：units 用假名，一个拍（mora）一个音' : '中文：一个字一个音，units 就是逐字拆开'}
- 歌词真挚、有画面，青春感，适合 Leo/need；不要抄现有歌曲的歌词`;
    const user = `主题：${String(p.theme || '').slice(0, 200) || '自由发挥'}\n每句的音数：${phrases.join('、')}`;
    progress(p.id, 'writing');
    const r = await chatJSON(sys, user, signal, 3000);
    const lines = (Array.isArray(r.lines) ? r.lines : []).slice(0, phrases.length).map((l, i) => {
      let units = Array.isArray(l && l.units) ? l.units.map(String).filter(Boolean) : SingDSP.syllabify(String(l && l.text || ''));
      if (units.length > phrases[i]) units = units.slice(0, phrases[i]);
      while (units.length < phrases[i]) units.push(lang === 'ja' ? 'ら' : '啦');
      return { text: units.join(''), units };
    });
    return { ok: true, lines, comment: typeof r.comment === 'string' ? { ichika: r.comment.slice(0, 60) } : null };
  }));

  /* ---------- 4. 谱子图片：用看图模型抄成文字 ---------- */
  handle('band-read-image', (p) => job(p.id, async (signal) => {
    const t = team.ichika;
    if (!t || !t.visionCfg) throw new BandError('一歌没有加载成功');
    const v = t.visionCfg();
    if (!v.apiKey) throw new BandError('看谱子图片需要看图模型（团队设置 → 硅基流动 → 看图用的 API 密钥）', { noConfig: true });
    if (!v.model && t.pickVisionModel) v.model = (await t.pickVisionModel(v)) || '';
    if (!v.model) throw new BandError('没有找到可用的看图模型，请在团队设置里填一个');
    const b64 = String(p.b64 || ''), mime = /^image\/(png|jpeg|webp)$/.test(p.mime) ? p.mime : 'image/png';
    if (!b64 || b64.length > 14e6) throw new BandError('图片太大了（最大约 10MB）');
    progress(p.id, 'reading');
    const system = `你是乐谱转写助手。把图片里的乐谱尽量完整、准确地抄成文字，不要评价：
- 先写曲名、调号（写成 1=X）、拍号、速度（有的话）
- 简谱照原样抄（1–7、0、- 、下划线 _ 表示减时、' 和 , 表示八度、| 小节线）；五线谱按小节转成简谱；六线谱 / 四线谱照原样逐行抄
- 有和弦就写成 和弦：| C | G | …；有歌词就把歌词写在对应那一行旋律下面；分声部的谱子每个声部单独抄，标明是哪个乐器
- 看不清的地方写“（看不清）”`;
    const r = await llm.request({ ...v, temperature: 0.1 }, { system, messages: [{ role: 'user', content: [{ type: 'image', mime, b64 }, { type: 'text', text: '请把这张乐谱抄成文字。' }] }], json: false, maxTokens: 3500, signal });
    if (r.error) throw new BandError('看图模型出错：' + r.error);
    const text = String(r.data.choices[0].message.content || '').trim();
    if (!text) throw new BandError('看图模型没有抄出东西');
    return { ok: true, text: text.slice(0, 6000), model: v.model };
  }));

  /* ---------- 5. 一歌的复刻音色：一句一句地念（之后在窗口里变调对齐到旋律上） ---------- */
  const ERR = { 1002: '请求太频繁', 1004: 'MiniMax 鉴权失败，请检查语音的密钥', 1008: 'MiniMax 账户余额不足', 1026: '歌词里有被判定为敏感的内容', 2013: '参数不被接受（模型名或音色 ID 可能不对）', 2049: 'MiniMax 密钥无效' };
  async function speakUnits(s, units, { signal, cacheDir }) {
    const key = llm.cleanKey(s.ttsKey), voiceId = String(s.ttsVoiceId || '').trim();
    if (!key || !voiceId) throw new BandError('一歌唱歌要用 MiniMax 复刻的音色：团队设置 → 声音里填 MiniMax 密钥和一歌的复刻音色 ID', { noConfig: true });
    { const ki = llm.keyIssue(key, 'MiniMax 密钥'); if (ki) throw new BandError(ki, { noConfig: true }); }
    const base = String(s.ttsBase || 'https://api.minimaxi.com').trim().replace(/\/+$/, ''), model = s.ttsModel || 'speech-2.8-hd';
    const gap = Math.max(0.2, Math.min(0.8, Number(s.singGap) || 0.35));
    const text = units.join(`<#${gap.toFixed(2)}#>`);
    const lang = units.some((u) => /[぀-ヿ]/.test(u)) ? 'Japanese' : units.some((u) => /[㐀-鿿]/.test(u)) ? 'Chinese' : 'auto';
    const hash = crypto.createHash('sha1').update([voiceId, model, lang, text].join('|')).digest('hex');
    const file = path.join(cacheDir, hash + '.mp3');
    if (fs.existsSync(file)) return { b64: fs.readFileSync(file).toString('base64'), cached: true };
    let url = base + '/v1/t2a_v2';
    if (String(s.ttsGroupId || '').trim()) url += '?GroupId=' + encodeURIComponent(String(s.ttsGroupId).trim());
    let res;
    try {
      res = await fetch(url, { method: 'POST', signal, headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + key },
        body: JSON.stringify({ model, text, stream: false, language_boost: lang, output_format: 'hex', voice_setting: { voice_id: voiceId, speed: 0.9, vol: 1, pitch: 0 }, audio_setting: { sample_rate: 32000, bitrate: 128000, format: 'mp3', channel: 1 } }) });
    } catch (e) { if (signal.aborted) throw e; throw new BandError('连不上 MiniMax：' + (e.cause && e.cause.code || e.message)); }
    const body = await res.text().catch(() => '');
    if (!res.ok) throw new BandError(`MiniMax 返回 ${res.status}：${body.slice(0, 120)}`);
    let j; try { j = JSON.parse(body); } catch (e) { throw new BandError('MiniMax 返回的内容不是 JSON'); }
    const code = j && j.base_resp && j.base_resp.status_code;
    if (code) throw new BandError(`MiniMax 出错（${code}）${ERR[code] ? '：' + ERR[code] : ''} ${String(j.base_resp.status_msg || '').slice(0, 80)}`.trim());
    const hex = j && j.data && j.data.audio;
    if (!hex || !/^[0-9a-fA-F]+$/.test(hex.slice(0, 200))) throw new BandError('MiniMax 没有返回音频');
    const buf = Buffer.from(hex, 'hex');
    try { fs.mkdirSync(cacheDir, { recursive: true }); fs.writeFileSync(file, buf); } catch (e) {}
    return { b64: buf.toString('base64') };
  }
  handle('band-sing-voice', (p) => job(p.id, async (signal) => {
    const units = Array.isArray(p.units) ? p.units.map(String).filter(Boolean).slice(0, 24) : [];
    if (!units.length) throw new BandError('这一句没有要唱的音');
    const r = await speakUnits(sOf('ichika'), units, { signal, cacheDir: path.join(userData, 'members', 'ichika', 'sing-cache') });
    return { ok: true, b64: r.b64, cached: !!r.cached };
  }));

  /* ---------- 文件 ---------- */
  const safeName = (s, d) => (String(s || '').replace(/[\\/:*?"<>|\r\n]/g, '_').trim() || d).slice(0, 40);
  function ensureProject(title) {
    if (project) return project;
    const d = new Date(), pad = (n) => String(n).padStart(2, '0');
    const stamp = `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}-${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}`;
    let base; try { base = app.getPath('music'); } catch (e) { base = app.getPath('documents'); }
    const t = safeName(title, 'Leoneed的合奏');
    const parent = path.join(base, 'Leoneed合奏');
    fs.mkdirSync(parent, { recursive: true });
    let dir = path.join(parent, `${t}-${stamp}`), suffix = 1;
    for (;;) {
      try { fs.mkdirSync(dir); break; }
      catch (e) { if (e.code !== 'EEXIST') throw e; dir = path.join(parent, `${t}-${stamp}-${++suffix}`); }
    }
    project = { dir, title: t };
    return project;
  }
  const inProject = (name) => {
    const parts = String(name || '').split('/').map((x) => safeName(x, '')).filter((x) => x && !x.startsWith('.'));
    if (!parts.length) throw new BandError('文件名不对');
    return path.join(project.dir, ...parts.slice(0, 2));
  };
  handle('band-new-project', () => { cancelChat(); cancelComments(); project = null; return { ok: true }; });
  handle('band-save', (p) => {
    ensureProject(p.title);
    const saved = [];
    for (const f of (Array.isArray(p.files) ? p.files : []).slice(0, 40)) {
      const file = inProject(f.name);
      fs.mkdirSync(path.dirname(file), { recursive: true });
      if (f.text != null) fs.writeFileSync(file, String(f.text), 'utf8');
      else if (f.bytes) fs.writeFileSync(file, Buffer.from(f.bytes));
      else continue;
      saved.push(file);
    }
    return { ok: true, dir: project.dir, saved: saved.map((f) => path.relative(project.dir, f)) };
  });
  handle('band-open-folder', () => { if (project) shell.openPath(project.dir); return { ok: !!project }; });
  handle('band-pick', async (p) => {
    const kind = p.kind === 'song' ? 'song' : 'score';
    const r = await dialog.showOpenDialog(getWin(), kind === 'song'
      ? { title: '打开保存过的合奏谱', properties: ['openFile'], filters: [{ name: '合奏谱', extensions: ['json'] }] }
      : { title: '选一份谱子来拆解', properties: ['openFile'], filters: [{ name: '谱子', extensions: ['mid', 'midi', 'musicxml', 'xml', 'txt', 'png', 'jpg', 'jpeg', 'webp'] }, { name: '所有文件', extensions: ['*'] }] });
    if (r.canceled || !r.filePaths[0]) return { canceled: true };
    const f = r.filePaths[0], st = fs.statSync(f);
    if (st.size > 12 * 1024 * 1024) throw new BandError('文件太大了');
    const ext = path.extname(f).slice(1).toLowerCase();
    if (kind === 'song' || ['txt', 'xml', 'musicxml'].includes(ext)) return { ok: true, name: path.basename(f), ext, text: fs.readFileSync(f, 'utf8') };
    return { ok: true, name: path.basename(f), ext, bytes: fs.readFileSync(f) };
  });

  /* ---------- 在她自己的乐器窗口里打开这一轨 ---------- */
  handle('band-open-part', (p) => {
    const t = team[p.who];
    if (!t || !t.openSynthWith) return { error: '她没有加载成功' };
    t.openSynthWith(String(p.title || ''), String(p.text || '').slice(0, 60000));
    return { ok: true };
  });

  /* ---------- 桌面上的四个人跟着演 ---------- */
  handle('band-perform', (p) => {
    const at = Number(p.at) || Date.now(), duration = Math.max(1, Math.min(900, +p.duration || 0));
    const parts = Array.isArray(p.parts) ? p.parts : [];
    for (const m of members) {
      const t = team[m.id];
      if (!t || !t.perform || !online(m.id)) continue;
      const plays = parts.includes(m.part) || (m.id === 'ichika' && p.vocal);
      if (!plays) continue;
      t.perform({ kind: 'start', at, duration, mood: p.mood || 'happy', env: m.id === 'ichika' && p.vocal && Array.isArray(p.env) ? p.env.slice(0, 50 * 900) : null, envRate: +p.envRate || 50 });
    }
    return { ok: true };
  });
  handle('band-perform-stop', () => { for (const m of members) { const t = team[m.id]; if (t && t.perform) t.perform({ kind: 'stop' }); } return { ok: true }; });

  /* ---------- 大家的交流 ---------- */
  let chatController = null, chatEpoch = 0, sayEpoch = 0;
  const commentTimers = new Set();
  function cancelChat() { chatEpoch++; if (chatController) chatController.abort(); chatController = null; }
  function cancelComments() { sayEpoch++; for (const t of commentTimers) clearTimeout(t); commentTimers.clear(); }
  handle('band-chat', async (p) => {
    const ids = Array.isArray(p.ids) ? p.ids.filter((x) => members.some((m) => m.id === x)) : null;
    const talkId = String(p.talkId || '');
    cancelChat();
    const ctl = new AbortController(), epoch = chatEpoch, origin = getWin();
    chatController = ctl;
    const stale = () => ctl.signal.aborted || epoch !== chatEpoch || origin !== getWin() || !origin || origin.isDestroyed();
    try {
    const r = await group.workChat(String(p.context || '').slice(0, 2500), ids, {
      instruction: String(p.instruction || '').slice(0, 600), max: +p.max || 4,
      signal: ctl.signal,
      onLine: (l) => { if (!stale()) send('band-talk', { talkId, who: l.who, to: l.to, text: l.reply }); },
      shouldSkip: stale,
    });
    if (stale()) return { canceled: true, lines: [] };
    if (r.error) return { error: r.error };
    return { ok: true, lines: r.lines.map((l) => ({ who: l.who, to: l.to, text: l.reply })) };
    } finally { if (chatController === ctl) chatController = null; }
  });
  // 写好的谱子里四个人各自的一句话：直接让她们在桌面上说（不再请求模型）
  handle('band-say', (p) => {
    cancelComments();
    const epoch = sayEpoch, origin = getWin();
    const lines = (Array.isArray(p.lines) ? p.lines : []).slice(0, 4);
    let delay = 0;
    for (const l of lines) {
      const t = team[l.who]; if (!t || !online(l.who)) continue;
      const text = String(l.text || '').slice(0, 80); if (!text) continue;
      const timer = setTimeout(() => {
        commentTimers.delete(timer);
        if (epoch !== sayEpoch || origin !== getWin() || !origin || origin.isDestroyed() || !online(l.who)) return;
        try { t.say({ t: text, m: l.mood || 'smile', a: 'nod' }); } catch (e) {}
      }, delay);
      commentTimers.add(timer);
      delay += Math.max(2200, 900 + text.length * 170);
    }
    return { ok: true };
  });
  ipcMain.on('band-chat-skip', (e) => { if (fromWin(e)) { cancelChat(); cancelComments(); } });
  ipcMain.on('band-cancel', (e, id) => { if (!fromWin(e)) return; const c = jobs.get(String(id)); if (c) c.abort(); });

  return {
    windowClosed: () => { cancelChat(); cancelComments(); project = null; for (const c of jobs.values()) c.abort(); jobs.clear(); for (const m of members) { const t = team[m.id]; if (t && t.perform) t.perform({ kind: 'stop' }); } },
    _test: { project: () => project, E, Core },
  };
};
