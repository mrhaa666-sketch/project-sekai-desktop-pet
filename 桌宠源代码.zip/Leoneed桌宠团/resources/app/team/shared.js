'use strict';
/* 共用设置：称呼、各家 API 的地址/密钥/模型只存一份，四个成员都用它。
 * 每个成员各自的设置文件里仍然有这些键（成员原来的代码照常读取）；任何一个成员保存时有改动，就同步给其他三个。
 * 复刻音色 ID（ttsVoiceId）、人设、窗口位置、大小这些是每个人自己的，不共用。 */
const path = require('path');

const SHARED_KEYS = [
  'name', 'jaName', 'userBirthday', 'anniversary',
  'apiType', 'apiBase', 'apiKey', 'model',
  'ttsEnabled', 'ttsBase', 'ttsKey', 'ttsGroupId', 'ttsModel',
  'asrBase', 'asrKey', 'asrModel', 'asrLang',
  'embBase', 'embKey', 'embModel',
  'visionType', 'visionBase', 'visionKey', 'visionModel',
  'sfBase', 'sfKey', 'lyricsModel', 'lyricsAudioModel', 'lyricsAsrModel',
];
const NO_EMPTY = ['apiBase', 'ttsBase', 'visionBase', 'ttsModel', 'paintModel', 'sfBase'];
const SECRET = ['apiKey', 'ttsKey', 'asrKey', 'embKey', 'visionKey', 'sfKey'];
const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);

module.exports = function createShared({ userData, members, readJSON, writeJSON }) {
  const FILE = path.join(userData, 'shared.json');
  let store = readJSON(FILE, null);
  if (!store || typeof store !== 'object' || Array.isArray(store)) {
    // 第一次：从各成员原来的设置里收集，每一项取第一个填了的值
    store = {};
    for (const m of members) {
      const loaded = readJSON(path.join(userData, 'members', m.id, 'settings.json'), {});
      const s = loaded && typeof loaded === 'object' && !Array.isArray(loaded) ? loaded : {};
      for (const k of SHARED_KEYS) {
        if (k in store) continue;
        const v = s[k];
        if (v !== undefined && v !== null && v !== '') store[k] = v;
      }
    }
    writeJSON(FILE, store);
  }

  return {
    SHARED_KEYS, SECRET,
    get: () => ({ ...store }),
    // 成员刚读完自己的设置：用共用的值覆盖
    sharedFor(_id, s) {
      const out = {};
      for (const k of SHARED_KEYS) if (k in store && (!s || !same(s[k], store[k]))) out[k] = store[k];
      return out;
    },
    // 成员保存设置：和共用的值比较，有改动就记下来并同步给其他成员
    onSave(id, s, push) {
      const changes = {};
      for (const k of SHARED_KEYS) {
        if (!(k in s)) continue;
        if (!same(s[k], store[k])) changes[k] = s[k];
      }
      if (!Object.keys(changes).length) return;
      Object.assign(store, changes);
      writeJSON(FILE, store);
      for (const m of members) if (m.id !== id) push(m.id, changes);
    },
    // 团队设置面板：密钥不发给页面，只告诉页面“填过没有”
    publicView(team) {
      const v = {};
      for (const k of SHARED_KEYS) v[k] = SECRET.includes(k) ? '' : (store[k] ?? '');
      for (const k of SECRET) v[k + 'Set'] = !!store[k];
      v.voices = members.map((m) => ({ id: m.id, name: m.name, voiceId: team[m.id] ? String(team[m.id].settings().ttsVoiceId || '') : '' }));
      return v;
    },
    saveFromPanel(v, team) {
      if (!v || typeof v !== 'object') return { error: '内容不对' };
      const changes = {};
      const str = (x, n = 300) => String(x == null ? '' : x).trim().slice(0, n);
      for (const k of SHARED_KEYS) {
        if (!(k in v)) continue;
        if (SECRET.includes(k)) {
          if (v[k + 'Clear']) { if (store[k]) changes[k] = ''; continue; }
          const nv = str(v[k], 400).replace(/\s+/g, '');
          if (nv && nv !== store[k]) changes[k] = nv;          // 留空 = 不改
          continue;
        }
        const nv = k === 'ttsEnabled' ? !!v[k] : str(v[k]);
        if (nv === '' && NO_EMPTY.includes(k)) continue;           // 地址、模型这些留空 = 不改（用原来的或默认的）
        if (!same(nv, store[k] ?? (k === 'ttsEnabled' ? false : ''))) changes[k] = nv;
      }
      if (Object.keys(changes).length) {
        Object.assign(store, changes);
        writeJSON(FILE, store);
        for (const m of members) if (team[m.id]) team[m.id].applyShared(changes);
      }
      // 每个人自己的复刻音色 ID
      if (Array.isArray(v.voices)) {
        for (const it of v.voices) {
          const t = it && team[it.id];
          if (!t) continue;
          const vid = str(it.voiceId, 120);
          if (vid !== String(t.settings().ttsVoiceId || '')) t.applyOwn({ ttsVoiceId: vid });
        }
      }
      return { ok: true, changed: Object.keys(changes).length };
    },
  };
};
