'use strict';
/* 一起合奏（窗口部分）
 * 四个乐器各用各自桌宠的合成器（一歌的电吉他、咲希的电子琴、穗波的架子鼓、志步的贝斯）在这里离线合成，
 * 一歌的歌声：每句先用她复刻的音色念出来，再在后台线程里切音、变调、对齐到旋律上；最后五轨一起混音播放 / 导出。 */
const api = window.bandAPI;
const $ = (id) => document.getElementById(id);
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const SR = 44100, LEAD = 0.05;   // 吉他和贝斯的合成器开头空了 0.05 秒，其他轨跟着对齐

/* ---------- 载入四个成员的乐器（各自都叫 Jianpu，按顺序载入、分别记下） ---------- */
let ENG = null, Core = null, DSP = null, Import = null;
function loadScript(src) { return new Promise((res, rej) => { const s = document.createElement('script'); s.src = src; s.onload = res; s.onerror = () => rej(new Error('加载失败：' + src)); document.head.appendChild(s); }); }
async function loadEngines() {
  await loadScript('w/keys-jianpu.js'); const keys = window.Jianpu;
  await loadScript('w/guitar-jianpu.js'); const guitar = window.Guitar;
  await loadScript('w/bass-jianpu.js'); const bass = window.Bass;
  await loadScript('w/drums.js'); const drums = window.Drums;
  await loadScript('w/sing-dsp.js'); await loadScript('w/band-core.js'); await loadScript('w/score-import.js');
  ENG = { guitar, keys, bass, drums }; Core = window.BandCore; DSP = window.SingDSP; Import = window.ScoreImport;
}

/* ---------- 成员和声部 ---------- */
let roster = [];
const mem = (id) => roster.find((m) => m.id === id) || { id, short: id, name: id, color: '#4455dd' };
const TRACKS = [
  { key: 'guitar', who: 'ichika', label: '电吉他', title: '电吉他', tone: 'guitar' },
  { key: 'vocal', who: 'ichika', label: '主唱', title: '主唱' },
  { key: 'keys', who: 'saki', label: '电子琴', title: '电子琴', tone: 'keys' },
  { key: 'drums', who: 'honami', label: '架子鼓', title: '架子鼓', tone: 'kit' },
  { key: 'bass', who: 'shiho', label: '贝斯', title: '贝斯', tone: 'bass' },
];
const TONE_KEY = { guitar: '音色', keys: '音色', bass: '音色', kit: '鼓组' };
const avatar = (m, s = 30) => (m.src ? `<span class="av" style="width:${s}px;height:${s}px"><img src="${m.src}" alt=""></span>` : `<span class="av" style="width:${s}px;height:${s}px;background:${m.color}">${esc((m.short || '?').slice(0, 1))}</span>`);

/* ---------- 合奏谱的状态 ---------- */
let S = null;   // { raw, title, bpm, key, beats, totalBars, sections, parts: {guitar,keys,bass,drums}, vocal: [...], lang, octave, errors: {}, warnings: [] }
const mix = { guitar: 0.8, vocal: 1.0, keys: 0.7, drums: 0.85, bass: 0.9 };
const mute = {}, solo = {};
let bufs = {}, dirty = new Set(), vocalEnv = null;
let cfg = {};

function fromAssembled(a, raw) {
  return { raw: raw || a.song, title: a.song.title, bpm: a.song.bpm, key: a.song.key, beats: a.song.beats, totalBars: a.totalBars, sections: a.sections,
    parts: a.parts, vocal: a.vocal, lang: a.song.vocalLang, octave: 0, errors: {}, warnings: [...a.warnings, ...a.bad.map((b) => `${b.section}的${Core.PART_LABEL[b.part]}没写对（${b.error}），这一段先空着`)] };
}
function setSong(s, { keepBuffers = false } = {}) {
  S = s;
  if (!keepBuffers) { bufs = {}; vocalEnv = null; dirty = new Set(['guitar', 'keys', 'bass', 'drums', 'vocal']); }
  stop();
  $('title').value = S.title;
  validateAll();
  renderSong();
  $('render').disabled = false;
  $('play').disabled = true; $('wav').disabled = true; $('stems').disabled = true;
}
function validateAll() {
  if (!S) return;
  S.errors = {};
  for (const p of Core.PARTS) {
    const sc = ENG[p].parse(S.parts[p] || '');
    if (sc.error) S.errors[p] = sc.error.msg;
  }
}
const spb = () => 60 / S.bpm;
const songSeconds = () => (S ? S.totalBars * S.beats * spb() + 2 : 0);

/* ---------- 画面 ---------- */
const SEC_COLORS = ['#33aaee', '#ffdd44', '#ee6666', '#bbdd22', '#4455dd', '#8fa0ff'];
function renderSong() {
  if (!S) { $('songTitle').textContent = '还没有合奏谱'; $('chips').innerHTML = ''; return; }
  $('songTitle').textContent = S.title;
  const dur = S.totalBars * S.beats * spb();
  $('chips').innerHTML = [`1=${S.key}`, `${S.beats}/4`, `♩=${S.bpm}`, `${S.totalBars} 小节`, `${Math.floor(dur / 60)}:${String(Math.round(dur % 60)).padStart(2, '0')}`, S.vocal.length ? `主唱 ${S.vocal.length} 句（${S.lang === 'ja' ? '日语' : '中文'}）` : '纯器乐']
    .map((t) => `<span class="chip">${esc(t)}</span>`).join('');
  const bar = $('secBar');
  bar.querySelectorAll('.sec').forEach((x) => x.remove());
  S.sections.forEach((s, i) => {
    const d = document.createElement('div');
    d.className = 'sec'; d.style.flex = String(s.bars); d.style.background = SEC_COLORS[i % SEC_COLORS.length] + '99';
    d.textContent = s.name; d.title = `${s.name}：第 ${s.bar + 1}–${s.bar + s.bars} 小节`;
    bar.insertBefore(d, $('ph'));
  });
  renderTracks();
  const w = S.warnings.slice(0, 20);
  $('warn').style.display = w.length ? 'block' : 'none';
  $('warn').textContent = w.length ? '提示：\n' + w.join('\n') : '';
}
function trackStatus(t) {
  if (t.key === 'vocal') {
    if (!S.vocal.length) return ['', '没有要唱的'];
    if (!cfg.voiceReady) return ['warn', '还没有一歌的复刻音色'];
    return bufs.vocal && !dirty.has('vocal') ? ['ok', '已合成'] : ['', `${S.vocal.length} 句，待合成`];
  }
  if (S.errors[t.key]) return ['err', '谱子有错：' + S.errors[t.key]];
  return bufs[t.key] && !dirty.has(t.key) ? ['ok', '已合成'] : ['', '待合成'];
}
function toneOf(p) {
  const head = String(S.parts[p] || '').split('\n')[0];
  const re = p === 'drums' ? /鼓组=([^\s]+)/ : /音色=([^\s]+)/;
  return (re.exec(head) || [])[1] || '';
}
function renderTracks() {
  const box = $('tracks');
  const open = new Set([...box.querySelectorAll('.trk.open')].map((x) => x.dataset.k));
  box.innerHTML = TRACKS.map((t) => {
    const m = mem(t.who), [cls, st] = trackStatus(t);
    const tone = t.tone ? `<select data-act="tone">${Core.TONES[t.tone].map((v) => `<option ${v === toneOf(t.key) ? 'selected' : ''}>${v}</option>`).join('')}</select>` : '';
    const style = t.key === 'keys' ? `<select data-act="style">${Core.TONES.keysStyle.map((v) => `<option ${new RegExp('伴奏=' + v).test(S.parts.keys) ? 'selected' : ''}>${v}</option>`).join('')}</select>` : '';
    const isV = t.key === 'vocal';
    const text = isV ? Core.vocalToText(S.vocal, { syllabify: DSP.syllabify }) : S.parts[t.key];
    const hint = isV ? '一行一句：<code>@小节[:拍] 歌词 | 旋律简谱</code>，例如 <code>@5 夜空的星星 | 5 3 2_ 1_ 2-</code>（第 5 小节开头唱）。旋律：1–7，0 休止，<code>\'</code> 高八度，<code>,</code> 低八度，<code>_</code> 半拍，<code>-</code> 加一拍，<code>.</code> 附点。想自己分音就用 / 隔开歌词'
      : t.key === 'drums' ? '穗波的鼓谱：一行一个鼓，竖着对齐的是同一时刻；- 空，o 敲，O 重音，g 鬼音。和她自己的架子鼓窗口写法一样'
        : '和她自己的乐器窗口写法一样（第一行是调、拍号、速度、音色；“和弦：”那一行会自动加伴奏）。改完点“用这份谱子”';
    return `<div class="trk ${open.has(t.key) ? 'open' : ''}" data-k="${t.key}" style="--c:${m.color}">
      <div class="h">${avatar(m)}<div><div class="nm" style="color:${m.color}">${esc(m.short)} · ${t.label}</div><div class="rl st ${cls}">${esc(st)}</div></div>
        <span class="sp"></span>
        <input type="range" min="0" max="1.5" step="0.05" value="${mix[t.key]}" data-act="vol" title="音量">
        <button class="ms ${mute[t.key] ? 'on' : ''}" data-act="mute" title="静音">M</button><button class="ms ${solo[t.key] ? 'on' : ''}" data-act="solo" title="只听这一轨">S</button></div>
      <div class="tools">
        <button data-act="edit">${isV ? '歌词和旋律' : '谱子'}</button>
        ${isV ? '' : `<button data-act="open" title="在${esc(m.short)}自己的${t.label}窗口里打开，可以单独练、改、导出">在${esc(m.short)}的窗口打开</button>`}
        <button data-act="revise">让${esc(m.short)}重写…</button>
        ${tone}${style}
        ${isV ? `<select data-act="octave" title="一歌唱的音高"><option value="0" ${S.octave === 0 ? 'selected' : ''}>原调</option><option value="1" ${S.octave === 1 ? 'selected' : ''}>高八度</option><option value="-1" ${S.octave === -1 ? 'selected' : ''}>低八度</option></select>` : ''}
      </div>
      <div class="rev"><input data-act="revText" maxlength="200" placeholder="想怎么改？例如：副歌更有力一点 / 前奏加一段 riff（不填就让她自由发挥）"><button class="primary" data-act="reviseGo">重写</button></div>
      <div class="ed"><textarea spellcheck="false" wrap="off" data-act="text">${esc(text)}</textarea><div class="hint">${hint}</div>
        <div class="row" style="margin-top:5px"><button class="primary" data-act="apply">用这份谱子</button><span class="sub" data-act="msg"></span></div></div>
    </div>`;
  }).join('');
}
$('tracks').addEventListener('click', async (e) => {
  const card = e.target.closest('.trk'); if (!card || !S) return;
  const k = card.dataset.k, act = e.target.dataset.act, t = TRACKS.find((x) => x.key === k);
  if (act === 'edit') card.classList.toggle('open');
  else if (act === 'mute' || act === 'solo') { const o = act === 'mute' ? mute : solo; o[k] = !o[k]; e.target.classList.toggle('on', o[k]); applyGains(); }
  else if (act === 'open') { const r = await api.openPart({ who: t.who, title: `${S.title} · ${t.title}`, text: S.parts[k] }); if (r && r.error) status(r.error, 'err'); }
  else if (act === 'revise') card.classList.toggle('rv');
  else if (act === 'reviseGo') revise(k, card.querySelector('[data-act=revText]').value);
  else if (act === 'apply') applyText(k, card);
});
$('tracks').addEventListener('input', (e) => {
  const card = e.target.closest('.trk'); if (!card || !S) return;
  const k = card.dataset.k;
  if (e.target.dataset.act === 'vol') { mix[k] = +e.target.value; applyGains(); }
});
$('tracks').addEventListener('change', (e) => {
  const card = e.target.closest('.trk'); if (!card || !S) return;
  const k = card.dataset.k, act = e.target.dataset.act;
  if (act === 'tone') setHeader(k, k === 'drums' ? '鼓组' : '音色', e.target.value);
  else if (act === 'style') setHeader('keys', '伴奏', e.target.value);
  else if (act === 'octave') { S.octave = +e.target.value; dirty.add('vocal'); renderTracks(); }
});
function setHeader(p, key, v) {
  const lines = String(S.parts[p]).split('\n');
  const re = new RegExp(key + '=[^\\s]+');
  lines[0] = re.test(lines[0]) ? lines[0].replace(re, `${key}=${v}`) : `${lines[0]} ${key}=${v}`;
  S.parts[p] = lines.join('\n');
  dirty.add(p); validateAll(); renderTracks();
}
function applyText(k, card) {
  const text = card.querySelector('[data-act=text]').value, msg = card.querySelector('[data-act=msg]');
  if (k === 'vocal') {
    const r = Core.textToVocal(text, { parseJianpu: DSP.parseJianpu, syllabify: DSP.syllabify });
    const total = S.totalBars * S.beats;
    S.vocal = r.lines.filter((l) => l.bar * S.beats + l.beat < total).map((l) => ({ ...l, section: '' }));
    dirty.add('vocal');
    msg.textContent = r.errors.length ? r.errors.slice(0, 3).join('；') : `好了，${S.vocal.length} 句`;
  } else {
    const sc = ENG[k].parse(text);
    if (sc.error) { msg.textContent = '有错：' + sc.error.msg; return; }
    S.parts[k] = text; dirty.add(k);
    const len = (sc.notes ? sc.notes.reduce((m, n) => Math.max(m, n.t + n.dur), 0) : sc.total) / S.beats;
    msg.textContent = Math.abs(len - S.totalBars) > 0.01 && len > S.totalBars ? `好了（这一轨有 ${len.toFixed(1)} 小节，比整首长，多出来的部分会在最后单独响）` : '好了';
  }
  validateAll(); renderSong();
  card.classList.add('open');
}

/* ---------- 状态栏、对话 ---------- */
function status(t, cls = '') { $('status').textContent = t || ''; $('status').className = cls; }
function talk(who, text, sys = false) {
  const m = who ? mem(who) : null;
  $('talk').insertAdjacentHTML('beforeend', sys || !m ? `<div class="tl sys"><div class="tx">${esc(text)}</div></div>`
    : `<div class="tl">${avatar(m, 26)}<div><div class="who" style="color:${m.color}">${esc(m.short)}</div><div class="tx">${esc(text)}</div></div></div>`);
  $('talk').scrollTop = $('talk').scrollHeight;
}
api.onTalk((l) => talk(l.who, l.text));
$('skip').onclick = () => api.skipChat();
async function bandTalk(context, instruction, max = 4) {
  if (!$('chatOn').checked) return;
  const r = await api.chat({ context, instruction, max, talkId: String(Date.now()) });
  if (r && r.error) talk(null, '（聊天没成功：' + r.error + '）', true);
}
function songBrief() {
  if (!S) return '';
  return `曲名《${S.title}》，1=${S.key}，${S.beats}/4，♩=${S.bpm}，${S.totalBars} 小节；段落：${S.sections.map((s) => `${s.name}（${s.bars} 小节）`).join('、')}。` +
    (S.vocal.length ? `一歌要唱的歌词：${S.vocal.slice(0, 8).map((l) => l.text).join(' / ')}` : '这一首是纯器乐。');
}
function sayComments(c) {
  if (!c) return;
  const lines = ['ichika', 'saki', 'honami', 'shiho'].filter((id) => c[id]).map((id) => ({ who: id, text: String(c[id]).slice(0, 60) }));
  lines.forEach((l) => talk(l.who, l.text));
  if (lines.length) api.say({ lines });
}

/* ---------- 准备情况 ---------- */
async function refreshConfig() {
  cfg = await api.config();
  const y = (ok, a, b) => `<span class="${ok ? 'ok' : 'no'}">${ok ? a : b}</span>`;
  $('cfg').innerHTML = `<b>准备情况</b><br>写谱 / 拆谱：${y(cfg.chatReady, '聊天模型 ' + esc(cfg.chatModel), '还没有聊天模型')}<br>一歌唱歌：${y(cfg.voiceReady, '用她复刻的音色', '还没有复刻音色（只合成乐器）')}<br>谱子图片：${y(cfg.visionReady, '可以看图', '还没有看图模型')}<br><a id="toSettings">去团队设置…</a>`;
  $('toSettings').onclick = () => api.openGroup();
}

/* ---------- 让大家写 ---------- */
let busy = null;
function setBusy(id, text) {
  busy = id;
  for (const b of ['w_go', 'i_split', 'i_llm', 'i_read']) $(b).disabled = !!id;
  if (id) status(text);
}
api.onProgress((p) => {
  if (!busy || p.id !== busy) return;
  const t = { writing: '大家在写谱子…（长一点的曲子要等一两分钟）', checking: '检查谱子…', repair: `有 ${p.count} 处写得不对，正在请她们改…`, reading: '看图模型在抄谱子…' }[p.stage];
  if (t) status(t);
});
async function composeWith(params, note) {
  const id = 'c' + Date.now();
  setBusy(id, note || '大家在写谱子…');
  talk(null, note || '开始写谱子', true);
  try {
    const r = await api.compose({ id, ...params });
    if (r.error) { status(r.error, 'err'); talk(null, '没写成：' + r.error, true); return false; }
    const a = Core.assemble(r.raw, ENG, { syllabify: DSP.syllabify });
    await api.newProject();
    setSong(fromAssembled(a, r.raw));
    status(`写好了《${S.title}》：${S.totalBars} 小节。点“合成”听听看。`, 'ok');
    sayComments(r.comment);
    bandTalk(songBrief(), '合奏谱刚写好。每个人说一句自己负责的声部打算怎么弹（一歌也说说要唱的部分），可以互相回应一句。', 4);
    return true;
  } finally { setBusy(null); }
}
$('w_go').onclick = () => composeWith({
  theme: $('w_theme').value.trim(), style: $('w_style').value.trim(), bpm: +$('w_bpm').value || 0, key: $('w_key').value, beats: +$('w_beats').value,
  length: $('w_len').value, grid: +$('w_grid').value, vocal: $('w_vocal').checked, language: $('w_lang').value, lyrics: $('w_lyrics').value.trim(),
});

/* ---------- 让某个人重写自己的声部 ---------- */
async function revise(part, instruction) {
  if (!S || busy) return;
  if (!S.raw || !Array.isArray(S.raw.sections)) { status('这份合奏谱缺少段落信息，不能让她们重写；可以直接改谱子', 'err'); return; }
  const t = TRACKS.find((x) => x.key === part), m = mem(t.who);
  const id = 'r' + Date.now();
  // 主唱和乐器的修改都基于最新的状态：先把窗口里改过的主唱写回合奏谱
  const raw = JSON.parse(JSON.stringify(S.raw));
  if (part !== 'vocal') syncVocalToRaw(raw);
  setBusy(id, `${m.short}在重写${t.label}…`);
  try {
    const r = await api.revise({ id, raw, part, instruction: String(instruction || '').trim() });
    if (r.error) { status(r.error, 'err'); return; }
    const a = Core.assemble(r.raw, ENG, { syllabify: DSP.syllabify });
    const keep = {};
    for (const p of Core.PARTS) if (p !== part) keep[p] = S.parts[p];      // 其他声部保留窗口里的样子（可能手动改过）
    const s = fromAssembled(a, r.raw);
    for (const p of Object.keys(keep)) s.parts[p] = keep[p];
    if (part !== 'vocal') { s.vocal = S.vocal; }
    s.octave = S.octave;
    const oldBufs = bufs;
    setSong(s, { keepBuffers: true });
    bufs = oldBufs; dirty = new Set([part]);
    renderTracks();
    status(`${m.short}改好了${t.label}。点“合成”听听看。`, 'ok');
    sayComments(r.comment);
  } finally { setBusy(null); }
}
// 主唱：窗口里改过的句子写回合奏谱（按小节放回各段）
function syncVocalToRaw(raw) {
  const map = Core.sectionMap(raw);
  for (const s of raw.sections) s.vocal = [];
  for (const l of S.vocal) {
    const i = Math.max(0, map.findIndex((x) => l.bar >= x.bar && l.bar < x.bar + x.bars));
    const sec = raw.sections[i], x = map[i];
    sec.vocal.push({ bar: l.bar - x.bar, beat: l.beat, text: l.text, units: l.units, notes: l.notes });
  }
}

/* ---------- 拆解谱子 ---------- */
let imported = null;     // MIDI / MusicXML 读出来的
let imageData = null;
const ROLE_OPTS = [['', '不用'], ['vocal', '一歌 · 唱'], ['guitar', '一歌 · 电吉他'], ['keys', '咲希 · 电子琴'], ['drums', '穗波 · 架子鼓'], ['bass', '志步 · 贝斯']];
function showImport(kind) {
  $('midiBox').style.display = kind === 'tracks' ? 'block' : 'none';
  $('textBox').style.display = kind === 'text' || kind === 'image' ? 'block' : 'none';
  $('i_read').style.display = kind === 'image' ? 'block' : 'none';
  $('imgPrev').style.display = kind === 'image' ? 'block' : 'none';
}
$('i_pick').onclick = async () => {
  const r = await api.pick({ kind: 'score' });
  if (!r || r.canceled) return;
  if (r.error) { status(r.error, 'err'); return; }
  $('i_name').textContent = r.name; $('fileInfo').textContent = '';
  imported = null; imageData = null;
  try {
    if (r.ext === 'mid' || r.ext === 'midi') loadTracks(Import.readMidi(new Uint8Array(r.bytes)), r.name);
    else if (r.ext === 'musicxml' || (r.ext === 'xml' && /<score-partwise/.test(r.text))) loadTracks(Import.readMusicXML(r.text), r.name);
    else if (['png', 'jpg', 'jpeg', 'webp'].includes(r.ext)) {
      const bytes = new Uint8Array(r.bytes);
      let bin = ''; for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
      imageData = { b64: btoa(bin), mime: r.ext === 'png' ? 'image/png' : r.ext === 'webp' ? 'image/webp' : 'image/jpeg' };
      $('imgPrev').src = `data:${imageData.mime};base64,${imageData.b64}`;
      $('i_text').value = '';
      showImport('image');
      $('fileInfo').textContent = cfg.visionReady ? '先点“用看图模型把图片抄成文字”，看一下抄得对不对，再交给大家拆。' : '看谱子图片需要先在团队设置里填看图模型的密钥。';
    } else { $('i_text').value = String(r.text || '').slice(0, 6000); showImport('text'); }
  } catch (e) { status('读不了这份谱子：' + e.message, 'err'); }
};
$('i_paste').onclick = () => { imported = null; imageData = null; $('i_name').textContent = '文字谱'; $('fileInfo').textContent = ''; showImport('text'); $('i_text').focus(); };
function loadTracks(d, name) {
  if (!d.tracks.length) throw new Error('里面没有音符');
  imported = d;
  const roles = Core.guessRoles(d.tracks);
  $('trackTable').innerHTML = '<tr><td class="sub">轨道</td><td class="sub">音符</td><td class="sub">交给</td></tr>' + d.tracks.map((t, i) =>
    `<tr><td>${esc(t.name)}${t.drum ? '（鼓）' : ''}</td><td>${t.notes.length}</td><td><select data-tr="${i}">${ROLE_OPTS.map(([v, l]) => `<option value="${v}" ${roles[i] === v ? 'selected' : ''}>${l}</option>`).join('')}</select></td></tr>`).join('');
  const melodic = d.tracks.filter((t) => !t.drum).flatMap((t) => t.notes);
  const kp = d.keyPc != null ? d.keyPc : Core.estimateKey(melodic);
  $('i_key').innerHTML = Core.KEY_NAME.map((k, i) => `<option value="${i}" ${i === kp ? 'selected' : ''}>${k}${i === kp ? (d.keyPc != null ? '（谱上写的）' : '（猜的）') : ''}</option>`).join('');
  $('i_bpm').value = d.bpm; $('i_beats').value = String(d.beats);
  $('fileInfo').textContent = `${name}：${d.tracks.length} 轨。下面可以改每一轨交给谁。`;
  showImport('tracks');
}
$('i_split').onclick = async () => {
  if (!imported || busy) return;
  const roles = imported.tracks.map((_, i) => { const el = document.querySelector(`[data-tr="${i}"]`); return el ? el.value : ''; });
  // 同一个声部只能交给一轨：多选的合并
  const lyricsLines = $('i_lyrics').value.split('\n');
  let f;
  try {
    f = Core.fromTracks({ tracks: imported.tracks, roles, bpm: +$('i_bpm').value || imported.bpm, beats: +$('i_beats').value, title: imported.title || $('i_name').textContent.replace(/\.[^.]+$/, ''),
      keyPc: +$('i_key').value, lyricsLines, syllabify: DSP.syllabify, vocalLang: $('i_lang').value }, ENG);
  } catch (e) { status('拆不了：' + e.message, 'err'); return; }
  const a = Core.assemble(f.raw, ENG, { syllabify: DSP.syllabify });
  const s = fromAssembled(a, f.raw);
  const LBL = { guitar: '一歌按和弦弹伴奏', keys: '咲希按和弦弹伴奏', bass: '志步按和弦弹根音', drums: '穗波打基本节奏' };
  if (f.filled.length) s.warnings.unshift('谱子里没有的声部已经补上：' + f.filled.map((p) => LBL[p]).join('、') + '（可以让她们重写）');
  await api.newProject(); setSong(s);
  status(`拆好了：${S.totalBars} 小节。`, 'ok');
  talk(null, `拆好了《${S.title}》`, true);
  // 有旋律但没有歌词：让一歌按每句的音数写词
  const noLyrics = !lyricsLines.some((l) => l.trim());
  if (f.phrases.length && noLyrics && $('i_autoLyrics').checked && cfg.chatReady) {
    const id = 'l' + Date.now();
    setBusy(id, '一歌在按旋律写词…');
    try {
      const r = await api.lyrics({ id, phrases: f.phrases, language: $('i_lang').value, theme: $('i_theme').value.trim() });
      if (r.error) status('写词没成功：' + r.error + '（先唱“啦”）', 'err');
      else {
        r.lines.forEach((l, i) => { if (S.vocal[i]) { S.vocal[i].units = l.units; S.vocal[i].text = l.text; } });
        dirty.add('vocal'); renderTracks(); status('一歌写好了词。点“合成”听听看。', 'ok'); sayComments(r.comment);
      }
    } finally { setBusy(null); }
  }
  bandTalk(songBrief(), '刚把一份谱子拆成了四个声部。大家各自说一句拿到的声部怎么样、打算怎么弹。', 4);
};
$('i_read').onclick = async () => {
  if (!imageData || busy) return;
  const id = 'v' + Date.now();
  setBusy(id, '看图模型在抄谱子…');
  try {
    const r = await api.readImage({ id, ...imageData });
    if (r.error) { status(r.error, 'err'); return; }
    $('i_text').value = r.text;
    status('抄好了，看一下对不对（可以直接改），再点“交给大家拆”。', 'ok');
  } finally { setBusy(null); }
};
$('i_llm').onclick = async () => {
  if (busy) return;
  const text = $('i_text').value.trim();
  if (!text) { status(imageData ? '先把图片抄成文字' : '先贴上谱子的文字', 'err'); return; }
  await composeWith({ source: text, vocal: $('t_vocal').checked, language: $('t_lang').value, grid: 16 }, '大家在拆这份谱子…');
};

/* ---------- 合成 ---------- */
let renderSeq = 0;
async function decodeMp3(b64) {
  const bin = atob(b64), bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  const ctx = new OfflineAudioContext(1, 1, SR);
  const buf = await ctx.decodeAudioData(bytes.buffer);
  return buf.getChannelData(0).slice();
}
let worker = null, wseq = 0;
const wjobs = new Map();
function singWorker(msg, onProgress) {
  if (!worker) {
    worker = new Worker('w/band-sing-worker.js');
    worker.onmessage = (e) => { const d = e.data, j = wjobs.get(d.id); if (!j) return; if (d.progress != null) { j.onProgress && j.onProgress(d.progress, d.stage); return; } wjobs.delete(d.id); d.error ? j.rej(new Error(d.error)) : j.res(d.result); };
  }
  const id = ++wseq;
  return new Promise((res, rej) => { wjobs.set(id, { res, rej, onProgress }); worker.postMessage({ id, ...msg }, msg.lines.map((l) => l.samples.buffer)); });
}
async function renderVocal(seq) {
  if (!S.vocal.length) { bufs.vocal = null; vocalEnv = null; return; }
  if (!cfg.voiceReady) { bufs.vocal = null; vocalEnv = null; status('还没有一歌的复刻音色，这次只合成乐器（团队设置 → 声音）'); await sleep(800); return; }
  const lines = new Array(S.vocal.length);
  let done = 0, cached = 0, i = 0;
  const id = 's' + Date.now();
  const one = async () => {
    while (i < S.vocal.length) {
      const k = i++;
      const l = S.vocal[k];
      const r = await api.singVoice({ id: id + k, units: l.units });
      if (seq !== renderSeq) throw new Error('已取消');
      if (r.error) throw new Error(`第 ${k + 1} 句：${r.error}`);
      if (r.cached) cached++;
      lines[k] = { samples: await decodeMp3(r.b64), sr: SR, notes: l.notes, start: (l.bar * S.beats + l.beat) * spb() + LEAD };
      status(`一歌在念歌词…（${++done}/${S.vocal.length}${cached ? `，${cached} 句用了上次的` : ''}）`);
    }
  };
  await Promise.all([one(), one(), one()]);
  const r = await singWorker({ lines, bpm: S.bpm, keyPc: Core.keyPc(S.key), octave: S.octave }, (p, st) => status(`一歌在唱…${st || ''} ${Math.round(p * 100)}%`));
  if (seq !== renderSeq) return;
  const b = new AudioBuffer({ length: r.vocal.length, numberOfChannels: 1, sampleRate: SR });
  b.copyToChannel(r.vocal, 0);
  bufs.vocal = b; vocalEnv = r.env;
  if (r.warn && r.warn.length) S.warnings = [...new Set([...S.warnings, ...r.warn])];
}
$('render').onclick = async () => {
  if (!S) return;
  stop();
  const seq = ++renderSeq;
  $('render').disabled = true; $('play').disabled = true;
  try {
    validateAll();
    for (const t of TRACKS) {
      if (t.key === 'vocal' || !dirty.has(t.key)) continue;
      if (S.errors[t.key]) { bufs[t.key] = null; continue; }
      status(`${mem(t.who).short}在弹${t.label}…`);
      await sleep(30);
      bufs[t.key] = await ENG[t.key].render(ENG[t.key].parse(S.parts[t.key]), { sampleRate: SR });
      dirty.delete(t.key);
      if (seq !== renderSeq) return;
      renderTracks();
    }
    if (dirty.has('vocal')) { await renderVocal(seq); dirty.delete('vocal'); }
    if (seq !== renderSeq) return;
    renderTracks(); renderSong();
    const errs = Object.keys(S.errors);
    status(errs.length ? `合成好了，但${errs.map((p) => Core.PART_LABEL[p]).join('、')}的谱子有错，没有声音。` : '合成好了，点“播放”。', errs.length ? 'err' : 'ok');
    $('play').disabled = false; $('wav').disabled = false; $('stems').disabled = false;
  } catch (e) {
    status('合成失败：' + e.message, 'err');
    if (Object.keys(bufs).some((k) => bufs[k])) { $('play').disabled = false; $('wav').disabled = false; $('stems').disabled = false; }
  } finally { $('render').disabled = false; }
};

/* ---------- 播放 ---------- */
let actx = null, playing = null, offsetSec = 0, firstListen = true;
const OFFSET = { guitar: 0, bass: 0, keys: LEAD, drums: LEAD, vocal: 0 };
function gainOf(k) {
  const anySolo = Object.values(solo).some(Boolean);
  if (mute[k] || (anySolo && !solo[k])) return 0;
  return mix[k];
}
function applyGains() { if (playing) for (const k of Object.keys(playing.gains)) playing.gains[k].gain.setTargetAtTime(gainOf(k), actx.currentTime, 0.02); }
function duration() { return Math.max(0, ...Object.entries(bufs).filter(([, b]) => b).map(([k, b]) => b.duration + OFFSET[k])); }
function buildGraph(ctx, when, from) {
  const master = ctx.createGain(); master.gain.value = 0.9;
  const comp = ctx.createDynamicsCompressor(); comp.threshold.value = -10; comp.ratio.value = 4; comp.attack.value = 0.003; comp.release.value = 0.2;
  master.connect(comp); comp.connect(ctx.destination);
  const gains = {}, srcs = [];
  for (const [k, b] of Object.entries(bufs)) {
    if (!b) continue;
    const g = ctx.createGain(); g.gain.value = gainOf(k); g.connect(master);
    const s = ctx.createBufferSource(); s.buffer = b; s.connect(g);
    const at = OFFSET[k] - from;
    if (at >= 0) s.start(when + at); else if (-at < b.duration) s.start(when, -at); else continue;
    gains[k] = g; srcs.push(s);
  }
  return { gains, srcs };
}
async function play(from = offsetSec) {
  if (!Object.values(bufs).some(Boolean)) return;
  stop(false);
  if (!actx) actx = new AudioContext({ sampleRate: SR });
  if (actx.state === 'suspended') await actx.resume();
  const when = actx.currentTime + 0.08;
  const g = buildGraph(actx, when, from);
  playing = { ...g, when, from, dur: duration() };
  $('play').textContent = '❚❚ 暂停'; $('stop').disabled = false;
  if ($('perform').checked) {
    const parts = Core.PARTS.filter((p) => bufs[p] && gainOf(p) > 0);
    const env = vocalEnv && bufs.vocal && gainOf('vocal') > 0 ? vocalEnv.slice(Math.floor(from * 50)) : null;
    api.perform({ at: Date.now() + 80, duration: playing.dur - from, parts, vocal: !!env, env, envRate: 50, mood: 'happy' });
  }
  tick();
}
function stop(reset = true) {
  if (playing) { for (const s of playing.srcs) { try { s.stop(); } catch (e) {} } playing = null; api.performStop(); }
  $('play').textContent = '▶ 播放'; $('stop').disabled = true;
  if (reset) { offsetSec = 0; showTime(0); }
}
function pos() { return playing ? Math.max(0, actx.currentTime - playing.when) + playing.from : offsetSec; }
function showTime(t) {
  const d = S ? (Object.values(bufs).some(Boolean) ? duration() : songSeconds()) : 0;
  const f = (x) => `${Math.floor(x / 60)}:${String(Math.floor(x % 60)).padStart(2, '0')}`;
  $('time').textContent = `${f(t)} / ${f(d)}`;
  $('seekBar').style.width = d ? `${Math.min(100, t / d * 100)}%` : '0';
  const ph = $('ph');
  if (S && t > 0) {
    const songLen = S.totalBars * S.beats * spb();
    ph.style.display = 'block'; ph.style.left = `${Math.min(100, Math.max(0, (t - LEAD) / songLen * 100))}%`;
  } else ph.style.display = 'none';
}
function tick() {
  if (!playing) return;
  const t = pos();
  showTime(t);
  if (t >= playing.dur) {
    stop();
    if (firstListen && $('chatOn').checked) { firstListen = false; bandTalk(songBrief(), '刚才四个人一起把这首从头到尾合了一遍。每个人说一句感想（哪里合得好、哪里想再练练），可以互相回应。', 4); }
    return;
  }
  requestAnimationFrame(tick);
}
$('play').onclick = () => { if (playing) { offsetSec = pos(); stop(false); showTime(offsetSec); } else play(); };
$('stop').onclick = () => stop();
function seekTo(frac) {
  const d = Object.values(bufs).some(Boolean) ? duration() : 0;
  if (!d) return;
  offsetSec = Math.max(0, Math.min(d - 0.1, frac * d));
  if (playing) play(offsetSec); else showTime(offsetSec);
}
$('seek').onclick = (e) => { const r = e.currentTarget.getBoundingClientRect(); seekTo((e.clientX - r.left) / r.width); };
$('secBar').onclick = (e) => {
  if (!S) return;
  const r = e.currentTarget.getBoundingClientRect(), songLen = S.totalBars * S.beats * spb(), d = duration();
  if (d) seekTo(((e.clientX - r.left) / r.width * songLen + LEAD) / d);
};

/* ---------- 导出 ---------- */
const fileBase = () => (S ? S.title.replace(/[\\/:*?"<>|]/g, '_') : '合奏');
async function mixdown() {
  const d = duration(), n = Math.ceil((d + 0.3) * SR);
  const ctx = new OfflineAudioContext(2, n, SR);
  buildGraph(ctx, 0, 0);
  const out = await ctx.startRendering();
  let pk = 0; for (let c = 0; c < 2; c++) { const x = out.getChannelData(c); for (let i = 0; i < x.length; i++) pk = Math.max(pk, Math.abs(x[i])); }
  if (pk > 0.95) for (let c = 0; c < 2; c++) { const x = out.getChannelData(c), k = 0.95 / pk; for (let i = 0; i < x.length; i++) x[i] *= k; }
  return out;
}
async function saveFiles(files, okText) {
  const r = await api.save({ title: S ? S.title : '', files });
  if (r.error) { status('保存失败：' + r.error, 'err'); return null; }
  status(`${okText}：${r.saved.join('、')}`, 'ok');
  return r;
}
$('wav').onclick = async () => {
  if (!S) return; status('正在混音…');
  const out = await mixdown();
  saveFiles([{ name: `${fileBase()}.wav`, bytes: ENG.drums.toWav(out) }], '导出好了');
};
$('stems').onclick = async () => {
  if (!S) return;
  const files = [];
  for (const t of TRACKS) { const b = bufs[t.key]; if (b) files.push({ name: `分轨/${mem(t.who).short}-${t.title}.wav`, bytes: ENG.drums.toWav(b) }); }
  saveFiles(files, '分轨导出好了');
};
$('midi').onclick = async () => {
  if (!S) return;
  const files = [];
  for (const t of TRACKS) {
    if (t.key === 'vocal') continue;
    const sc = ENG[t.key].parse(S.parts[t.key]);
    if (sc.error) continue;
    try { files.push({ name: `MIDI/${mem(t.who).short}-${t.title}.mid`, bytes: ENG[t.key].toMidi(sc) }); } catch (e) {}
  }
  saveFiles(files, 'MIDI 导出好了');
};

/* ---------- 保存 / 打开合奏谱 ---------- */
function songFile() {
  return { format: 'leoneed-band', version: 1, title: S.title, bpm: S.bpm, key: S.key, beats: S.beats, totalBars: S.totalBars, sections: S.sections, lang: S.lang, octave: S.octave,
    parts: S.parts, vocal: S.vocal.map((l) => ({ bar: l.bar, beat: l.beat, text: l.text, units: l.units, notes: l.notes })), raw: S.raw, mix };
}
$('saveSong').onclick = async () => {
  if (!S) return;
  S.title = $('title').value.trim() || S.title;
  const files = [
    { name: `${fileBase()}.合奏谱.json`, text: JSON.stringify(songFile(), null, 1) },
    { name: '一歌-电吉他.txt', text: S.parts.guitar }, { name: '咲希-电子琴.txt', text: S.parts.keys },
    { name: '穗波-架子鼓.txt', text: S.parts.drums }, { name: '志步-贝斯.txt', text: S.parts.bass },
  ];
  if (S.vocal.length) files.push({ name: '一歌-主唱（歌词和旋律）.txt', text: Core.vocalToText(S.vocal, { syllabify: DSP.syllabify }) + '\n' });
  saveFiles(files, '保存好了');
};
$('openSong').onclick = async () => {
  const r = await api.pick({ kind: 'song' });
  if (!r || r.canceled) return;
  try {
    const j = JSON.parse(r.text);
    if (j.format !== 'leoneed-band' || !j.parts) throw new Error('这不是合奏谱文件');
    await api.newProject();
    setSong({ raw: j.raw || null, title: String(j.title || '合奏').slice(0, 30), bpm: +j.bpm || 110, key: j.key || 'C', beats: +j.beats || 4, totalBars: +j.totalBars || 8,
      sections: Array.isArray(j.sections) ? j.sections : [{ name: '全曲', bar: 0, bars: +j.totalBars || 8 }], parts: j.parts, lang: j.lang === 'ja' ? 'ja' : 'zh', octave: +j.octave || 0,
      vocal: (j.vocal || []).map((l) => Core.cleanVocalLine(l, DSP.syllabify)).filter(Boolean), errors: {}, warnings: [] });
    if (j.mix) Object.assign(mix, j.mix);
    renderTracks();
    status(`打开了《${S.title}》`, 'ok');
  } catch (e) { status('打不开：' + e.message, 'err'); }
};
$('newSong').onclick = async () => {
  stop(); S = null; bufs = {}; firstListen = true;
  await api.newProject();
  $('tracks').innerHTML = '<div id="empty">在左边让大家写一首，或者拆解一份谱子。</div>';
  $('warn').style.display = 'none'; renderSong(); status('');
  $('play').disabled = true; $('wav').disabled = true; $('stems').disabled = true;
};
$('title').addEventListener('change', () => { if (S) { S.title = $('title').value.trim() || S.title; renderSong(); } });
$('openFolder').onclick = async () => { const r = await api.openFolder(); if (!r.ok) status('还没有保存过东西'); };
$('openGroup').onclick = () => api.openGroup();

/* ---------- 左边的页签 ---------- */
document.querySelectorAll('.tabs button').forEach((b) => b.onclick = () => {
  document.querySelectorAll('.tabs button').forEach((x) => x.classList.toggle('sel', x === b));
  document.querySelectorAll('.pane').forEach((p) => p.classList.toggle('show', p.id === 'pane-' + b.dataset.tab));
});

/* ---------- 启动 ---------- */
api.onRoster((r) => { roster = r; if (S) renderTracks(); });
window.addEventListener('focus', () => refreshConfig());
(async () => {
  try { await loadEngines(); } catch (e) { status(e.message, 'err'); return; }
  $('w_key').innerHTML = '<option value="">自动</option>' + Core.KEY_NAME.map((k) => `<option>${k}</option>`).join('');
  roster = await api.roster();
  await refreshConfig();
  $('render').disabled = true;
  talk(null, '四个人都到了。可以让大家写一首新曲子，也可以拿一份谱子来拆。', true);
})();
