'use strict';
/* 读导入的谱子：MIDI（.mid）和 MusicXML（.musicxml / .xml，未压缩）→ 每一轨的音符（以拍为单位）
 * 返回 { title, bpm, beats, keyPc（谱子里写了调号才有）, tracks: [{ name, program, drum, notes: [{ t, dur, midi, vel }] }] } */
(function (root) {
  /* ---------- MIDI ---------- */
  function readMidi(bytes) {
    const b = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
    let p = 0;
    const u32 = () => { const v = (b[p] << 24 | b[p + 1] << 16 | b[p + 2] << 8 | b[p + 3]) >>> 0; p += 4; return v; };
    const u16 = () => { const v = b[p] << 8 | b[p + 1]; p += 2; return v; };
    const str = (n) => { let s = ''; for (let i = 0; i < n; i++) s += String.fromCharCode(b[p + i]); p += n; return s; };
    const vlq = () => { let v = 0, c; do { c = b[p++]; v = (v << 7) | (c & 0x7f); } while (c & 0x80 && p < b.length); return v; };
    if (str(4) !== 'MThd') throw new Error('这不是 MIDI 文件');
    const hl = u32(); const fmt = u16(), ntr = u16(), div = u16(); p += hl - 6;
    if (div & 0x8000) throw new Error('这个 MIDI 用的是 SMPTE 时间格式，暂时不支持');
    let bpm = 0, beats = 0, keyPc = null, title = '';
    const out = new Map();         // `${track}:${channel}` → 轨
    const names = [];
    for (let tr = 0; tr < ntr && p < b.length; tr++) {
      const id = str(4), len = u32(), end = p + len;
      if (id !== 'MTrk') { p = end; continue; }
      let tick = 0, run = 0;
      const on = new Map();
      const prog = new Array(16).fill(0);
      while (p < end) {
        tick += vlq();
        let st = b[p];
        if (st & 0x80) p++; else st = run;
        if (st === 0xff) {
          const type = b[p++], l = vlq(), d = b.subarray(p, p + l); p += l;
          if (type === 0x51 && !bpm && l === 3) bpm = Math.round(60000000 / (d[0] << 16 | d[1] << 8 | d[2]));
          else if (type === 0x58 && !beats) beats = d[0] * 4 / (1 << d[1]);
          else if (type === 0x59 && keyPc === null) { const sf = (d[0] << 24) >> 24; keyPc = ((sf * 7) % 12 + 12) % 12; }
          else if (type === 0x03) { let s = ''; try { s = new TextDecoder().decode(d); } catch (e) {} names[tr] = s.trim(); if (tr === 0 && fmt === 1 && !title) title = s.trim(); }
          continue;
        }
        if (st === 0xf0 || st === 0xf7) { p += vlq(); continue; }
        run = st;
        const type = st & 0xf0, ch = st & 0x0f;
        const d1 = b[p++], d2 = type === 0xc0 || type === 0xd0 ? 0 : b[p++];
        if (type === 0xc0) { prog[ch] = d1; continue; }
        if (type !== 0x90 && type !== 0x80) continue;
        const key = ch * 128 + d1;
        if (type === 0x90 && d2 > 0) { if (!on.has(key)) on.set(key, []); on.get(key).push({ tick, vel: d2 }); continue; }
        const st0 = on.get(key); if (!st0 || !st0.length) continue;
        const s = st0.shift();
        const k = `${tr}:${ch}`;
        if (!out.has(k)) out.set(k, { tr, ch, program: prog[ch], notes: [] });
        out.get(k).notes.push({ t: s.tick / div, dur: Math.max(1, tick - s.tick) / div, midi: d1, vel: s.vel });
      }
      p = end;
    }
    const tracks = [...out.values()].filter((t) => t.notes.length).map((t) => ({
      name: (names[t.tr] || '') + (t.ch === 9 ? (names[t.tr] ? '' : '鼓') : '') || `第 ${t.tr + 1} 轨（通道 ${t.ch + 1}）`,
      program: t.program, drum: t.ch === 9, notes: t.notes.sort((a, c) => a.t - c.t),
    }));
    return { title, bpm: bpm || 120, beats: [2, 3, 4].includes(beats) ? beats : 4, keyPc, tracks };
  }

  /* ---------- MusicXML ---------- */
  const STEP = { C: 0, D: 2, E: 4, F: 5, G: 7, A: 9, B: 11 };
  // 鼓谱上的位置 → GM 打击乐（谱子里没写 midi-unpitched 时用）
  const DRUM_POS = { E4: 36, F4: 36, A4: 41, C5: 38, D5: 45, E5: 48, F5: 51, G5: 42, A5: 49, B5: 49 };
  function readMusicXML(text) {
    const doc = new DOMParser().parseFromString(text, 'application/xml');
    if (doc.querySelector('parsererror')) throw new Error('MusicXML 文件格式不对（如果是 .mxl 压缩文件，请先在打谱软件里导出为未压缩的 .musicxml）');
    if (doc.documentElement.nodeName === 'score-timewise') throw new Error('暂时只支持 partwise 格式的 MusicXML');
    const q = (el, s) => el.querySelector(s), qa = (el, s) => [...el.querySelectorAll(s)];
    const txt = (el, s, d = '') => { const x = el && q(el, s); return x ? x.textContent.trim() : d; };
    const title = txt(doc, 'work > work-title') || txt(doc, 'movement-title') || '';
    let bpm = 0, beats = 0, keyPc = null;
    const info = {};
    for (const sp of qa(doc, 'part-list > score-part')) {
      const id = sp.getAttribute('id');
      const unp = {};
      for (const mi of qa(sp, 'midi-instrument')) { const u = txt(mi, 'midi-unpitched'); if (u) unp[mi.getAttribute('id')] = +u - 1; }
      const prog = +txt(sp, 'midi-instrument > midi-program', '1') - 1;
      const name = txt(sp, 'part-name') || id;
      info[id] = { name, program: prog, unp, drum: /drum|percussion|鼓|ドラム/i.test(name) || Object.keys(unp).length > 0 || txt(sp, 'midi-instrument > midi-channel') === '10' };
    }
    const tracks = [];
    for (const part of qa(doc, 'score-partwise > part')) {
      const inf = info[part.getAttribute('id')] || { name: part.getAttribute('id'), program: 0, unp: {}, drum: false };
      let divs = 1, t = 0, measureStart = 0, measureLen = 4, lastStart = 0, drum = inf.drum;
      const notes = [], tied = new Map();
      for (const m of qa(part, 'measure')) {
        measureStart = t;
        let maxT = t;
        for (const el of m.children) {
          const n = el.nodeName;
          if (n === 'attributes') {
            const d = txt(el, 'divisions'); if (d) divs = +d || 1;
            const bt = txt(el, 'time > beats'), bu = txt(el, 'time > beat-type');
            if (bt && bu) { measureLen = +bt * 4 / +bu; if (!beats) beats = measureLen; }
            const f = txt(el, 'key > fifths'); if (f !== '' && keyPc === null) keyPc = ((+f * 7) % 12 + 12) % 12;
            if (/percussion/i.test(txt(el, 'clef > sign'))) drum = true;
          } else if (n === 'sound' || n === 'direction') {
            const s = n === 'sound' ? el : q(el, 'sound');
            if (s && s.getAttribute('tempo') && !bpm) bpm = Math.round(+s.getAttribute('tempo'));
          } else if (n === 'backup') { t -= (+txt(el, 'duration', '0')) / divs; }
          else if (n === 'forward') { t += (+txt(el, 'duration', '0')) / divs; maxT = Math.max(maxT, t); }
          else if (n === 'note') {
            if (q(el, 'grace')) continue;
            const dur = (+txt(el, 'duration', '0')) / divs;
            const chord = !!q(el, 'chord');
            const start = chord ? lastStart : t;
            if (!chord) { lastStart = t; t += dur; maxT = Math.max(maxT, t); }
            if (q(el, 'rest')) continue;
            let midi = null;
            const pitch = q(el, 'pitch'), unpitched = q(el, 'unpitched');
            if (pitch) midi = 12 * (+txt(pitch, 'octave', '4') + 1) + STEP[txt(pitch, 'step', 'C')] + Math.round(+txt(pitch, 'alter', '0'));
            else if (unpitched) {
              drum = true;
              const ins = q(el, 'instrument'), iid = ins && ins.getAttribute('id');
              midi = iid && inf.unp[iid] != null ? inf.unp[iid] : DRUM_POS[txt(unpitched, 'display-step', 'C') + txt(unpitched, 'display-octave', '5')] || 38;
            }
            if (midi == null) continue;
            const ties = qa(el, 'tie').map((x) => x.getAttribute('type'));
            const vel = (q(el, 'notations > articulations > accent') ? 110 : 85);
            if (ties.includes('stop') && tied.has(midi)) {
              const prev = tied.get(midi); prev.dur = start + dur - prev.t;
              if (!ties.includes('start')) tied.delete(midi);
              continue;
            }
            const note = { t: start, dur: Math.max(0.05, dur), midi, vel };
            notes.push(note);
            if (ties.includes('start')) tied.set(midi, note);
          }
        }
        // 小节结束：以写满的那个声部为准（弱起小节按实际长度）
        t = Math.max(maxT, measureStart + (m.getAttribute('implicit') === 'yes' ? 0 : 0));
        if (t - measureStart < measureLen - 1e-6 && m.getAttribute('implicit') !== 'yes' && notes.length) t = measureStart + measureLen;
      }
      if (notes.length) tracks.push({ name: inf.name, program: inf.program, drum, notes: notes.sort((a, b) => a.t - b.t) });
    }
    return { title, bpm: bpm || 120, beats: [2, 3, 4].includes(beats) ? beats : 4, keyPc, tracks };
  }

  root.ScoreImport = { readMidi, readMusicXML };
})(typeof window !== 'undefined' ? window : globalThis);
