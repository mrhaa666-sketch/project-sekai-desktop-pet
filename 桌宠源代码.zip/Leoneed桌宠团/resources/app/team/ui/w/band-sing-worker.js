'use strict';
// 合奏窗口的后台线程：把一歌每一句念出来的声音切成一个个音，变调、拉长到旋律上，放到曲子里对应的位置（和白葱桌宠的唱歌一样）
importScripts('sing-dsp.js');
self.onmessage = (e) => {
  const m = e.data || {}, id = m.id;
  const prog = (p, stage) => self.postMessage({ id, progress: p, stage });
  try {
    const D = self.SingDSP;
    const song = { bpm: m.bpm, lines: [] };
    const f0s = [], warn = [];
    m.lines.forEach((l, i) => {
      const n = D.sungCount(l.notes);
      const segs = D.segment(l.samples, l.sr, n);
      if (segs.length !== n) warn.push(`第 ${i + 1} 句切出 ${segs.length} 个音，应该是 ${n} 个，少的音会空着`);
      const units = segs.map((s) => { const x = l.samples.slice(s.s, s.e); const f0 = D.estimateF0(x, l.sr); if (f0 > 0) f0s.push(f0); return { x, sr: l.sr, f0 }; });
      song.lines.push({ notes: l.notes, units, start: l.start });
      prog(0.05 + 0.25 * (i + 1) / m.lines.length, '切分和测音高');
    });
    f0s.sort((a, b) => a - b);
    const voiceF0 = f0s.length ? f0s[Math.floor(f0s.length / 2)] : 0;
    song.tonic = D.pickTonicForKey(m.keyPc || 0, voiceF0, song.lines) + (m.octave || 0) * 12;
    const r = D.renderSong(song, { sr: 44100, backing: null, onProgress: (p) => prog(0.3 + p * 0.7, '变调和拼接') });
    // 人声单独返回（窗口里再和四个乐器混音）
    let pk = 1e-6; for (let i = 0; i < r.vocal.length; i++) pk = Math.max(pk, Math.abs(r.vocal[i]));
    const g = 0.89 / pk; for (let i = 0; i < r.vocal.length; i++) r.vocal[i] *= g;
    self.postMessage({ id, result: { vocal: r.vocal, env: r.env, envRate: r.envRate, lines: r.lines, tonic: song.tonic, voiceF0: Math.round(voiceF0), warn } }, [r.vocal.buffer]);
  } catch (err) {
    self.postMessage({ id, error: String((err && err.message) || err) });
  }
};
