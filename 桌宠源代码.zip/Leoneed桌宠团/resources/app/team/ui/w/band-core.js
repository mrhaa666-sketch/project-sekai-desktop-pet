'use strict';
/* 合奏谱：主进程和合奏窗口共用的部分（不碰声音）
 *
 * 合奏谱（song）的样子：
 *   { title, bpm, key: 'D'（1=D）, beats: 4,
 *     tones: { guitar: '过载', keys: '电子琴', keysStyle: '分解', bass: '指弹', kit: '原声', grid: 16 },
 *     sections: [{ name, bars, chords: '| D | A | Bm | G |', guitar, keys, bass, drums, vocal: [{ bar, beat, text, units, notes }] }],
 *     vocalLang: 'zh' | 'ja' }
 * 每段的 guitar / keys / bass 是简谱正文（不带开头那行），drums 是这一段的鼓谱行；同一段里四个声部一样长。
 * assemble() 把各段接起来，变成四个成员各自的乐器窗口能直接打开的完整谱子（一歌：电吉他简谱，咲希：电子琴简谱，
 * 穗波：鼓谱，志步：贝斯简谱），长度不对的段落自动补休止或截掉，保证四个人对得齐。
 * 主唱（一歌）的旋律：notes 是 [半音, 拍数]，半音以 1（do）为 0；休止写 [null, 拍数]。 */
(function (root) {
  const PC = { C: 0, 'C#': 1, Db: 1, D: 2, 'D#': 3, Eb: 3, E: 4, F: 5, 'F#': 6, Gb: 6, G: 7, 'G#': 8, Ab: 8, A: 9, 'A#': 10, Bb: 10, B: 11 };
  const KEY_NAME = ['C', 'Db', 'D', 'Eb', 'E', 'F', 'F#', 'G', 'Ab', 'A', 'Bb', 'B'];
  const SHARP_KEYS = [2, 4, 6, 7, 9, 11];          // D E F# G A B 调用升号
  const NAMES_SHARP = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];
  const NAMES_FLAT = ['C', 'Db', 'D', 'Eb', 'E', 'F', 'Gb', 'G', 'Ab', 'A', 'Bb', 'B'];
  const TONES = {
    guitar: ['清音', '过载', '失真'], keys: ['电子琴', '电钢琴', '风琴', '合成器'], keysStyle: ['流行', '分解', '柱式', '长音'],
    bass: ['指弹', '拨片', '击弦', '过载'], kit: ['原声', '电子'],
  };
  const DEFAULT_TONES = { guitar: '过载', keys: '电子琴', keysStyle: '分解', bass: '指弹', kit: '原声', grid: 16 };
  const VOCAL_BEATS = [0.25, 0.5, 0.75, 1, 1.5, 2, 3, 4];
  const PARTS = ['guitar', 'keys', 'bass', 'drums'];
  const clamp = (x, a, b) => Math.max(a, Math.min(b, x));
  const q4 = (x) => Math.round(x * 4) / 4;

  function keyPc(k) {
    const m = /^\s*([#b]?)([A-Ga-g])([#b]?)/.exec(String(k || ''));
    if (!m) return null;
    const acc = (m[1] || m[3]) === '#' ? 1 : (m[1] || m[3]) === 'b' ? -1 : 0;
    return (PC[m[2].toUpperCase()] + acc + 12) % 12;
  }
  const keyName = (pc) => KEY_NAME[((pc % 12) + 12) % 12];
  // 各乐器里“1”对应的音（和各自的简谱解析一致）
  const guitarTonic = (pc) => { const t = 60 + pc; return t > 66 ? t - 12 : t; };
  const keysTonic = guitarTonic;
  const bassTonic = (pc) => { let t = 24 + pc; while (t < 28) t += 12; return t; };

  /* ---------- 头部 ---------- */
  function cleanTones(t = {}) {
    const o = { ...DEFAULT_TONES };
    for (const k of Object.keys(TONES)) if (TONES[k].includes(t[k])) o[k] = t[k];
    o.grid = +t.grid === 8 ? 8 : 16;
    return o;
  }
  function headers(song) {
    const k = keyName(keyPc(song.key) ?? 0), b = song.beats, t = cleanTones(song.tones);
    return {
      guitar: `1=${k} ${b}/4 ♩=${song.bpm} 音色=${t.guitar}`,
      keys: `1=${k} ${b}/4 ♩=${song.bpm} 音色=${t.keys} 伴奏=${t.keysStyle}`,
      bass: `1=${k} ${b}/4 ♩=${song.bpm} 音色=${t.bass}`,
      drums: `♩=${song.bpm} ${b}/4 每格=1/${t.grid} 鼓组=${t.kit}`,
    };
  }

  /* ---------- 时值 → 简谱写法 ---------- */
  // d 拍（四分之一拍的整数倍）：先写不足一拍的部分，再用 - 补整拍
  function durToken(sym, d) {
    d = Math.max(0.25, q4(d));
    const n = Math.floor(d + 1e-6), f = Math.round((d - n) * 4) / 4;
    if (f < 1e-6) return sym + ' -'.repeat(n - 1);
    return sym + { 0.25: '__', 0.5: '_', 0.75: '_.' }[f] + ' -'.repeat(n);
  }
  function restFill(beats) {
    const out = [];
    let left = q4(beats);
    while (left > 1e-6) { const d = Math.min(4, left); out.push(durToken('0', d)); left = q4(left - d); }
    return out.join(' ');
  }
  // 音 → 简谱（相对 tonic）：1–7 加升降号和八度点
  const DEGREE = ['1', '#1', '2', 'b3', '3', '4', '#4', '5', 'b6', '6', 'b7', '7'];
  function degreeToken(midi, tonic) {
    const rel = midi - tonic, oct = Math.floor(rel / 12), d = DEGREE[((rel % 12) + 12) % 12];
    return d + (oct > 0 ? "'".repeat(oct) : oct < 0 ? ','.repeat(-oct) : '');
  }
  function noteName(midi, pc) {
    const names = SHARP_KEYS.includes(pc) ? NAMES_SHARP : NAMES_FLAT;
    return names[((midi % 12) + 12) % 12] + (Math.floor(midi / 12) - 1);
  }

  /* ---------- 正文清理：去掉模型写的头部、和弦行、代码块标记 ---------- */
  function cleanBody(text, kind) {
    let s = String(text || '').replace(/```[a-z]*\n?/gi, '').replace(/\r/g, '');
    const lines = s.split('\n').filter((l) => {
      const t = l.trim();
      if (!t) return kind === 'drums';
      if (/^(和弦|chords?)\s*[:：]/i.test(t)) return false;
      if (kind === 'drums') return /^[一-龥A-Za-z0-9　 ]{1,6}\s*[|｜]/.test(t);
      if (/(♩|音色|伴奏|鼓组|每格|bpm)\s*[=:：]?/i.test(t) || /^1\s*=\s*[#b]?[A-G]/i.test(t)) return false;
      return true;
    });
    return lines.join('\n').replace(/\n{3,}/g, '\n\n').trim();
  }

  /* ---------- 让一段的长度正好是 want 拍：短了补休止，长了截掉 ---------- */
  function fitJianpu(E, header, body, want) {
    body = cleanBody(body, 'jianpu');
    if (!body) return { body: restFill(want), empty: true };
    const off = header.length + 1;
    let sc = E.parse(header + '\n' + body);
    if (sc.error) return { error: sc.error.msg, near: (header + '\n' + body).slice(Math.max(0, sc.error.pos - 8), sc.error.pos + 8).replace(/\n/g, ' ') };
    if (E.isTab && E.isTab(header + '\n' + body)) return { error: '这里要写简谱，不要写成六线谱 / 四线谱' };
    let fixed = '';
    for (let round = 0; round < 3; round++) {
      const total = sc.notes.reduce((m, n) => Math.max(m, n.t + n.dur), 0);
      if (Math.abs(total - want) < 1e-6) break;
      if (total < want) { body = body.replace(/\s*\|?\s*$/, '') + ' ' + restFill(want - total) + ' |'; fixed = fixed || 'short'; }
      else {
        const keep = sc.notes.filter((n) => n.t + n.dur <= want + 1e-6);
        const last = keep[keep.length - 1];
        const cut = last ? Math.max(0, last.src[1] - off) : 0;
        const got = last ? last.t + last.dur : 0;
        body = body.slice(0, cut).replace(/\s+$/, '') + ' ' + (want - got > 1e-6 ? restFill(want - got) : '') + ' |';
        fixed = 'long';
      }
      sc = E.parse(header + '\n' + body);
      if (sc.error) return { error: sc.error.msg };
    }
    return { body: body.trim(), fixed };
  }
  function fitDrums(Dr, header, body, bars) {
    body = cleanBody(body, 'drums');
    // 各行格数不一样时先用“-”补齐；几组接成一组（同一个鼓的格子按顺序接起来，小节线排版时重新加）
    if (body) {
      const order = [], acc = {};
      let total = 0;
      for (const grp of body.split(/\n\s*\n/)) {
        const rows = grp.split('\n').map((l) => /^\s*([一-龥A-Za-z0-9]{1,6})[　 ]*[|｜](.*)$/.exec(l)).filter(Boolean)
          .map((m) => ({ name: m[1].toLowerCase(), cells: m[2].replace(/[|｜\s　]/g, '').replace(/[—－–]/g, '-') }));
        if (!rows.length) continue;
        const w = Math.max(...rows.map((r) => r.cells.length));
        for (const r of rows) {
          if (r.name in acc) { if (acc[r.name].length > total) continue; } else { order.push(r.name); acc[r.name] = '-'.repeat(total); }
          acc[r.name] += r.cells.padEnd(w, '-');
        }
        total += w;
        for (const n of order) acc[n] = acc[n].padEnd(total, '-');
      }
      body = order.map((n) => `${n}|${acc[n]}|`).join('\n');
    }
    let sc = body ? Dr.parse(header + '\n\n' + body) : null;
    if (sc && sc.error) return { error: sc.error.msg };
    if (!sc) { sc = Dr.parse(header + '\n\n踩镲|-|'); sc.rows = {}; sc.empty = true; }
    const want = bars * sc.per * sc.beats, had = sc.cells;
    for (const id of Object.keys(sc.rows)) {
      const r = sc.rows[id].slice(0, want);
      while (r.length < want) r.push(0);
      sc.rows[id] = r;
    }
    sc.cells = want;
    const text = Dr.serialize(sc, { barsPerLine: 2, header: '#' }).split('\n').slice(1).join('\n').trim();
    return { body: text, fixed: had === want ? '' : had < want ? 'short' : 'long', empty: !!sc.empty };
  }

  /* ---------- 和弦 ---------- */
  function chordCells(str, bars, E, fallback) {
    const cells = String(str || '').replace(/^(和弦|chords?)\s*[:：]/i, '').split(/[|｜]/).map((c) => c.trim()).filter(Boolean);
    const ok = (n) => { try { return !!E.parseChord(n); } catch (e) { return false; } };
    const out = [];
    let prev = fallback;
    for (let i = 0; i < bars; i++) {
      const c = cells[i];
      if (!c) { out.push(prev); continue; }
      const names = c.split(/\s+/).slice(0, 2).map((n) => {
        if (ok(n)) return n;
        const base = (/^[A-G][#b]?m?/.exec(n) || [])[0];
        return base && ok(base) ? base : prev.split(' ').pop();
      });
      const cell = names.join(' ');
      out.push(cell); prev = names[names.length - 1];
    }
    return out;
  }

  /* ---------- 主唱：整理一行 ---------- */
  function cleanVocalLine(l, syllabify) {
    const text = String(l && l.text || '').trim().slice(0, 60);
    let units = Array.isArray(l && l.units) ? l.units.map((u) => String(u).trim()).filter(Boolean).slice(0, 24) : [];
    if (!units.length && syllabify) units = syllabify(text).slice(0, 24);
    if (!units.length) return null;
    let notes = (Array.isArray(l.notes) ? l.notes : []).filter((n) => Array.isArray(n) && (n[0] === null || Number.isFinite(+n[0])) && Number.isFinite(+n[1]))
      .map((n) => [n[0] === null ? null : clamp(Math.round(+n[0]), -12, 19), VOCAL_BEATS.reduce((p, x) => (Math.abs(x - n[1]) < Math.abs(p - n[1]) ? x : p), 1)]);
    const sung = notes.filter((n) => n[0] != null);
    if (sung.length !== units.length) {
      // 音和字数对不上：按字数重排，缺的音沿用前一个音高、1 拍
      const fill = [];
      for (let i = 0; i < units.length; i++) fill.push(sung[i] || [fill.length ? fill[fill.length - 1][0] : 0, 1]);
      notes = fill;
    }
    while (notes.length && notes[notes.length - 1][0] == null) notes.pop();
    return { text: text || units.join(''), units, notes, bar: Math.max(0, Math.round(+l.bar) || 0), beat: Math.max(0, Math.round((+l.beat || 0) * 4) / 4) };
  }
  const lineBeats = (l) => l.notes.reduce((s, n) => s + n[1], 0);

  /* ---------- 把各段接起来 ---------- */
  // E = { guitar: Guitar, keys: Keys, bass: Bass, drums: Drums }（各成员的简谱 / 鼓谱解析）
  function assemble(raw, E, { syllabify = null } = {}) {
    const warnings = [];
    const song = {
      title: String(raw.title || '').trim().slice(0, 30) || '未命名的合奏',
      bpm: clamp(Math.round(+raw.bpm) || 110, 50, 220),
      key: keyName(keyPc(raw.key) ?? 0),
      beats: [2, 3, 4].includes(+raw.beats) ? +raw.beats : 4,
      tones: cleanTones(raw.tones || {}),
      vocalLang: raw.vocalLang === 'ja' ? 'ja' : 'zh',
      sections: [],
    };
    const pc = keyPc(song.key);
    const H = headers(song);
    const byName = {};
    const secs = (Array.isArray(raw.sections) ? raw.sections : []).slice(0, 24);
    for (const s0 of secs) {
      if (!s0) continue;
      const src = s0.same && byName[String(s0.same).trim()] ? byName[String(s0.same).trim()] : null;
      const s = { name: String(s0.name || `第${song.sections.length + 1}段`).trim().slice(0, 12), bars: clamp(Math.round(+(s0.bars || (src && src.bars))) || 4, 1, 32) };
      for (const k of ['chords', ...PARTS]) s[k] = s0[k] != null && String(s0[k]).trim() ? String(s0[k]) : src ? src[k] : '';
      s.same = src ? src.name : '';
      s.vocal = (Array.isArray(s0.vocal) ? s0.vocal : []).map((l) => cleanVocalLine(l, syllabify)).filter(Boolean);
      song.sections.push(s);
      if (!byName[s.name]) byName[s.name] = s;
    }
    if (!song.sections.length) throw new Error('合奏谱里没有段落');
    const totalBars = song.sections.reduce((n, s) => n + s.bars, 0);
    if (totalBars > 160) throw new Error('曲子太长了（超过 160 小节）');

    const tonicChord = song.key;
    const bodies = { guitar: [], keys: [], bass: [], drums: [] }, chords = [];
    const bad = [];       // 解析不了的段：[{ part, section, error }]
    let bar0 = 0;
    const vocal = [];
    for (const s of song.sections) {
      const want = s.bars * song.beats;
      s.start = bar0;
      chords.push(...chordCells(s.chords, s.bars, E.keys, chords.length ? chords[chords.length - 1].split(' ').pop() : tonicChord));
      for (const p of ['guitar', 'keys', 'bass']) {
        const r = fitJianpu(E[p], H[p], s[p], want);
        if (r.error) { bad.push({ part: p, section: s.name, error: r.error, near: r.near || '' }); bodies[p].push(`// ${s.name}（这一段没写对，先空着）\n` + restFill(want) + ' |'); continue; }
        if (r.fixed) warnings.push(`${s.name}的${PART_LABEL[p]}长度不对，已${r.fixed === 'short' ? '补了休止' : '截掉多出来的部分'}`);
        bodies[p].push(`// ${s.name}\n` + r.body);
        s[p] = r.body;
      }
      const d = fitDrums(E.drums, H.drums, s.drums, s.bars);
      if (d.error) { bad.push({ part: 'drums', section: s.name, error: d.error }); const e = fitDrums(E.drums, H.drums, '', s.bars); bodies.drums.push(e.body); }
      else {
        if (d.fixed) warnings.push(`${s.name}的鼓长度不对，已${d.fixed === 'short' ? '补齐' : '截掉多出来的部分'}`);
        bodies.drums.push(d.body); s.drums = d.body;
      }
      // 主唱：小节是这一段里的第几小节，换成整首的位置；不能超出这一段
      for (const l of s.vocal) {
        const start = (bar0 + Math.min(l.bar, s.bars - 1)) * song.beats + Math.min(l.beat, song.beats - 0.25);
        vocal.push({ ...l, at: start, section: s.name });
      }
      bar0 += s.bars;
    }
    // 主唱的行不能重叠，也不能超出整首
    vocal.sort((a, b) => a.at - b.at);
    let end = -1;
    const totalBeats = totalBars * song.beats;
    const vlines = [];
    for (const l of vocal) {
      if (l.at < end - 1e-6) { warnings.push(`“${l.text}”和上一句重叠，往后挪了`); l.at = Math.ceil(end / song.beats) * song.beats; }
      let len = lineBeats(l);
      if (l.at >= totalBeats) { warnings.push(`“${l.text}”超出了曲子，没有唱`); continue; }
      while (l.at + len > totalBeats + 1e-6 && l.notes.length > 1) { const n = l.notes.pop(); if (n[0] != null) l.units.pop(); len = lineBeats(l); }
      end = l.at + len;
      vlines.push({ text: l.text, units: l.units, notes: l.notes, bar: Math.floor(l.at / song.beats), beat: q4(l.at % song.beats), section: l.section });
    }
    const chordLine = '和弦：| ' + chords.join(' | ') + ' |';
    const parts = {
      guitar: `${H.guitar}\n${chordLine}\n\n${bodies.guitar.join('\n')}\n`,
      keys: `${H.keys}\n${chordLine}\n\n${bodies.keys.join('\n')}\n`,
      bass: `${H.bass}\n\n${bodies.bass.join('\n')}\n`,
      drums: `${H.drums}\n\n${bodies.drums.join('\n\n')}\n`,
    };
    song.sections.forEach((s) => { delete s.start; });
    return { song, parts, vocal: vlines, totalBars, sections: sectionMap(song), chords, bad, warnings, keyPc: pc };
  }
  const PART_LABEL = { guitar: '吉他', keys: '电子琴', bass: '贝斯', drums: '鼓' };
  function sectionMap(song) {
    let b = 0;
    return song.sections.map((s) => { const o = { name: s.name, bar: b, bars: s.bars }; b += s.bars; return o; });
  }

  // 旋律 → 简谱（时值只用 1/4、1/2、3/4、1、1.5、2、3、4 拍，写回去不走样）
  function melodyText(notes) {
    const DUR = { 0.25: '__', 0.5: '_', 0.75: '_.', 1: '', 1.5: '.', 2: '-', 3: '--', 4: '---' };
    return notes.map(([semi, beats]) => {
      let s = '0';
      if (semi != null) { const o = Math.floor(semi / 12), p = ((semi % 12) + 12) % 12; s = DEGREE[p] + (o > 0 ? "'".repeat(o) : ','.repeat(-o)); }
      return s + (DUR[beats] ?? '');
    }).join(' ');
  }
  /* ---------- 主唱的文字写法（合奏窗口里编辑用） ----------
   * 一行一句：@小节:拍 歌词 | 旋律简谱      例：@5 夜空的星星 | 5 3 2 1 2-    @6:2.5 …（第 6 小节第 2.5 拍开始）
   * 小节从 1 开始数，拍从 0 开始；歌词按字分音，日语按假名的拍分；想自己分就用 / 隔开 */
  function vocalToText(lines, { toJianpu, syllabify } = {}) {
    return lines.map((l) => {
      const auto = syllabify ? syllabify(l.text) : [];
      const words = auto.length === l.units.length && auto.every((u, i) => u === l.units[i]) ? l.text : l.units.join('/');
      return `@${l.bar + 1}${l.beat ? ':' + l.beat : ''} ${words} | ${(toJianpu || melodyText)(l.notes)}`;
    }).join('\n');
  }
  function textToVocal(text, { parseJianpu, syllabify }) {
    const out = [], errors = [];
    String(text || '').split('\n').forEach((raw, i) => {
      const t = raw.trim();
      if (!t || t.startsWith('//')) return;
      const m = /^@\s*(\d+)(?:\s*[:：]\s*(\d+(?:\.\d+)?))?\s+(.+?)\s*[|｜]\s*(.+)$/.exec(t);
      if (!m) { errors.push(`第 ${i + 1} 行看不懂（写法：@小节:拍 歌词 | 旋律）`); return; }
      const units = syllabify(m[3]);
      const pj = parseJianpu(m[4]);
      const notes = pj && Array.isArray(pj.notes) ? pj.notes : Array.isArray(pj) ? pj : null;
      if (!notes || (pj.errors && pj.errors.length)) { errors.push(`第 ${i + 1} 行的旋律：${(pj && pj.errors || ['看不懂']).join('，')}`); return; }
      const sung = notes.filter((n) => n[0] != null).length;
      if (sung !== units.length) errors.push(`第 ${i + 1} 行：${units.length} 个字，旋律有 ${sung} 个音（会自动对齐）`);
      const l = cleanVocalLine({ text: m[3].replace(/\//g, ''), units, notes, bar: (+m[1] || 1) - 1, beat: +m[2] || 0 });
      if (l) out.push(l);
    });
    return { lines: out, errors };
  }

  /* ========== 拆解导入的谱子（MIDI / MusicXML 解析出的音符） ==========
   * tracks: [{ name, program, drum, notes: [{ t, dur, midi, vel }] }]（t、dur 以拍为单位） */
  const GM_DRUM = { 35: 'kick', 36: 'kick', 37: 'rim', 38: 'snare', 40: 'snare', 39: 'clap', 42: 'hihat', 44: 'pedal', 46: 'openhat', 41: 'tom3', 43: 'tom3',
    45: 'tom2', 47: 'tom2', 48: 'tom1', 50: 'tom1', 49: 'crash', 52: 'crash', 55: 'crash', 57: 'crash', 51: 'ride', 59: 'ride', 53: 'bell', 54: 'hihat', 56: 'rim' };
  const avgPitch = (t) => (t.notes.length ? t.notes.reduce((s, n) => s + n.midi, 0) / t.notes.length : 0);
  const polyRatio = (t) => {
    if (!t.notes.length) return 0;
    const starts = new Map(); for (const n of t.notes) { const k = q4(n.t); starts.set(k, (starts.get(k) || 0) + 1); }
    return [...starts.values()].filter((c) => c > 1).length / starts.size;
  };
  // 自动猜每一轨交给谁：guitar / keys / bass / drums / vocal / ''（不用）
  function guessRoles(tracks) {
    const roles = tracks.map(() => '');
    const free = (r) => !roles.includes(r);
    tracks.forEach((t, i) => { if (t.drum && t.notes.length && free('drums')) roles[i] = 'drums'; });
    const byName = (re) => tracks.findIndex((t, i) => !roles[i] && t.notes.length && re.test(t.name || ''));
    const pick = (role, i) => { if (i >= 0 && free(role)) roles[i] = role; };
    pick('vocal', byName(/vocal|voice|melody|lead|sing|唱|旋律|人声|主旋|ボーカル|歌/i));
    pick('bass', byName(/bass|贝斯|ベース|低音/i));
    pick('guitar', byName(/guitar|gtr|吉他|ギター/i));
    pick('keys', byName(/piano|key|organ|synth|琴|键盘|ピアノ|キーボード/i));
    const melodic = tracks.map((t, i) => ({ t, i })).filter((x) => !roles[x.i] && !x.t.drum && x.t.notes.length);
    const prog = (x, a, b) => x.t.program >= a && x.t.program <= b;
    for (const x of melodic) if (free('bass') && (prog(x, 32, 39) || avgPitch(x.t) < 50)) roles[x.i] = 'bass';
    for (const x of melodic) if (!roles[x.i] && free('guitar') && prog(x, 24, 31)) roles[x.i] = 'guitar';
    for (const x of melodic) if (!roles[x.i] && free('keys') && (prog(x, 0, 23) || prog(x, 80, 95))) roles[x.i] = 'keys';
    // 主唱：剩下的单音旋律里最高的那一轨
    const mono = melodic.filter((x) => !roles[x.i] && polyRatio(x.t) < 0.2).sort((a, b) => avgPitch(b.t) - avgPitch(a.t));
    if (free('vocal') && mono.length) roles[mono[0].i] = 'vocal';
    for (const x of melodic) if (!roles[x.i]) { const r = ['keys', 'guitar', 'bass'].find(free); if (r) roles[x.i] = r; }
    return roles;
  }
  // 调：按音高分布（Krumhansl 大调轮廓）猜 1 是什么
  const MAJOR = [6.35, 2.23, 3.48, 2.33, 4.38, 4.09, 2.52, 5.19, 2.39, 3.66, 2.29, 2.88];
  function estimateKey(notes) {
    const h = new Array(12).fill(0);
    for (const n of notes) h[((n.midi % 12) + 12) % 12] += Math.min(4, n.dur || 0.5);
    let best = 0, bs = -Infinity;
    for (let k = 0; k < 12; k++) { let s = 0; for (let i = 0; i < 12; i++) s += h[(i + k) % 12] * MAJOR[i]; if (s > bs) { bs = s; best = k; } }
    return best;
  }
  // 每小节的和弦（大三 / 小三和弦里最像的；低音权重大）
  function estimateChords(notes, bars, beats, pc) {
    const names = SHARP_KEYS.includes(pc) ? NAMES_SHARP : NAMES_FLAT;
    const out = [];
    let prev = names[pc];
    for (let b = 0; b < bars; b++) {
      const t0 = b * beats, t1 = t0 + beats, h = new Array(12).fill(0);
      let low = null;
      for (const n of notes) {
        const ov = Math.min(t1, n.t + n.dur) - Math.max(t0, n.t);
        if (ov <= 0) continue;
        h[((n.midi % 12) + 12) % 12] += ov;
        if (!low || n.midi < low.midi) low = n;
      }
      if (low) h[((low.midi % 12) + 12) % 12] += beats * 0.8;
      if (h.every((v) => v === 0)) { out.push(prev); continue; }
      let best = null, bs = -Infinity;
      for (let r = 0; r < 12; r++) for (const [q, iv] of [['', [0, 4, 7]], ['m', [0, 3, 7]]]) {
        const inKey = [0, 2, 4, 5, 7, 9, 11].includes((r - pc + 12) % 12) ? 0.15 * beats : 0;
        const s = iv.reduce((a, i) => a + h[(r + i) % 12], 0) - 0.5 * h.reduce((a, v, i) => a + (iv.includes((i - r + 12) % 12) ? 0 : v), 0) + inKey;
        if (s > bs) { bs = s; best = names[r] + q; }
      }
      out.push(best); prev = best;
    }
    return out;
  }
  // 一段音符 → 简谱正文（t 相对这一段开头）。mode: 'deg'（按 tonic 写 1–7）或 'name'（写音名，咲希的电子琴用）
  function notesToBody(notes, { bars, beats, tonic, pc, mode = 'deg', poly = 'chord', lo = 0, hi = 127 }) {
    const want = bars * beats;
    const byOnset = new Map();
    for (const n of notes) {
      const t = q4(n.t);
      if (t < 0 || t >= want) continue;
      let m = n.midi; while (m < lo) m += 12; while (m > hi) m -= 12;
      const e = Math.min(want, Math.max(t + 0.25, q4(n.t + n.dur)));
      const g = byOnset.get(t) || { t, end: t, pitches: [] };
      g.end = Math.max(g.end, e); if (!g.pitches.includes(m)) g.pitches.push(m);
      byOnset.set(t, g);
    }
    const groups = [...byOnset.values()].sort((a, b) => a.t - b.t);
    const tok = (pitches) => {
      pitches.sort((a, b) => a - b);
      let ps = poly === 'low' ? [pitches[0]] : poly === 'high' ? [pitches[pitches.length - 1]] : pitches.slice(-4);
      const one = (m) => (mode === 'name' ? noteName(m, pc) : degreeToken(m, tonic));
      return ps.length > 1 ? '[' + ps.map(one).join(' ') + ']' : one(ps[0]);
    };
    const out = [];
    let cur = 0;
    const barMark = () => { if (cur > 0 && Math.abs(cur / beats - Math.round(cur / beats)) < 1e-6) out.push(Math.round(cur / beats) % 4 === 0 ? '|\n' : '|'); };
    const restTo = (t) => {
      while (cur < t - 1e-6) {
        const toBar = (Math.floor(cur / beats + 1e-6) + 1) * beats;
        const d = Math.min(t, toBar) - cur;
        out.push(durToken('0', d)); cur = q4(cur + d); barMark();
      }
    };
    groups.forEach((g, i) => {
      restTo(g.t);
      const next = i + 1 < groups.length ? groups[i + 1].t : want;
      const end = Math.min(next, g.end);
      out.push(durToken(tok(g.pitches), end - g.t)); cur = q4(end);
      if (Math.abs(cur / beats - Math.round(cur / beats)) < 1e-6) barMark();
    });
    restTo(want);
    return out.join(' ').replace(/ \|\n /g, ' |\n').replace(/\|\n$/, '|').trim();
  }
  function notesToDrums(notes, { bars, beats, grid = 16 }) {
    const per = grid / 4, cells = bars * beats * per, rows = {};
    for (const n of notes) {
      const id = GM_DRUM[n.midi]; if (!id) continue;
      const c = Math.round(n.t * per);
      if (c < 0 || c >= cells) continue;
      rows[id] = rows[id] || new Array(cells).fill(0);
      const v = n.vel >= 100 ? 1 : n.vel < 45 ? 0.3 : 0.78;
      rows[id][c] = Math.max(rows[id][c], v);
    }
    return { rows, cells, per };
  }
  // 本地补一个声部（导入的谱子里没有这个乐器时）
  function localDrums(bars, beats, grid, { first = true, fill = true } = {}) {
    const per = grid / 4, cpb = beats * per, rows = { crash: [], hihat: [], snare: [], kick: [] };
    for (let b = 0; b < bars; b++) for (let k = 0; k < cpb; k++) {
      const beat = k / per, onBeat = k % per === 0, eighth = per >= 2 ? k % (per / 2) === 0 : onBeat;
      const lastBar = fill && b === bars - 1 && bars >= 4;
      rows.crash.push(first && b === 0 && k === 0 ? 1 : 0);
      rows.hihat.push(eighth && !(first && b === 0 && k === 0) && !(lastBar && beat >= beats - 1) ? 0.78 : 0);
      const back = beats === 3 ? beat === 1 || beat === 2 : beats === 2 ? beat === 1 : beat === 1 || beat === 3;
      rows.snare.push(onBeat && back && !(lastBar && beat >= beats - 1) ? 1 : lastBar && beat >= beats - 1 ? 0.78 : 0);
      const kick = beats === 3 ? beat === 0 : beat === 0 || beat === 2 || (beats === 4 && beat === 2.5);
      rows.kick.push(kick ? 0.78 : 0);
    }
    return { rows, cells: bars * cpb, per };
  }
  function drumsToBody(Dr, d, header) {
    const sc = Dr.parse(header + '\n\n踩镲|-|');
    sc.rows = d.rows; sc.cells = d.cells;
    return Dr.serialize(sc, { barsPerLine: 2, header: '#' }).split('\n').slice(1).join('\n').trim();
  }
  function localBass(chords, beats, pc, E) {
    const tonic = bassTonic(pc);
    return chords.map((c) => {
      const names = c.split(' ');
      const half = beats / names.length;
      return names.map((n) => {
        const ch = E.bass.parseChord(n) || E.keys.parseChord(n);
        let root = ch ? ch.pc : pc;
        let m = 28 + ((root - 4 + 12) % 12);          // E1 起最近的根音
        if (m < 33) m += 12;
        const cnt = Math.max(1, Math.round(half / 0.5));
        return new Array(cnt).fill(durToken(degreeToken(m, tonic), 0.5)).join(' ');
      }).join(' ') + ' |';
    }).join(' ').replace(/((?:[^|]*\|){4})/g, '$1\n').trim();
  }
  // 旋律 → 主唱的乐句（按休止切开），歌词稍后填
  function melodyPhrases(notes, { beats, pc }) {
    const tonic = 60 + pc;
    const mono = [];
    for (const n of [...notes].sort((a, b) => a.t - b.t || b.midi - a.midi)) {
      const t = q4(n.t);
      if (mono.length && Math.abs(mono[mono.length - 1].t - t) < 1e-6) continue;
      if (mono.length) { const p = mono[mono.length - 1]; p.dur = Math.min(p.dur, t - p.t); }
      mono.push({ t, dur: Math.max(0.25, q4(n.dur)), midi: n.midi });
    }
    const phrases = [];
    let cur = null;
    for (const n of mono) {
      if (n.dur < 0.25) continue;
      if (!cur || n.t - (cur.t + cur.len) >= 1 || cur.notes.length >= 16) { cur = { t: n.t, len: 0, notes: [] }; phrases.push(cur); }
      const gap = n.t - (cur.t + cur.len);
      if (gap >= 0.25) cur.notes.push([null, VOCAL_BEATS.reduce((p, x) => (Math.abs(x - gap) < Math.abs(p - gap) ? x : p), 1)]);
      cur.notes.push([n.midi - tonic, VOCAL_BEATS.reduce((p, x) => (Math.abs(x - n.dur) < Math.abs(p - n.dur) ? x : p), 1)]);
      cur.len = n.t + n.dur - cur.t;
    }
    // 音高整体挪到 -5..14 附近（do 为 0）
    const all = phrases.flatMap((p) => p.notes.filter((x) => x[0] != null).map((x) => x[0]));
    if (all.length) {
      const mid = (Math.min(...all) + Math.max(...all)) / 2, shift = -12 * Math.round((mid - 5) / 12);
      for (const p of phrases) for (const x of p.notes) if (x[0] != null) x[0] += shift;
    }
    return phrases.map((p) => ({ bar: Math.floor(p.t / beats), beat: q4(p.t % beats), notes: p.notes, count: p.notes.filter((x) => x[0] != null).length }));
  }

  /* 导入的音符 → 合奏谱（每 8 小节一段）。roles[i] 是第 i 轨交给谁 */
  function fromTracks({ tracks, roles, bpm, beats, title, keyPc: kpc, lyricsLines = [], syllabify }, E) {
    beats = [2, 3, 4].includes(beats) ? beats : 4;
    const of = (r) => tracks.filter((t, i) => roles[i] === r).flatMap((t) => t.notes);
    const melodic = tracks.filter((t, i) => roles[i] && roles[i] !== 'drums').flatMap((t) => t.notes);
    const pc = Number.isFinite(kpc) ? kpc : estimateKey(melodic.length ? melodic : tracks.flatMap((t) => (t.drum ? [] : t.notes)));
    const end = Math.max(0, ...tracks.flatMap((t, i) => (roles[i] ? t.notes.map((n) => n.t + n.dur) : [])));
    const bars = clamp(Math.ceil(end / beats - 1e-6), 1, 160);
    const harmony = tracks.filter((t, i) => ['keys', 'guitar', 'bass'].includes(roles[i])).flatMap((t) => t.notes);
    const chords = estimateChords(harmony.length ? harmony : melodic, bars, beats, pc);
    const tones = { ...DEFAULT_TONES, grid: 16 };
    const song = { vocalLang: arguments[0].vocalLang === 'ja' ? 'ja' : 'zh', title: title || '导入的曲子', bpm: clamp(Math.round(bpm) || 110, 50, 220), key: keyName(pc), beats, tones, sections: [] };
    const H = headers(song);
    const has = { guitar: of('guitar').length > 0, keys: of('keys').length > 0, bass: of('bass').length > 0, drums: of('drums').length > 0, vocal: of('vocal').length > 0 };
    const filled = [];
    const SEC = 8;
    for (let b0 = 0, k = 1; b0 < bars; b0 += SEC, k++) {
      const n = Math.min(SEC, bars - b0), t0 = b0 * beats, t1 = (b0 + n) * beats;
      const slice = (arr) => arr.filter((x) => x.t >= t0 - 1e-6 && x.t < t1 - 1e-6).map((x) => ({ ...x, t: x.t - t0 }));
      const s = { name: `第${k}段`, bars: n, chords: '| ' + chords.slice(b0, b0 + n).join(' | ') + ' |' };
      s.guitar = has.guitar ? notesToBody(slice(of('guitar')), { bars: n, beats, tonic: guitarTonic(pc), pc, poly: 'chord', lo: 40, hi: 88 }) : restFill(n * beats);
      s.keys = has.keys ? notesToBody(slice(of('keys')), { bars: n, beats, tonic: keysTonic(pc), pc, mode: 'name', poly: 'chord', lo: 21, hi: 108 }) : restFill(n * beats);
      s.bass = has.bass ? notesToBody(slice(of('bass')), { bars: n, beats, tonic: bassTonic(pc), pc, poly: 'low', lo: 28, hi: 67 }) : localBass(chords.slice(b0, b0 + n), beats, pc, E);
      s.drums = drumsToBody(E.drums, has.drums ? notesToDrums(slice(of('drums')), { bars: n, beats, grid: 16 }) : localDrums(n, beats, 16, { first: true, fill: b0 + n < bars }), H.drums);
      song.sections.push(s);
    }
    if (!has.bass) filled.push('bass');
    if (!has.drums) filled.push('drums');
    if (!has.guitar) filled.push('guitar');
    if (!has.keys) filled.push('keys');
    // 主唱：旋律按乐句切开，歌词一行对一句（字数不够的句子先唱“啦”）
    const phrases = has.vocal ? melodyPhrases(of('vocal'), { beats, pc }) : [];
    const lyr = lyricsLines.map((l) => String(l || '').trim()).filter(Boolean);
    phrases.forEach((p, i) => {
      const sec = song.sections[Math.min(song.sections.length - 1, Math.floor(p.bar / SEC))];
      let units = lyr[i] && syllabify ? syllabify(lyr[i]) : [];
      if (units.length > p.count) units = units.slice(0, p.count);
      while (units.length < p.count) units.push(song.vocalLang === 'ja' ? 'ら' : '啦');
      sec.vocal = sec.vocal || [];
      sec.vocal.push({ bar: p.bar - Math.floor(p.bar / SEC) * SEC, beat: p.beat, text: units.join(''), units, notes: p.notes });
    });
    return { raw: song, filled, phrases: phrases.map((p) => ({ bar: p.bar, beat: p.beat, count: p.count, notes: p.notes })), chords, keyPc: pc, bars };
  }

  const api = { PC, KEY_NAME, TONES, DEFAULT_TONES, PARTS, PART_LABEL, VOCAL_BEATS, keyPc, keyName, guitarTonic, keysTonic, bassTonic, headers, durToken, restFill, degreeToken, noteName,
    cleanBody, fitJianpu, fitDrums, melodyText, chordCells, cleanVocalLine, assemble, sectionMap, vocalToText, textToVocal,
    guessRoles, estimateKey, estimateChords, notesToBody, notesToDrums, localDrums, localBass, melodyPhrases, fromTracks, lineBeats };
  root.BandCore = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);
