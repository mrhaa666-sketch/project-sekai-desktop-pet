// 合奏窗口：只暴露合奏需要的接口（密钥不会传到页面）
const { contextBridge, ipcRenderer } = require('electron');
const inv = (ch) => (p) => ipcRenderer.invoke(ch, p);
contextBridge.exposeInMainWorld('bandAPI', {
  roster: () => ipcRenderer.invoke('team-roster'),
  config: inv('band-config'),
  compose: inv('band-compose'),
  revise: inv('band-revise'),
  lyrics: inv('band-lyrics'),
  readImage: inv('band-read-image'),
  singVoice: inv('band-sing-voice'),
  newProject: inv('band-new-project'),
  save: inv('band-save'),
  openFolder: inv('band-open-folder'),
  pick: inv('band-pick'),
  openPart: inv('band-open-part'),
  perform: inv('band-perform'),
  performStop: inv('band-perform-stop'),
  chat: inv('band-chat'),
  say: inv('band-say'),
  skipChat: () => ipcRenderer.send('band-chat-skip'),
  cancel: (id) => ipcRenderer.send('band-cancel', id),
  openGroup: () => ipcRenderer.send('team-open-group'),
  openMemberSettings: (id) => ipcRenderer.send('team-open-member-settings', id),
  onTalk: (cb) => ipcRenderer.on('band-talk', (_e, v) => cb(v)),
  onProgress: (cb) => ipcRenderer.on('band-progress', (_e, v) => cb(v)),
  onRoster: (cb) => ipcRenderer.on('team-roster', (_e, v) => cb(v)),
});
