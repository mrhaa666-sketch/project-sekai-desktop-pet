// 群聊窗口：只暴露群聊需要的接口（密钥不会传到页面）
const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('groupAPI', {
  roster: () => ipcRenderer.invoke('team-roster'),
  say: (text, target) => ipcRenderer.invoke('group-say', { text, target }),
  log: (target) => ipcRenderer.invoke('group-log', target),
  clear: (target) => ipcRenderer.invoke('group-clear', target),
  stop: () => ipcRenderer.send('group-stop'),
  setOnline: (id, v) => ipcRenderer.invoke('team-set-online', { id, v }),
  setAvatarMode: (id, v) => ipcRenderer.invoke('team-set-avatar-mode', { id, v }),
  pickAvatar: (id) => ipcRenderer.invoke('team-pick-avatar', id),
  resetAvatar: (id) => ipcRenderer.invoke('team-reset-avatar', id),
  openMemberSettings: (id) => ipcRenderer.send('team-open-member-settings', id),
  openBand: () => ipcRenderer.send('team-open-band'),
  settingsGet: () => ipcRenderer.invoke('team-settings-get'),
  settingsSave: (v) => ipcRenderer.invoke('team-settings-save', v),
  onLine: (cb) => ipcRenderer.on('group-line', (_e, v) => cb(v)),
  onTyping: (cb) => ipcRenderer.on('group-typing', (_e, v) => cb(v)),
  onError: (cb) => ipcRenderer.on('group-error', (_e, v) => cb(v)),
  onRoster: (cb) => ipcRenderer.on('team-roster', (_e, v) => cb(v)),
  onFocus: (cb) => ipcRenderer.on('group-focus', (_e, v) => cb(v)),
});
