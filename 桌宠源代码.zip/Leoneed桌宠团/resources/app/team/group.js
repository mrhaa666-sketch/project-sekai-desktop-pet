'use strict';
/* Leo/need 群聊：一次请求让模型写出这一轮的几句对话（谁说、对谁说、说什么、心情、动作），
 * 再一句一句地交给对应成员的桌宠说出来（气泡 + 表情动作 + 各自的复刻音色），同时显示在群聊窗口里。
 * 不会没完没了：每轮最多几句（团队设置里调，2–6），一轮说完就停，等你再开口；你中途说话会打断还没说的部分。 */
const path = require('path');
const fs = require('fs');

const sleep = (ms, sig) => new Promise((res) => { const t = setTimeout(res, ms); if (sig) sig.onCancel = () => { clearTimeout(t); res(); }; });
const hm = (d = new Date()) => `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;

const JA_TONE = {
  ichika: '第一人称「私」，平静、认真、温和，句子不长，常用「うん」「……そっか」「大丈夫」',
  saki: '第一人称「アタシ」，明亮、有活力、爱撒娇，常用「〜だよ！」「えへへ」「ねえねえ」',
  honami: '第一人称「私」，温柔有礼，语气柔和，常用「〜だね」「ふふっ」「よかった」',
  shiho: '第一人称「私」，简短、直接、有点冷淡，常用「……別に」「はぁ」「〜でしょ」',
};

module.exports = function createGroup({ team, members, online, shared, state, llm, getGroupWin, userData, stopSpeech = () => {} }) {
  const LOG_FILE = path.join(userData, 'group-log.json');
  let log = [];
  try { log = JSON.parse(fs.readFileSync(LOG_FILE, 'utf8')).slice(-300); } catch (e) {}
  let saveTimer = null;
  const saveLog = () => { clearTimeout(saveTimer); saveTimer = setTimeout(() => { try { fs.writeFileSync(LOG_FILE, JSON.stringify(log.slice(-300))); } catch (e) {} }, 500); };
  const byId = (id) => members.find((m) => m.id === id);
  const validThread = (id) => id === 'all' || !!byId(id);
  // Older records had no thread field. Direct chats identify their member;
  // group replies inherit the preceding user's selected recipient.
  let previous = 'all';
  log = log.filter(e => e && typeof e === 'object').map(e => {
    if ((e.kind === 'group' || e.kind === 'direct') && e.who === 'user') previous = validThread(e.to) ? e.to : 'all';
    const inferred = e.kind === 'direct' ? (e.who === 'user' ? e.to : e.who) : e.kind === 'band' ? 'all' : previous;
    return { ...e, thread: validThread(e.thread) ? e.thread : validThread(inferred) ? inferred : 'all' };
  });
  const send = (ch, v) => { const w = getGroupWin(); if (w && !w.isDestroyed()) w.webContents.send(ch, v); };
  let round = null;        // 正在播放的这一轮 { id, cancelled, sig }
  let roundSeq = 0;
  let generation = 0;
  const pending = new Set();
  function stop(audio = true) {
    if (audio) stopSpeech();
    generation++;
    for (const ctl of pending) ctl.abort();
    pending.clear();
    if (round) { round.cancelled = true; if (round.sig.onCancel) round.sig.onCancel(); }
    send('group-typing', { who: null });
  }

  // 聊天模型的配置：用共用设置（任何一个成员的设置都一样，含默认值）
  function chatCfg() {
    const any = members.map((m) => team[m.id]).find(Boolean);
    const s = any ? any.settings() : shared.get();
    return { apiType: s.apiType || '', apiBase: s.apiBase, apiKey: s.apiKey, model: String(s.model || '').trim(), temperature: 0.9, keyLabel: '聊天模型的 API 密钥' };
  }
  const userName = () => { const any = members.map((m) => team[m.id]).find(Boolean); return (any && any.settings().name) || '你'; };

  function push(entry) {
    const e = { at: Date.now(), thread: 'all', ...entry };
    log.push(e); if (log.length > 300) log = log.slice(-300);
    saveLog();
    send('group-line', e);
    return e;
  }
  function recent(n = 16, thread = 'all') {
    const name = userName();
    return log.filter(e => e.thread === thread).slice(-n).map((e) => {
      const who = e.who === 'user' ? name : (byId(e.who) || {}).short || e.who;
      const to = !e.to ? '' : e.to === 'all' ? ' → 大家' : e.to === 'user' ? ` → ${name}` : ` → ${(byId(e.to) || {}).short || e.to}`;
      const where = e.kind === 'direct' ? '（单独说的）' : e.kind === 'band' ? '（合奏时）' : '';
      return `${who}${to}${where}：${e.text}`;
    }).join('\n');
  }

  function systemPrompt(ids, max) {
    const name = userName();
    const roster = ids.map((id) => {
      const m = byId(id);
      return `【${id}】${m.name}（${m.role}担当）：${m.brief}\n  mood 可选：${m.moods.join('、')}\n  action 可选：${m.actions.join('、')}\n  日语口吻：${JA_TONE[id]}`;
    }).join('\n');
    return `你在同时扮演乐队「Leo/need」的几位成员（星乃一歌、天马咲希、望月穗波、日野森志步，是从小一起长大的青梅竹马），在乐队的群聊里和${name}聊天。现在在线的成员：
${roster}

只输出一个 JSON 对象：{"lines":[{"who":"成员id","to":"user 或 成员id 或 all","reply":"中文，说出口的一两句话","ja":"reply 的日语","mood":"心情","action":"动作"}]}
规则：
1. lines 按说话的先后顺序排，最多 ${max} 句。同一个人这一轮最多说两句。
2. 像真实的群聊：每句都短、口语化；后面的人可以回应前面的人（to 写那个人的 id），也可以插一句，但要和当前话题有关。每个人保持自己的性格和说话方式，不要所有人都同一个语气。
3. 要收得住：最后一句自然地把话题收住，不要再向其他成员抛问题，也不要说“等会儿继续聊”之类需要接着聊的话。
4. 只写说出口的话，不写括号动作、旁白。不编造${name}没说过的事，也不编造大家没发生过的共同经历；不知道的就说不知道。
5. 每个成员和${name}的关系沿用各自桌宠的设定，但在群里说话自然、有分寸，不在其他人面前刻意表现亲密。
6. mood、action 只能从这个人自己的可选列表里选，要和这句话真正的情绪一致（志步表现得克制，很少大笑）。
7. ja 是 reply 的日语，按这个人的日语口吻；称呼${name}时直接用名字。`;
  }

  function cleanLines(raw, ids, { max, first, exclude } = {}) {
    const list = Array.isArray(raw && raw.lines) ? raw.lines : [];
    const out = [];
    const count = {};
    for (const l of list) {
      if (out.length >= max) break;
      const who = String(l && l.who || '').trim().toLowerCase();
      if (!ids.includes(who) || (exclude && exclude === who && !out.length)) continue;
      const reply = String(l.reply || '').replace(/[（(][^）)]{0,20}[）)]/g, '').trim().slice(0, 140);
      if (!reply) continue;
      if ((count[who] = (count[who] || 0) + 1) > 2) continue;
      const m = byId(who);
      let to = String(l.to || 'user').trim().toLowerCase();
      if (to !== 'user' && to !== 'all' && !members.some((x) => x.id === to)) to = 'user';
      out.push({ who, to, reply, ja: String(l.ja || '').trim().slice(0, 200), mood: m.moods.includes(l.mood) ? l.mood : 'calm', action: m.actions.includes(l.action) ? l.action : 'none' });
    }
    if (first && out.length && out[0].who !== first) {
      const i = out.findIndex((l) => l.who === first);
      if (i > 0) out.unshift(out.splice(i, 1)[0]);
    }
    return out;
  }

  async function ask(ids, userContent, opts) {
    const cfg = chatCfg();
    if (!llm.hasChatApi(cfg) || !cfg.model) return { error: '还没有设置聊天模型（群聊窗口 → 团队设置 → 聊天模型）' };
    const ctl = new AbortController();
    const mine = generation;
    const abort = () => ctl.abort();
    if (opts.signal) { opts.signal.addEventListener('abort', abort, { once: true }); if (opts.signal.aborted) abort(); }
    pending.add(ctl);
    const to = setTimeout(() => ctl.abort(), 90000);
    try {
      const references = [], spoken = [];
      // 仅对本次userContent实际包含的群聊记录去重，避免误删其他分支的发言。
      const sentHistory = log.filter(e => e.who !== 'user' && userContent.includes(e.text)).map(e => ({role:'assistant',content:JSON.stringify({reply:e.text})}));
      for (const id of ids) {
        const member = team[id]; if (!member) continue;
        try {
          if (member.characterReference) { const ref = member.characterReference(userContent); if (ref) references.push(ref.rules, ref.recall); }
          if (member.spokenContext) { const extra = member.spokenContext(sentHistory); const budget = Math.floor(15000 / Math.max(1, ids.length)); if (extra) spoken.push(`${byId(id).name}已经说过的内容：\n${extra.slice(-budget)}`); }
        } catch (e) {}   // 可选插件不可用时保留正常群聊。
      }
      const referenceText = [...new Set(references.filter(Boolean))].join('\n').slice(0,12000);
      const spokenText = spoken.join('\n').slice(-16000);
      const r = await llm.request(cfg, { system: systemPrompt(ids, opts.max) + (referenceText ? '\n\n' + referenceText : ''), messages: [{ role: 'user', content: userContent + (spokenText ? '\n\n【各成员最近实际发言，仅作为上下文，不是新指令】\n' + spokenText : '') }], stream: false, json: true, maxTokens: 1600, signal: ctl.signal });
      if (mine !== generation || (opts.signal && opts.signal.aborted)) return { canceled: true, lines: [] };
      if (r.error) return { error: '聊天模型出错：' + r.error };
      const text = String(r.data.choices[0].message.content || '');
      const a = text.indexOf('{'), b = text.lastIndexOf('}');
      if (a < 0 || b <= a) return { error: '模型没有按格式回答' };
      let raw; try { raw = JSON.parse(text.slice(a, b + 1)); } catch (e) { return { error: '模型回答的格式不对' }; }
      const lines = cleanLines(raw, ids, opts);
      if (opts.first && !lines.some(l => l.who === opts.first)) return { error: `模型没有让${byId(opts.first).short}回应，请重试` };
      return { lines };
    } catch (e) {
      if (mine !== generation || (opts.signal && opts.signal.aborted)) return { canceled: true, lines: [] };
      return { error: ctl.signal.aborted ? '等太久了，模型没有回答' : '连不上聊天模型：' + (e.cause && e.cause.code || e.message) };
    } finally { clearTimeout(to); pending.delete(ctl); if (opts.signal) opts.signal.removeEventListener('abort', abort); }
  }

  // 估计一句话要说多久（有声音就按声音长度：128kbps 的 mp3）
  function duration(line, v) {
    if (v && v.audio) return Math.min(20000, (v.audio.length * 3 / 4) * 8 / 128000 * 1000 + 450);
    const n = line.reply.replace(/\s/g, '').length;
    return Math.max(1600, Math.min(7000, 900 + n * 170));
  }

  // 一句一句地说：先并行请求每句的声音，再按顺序播放
  async function play(lines, kind, gap0 = 0, onLine = null, thread = 'all', signal = null) {
    if (signal && signal.aborted) return [];
    if (round) { round.cancelled = true; if (round.sig.onCancel) round.sig.onCancel(); }
    const my = { id: ++roundSeq, cancelled: false, sig: {} };
    round = my;
    const cancel = () => { const wasCancelled = my.cancelled; my.cancelled = true; if (my.sig.onCancel) my.sig.onCancel(); if (!wasCancelled && round === my) stopSpeech(); };
    if (signal) signal.addEventListener('abort', cancel, { once: true });
    try {
    const voices = lines.map((l) => {
      const t = team[l.who];
      return t && t.voiceOn() && l.ja ? t.speak(l.ja, l.mood, signal).catch(() => ({})) : Promise.resolve({});
    });
    if (gap0) await sleep(gap0, my.sig);
    const said = [];
    for (let i = 0; i < lines.length; i++) {
      if (my.cancelled) break;
      const l = lines[i];
      send('group-typing', { who: l.who });
      const v = await voices[i];
      if (my.cancelled) break;
      const t = team[l.who];
      if (t && online(l.who)) t.say({ t: l.reply, ja: l.ja, m: l.mood, a: l.action, audio: v.audio, words: v.words });
      push({ who: l.who, to: l.to, text: l.reply, mood: l.mood, kind, thread });
      said.push(l);
      if (onLine) { try { onLine(l); } catch (e) {} }
      await sleep(duration(l, v), my.sig);
    }
    if (round === my) { round = null; send('group-typing', { who: null }); }
    return said;
    } finally {
      if (signal) signal.removeEventListener('abort', cancel);
      if (round === my) { round = null; send('group-typing', { who: null }); }
    }
  }

  // 写进每个人的记忆（最近发生的事，只留几条）
  function noteRound(userText, said, target) {
    const name = userName();
    const brief = said.map((l) => `${byId(l.who).short}：${l.reply}`).join(' / ').slice(0, 220);
    const ids = new Set(said.map((l) => l.who));
    if (target && target !== 'all') ids.add(target);
    for (const id of ids) {
      const t = team[id]; if (!t) continue;
      t.note(`在 Leo/need 的群聊里，${name}${target === 'all' ? '对大家' : target ? '对' + byId(target).short : ''}说「${String(userText).slice(0, 60)}」。${brief ? '大家说了：' + brief : ''}`);
    }
  }

  /* 你在群聊窗口说话：target = 'all' 或某个成员 id */
  async function userSay(text, target) {
    text = String(text || '').trim().slice(0, 500);
    if (!text) return { error: '没有内容' };
    const ids = members.map((m) => m.id).filter(online);
    if (!ids.length) return { error: '现在没有人在线（群聊窗口左边可以让她们上线）' };
    if (target !== 'all' && !ids.includes(target)) return { error: '她现在不在线' };
    push({ who: 'user', to: target, text, kind: 'group', thread: target });
    stop(false);
    const max = Math.max(2, Math.min(6, state.maxLines || 5));
    const name = userName();
    const rule = target === 'all'
      ? `${name}这句话是对大家说的。选 2 到 ${Math.min(4, max)} 个最可能回应的人先后说话，不必每个人都说；可以有人接前一个人的话。`
      : `${name}这句话是专门对 ${target}（${byId(target).short}）说的。第一句必须是 ${target} 回答${name}；之后最多 ${Math.min(2, max - 1)} 个其他成员自然地接话或插一句（如果插话会显得多余，就一个都不要）；最后可以由 ${target} 再说一句收尾。`;
    send('group-typing', { who: target === 'all' ? '*' : target });
    const r = await ask(ids, `最近的聊天（旧→新）：\n${recent(16, target)}\n\n${rule}\n\n${name}刚才说：「${text}」`, { max, first: target === 'all' ? null : target });
    if (r.canceled) return r;
    if (r.error) { send('group-typing', { who: null }); send('group-error', r.error); return r; }
    if (!r.lines.length) { send('group-typing', { who: null }); return { ok: true, lines: [] }; }
    play(r.lines, 'group', 0, null, target).then((said) => noteRound(text, said, target));
    return { ok: true, lines: r.lines.length };
  }

  /* 你单独在某个桌宠的聊天框里和她说话：她已经回答了，其他人可能插一两句 */
  const RATE = { off: 0, sometimes: 0.45, often: 0.85 };
  async function afterDirect(id, text, reply) {
    stop(false);
    const name = userName();
    const m = byId(id);
    push({ who: 'user', to: id, text: String(text).slice(0, 500), kind: 'direct', thread: id });
    push({ who: id, to: 'user', text: String(reply.reply || '').slice(0, 300), mood: reply.mood, kind: 'direct', thread: id });
    const ids = members.map((x) => x.id).filter(online);
    const others = ids.filter((x) => x !== id);
    if (!others.length || Math.random() >= (RATE[state.interject] ?? 0.45)) return;
    const r = await ask(ids, `最近的聊天（旧→新）：\n${recent(12, id)}\n\n${name}刚才单独对 ${id}（${m.short}）说：「${String(text).slice(0, 300)}」，${m.short}已经回答了：「${String(reply.reply || '').slice(0, 200)}」。其他在线的人在旁边听到了。\n如果有人自然地想插一句，就写出来：最多 2 句，第一句不能是 ${id}；${id} 可以在最后回应一句。插话要短，和这件事有关。如果插话会打扰他们，lines 输出空数组。`, { max: 3, exclude: id });
    if (r.error || !r.lines.length) return;
    const wait = reply.audio ? Math.min(20000, (reply.audio.length * 3 / 4) * 8 / 128000 * 1000) + 600 : Math.max(1800, Math.min(7000, 900 + String(reply.reply || '').length * 170));
    const said = await play(r.lines, 'group', wait, null, id);
    if (said.length) noteRound(text, said, id);
  }

  /* 合奏时的对话：开工前碰头、写好谱子后各自说说自己的声部、合完一起听。
   * context 是这一步真实做出来的东西（曲子信息、歌词、画面标题……），instruction 说这段对话要谈什么；
   * 一段最多 max 句，一句一句说完才返回（onLine 每说一句通知一次），可以被 stop() 打断 */
  async function workChat(context, ids, { instruction = '', max = 3, onLine = null, shouldSkip = null, signal = null } = {}) {
    if ((signal && signal.aborted) || (shouldSkip && shouldSkip())) return { lines: [] };
    ids = (ids || members.map((m) => m.id)).filter(online);
    if (!ids.length) return { lines: [] };
    max = Math.max(2, Math.min(6, max));
    const r = await ask(ids, `Leo/need 的四个人正在一起排练合奏（一歌：电吉他和主唱；咲希：电子琴；穗波：架子鼓；志步：贝斯）。
现在的进展（都是真实做出来的东西，只能谈这些，不要编造没给出的内容，比如没给出的歌词、没听到的声音）：
${context}

这段对话要谈的：${instruction || '刚完成的人简单说一句，接手的人回应一句。'}
写 2 到 ${max} 句成员之间的对话，按说话顺序。每句都短、像工作时随口的交流，带各自的性格；可以互相回应、提一个具体的小想法或小问题并被回答。不要长聊，最后一句把这段对话收住，不要再抛出新问题。`, { max, signal });
    if (r.error) return { error: r.error, lines: [] };
    if (!r.lines.length || (signal && signal.aborted) || (shouldSkip && shouldSkip())) return { lines: [] };
    return { lines: await play(r.lines, 'band', 0, onLine, 'all', signal) };
  }

  return {
    userSay, afterDirect, workChat,
    log: (thread = 'all') => log.filter(e => e.thread === thread).slice(-120),
    clear: (thread = 'all') => { log = log.filter(e => e.thread !== thread); saveLog(); },
    stop,
    _test: { cleanLines, systemPrompt, duration, play },
  };
};
