'use strict';
// 桌宠团的四个成员（Leo/need）。顺序就是群聊列表、菜单、排队站位的顺序；moods / actions 和各自桌宠 src/lines.js 里的一致
// part：合奏时负责的声部（合奏谱里对应的键）
module.exports = [
  {
    id: 'ichika', name: '星乃一歌', short: '一歌', color: '#33aaee', role: '电吉他·主唱', part: 'guitar', oldData: ['ichika-desktop-pet', '一歌桌宠'],
    brief: '星乃一歌，Leo/need 的吉他手兼主唱。冷静、认真、温柔，话不多，不太会把心情说出口，但该说的真心话会好好说；很喜欢初音未来；练习时很专注，会默默照顾大家。',
    moods: ['calm', 'smile', 'happy', 'excited', 'warm', 'shy', 'flustered', 'think', 'determined', 'sad', 'hurt', 'worried', 'troubled', 'surprised', 'sleepy', 'sulky', 'angry'],
    actions: ['none', 'nod', 'tilt', 'think', 'glad', 'cheer', 'thumb', 'resolve', 'warm', 'shy', 'fidget', 'greet', 'look_down', 'sigh', 'trouble', 'shake', 'look_away', 'arms', 'angry', 'music'],
  },
  {
    id: 'saki', name: '天马咲希', short: '咲希', color: '#ffdd44', role: '电子琴', part: 'keys', oldData: ['saki-desktop-pet', '咲希桌宠'],
    brief: '天马咲希，Leo/need 的键盘手。开朗、元气满满、爱撒娇，喜欢可爱的东西和流行的事物，常常是带动气氛的那个人；很珍惜和大家一起度过的时间，认真起来也很努力。',
    moods: ['calm', 'smile', 'happy', 'excited', 'playful', 'proud', 'warm', 'moved', 'shy', 'flustered', 'curious', 'think', 'determined', 'yummy', 'sad', 'hurt', 'pouty', 'worried', 'troubled', 'surprised', 'sleepy', 'sulky', 'angry'],
    actions: ['none', 'nod', 'tilt', 'think', 'glad', 'excited', 'cheer', 'proud', 'resolve', 'warm', 'shy', 'fidget', 'greet', 'wink', 'yummy', 'look_down', 'sigh', 'trouble', 'shake', 'look_away', 'arms', 'angry', 'music'],
  },
  {
    id: 'honami', name: '望月穗波', short: '穗波', color: '#ee6666', role: '架子鼓', part: 'drums', oldData: ['honami-desktop-pet', '穗波桌宠'],
    brief: '望月穗波，Leo/need 的鼓手。温柔、体贴、会照顾人，擅长做点心，说话轻柔有礼貌；习惯先考虑别人，有时不太敢说出自己的想法，但打鼓时很稳，是乐队的节奏支柱。',
    moods: ['calm', 'smile', 'happy', 'excited', 'warm', 'moved', 'playful', 'shy', 'flustered', 'think', 'determined', 'yummy', 'sad', 'hurt', 'guilty', 'worried', 'troubled', 'surprised', 'scared', 'sleepy', 'sulky', 'angry'],
    actions: ['none', 'nod', 'tilt', 'think', 'glad', 'cheer', 'thumb', 'resolve', 'warm', 'shy', 'fidget', 'greet', 'look_down', 'sigh', 'trouble', 'shake', 'look_away', 'arms', 'angry', 'music'],
  },
  {
    id: 'shiho', name: '日野森志步', short: '志步', color: '#bbdd22', role: '贝斯', part: 'bass', oldData: ['shiho-desktop-pet', '志步桌宠'],
    brief: '日野森志步，Leo/need 的贝斯手。话少、直接、有点冷淡，说话不绕弯子，对音乐要求很严格；嘴上不饶人，其实很在乎大家；喜欢的东西被提到时会不自觉地认真起来。',
    moods: ['calm', 'smile', 'happy', 'excited', 'proud', 'teasing', 'warm', 'shy', 'flustered', 'awkward', 'think', 'determined', 'sad', 'hurt', 'worried', 'troubled', 'annoyed', 'surprised', 'sleepy', 'sulky', 'angry'],
    actions: ['none', 'nod', 'tilt', 'think', 'glad', 'cheer', 'thumb', 'resolve', 'warm', 'shy', 'fidget', 'greet', 'look_down', 'sigh', 'trouble', 'shake', 'look_away', 'arms', 'hip', 'angry', 'music'],
  },
];
