'use strict';
/* Leo/need 桌宠团：一个程序里同时运行一歌、咲希、穗波、志步四个桌宠
 *  - 每个成员仍然是原来的桌宠（模型、人设、记忆、换装、各自的乐器窗口都保留），由 shim.js 隔开，互不干扰
 *  - 密钥和模型只填一次：在任意一个成员的设置里改，或者在“团队设置”里改，四个人一起生效
 *  - 乐队群聊：可以对全体说，也可以只对某一个人说；回答一句一句地出来，别人会接话、插话，但每轮有上限
 *  - 一起合奏：按乐队分工，一歌电吉他 + 主唱、咲希电子琴、穗波架子鼓、志步贝斯；
 *    合奏谱可以让大家自己写，也可以把你上传的谱子（MIDI、MusicXML、简谱 / 六线谱文字、谱子图片）拆成四个声部
 *  - 每个成员都可以切换成头像模式（不显示模型，只显示头像） */
const { app, BrowserWindow, ipcMain, Menu, Tray, nativeImage, screen, shell, dialog } = require('electron');
const path = require('path');
const fs = require('fs');

const APP_DIR = path.join(__dirname, '..');
const MEMBERS = require('./members');

app.setName('leoneed-team');
app.setPath('userData', path.join(app.getPath('appData'), 'leoneed-team'));
if (!app.requestSingleInstanceLock()) { app.quit(); process.exit(0); }
const USER_DATA = app.getPath('userData');
fs.mkdirSync(path.join(USER_DATA, 'members'), { recursive: true });

const readJSON = (f, d) => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch (e) { return d; } };
const writeJSON = (f, o) => { try { fs.mkdirSync(path.dirname(f), { recursive: true }); fs.writeFileSync(f + '.tmp', JSON.stringify(o, null, 2)); fs.renameSync(f + '.tmp', f); } catch (e) { console.error('写入失败', f, e.message); } };

/* ---------- 第一次运行：沿用以前单独安装的桌宠的数据（只复制，不动原来的） ---------- */
const MIGRATE = ['settings.json', 'chat-history.json', 'memory.json', 'affection.json', 'proactive.json', 'scores.json', 'spoken-context.jsonl'];
const MIGRATION_FILE = path.join(USER_DATA, 'migration-state.json');
let migratedSupplement = {};
try { migratedSupplement = JSON.parse(fs.readFileSync(MIGRATION_FILE, 'utf8')) || {}; } catch (_) {}
for (const m of MEMBERS) {
  const dst = path.join(USER_DATA, 'members', m.id);
  const initialized = fs.existsSync(path.join(dst, 'settings.json'));
  if (initialized && migratedSupplement[m.id] === 1) continue;
  const src = m.oldData.map((n) => path.join(app.getPath('appData'), n)).find((d) => fs.existsSync(path.join(d, 'settings.json')));
  if (!src) continue;
  fs.mkdirSync(dst, { recursive: true });
  let failed = false;
  const files = initialized ? ['scores.json', 'spoken-context.jsonl'] : MIGRATE;
  for (const f of files) {
    try {
      if (!fs.existsSync(path.join(dst, f)) && fs.existsSync(path.join(src, f))) fs.copyFileSync(path.join(src, f), path.join(dst, f));
    } catch (_) { failed = true; }
  }
  if (!failed) migratedSupplement[m.id] = 1;
  if (!initialized) m.migrated = true;
}
try {
  fs.writeFileSync(MIGRATION_FILE + '.tmp', JSON.stringify(migratedSupplement));
  fs.renameSync(MIGRATION_FILE + '.tmp', MIGRATION_FILE);
} catch (_) {}

/* ---------- 团队状态 ---------- */
const STATE_FILE = path.join(USER_DATA, 'team.json');
const state = Object.assign({ offline: [], placed: false, interject: 'sometimes', groupOpen: true, maxLines: 5 }, readJSON(STATE_FILE, {}));
const saveState = () => writeJSON(STATE_FILE, state);

/* ---------- 共用设置：密钥、模型、称呼 ---------- */
const shared = require('./shared')({ userData: USER_DATA, members: MEMBERS, readJSON, writeJSON });

/* ---------- 加载四个成员 ---------- */
const host = {
  userData: USER_DATA,
  trays: new Map(),
  quitAll: () => { quitting = true; app.quit(); },
  trayChanged: () => scheduleTray(),
  menuItems: (id) => memberMenu(id),
};
let quitting = false;
const shim = require('./shim').install(host);
const team = {};                  // id → 成员主进程导出的 _team 接口
const speech = require('./speech-queue').createSpeechQueue();
const speechOwners = new Set();
ipcMain.handle('team-speech-start', (e, token) => {
  if (!shim.ownerOf(e.sender) || typeof token !== 'string' || token.length > 100) return false;
  const id = e.sender.id;
  if (!speechOwners.has(id)) {
    speechOwners.add(id);
    const clear = () => { speech.drop(id); speechOwners.delete(id); };
    e.sender.once('destroyed', clear);
    e.sender.on('render-process-gone', clear);
    e.sender.on('did-start-navigation', (_ev, _url, inPlace, mainFrame) => { if (mainFrame && !inPlace) speech.drop(id); });
  }
  return speech.acquire(id, token);
});
ipcMain.on('team-speech-end', (e, token) => { if (shim.ownerOf(e.sender)) speech.release(e.sender.id, token); });
function stopSpeech() {
  speech.cancelWaiting();
  for (const t of Object.values(team)) { const w = t.win(); if (w) w.webContents.send('team-speech-stop'); }
}
global.__team = {
  loadingId: null,
  sharedFor: (id, s) => shared.sharedFor(id, s),
  onSave: (id, s) => shared.onSave(id, s, (otherId, changes) => { const t = team[otherId]; if (t) t.applyShared(changes); }),
  afterDirect: (id, text, r) => { if (group) group.afterDirect(id, text, r); },
  appDir: APP_DIR,
};
for (const m of MEMBERS) {
  const dir = path.join(APP_DIR, 'members', m.id);
  shim.add(m.id, dir);
  global.__team.loadingId = m.id;
  try {
    const mod = require(path.join(dir, 'main.js'));
    team[m.id] = mod._team;
  } catch (e) {
    console.error('成员加载失败', m.id, e);
    fs.appendFileSync(path.join(USER_DATA, 'crash.log'), `${new Date().toISOString()} 成员 ${m.id} 加载失败：${e.stack || e}\n`);
  }
}
global.__team.loadingId = null;
const byId = (id) => MEMBERS.find((m) => m.id === id);
const online = (id) => !state.offline.includes(id) && !!team[id];

/* ---------- 头像 ---------- */
const avatarFile = (id, kind) => path.join(USER_DATA, 'members', id, kind === 'custom' ? 'avatar-custom.png' : 'avatar.png');
function avatarInfo(id) {
  const m = byId(id); if (!m) return null;
  const custom = avatarFile(id, 'custom'), cap = avatarFile(id, 'cap'), ship = path.join(__dirname, 'avatars', id + '.png');
  const file = [custom, cap, ship].find((f) => fs.existsSync(f));
  let src = '';
  if (file) { try { src = 'data:image/png;base64,' + fs.readFileSync(file).toString('base64'); } catch (e) {} }
  return { id, name: m.name, short: m.short, color: m.color, src, needCapture: !fs.existsSync(cap), custom: fs.existsSync(custom) };
}
const avatarListeners = new Set();
function avatarChanged(id) {
  const t = team[id]; if (t && t.win()) t.win().webContents.send('team-avatar-changed');
  if (groupWin && !groupWin.isDestroyed()) groupWin.webContents.send('team-roster', roster());
  if (bandWin && !bandWin.isDestroyed()) bandWin.webContents.send('team-roster', roster());
}
ipcMain.handle('team-avatar', (e) => { const id = shim.ownerOf(e.sender); return id ? avatarInfo(id) : null; });
ipcMain.on('team-avatar-save', (e, { png } = {}) => {
  const id = shim.ownerOf(e.sender); if (!id) return;
  const m = /^data:image\/png;base64,([A-Za-z0-9+/=]+)$/.exec(String(png || ''));
  if (!m || m[1].length > 2e6) return;
  try { fs.writeFileSync(avatarFile(id, 'cap'), Buffer.from(m[1], 'base64')); avatarChanged(id); } catch (err) {}
});
async function pickAvatar(id, win) {
  const r = await dialog.showOpenDialog(win || null, { title: `给${byId(id).short}选一张头像`, properties: ['openFile'], filters: [{ name: '图片', extensions: ['png', 'jpg', 'jpeg', 'webp'] }] });
  if (r.canceled || !r.filePaths[0]) return { canceled: true };
  const img = nativeImage.createFromPath(r.filePaths[0]);
  if (img.isEmpty()) return { error: '读不了这张图片' };
  const { width, height } = img.getSize(), side = Math.min(width, height);
  const sq = img.crop({ x: Math.floor((width - side) / 2), y: Math.floor((height - side) / 2), width: side, height: side }).resize({ width: 256, height: 256, quality: 'best' });
  fs.writeFileSync(avatarFile(id, 'custom'), sq.toPNG());
  avatarChanged(id);
  return { ok: true };
}
function resetAvatar(id) { try { fs.rmSync(avatarFile(id, 'custom'), { force: true }); } catch (e) {} avatarChanged(id); return { ok: true }; }

/* ---------- 成员的显示：上线 / 下线 / 头像模式 ---------- */
function setOnline(id, v) {
  const t = team[id]; if (!t) return;
  state.offline = state.offline.filter((x) => x !== id);
  if (!v) state.offline.push(id);
  saveState();
  const w = t.win();
  if (w && !w.isDestroyed()) { if (v) w.showInactive(); else w.hide(); }
  refreshMenus();
}
function setAvatarMode(id, v) { const t = team[id]; if (t) t.setAvatarMode(!!v); refreshMenus(); }
function refreshMenus() {
  scheduleTray();
  if (groupWin && !groupWin.isDestroyed()) groupWin.webContents.send('team-roster', roster());
}
function roster() {
  return MEMBERS.map((m) => ({ ...avatarInfo(m.id), online: online(m.id), avatarMode: !!(team[m.id] && team[m.id].settings().avatarMode), loaded: !!team[m.id], voice: !!(team[m.id] && team[m.id].voiceOn()) }));
}

/* ---------- 菜单：加在每个成员右键菜单最上面，也放进托盘 ---------- */
function memberMenu(id) {
  const t = team[id], m = byId(id);
  const am = !!(t && t.settings().avatarMode);
  return [
    { label: '打开 Leo/need 群聊（四个人一起聊）…', click: () => openGroup(id) },
    { label: '一起合奏…', click: () => openBand() },
    { label: '头像模式（不显示模型，只显示头像）', type: 'checkbox', checked: am, click: (it) => setAvatarMode(id, it.checked) },
    { label: `换${m ? m.short : ''}的头像…`, click: () => pickAvatar(id) },
    { label: `让${m ? m.short : '她'}先下线（隐藏）`, click: () => setOnline(id, false) },
  ];
}
let tray = null, trayTimer = null;
function scheduleTray() { clearTimeout(trayTimer); trayTimer = setTimeout(buildTray, 120); }
function buildTray() {
  if (!tray) return;
  const items = [
    { label: '打开 Leo/need 群聊…', click: () => openGroup() },
    { label: '一起合奏…', click: () => openBand() },
    { label: '团队设置（密钥和模型只填一次）…', click: () => openGroup(null, 'settings') },
    { type: 'separator' },
  ];
  for (const m of MEMBERS) {
    const t = team[m.id];
    if (!t) { items.push({ label: `${m.name}（加载失败）`, enabled: false }); continue; }
    const tr = host.trays.get(m.id);
    items.push({ label: m.name, submenu: [
      { label: '在桌面上', type: 'checkbox', checked: online(m.id), click: (it) => setOnline(m.id, it.checked) },
      { label: '头像模式', type: 'checkbox', checked: !!t.settings().avatarMode, click: (it) => setAvatarMode(m.id, it.checked) },
      { type: 'separator' },
      ...(tr && tr.menu ? [{ label: `${m.short}的完整菜单`, submenu: tr.menu }] : []),
    ] });
  }
  items.push({ type: 'separator' }, { label: '全部显示', click: () => MEMBERS.forEach((m) => setOnline(m.id, true)) }, { label: '四个人排成一排（右下角）', click: () => lineUp(true) },
    { label: '打开数据文件夹', click: () => shell.openPath(USER_DATA) }, { type: 'separator' }, { label: '退出桌宠团', click: () => host.quitAll() });
  tray.setContextMenu(Menu.buildFromTemplate(items));
}

/* ---------- 第一次启动：四个人在屏幕右下角排成一排，不叠在一起 ---------- */
function lineUp(force) {
  if (state.placed && !force) return;
  const wa = screen.getPrimaryDisplay().workArea;
  let right = wa.x + wa.width - 20;
  for (const m of [...MEMBERS].reverse()) {
    const t = team[m.id]; if (!t || !t.win()) continue;
    const [w, h] = t.size();
    const x = Math.round(right - w), y = wa.y + wa.height - h;
    t.moveTo(x, y);
    right = x + Math.round(w * 0.22);   // 稍微叠一点，不占太宽
  }
  state.placed = true; saveState();
}

/* ---------- 群聊 / 合奏 / 团队设置窗口 ---------- */
let groupWin = null, bandWin = null, group = null, band = null;
function uiWindow(file, opts, preload) {
  const w = new BrowserWindow({
    width: opts.width, height: opts.height, minWidth: opts.minWidth || 640, minHeight: opts.minHeight || 480, title: opts.title,
    icon: path.join(__dirname, 'ui', 'icon.png'), autoHideMenuBar: true, backgroundColor: opts.bg || '#171b2a', show: false,
    webPreferences: { preload: path.join(__dirname, preload), contextIsolation: true, nodeIntegration: false, sandbox: true, backgroundThrottling: false },
  });
  w.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  w.webContents.on('will-navigate', (e) => e.preventDefault());
  w.loadFile(path.join(__dirname, 'ui', file));
  w.once('ready-to-show', () => w.show());
  return w;
}
function openGroup(target, tab) {
  if (groupWin && !groupWin.isDestroyed()) { groupWin.show(); groupWin.focus(); if (target || tab) groupWin.webContents.send('group-focus', { target, tab }); return groupWin; }
  groupWin = uiWindow('group.html', { width: 900, height: 680, title: 'Leo/need · 乐队群聊' }, 'preload-group.js');
  groupWin.webContents.once('did-finish-load', () => { if (target || tab) groupWin.webContents.send('group-focus', { target, tab }); });
  groupWin.on('closed', () => { groupWin = null; if (!quitting) { state.groupOpen = false; saveState(); } });
  state.groupOpen = true; saveState();
  return groupWin;
}
function openBand() {
  if (bandWin && !bandWin.isDestroyed()) { bandWin.show(); bandWin.focus(); return bandWin; }
  bandWin = uiWindow('band.html', { width: 1180, height: 860, minWidth: 940, minHeight: 640, title: 'Leo/need · 一起合奏', bg: '#171b2a' }, 'preload-band.js');
  bandWin.on('closed', () => { if (band) band.windowClosed(); bandWin = null; });
  return bandWin;
}
const fromWin = (w, e) => w && !w.isDestroyed() && e.sender === w.webContents;

ipcMain.handle('team-roster', () => roster());
ipcMain.handle('team-set-online', (e, { id, v }) => { if (fromWin(groupWin, e)) setOnline(id, v); return roster(); });
ipcMain.handle('team-set-avatar-mode', (e, { id, v }) => { if (fromWin(groupWin, e)) setAvatarMode(id, v); return roster(); });
ipcMain.handle('team-pick-avatar', (e, id) => (fromWin(groupWin, e) && byId(id) ? pickAvatar(id, groupWin) : { error: 'denied' }));
ipcMain.handle('team-reset-avatar', (e, id) => (fromWin(groupWin, e) && byId(id) ? resetAvatar(id) : { error: 'denied' }));
ipcMain.on('team-open-member-settings', (e, id) => { if ((fromWin(groupWin, e) || fromWin(bandWin, e)) && team[id]) team[id].openSettings(); });
ipcMain.on('team-open-band', (e) => { if (fromWin(groupWin, e)) openBand(); });
ipcMain.on('team-open-group', (e) => { if (fromWin(bandWin, e)) openGroup(); });
ipcMain.handle('team-settings-get', (e) => (fromWin(groupWin, e) ? { ...shared.publicView(team), interject: state.interject, maxLines: state.maxLines, members: MEMBERS.map((m) => ({ id: m.id, name: m.name })) } : { error: 'denied' }));
ipcMain.handle('team-settings-save', (e, v) => {
  if (!fromWin(groupWin, e)) return { error: 'denied' };
  const r = shared.saveFromPanel(v, team);
  state.interject = ['off', 'sometimes', 'often'].includes(v.interject) ? v.interject : state.interject;
  state.maxLines = Math.max(2, Math.min(6, parseInt(v.maxLines, 10) || state.maxLines));
  saveState();
  refreshMenus();
  return r;
});

// 群聊
ipcMain.handle('group-say', (e, { text, target } = {}) => (fromWin(groupWin, e) && group ? group.userSay(text, target === 'all' || byId(target) ? target : 'all') : { error: 'denied' }));
ipcMain.handle('group-log', (e, target) => (fromWin(groupWin, e) && group ? group.log(target === 'all' || byId(target) ? target : 'all') : []));
ipcMain.handle('group-clear', (e, target) => { if (fromWin(groupWin, e) && group) group.clear(target === 'all' || byId(target) ? target : 'all'); return true; });
ipcMain.on('group-stop', (e) => { if (fromWin(groupWin, e) && group) group.stop(); });

/* ---------- 启动 ---------- */
app.whenReady().then(() => {
  const llm = require(path.join(APP_DIR, 'members', 'ichika', 'llm.js'));
  group = require('./group')({ team, members: MEMBERS, online, shared, state, llm, getGroupWin: () => groupWin, userData: USER_DATA, stopSpeech });
  band = require('./band')({ team, members: MEMBERS, online, shared, state, llm, group, getWin: () => bandWin, userData: USER_DATA, appDir: APP_DIR });
  const img = nativeImage.createFromPath(path.join(__dirname, 'ui', 'icon.png')).resize({ width: 16, height: 16 });
  tray = new Tray(img);
  tray.setToolTip('Leo/need 桌宠团');
  tray.on('click', () => openGroup());
  buildTray();
  // 等四个人的窗口都建好，再排位置、处理下线的成员
  let tries = 0;
  const ready = setInterval(() => {
    tries++;
    const all = MEMBERS.every((m) => !team[m.id] || team[m.id].win());
    if (!all && tries < 50) return;
    clearInterval(ready);
    lineUp(false);
    for (const id of state.offline) { const t = team[id]; if (t && t.win()) t.win().hide(); }
    if (state.groupOpen) openGroup();
    scheduleTray();
  }, 200);
});
app.on('second-instance', () => openGroup());
app.on('window-all-closed', () => {});
app.on('before-quit', () => { quitting = true; });

module.exports = { _test: { trays: host.trays, team, MEMBERS, shared, state, openGroup, openBand, group: () => group, band: () => band, roster, setOnline, setAvatarMode, lineUp, avatarInfo, getGroupWin: () => groupWin, getBandWin: () => bandWin } };
